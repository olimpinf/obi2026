--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17 (Ubuntu 14.17-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.17 (Ubuntu 14.17-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE public.school ALTER COLUMN school_id DROP DEFAULT;
ALTER TABLE public.compet ALTER COLUMN compet_id DROP DEFAULT;
ALTER TABLE public.colab ALTER COLUMN colab_id DROP DEFAULT;
DROP SEQUENCE public.school_school_id_seq;
DROP TABLE public.school;
DROP TABLE public.level;
DROP SEQUENCE public.compet_compet_id_seq;
DROP TABLE public.compet;
DROP SEQUENCE public.colab_colab_id_seq;
DROP TABLE public.colab;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: colab; Type: TABLE; Schema: public; Owner: obi
--

CREATE TABLE public.colab (
    colab_id integer NOT NULL,
    colab_name character varying(60) NOT NULL,
    colab_sex character(1),
    colab_school_id integer NOT NULL,
    colab_email character varying(50),
    colab_admin_full character(1) DEFAULT 'N'::bpchar,
    colab_admin character(1) DEFAULT 'N'::bpchar,
    user_id integer
);


ALTER TABLE public.colab OWNER TO obi;

--
-- Name: colab_colab_id_seq; Type: SEQUENCE; Schema: public; Owner: obi
--

CREATE SEQUENCE public.colab_colab_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.colab_colab_id_seq OWNER TO obi;

--
-- Name: colab_colab_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: obi
--

ALTER SEQUENCE public.colab_colab_id_seq OWNED BY public.colab.colab_id;


--
-- Name: compet; Type: TABLE; Schema: public; Owner: obi
--

CREATE TABLE public.compet (
    compet_id integer NOT NULL,
    compet_name character varying(60) NOT NULL,
    compet_type integer,
    compet_birth_year integer,
    compet_birth_month integer,
    compet_birth_day integer,
    compet_sex character(1),
    compet_school_id integer NOT NULL,
    compet_year character varying(50),
    compet_email character varying(50),
    compet_points integer,
    compet_rank integer,
    compet_rank_final integer,
    compet_conf integer,
    course_place character varying(32),
    compet_rank_fase1 integer,
    compet_points_fase1 integer,
    compet_rank_fase2 integer,
    compet_points_fase2 integer,
    compet_points_final integer,
    compet_birth_date date,
    compet_classif_fase1 integer,
    compet_classif_fase2 integer,
    compet_classif_fase3 integer,
    compet_school_id_fase3 integer,
    compet_points_fase3 integer,
    compet_rank_fase3 integer,
    compet_answers_fase1 text,
    compet_answers_fase2 text,
    compet_answers_fase3 text,
    compet_medal character(1),
    user_id integer,
    compet_rank_state integer,
    compet_id_full character varying(16)
);


ALTER TABLE public.compet OWNER TO obi;

--
-- Name: compet_compet_id_seq; Type: SEQUENCE; Schema: public; Owner: obi
--

CREATE SEQUENCE public.compet_compet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compet_compet_id_seq OWNER TO obi;

--
-- Name: compet_compet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: obi
--

ALTER SEQUENCE public.compet_compet_id_seq OWNED BY public.compet.compet_id;


--
-- Name: level; Type: TABLE; Schema: public; Owner: obi
--

CREATE TABLE public.level (
    level_id integer,
    level_short_name character varying(60)
);


ALTER TABLE public.level OWNER TO obi;

--
-- Name: school; Type: TABLE; Schema: public; Owner: obi
--

CREATE TABLE public.school (
    school_id integer NOT NULL,
    school_code integer DEFAULT 0,
    school_name character varying(60) DEFAULT ''::character varying NOT NULL,
    school_address1 character varying(60) DEFAULT ''::character varying NOT NULL,
    school_address2 character varying(60) DEFAULT ''::character varying NOT NULL,
    school_address3 character varying(60) DEFAULT ''::character varying NOT NULL,
    school_zip character varying(10) DEFAULT ''::character varying NOT NULL,
    school_city character varying(40) DEFAULT ''::character varying NOT NULL,
    school_state character(2) DEFAULT ''::bpchar NOT NULL,
    school_ddd character varying(4) DEFAULT ''::character varying NOT NULL,
    school_phone character varying(10) DEFAULT ''::character varying NOT NULL,
    school_deleg_name character varying(60) DEFAULT ''::character varying NOT NULL,
    school_deleg_email character varying(50) DEFAULT ''::character varying NOT NULL,
    school_deleg_ddd character varying(4) DEFAULT ''::character varying NOT NULL,
    school_deleg_phone character varying(10) DEFAULT ''::character varying NOT NULL,
    school_deleg_conf character varying(10) DEFAULT ''::character varying NOT NULL,
    school_deleg_login character varying(20) DEFAULT ''::character varying NOT NULL,
    school_type integer,
    school_deleg_username character varying(70) DEFAULT ''::character varying,
    school_prev integer,
    school_address character varying(200),
    school_address_number character varying(70),
    school_address_complement character varying(70),
    school_address_district character varying(70),
    school_is_known boolean,
    school_is_site_phase3 boolean,
    school_site_phase3_show boolean,
    school_site_phase3 integer DEFAULT 0,
    school_site_phase3_type integer,
    school_site_phase3_prog integer DEFAULT 0,
    school_site_phase3_ini integer DEFAULT 0,
    school_address_building character varying(256),
    school_address_map character varying(256),
    school_has_medal boolean DEFAULT false,
    school_hash character varying(256),
    school_inep_code integer,
    school_ok boolean DEFAULT false,
    school_turn_phase1_prog character(1),
    school_turn_phase1_ini character(1),
    school_address_other character varying(1024),
    school_change_coord boolean
);


ALTER TABLE public.school OWNER TO obi;

--
-- Name: school_school_id_seq; Type: SEQUENCE; Schema: public; Owner: obi
--

CREATE SEQUENCE public.school_school_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.school_school_id_seq OWNER TO obi;

--
-- Name: school_school_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: obi
--

ALTER SEQUENCE public.school_school_id_seq OWNED BY public.school.school_id;


--
-- Name: colab colab_id; Type: DEFAULT; Schema: public; Owner: obi
--

ALTER TABLE ONLY public.colab ALTER COLUMN colab_id SET DEFAULT nextval('public.colab_colab_id_seq'::regclass);


--
-- Name: compet compet_id; Type: DEFAULT; Schema: public; Owner: obi
--

ALTER TABLE ONLY public.compet ALTER COLUMN compet_id SET DEFAULT nextval('public.compet_compet_id_seq'::regclass);


--
-- Name: school school_id; Type: DEFAULT; Schema: public; Owner: obi
--

ALTER TABLE ONLY public.school ALTER COLUMN school_id SET DEFAULT nextval('public.school_school_id_seq'::regclass);


--
-- Data for Name: colab; Type: TABLE DATA; Schema: public; Owner: obi
--

COPY public.colab (colab_id, colab_name, colab_sex, colab_school_id, colab_email, colab_admin_full, colab_admin, user_id) FROM stdin;
21	Alayne Duarte	F	101	\N	N	N	\N
22	Fábio Andre Garcia da Costa	M	101	\N	N	N	\N
23	Ingrid Silva	F	101	\N	N	N	\N
24	Rosana Cristina Colombo	F	241	\N	N	N	\N
25	Carlos Isaías dos Santos Júnior	M	241	\N	N	N	\N
4	Carlos Henrique Cardonha	M	13	\N	N	N	\N
5	Marcel Kenji de Carli Silva	M	13	\N	N	N	\N
6	Juliano Prim	M	361	\N	N	N	\N
7	Rogério Osvaldo Chaparin	M	159	\N	N	N	\N
8	Washington José  S.  Alves	M	159	\N	N	N	\N
9	Juliano Coelho Miranda	M	397	\N	N	N	\N
26	Márcia Silva Madeira	F	7	\N	N	N	\N
27	Juliana Abrantes Freire	F	338	\N	N	N	\N
28	Guilherme Fonseca Alvarenga	M	338	\N	N	N	\N
29	Christiano Cadoná	M	98	\N	N	N	\N
30	Fátima Bernardes	F	98	\N	N	N	\N
31	Fábio Augustus de Almeida	M	99	\N	N	N	\N
32	Cláudia Nalon	F	366	\N	N	N	\N
33	Humberto Schneider	M	73	\N	N	N	\N
34	Marcos Schneider	M	73	\N	N	N	\N
35	Márcia Gomes da Silva	F	143	\N	N	N	\N
36	Isabel Cristina Durante	F	249	\N	N	N	\N
18	Andréa Campos de Oliveira Azevedo	F	265	\N	N	N	\N
16	Arlete Maria Rodrigues	F	265	\N	N	N	\N
12	Daisy Strose Guidini	F	265	\N	N	N	\N
11	Izabel Ferraz C. Pousa	F	265	\N	N	N	\N
37	Maria Vanuza da Silva	F	43	\N	N	N	\N
20	José Rinaldo M. Carvalho	M	265	\N	N	N	\N
13	Patrícia Lucas da Silva	F	265	\N	N	N	\N
14	Regiane Cayuela Lopes	F	265	\N	N	N	\N
17	Regina Faria de Castro Dinamarco	F	265	\N	N	N	\N
38	SILVANA  BARBOZA  CORDEIRO	F	168	\N	N	N	\N
39	SILVIA  BATISTA  DE  MOURA	F	168	\N	N	N	\N
40	ELISABETE  APARECIDA  PRADO  DOS  CAMPOS	F	168	\N	N	N	\N
41	JOANA  CLAUDIA  SCARIN	F	168	\N	N	N	\N
42	Carmen Lúcia Blanco Arias	F	112	\N	N	N	\N
43	Maria Helena F. dos Santos	F	112	\N	N	N	\N
44	Regina Maria da Silveira Cardoso	F	258	\N	N	N	\N
295	Wellington Tadeu Figueiredo	M	540	secretaria@escolamagnus.com.br	N	N	\N
351	Ellen Ximena	F	8		N	N	\N
50	Helba Alexandra Hermini	F	393	\N	N	N	\N
90	Denilson Figueiredo de Sá	M	274	denilsonsa@gmail.com	N	N	\N
51	Fabrício Manoel de Jesus	M	22	\N	N	N	\N
52	Frederico Ozanan Caixeta Junior	M	19	\N	N	N	\N
352	Sara Lopes Alves Gama	F	8		N	N	\N
353	Paulo Victor Maia	M	8		N	N	\N
55	Venuza Martins Barros	F	151	\N	N	N	\N
56	André Luís Rodrigues dos Santos 	M	151	\N	N	N	\N
57	Anderson Carneiro dos Santos 	M	151	\N	N	N	\N
58	Cristiano Natal Toneis	M	328	\N	N	N	\N
59	Mara Regina Vieira Fontana	F	218	\N	N	N	\N
60	Clarice Pölking	F	218	\N	N	N	\N
314	Willian dos Santos Lima	M	296	willian.lima@gmail.com	N	N	\N
62	Kilian Kratz da Silva	F	218	\N	N	N	\N
316	Sandra Abib	F	557	sabib@dc.ufscar.br	N	N	\N
64	Jorge Albino Kleber	M	218	\N	N	N	\N
65	Márcio Vinícius Oliveira da Silva	M	218	\N	N	N	\N
66	Leonardo Teixeira	M	218	\N	N	N	\N
68	Francisco Assis da Silva	M	282	\N	N	N	\N
69	Marcelo Vinícius Creres Rosa	M	282	\N	N	N	\N
70	Leandro Luiz de Almeida	M	282	\N	N	N	\N
71	Sandra Rodrigues de Lima Torres	F	380	\N	N	N	\N
72	Telma Bernardo Stallbaum	F	380	\N	N	N	\N
73	Dóris Reis Lucas Vieira	F	380	\N	N	N	\N
74	Sonia Maria Martini Bonatelli	F	380	\N	N	N	\N
75	Sonia Regina Facco	F	380	\N	N	N	\N
76	Ana Maria Cavallaro Cruz	F	330	\N	N	N	\N
77	Claudinei Noronha	M	330	\N	N	N	\N
78	Dima Giardini Noronha	F	330	\N	N	N	\N
79	Dilma Giardini Noronha	F	330	\N	N	N	\N
80	DOUGLAS FERREIRA TOMÉ	M	171	\N	N	N	\N
81	CARLOS EDUARDO BARBOSA DA SILVA	M	171	\N	N	N	\N
82	MARCIA FERNANDES NUNES DE ALMEIDA	F	125	\N	N	N	\N
83	MONICA DA CUNHA BARBATO	F	125	\N	N	N	\N
84	Cristina Margareth Weiss Ferreira	F	122	\N	N	N	\N
85	Cesar Augusto Cusin	M	122	\N	N	N	\N
94	Luciana Faria	F	140	\N	N	N	\N
87	Ana Gilda Dell Anhol Colturato	F	122	\N	N	N	\N
88	Heron Conrado do Carmo Ferreira	M	122	\N	N	N	\N
247	Gabriela Zimberg	F	153	\N	N	N	\N
93	Cristiane Attili Castela	F	293	\N	N	N	\N
95	Maria de Fátima de Freitas Bueno	F	140	\N	N	N	\N
96	Ivan Medeiros Monteiro	M	269	\N	N	N	\N
97	Rafael Gomes Tenório	M	140	\N	N	N	\N
101	Maria Teresa Vilela Puia	F	225	\N	N	N	\N
100	Edans Flávius de Oliveira Sandes	M	366	\N	N	N	\N
252	Erick Pereira de Oliveira	M	14	\N	N	N	\N
212	Carlos Cleiton Cordeiro Pinto	M	196	\N	N	N	\N
104	Robson Alves da Silva	F	28	\N	N	N	\N
105	VALDIR VASCONCELOS SAMPAIO	M	244	\N	N	N	\N
106	ANTONIO FRANCISCO DE CARVALHO	M	244	\N	N	N	\N
266	Glauce Aparecida de Carvalho Leite	F	504		N	N	\N
108	Marta Lessia Barbosa Soares	F	39	\N	N	N	\N
260	Rosely Cardoso Montagnini	F	8	\N	N	N	\N
257	Carlos Henrique Cardonha	M	13	\N	N	N	\N
250	Thais Vicensotto Bruno Narciso	F	225	thais_vbn@yahoo.com.br	N	N	\N
48	 André Luiz Dalastti	M	23	aldalas@feb.unesp.br	N	N	\N
113	Carlos Roberto	M	387	\N	N	N	\N
114	Luiz Arnaldo de Lima	M	387	\N	N	N	\N
115	Cristiane Maria Sato 	F	13	\N	N	N	\N
116	Fabrício Siqueira Benevides 	M	13	\N	N	N	\N
117	Pedro Ferreira Melo Júnior 	M	13	\N	N	N	\N
118	Rafael Portolan	M	115	\N	N	N	\N
119	Patricia Alessandra Xavier Gugel	F	115	\N	N	N	\N
91	Vinicius Fernandes dos Santos	M	274	vinicius.santos@gmail.com	N	N	\N
121	Luiz Fernando Bessa Seibel	M	338	\N	N	N	\N
122	ADRIANO CARVALHO FELIPE	M	236	\N	N	N	\N
123	ACÁCIO LIMA DE FREITAS	M	236	\N	N	N	\N
124	MARLY VITÓRIA DE FREITAS	F	236	\N	N	N	\N
125	Dilma Ricardo Freitas	F	35	\N	N	N	\N
126	MARIA LUISA RODRIGUES DOS SANTOS CORSI	F	175	\N	N	N	\N
127	ROSANGELA COBO	F	175	\N	N	N	\N
128	EDNA FATIMA ROMBALDI PEREIRA	F	175	\N	N	N	\N
129	MARIA IVETE PAIS TINETTE	F	175	\N	N	N	\N
130	ANTONIO APARECIDO	M	175	\N	N	N	\N
131	LUZIA APARECIDA FRANCISCO	F	175	\N	N	N	\N
132	Fernando Lavestein	M	222	\N	N	N	\N
136	João Paulo Mota	M	5	\N	N	N	\N
134	CARLOS DAMIÃO DOS SANTOS	M	203	\N	N	N	\N
216	MAIER TAVARES DIAS	M	117	\N	N	N	\N
355	SOCORRO KATIUSSIA SOUSA DOS REIS	F	467	katiussiace@hotmail.com	N	N	\N
356	DANIELI DELAMONICA VIANA GURGEL	F	467	danieliviana@yahoo.com.br	N	N	\N
357	ALBANISA CARVALHO GOMES	F	467	albanisacarvalho@hotmail.com	N	N	\N
358	JOSEBES LOPES	M	467	jolosa1@hotmail.com	N	N	\N
363	Meire Falque de Oliveira	F	189	colegio.peq@terra.com.br	N	N	\N
387	ANDRÉA GRESPAN FARIA DE SORDI	F	588	andgfar@bol.com.br	N	N	\N
364	Marcelo Tcacenco	M	189	colegio.peq@terra.com.br	N	N	\N
371	BENEDITO MARINHO DA SILVA	M	244	uipedroneiva@bol.com.br	N	N	\N
372	FRANCISCA FELIPE FELIX	F	244	uipedroneiva@bol.com.br	N	N	\N
147	Cristiano Francisco  Alves	M	5	\N	N	N	\N
370	MARIA DE LOURDES PEREIRA SOUSA	F	244	uipedroneiva@bol.com.br	N	N	\N
373	PAULO CHAVES CASTRO	M	244	uipedroneiva@bol.com.br	N	N	\N
150	Rúbia Maria Caramanico	F	8	\N	N	N	\N
225	Luciano Gomes Carneiro	M	157	\N	N	N	\N
92	LEANDRO DE ANDRADE FERREIRA Y FERREIRA	M	407	\N	N	N	\N
230	Ronaldo Bianchin	M	142	\N	N	N	\N
154	Caio Henrique Porto Cestari	M	8	\N	N	N	\N
155	Cássio Giovani Martins Trindade	M	8	\N	N	N	\N
228	GILCELÉIA CHAVES CASTRO	F	244	\N	N	N	\N
157	Christianne Fernandes	F	292	\N	N	N	\N
158	Renata Fernandes Penhavel	F	292	\N	N	N	\N
159	Maria Hilda de Andrade	F	293	\N	N	N	\N
160	Ronaldo Gil Pisaneski	M	293	\N	N	N	\N
161	Thitaka SugimotoYamada	F	293	\N	N	N	\N
162	Cleuton Conceição Vieira	M	293	\N	N	N	\N
163	Joaquim de Oliveira Jr.	M	293	\N	N	N	\N
164	Fernando Separovic	M	293	\N	N	N	\N
165	Renata Denadai Pengo	F	285	\N	N	N	\N
166	Sirlei Inês Sulzbach	F	239	\N	N	N	\N
170	Sergio Brauna da Silva	M	409	\N	N	N	\N
171	Lauro Lockmann	M	239	\N	N	N	\N
258	Aluno Teste	M	55	\N	N	N	\N
173	Helder Rezende Amaral	M	313	\N	N	N	\N
174	Sandra Cristina Puntel	F	313	\N	N	N	\N
175	Tiago Antônio	M	313	\N	N	N	\N
176	Nayara de Paula Silva	F	313	\N	N	N	\N
177	Reginaldo Faria da Silva	M	313	\N	N	N	\N
178	Lucas Ximenes Boa Sorte	M	313	\N	N	N	\N
179	Guilherme de Assis Ribeiro	M	313	\N	N	N	\N
180	Natália Cristina Barreto	F	313	\N	N	N	\N
181	Luana Mendes Gomes de Souza	F	313	\N	N	N	\N
182	Guilherme Precetti Neto	M	312	\N	N	N	\N
183	Mariana dos Santos Dias	F	312	\N	N	N	\N
184	Lilian Cristina de Souza	F	312	\N	N	N	\N
185	Priscila Micheli Pereira	F	312	\N	N	N	\N
186	Paulo Cesar dos Santos	M	312	\N	N	N	\N
187	Thaise Ferreira	F	312	\N	N	N	\N
188	ADRIANA CHAGAS DE ARAÚJO	F	179	\N	N	N	\N
189	Sidnei Bazílio Freire	M	215	\N	N	N	\N
190	César Ferreira Garcia	M	215	\N	N	N	\N
232	Daniel Birck	M	34	danielbirck@gmail.com	N	N	\N
192	Helen Aparecida de Oliveira	F	215	\N	N	N	\N
193	Luciene Regina S. Cruz	F	215	\N	N	N	\N
194	Diógenes da Silva Jr.	M	382	\N	N	N	\N
195	Luiz Henrique Massa Pilz	M	382	\N	N	N	\N
196	César Adriano do Amaral Sampaio	M	382	\N	N	N	\N
197	Irmã Maria Camila Marques	F	279	\N	N	N	\N
198	Irmã Maria da Conceição Paixão de Rezende	F	279	\N	N	N	\N
261	Thaíse Ferreira	F	312	\N	N	N	\N
103	Rosana Régia Araújo Gomes	F	225	\N	N	N	\N
205	Daniel Robson de Abreu Almeida	M	331	\N	N	N	\N
217	FLAVIO C. FARIAS DA CRUZ	M	117	\N	N	N	\N
201	CASSIO HENRIQUE ZOCCARATTO GUERRA	M	175	\N	N	N	\N
202	REBECA HELOISA MARQUES SEULIN	F	175	\N	N	N	\N
206	Gustavo Pappetti	M	331	\N	N	N	\N
204	LUIS EDUARDO MARTINS DE OLIVEIRA	M	175	\N	N	N	\N
207	Michelli Lima dos Santos	F	331	\N	N	N	\N
208	Naligia Festa	F	393	\N	N	N	\N
209	Assis Aparecido Piffer	M	393	\N	N	N	\N
210	José Eduardo Carvalho Monte	M	379	\N	N	N	\N
211	Ronaldo Silva Trindade	M	379	\N	N	N	\N
213	Andrea Moreira Pires	F	196	\N	N	N	\N
214	Sirlane Zebral Oliveira	F	279	\N	N	N	\N
215	SANDRA ALVES	F	109	\N	N	N	\N
200	Rosana Claudia Rodrigues	F	374	\N	N	N	\N
218	Natan de Almeida Laverde	M	132	\N	N	N	\N
219	Francisco Cadorno Vasconcelos Teles	M	334	\N	N	N	\N
220	José Cláudio Farias	M	334	\N	N	N	\N
221	IVAN FERNANDES	M	125	\N	N	N	\N
222	Josué Geraldo Botura do Carmo	M	345	\N	N	N	\N
267	Sonia Regina Packness Succar	F	504		N	N	\N
224	Núbia Cordeiro Pinto	F	196	\N	N	N	\N
293	ADRIANO MAICON DE SOUZA	M	560	ADRIANO.MAICON@UOL.COM.BR	N	N	\N
234	Clóvis da Silveira	M	512	\N	N	N	\N
235	CARINA MARIA CANCIAN	F	48	\N	N	N	\N
236	Sthephani Campos Ferreira	F	14	\N	N	N	\N
309	Ana Maria Benvindo de Carvalho dos Santos	F	491	anamaria@pirangi.com.br	N	N	\N
238	Alexandre Bartoli Monteiro	M	416	\N	N	N	\N
397	Gisele Mendes Damo	F	588	colegio@salesianoitajai.g12.br	N	N	\N
240	LUCIMAR APARECIDA MASCARIN	F	48	\N	N	N	\N
241	MARIA CRISTINA LIBERALI 	F	48	\N	N	N	\N
242	MARIA ANGELICA DE SOUZA	F	48	\N	N	N	\N
243	ELAINE APARECIDA AMALFI	F	48	\N	N	N	\N
244	SUELI RAIMUNDO GONÇALVES	F	48	\N	N	N	\N
246	Samuel Michel Garcia	M	518	\N	N	N	\N
248	Maurício Herculano de Oliveira Filho	M	196	\N	N	N	\N
249	FABIANA DE OLIVEIRA MENDES	F	373	\N	N	N	\N
251	Renato Bezerra Herebia	M	14	\N	N	N	\N
253	Ana Larissa Bezerra de Lima	F	350	\N	N	N	\N
256	Marco Aurélio de Patrício Ribeiro	M	526	\N	N	N	\N
259	Marcos Antônio dos Santos	M	491	\N	N	N	\N
199	Prof.(a) MARLI APARECIDA GRUPP SANTOS	F	355	\N	N	N	\N
231	Vitor Failace De Mario	M	274	vitordemario@gmail.com	N	N	\N
172	Prof.(a) ELZA SANTOS OLIVEIRA	F	355	\N	N	N	\N
254	Prof(a). LUCIANE MÜZEL DE ALMEIDA	F	355	\N	N	N	\N
262	Prof(a). LAURITA CAMARGO DE LIMA	F	355	\N	N	N	\N
264	Mateus Ferreira Duarte	M	504		N	N	\N
333	JORGE LUÍS TAKAHASHI HATTORI	M	5	jorge_hattori@yahoo.com.br	N	N	\N
269	Ana Amélia R. Silva	F	504		N	N	\N
270	Eva Elena das Dores Cruz	F	504		N	N	\N
271	Maria Angela Moino Guerra	F	504		N	N	\N
272	Rosemere de F. T. da Rosa	F	504		N	N	\N
334	WILTON DE PAULA FILHO	M	5		N	N	\N
274	Kelly Cristina Teodoro P. de Souza	F	504		N	N	\N
335	WINICIUS PEREIRA	M	5		N	N	\N
276	Rui Cardoso de Almeida	M	112	ruicardoso@msn.com	N	N	\N
277	Rogério de Moura Souza	M	112	rogeriodemoura@yahoo.com.br	N	N	\N
278	Manoel da Conceição Pontes Távora	M	112	tavora@fvt.com.br	N	N	\N
279	Carmen Lúcia Blanco Arias	F	112	carmen@fvt.com.br	N	N	\N
280	Claudia R. S. Sousa	F	504		N	N	\N
281	Janice Cleide Cunha	F	504		N	N	\N
282	Mirlei Aparecida Garcia de Oliveira	F	504		N	N	\N
283	Marcia Aparecida Silva Ribeiro	F	504		N	N	\N
233	Einstein do Nascimento Júnior	M	45	einsteinnjr@yahoo.com.br	N	N	\N
294	LEANDRO RODRIGO MARIOTTO	M	560	LR_MARIOTTO@HOTMAIL.COM	N	N	\N
285	Frederico Czar Filho	M	541	profczar@bol.com.br	N	N	\N
286	CARLA LOPES RODRIGUEZ	F	309	informatica@coopel.com.br	N	N	\N
287	Paulo Drager	M	462	pdrager@terra.com.br	N	N	\N
288	Rosângela Aparecida Batista Gattass	F	462	colcic@terra.com.br	N	N	\N
289	Andréa Lemes Lustig	F	462	lustig@terra.com.br	N	N	\N
290	Luciany da Silva Muniz Drager	F	462	luciany.cic@terra.com.br	N	N	\N
284	Rodrigo Ferreira de Carvalho	M	23	flash@feb.unesp.br	N	N	\N
317	Maria Auxiliadora F. V. G. de Oliveira	F	504		N	N	\N
292	Wladimir Araújo Tavares	M	555	wladimirufc@gmail.com	N	N	\N
296	Prof.(a) EUNICE APARECIDA DE PAULA	F	355		N	N	\N
255	Prof.   MÁRCIO ANTUNES DE LIMA	M	355	profmarcio.l@ig.com.br	N	N	\N
297	Sirlei Inês Sulzbach	M	239	sirlei@inf.ufrgs.br	N	N	\N
298	Aleardo Manacero Jr.	M	296	aleardo@ibilce.unesp.br	N	N	\N
299	Calebe de Paula Bianchini	M	4	calebe@anhembi.br	N	N	\N
120	Wilson Massashiro Yonezawa	M	372	yonezawa@fc.unesp.br	N	N	\N
300	Diego Gonçalves de Macedo	M	318	dihood@ig.com.br	N	N	\N
301	Maria Regina Santos M. Moreira	F	318	mreginamoreira@uol.com.br	N	N	\N
302	Lygia Macedo Loureiro de Abreu e Silva	F	318	leeloureiro@uol.com.br	N	N	\N
303	Maria Inês Pallamin	F	318	ines@monteirolobato-sjc.com.br	N	N	\N
304	Teresa Cristina Meyer	F	318	teresacristina@monteirolobato-sjc.com.br	N	N	\N
305	Flavio Renato Sambursky	M	303	f.r.s@uol.com.br	N	N	\N
306	Jose Claudio Treiger	M	303	drq@domain.com.br	N	N	\N
307	Debora Theodoro Amancio da Silva	F	274	deboratads@gmail.com	N	N	\N
308	Rodrigo Willemann	M	110	rodrigow@senai-sc.ind.br	N	N	\N
310	Glória Sulema Rapp de Melo Silva	F	462	yoyi_rapp_@hotmail.com	N	N	\N
239	Gabriela Anselmo Raymundo	F	497	profgabi@gmail.com	N	N	\N
313	Rudy Jordach Fernandes	M	283	rudyjor@yahoo.com	N	N	\N
315	Prof.(a)   Gisele	F	355		N	N	\N
322	Ana Patrícia Vieira Sacchi	F	568	patisacchi@hotmail.com	N	N	\N
319	Adriana Cristina J. M. B. Pinheiro	F	504		N	N	\N
320	Otávio Tonhá da Costa 	M	5	otavio@uniaraxa.edu.br	N	N	\N
321	Hélder Suzuki	M	78		N	N	\N
323	Francisco Carlos Antunes Bittencourt	M	504		N	N	\N
336	MARCIA HELENA DO PRADO RIVAS	F	5		N	N	\N
325	Jakeline Kelli Justino	F	504		N	N	\N
326	Leandro Figueiredo Pereira	M	504		N	N	\N
327	Patricia Caroline dos Santos	F	504		N	N	\N
328	Patricia Zilda Carvalho	F	504		N	N	\N
329	Rogeria Guedes Baptista Borges Ribeiro	F	504		N	N	\N
330	Viviane Aparecida Moreira	F	504		N	N	\N
324	Ivan Oliveira Damasceno	M	504		N	N	\N
331	Angelica Aparecida de Almeida	F	504		N	N	\N
332	MARCOS ALEXANDRE GENEROSO ROSA	M	5	marcosalex77@yahoo.com.br	N	N	\N
337	MARQUES DE MELO FILHO	M	5		N	N	\N
46	João Paulo Shiharu Toma	M	23	jp.toma@feb.unesp.br	N	N	\N
342	Davi Amorim Pinheiro	M	19	davinheiro@gmail.com	N	N	\N
343	Lucas Santos Caixeta	M	19	manotukano@hotmail.com	N	N	\N
344	Angelo Albiere Neto	M	19	albiere_bass@hotmail.com	N	N	\N
345	Silvio Cesar Viegas	M	479	scviegas@brturbo.com.br	N	N	\N
346	KÉDIMA BOONE RODRIGUES	F	533	kbmedeiros@marista.edu.br	N	N	\N
359	CESAR AUGUSTO CUSIN	M	122	cesarcusin@ig.com.br	N	N	\N
347	Thiago Rozineli	M	461	trozineli@uol.com.br	N	N	\N
360	VERA APARECIDA DE OLIVEIRA	F	122	verinha_oliveira@ig.com.br	N	N	\N
361	CRISTINA MARGARETH WEISS FERREIRA	F	122	cmwf@ig.com.br	N	N	\N
365	Narcelio Luiz de Souza	M	480	narcelioluiz@yahoo.com.br	N	N	\N
366	Cledimar Verissimo da Costa	F	480	cleidtibau@hotmai.com	N	N	\N
374	ENOQUE GOMES DA SILVA	M	244	uipedroneiva@bol.com.br	N	N	\N
376	Tarcio Cordeiro Ramos	M	548		N	N	\N
378	Vanessa Ianaconi	F	78		N	N	\N
379	Gisele Mendes Damo	F	7	colegio@salesianoitajai.g12.br	N	N	\N
401	Francisco Odivaldo Teixeira Júnior	M	516	teixeirajr@gmail.com	N	N	\N
389	MARIA CRISTINA LIBERALI DE ANDRADE	F	588	parabandeira@ig.com.br	N	N	\N
391	AILTON DE OLIVEIRA	M	588	ailtonprof@bol.com.br	N	N	\N
338	Maria Evani de Oliveira Assis Patrício	F	117	epatricio@fnet.org.br	N	N	\N
339	Sirlei Inês Sulzbach	M	239	sirlei@inf.ufrgs.br	N	N	\N
340	Jailson Torquato	M	83	jailson@satc.edu.br	N	N	\N
341	Sergio Coral	M	83	sergio@satc.edu.br	N	N	\N
348	Juliana Pimentel Silva	F	285	julianajups@ig.com.br	N	N	\N
349	Mariana Teresinha Rother Bertotti	F	285		N	N	\N
350	Helen Tessari Brandão	F	574	helen@saojosecuritiba.com.br	N	N	\N
354	Paulo André Bezerra de Melo	M	207	paulo-andre.melo@sanofi-aventis.com	N	N	\N
362	Maria Luiza Carlette Jungers	F	189	colegio.peq@terra.com.br	N	N	\N
375	Luciana Grasiela Darcie	F	48	grasielad@bol.com.br	N	N	\N
245	ANDREA GRESPAN FARIA DE SORDI	F	48	andgfar@bol.com.br	N	N	\N
377	Evandir Pereira da Silva Júnior	M	539	evandirpereira@hotmail.com	N	N	\N
367	IRACILDA SANTOS COSTA	F	244	uipedroneiva@bol.com.br	N	N	\N
369	MANOEL SOUSA MOURA	M	244	uipedroneiva@bol.com.br	N	N	\N
368	MARIA DO SOCORRO CHAVES CASTRO	F	244	uipedroneiva@bol.com.br	N	N	\N
398	Andréa Carla Gonçalves Vianna	F	588	vianna@fc.unesp.br	N	N	\N
402	SERGIO BARBOSA	M	588	sergio@colegiokoelle.com.br	N	N	\N
393	Evandro Augusto Marucci	M	588	marucci@gmail.com	N	N	\N
394	Luigi Jacometti Oliveira	M	588	luigijo@gmail.com	N	N	\N
400	Wilson Massashiro Yonezawa	M	588	yonezawa@fc.unesp.br	N	N	\N
396	José Eduardo Carvalho Monte	M	588	zd1@cefetop.edu.br	N	N	\N
403	MARIA LUIZA ALTARUGIO BARBANERA	F	588	luizabarbanera@claretianas.com.br	N	N	\N
\.


--
-- Data for Name: compet; Type: TABLE DATA; Schema: public; Owner: obi
--

COPY public.compet (compet_id, compet_name, compet_type, compet_birth_year, compet_birth_month, compet_birth_day, compet_sex, compet_school_id, compet_year, compet_email, compet_points, compet_rank, compet_rank_final, compet_conf, course_place, compet_rank_fase1, compet_points_fase1, compet_rank_fase2, compet_points_fase2, compet_points_final, compet_birth_date, compet_classif_fase1, compet_classif_fase2, compet_classif_fase3, compet_school_id_fase3, compet_points_fase3, compet_rank_fase3, compet_answers_fase1, compet_answers_fase2, compet_answers_fase3, compet_medal, user_id, compet_rank_state, compet_id_full) FROM stdin;
13890	Leticia Mota e Mota	1	1994	4	27	F	527	6ª Série 2 - PA	\N	\N	\N	92	\N	\N	1	11	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15201	Caio Henriques Santilli	1	1995	9	4	M	144	5ª Série	\N	\N	\N	92	\N	\N	1	11	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13956	Raissa Lima Bertasi	1	1993	11	3	F	544	6a série	\N	\N	\N	164	\N	\N	1	11	0	4	66	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15970	Ivany	2	1991	7	7	F	78	8EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10336	Edmar Victor Daniel	2	1992	5	4	M	473	8ª C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12647	ÍCARO DA SILVA SIQUEIRA	4	1989	2	27	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13285	Leonardo Antonio G. Baptista	4	1988	4	21	M	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	65	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11490	Victor Marinho Furtado	4	1987	10	11	M	274	Primeiro período	\N	\N	\N	42	\N	\N	\N	70	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11898	Paulo Victor Araújo	4	1988	7	11	M	282	1º Termo / BCC	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13986	Felipe Monte de Andrade	4	1990	11	1	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	70	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12987	BRENO ROBERTO MEIRA	4	1989	10	23	M	23	2A	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14409	Jefferson Quesado Neto	4	1989	3	23	M	555	3	\N	\N	\N	42	\N	\N	1	145	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14170	Samuel Yuri Deschamps	4	1986	10	28	M	564	1º Semestre do Ensino Superior	\N	\N	\N	42	\N	\N	1	65	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12651	ISMAEL AZEVEDO DE CASTRO FILHO	4	1990	4	5	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	60	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14406	Felix Tadashi Hatta Regal	4	1990	9	27	M	555	2	\N	\N	\N	42	\N	\N	1	265	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12900	Geison João Euzébio	4	1989	3	4	M	83	3ª Fase do Ensino Técnico	\N	\N	\N	42	\N	\N	1	100	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11895	Danilo Gea de Almeida	4	1988	7	2	M	282	1º Termo / BCC	\N	\N	\N	42	\N	\N	\N	65	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11897	Renato Garcia de Campos	4	1988	4	29	M	282	1º Termo / BCC	\N	\N	\N	42	\N	\N	\N	70	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13125	THIAGO ANTONIO VILLA MENEZES	4	1989	11	1	M	309	2ª	\N	\N	\N	42	\N	\N	1	160	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11715	MARCELO AUGUSTO DE LIMA BRASIL	4	1987	1	16	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14376	Fernando Wieliczko	4	1990	3	18	M	545	2o EM	\N	\N	\N	42	\N	\N	1	145	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11719	ERIVAN SOUZA DA SILVA FILHO	4	1988	10	8	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	65	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14499	Caio César Viel	4	1988	5	10	M	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	1	80	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11710	RUAN DIEGO DE OLIVEIRA CARVALHO	4	1989	2	3	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12936	Marcos Vinicius Batista dos Santos	4	1989	2	11	M	90	3 ano	\N	\N	\N	42	\N	\N	1	85	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12324	MIKAIL C. FREITAS	4	1990	6	27	M	487	2ª EM	\N	\N	\N	42	\N	\N	\N	65	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2957	ROMULO MARQUES GATTO	1	1995	2	20	M	57	6ª SÉRIE A	\N	\N	\N	92	\N	\N	1	13	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14864	CAIO BARBOSA AMORIM 	4	1988	6	26	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	\N	70	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13144	Rafael Moraes Frota	4	1988	5	12	M	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	1	95	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12989	VICTOR CÉSAR DE CARVALHO	4	1990	10	9	M	23	2A	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14065	Renato Ferreira Lima e Correa Pereira	4	1988	7	18	M	543	3a do médio	\N	\N	\N	42	\N	\N	\N	55	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12386	FELIPE RIBEIRO SARUHASHI	4	1987	7	17	M	23	3C	\N	\N	\N	42	\N	\N	\N	65	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11696	BRUNO SEABRA CARNEIRO	4	1987	5	27	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	1	185	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14077	Samuel Eidi Yagi	4	1986	10	31	M	372	1o - BCC	\N	\N	\N	42	\N	\N	1	105	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12325	MARCELO GALVÃO PÓVOA	4	1990	2	16	M	487	2ª EM	\N	\N	\N	42	\N	\N	1	100	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10904	João Sérgio da Silva Costa	4	1988	1	12	M	416	1pSI	\N	\N	\N	42	\N	\N	\N	50	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10256	Ewerton Martins de Menezes	4	1989	1	1	M	96	1o semestre	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13510	Danilo Placer de Moraes	4	1990	3	9	M	283	3o Semestre de 7	\N	\N	\N	42	\N	\N	1	110	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13977	Cassia do Carmo Vieira	4	1988	5	23	F	543	3a do médio 	\N	\N	\N	42	\N	\N	\N	60	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13128	Carlos Eduardo Betineli	4	1988	1	17	M	557	Prim. Sem. em Eng. da Computação	\N	\N	\N	42	\N	\N	1	100	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12997	HUGO OLIVEIRA CAMPOS	4	1990	2	6	M	23	2B	\N	\N	\N	42	\N	\N	\N	60	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14076	Gustavo Siqueira Bordon	4	1985	11	8	M	372	1o - BCC	\N	\N	\N	42	\N	\N	\N	40	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10811	Carlos Ferro	4	1987	9	7	M	493	Curso Médio concluído	\N	\N	\N	42	\N	\N	\N	65	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11894	Rafael Teles Vital	4	1987	5	27	M	282	1º Termo / BSI	\N	\N	\N	42	\N	\N	\N	75	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12646	THIAGO DOURADO DE ANDRADE	4	1989	12	20	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11802	João Paulo Condé Oliveira Prado	4	1988	5	1	M	13	Engenharia - Poli	\N	\N	\N	42	\N	\N	1	165	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11485	Guilherme Kroff Fogaça	4	1988	3	20	M	274	Primeiro período	\N	\N	\N	42	\N	\N	1	140	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11484	Eduardo Bomtempo Martins Rocha	4	1988	5	26	M	274	Primeiro período	\N	\N	\N	42	\N	\N	1	100	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13172	Vivian Nunes Saddi	4	1988	9	10	F	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9664	Vinícius Nunes Lage	4	1989	4	4	M	379	2º Ano	\N	\N	\N	42	\N	\N	1	280	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12360	THIAGO DINIZ SOTERO DE MENEZES	4	1989	6	17	M	23	3A	\N	\N	\N	42	\N	\N	1	100	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11900	Murilo Silva Pellosi 	4	1988	4	25	M	282	1º Termo / BCC	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13509	Matheus Figueiredo de Castro	4	1988	3	24	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	1	90	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13524	Thiago Berti Thomaz	4	1988	3	9	M	83	6ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	50	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11713	RAÍZA TAMAE SARKIS HANADA	4	1989	10	29	F	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10852	Pedro Thiago Ezequiel de Andrade	4	1988	8	3	M	96	1o Semestre	\N	\N	\N	42	\N	\N	1	265	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11489	Luís Fernando Schultz Xavier da Silveira	4	1988	12	2	M	274	Primeiro período	\N	\N	\N	42	\N	\N	1	405	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11959	Elias Gabriel Amaral da Silva	4	88	7	11	M	490	1º período de Engenharia da Computação	\N	\N	\N	42	\N	\N	\N	40	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12234	AFRÂNIO LOPES LUCAS	4	1989	9	25	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	1	85	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13040	EDUARDO HIDEKI MISSAKA MAKUDA	4	1989	4	21	M	23	2D	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13118	Andressa Tina Tsuruda	4	1988	10	26	F	557	Prim. Sem. de Ciência da Computação	\N	\N	\N	42	\N	\N	\N	20	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10931	Isabela Liane de Oliveira	4	1988	11	30	F	296	terceira	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11936	Felipe Augusto da Gloria	4	1988	9	16	M	496	3ºEnsino Médio 2005	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14586	Tiago Tafari Catelam 	4	1988	2	4	M	296	terceira	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14519	Felipe Lima Cury	2	1993	2	8	M	545	7a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14822	Rodrigo Koga Petrulio	4	1979	1	15	M	560	7º Semestre	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14584	Maira Lambort Batista	4	1987	12	2	F	296	terceira	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13525	Anderson Ricardo dos Santos Rodrigues	4	1988	1	19	M	83	6ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11930	Paulo Sergio de Almeida Oliveira	4	1987	4	14	M	496	3ºEnsino Médio 2005	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13526	Guilherme Sartor	4	1988	3	12	M	83	6ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10466	DAVI FARIAS RIBEIRO	4	1990	3	1	M	488	2ª SÉRIE DO ENSINO MÉDIO 	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11951	Marcos P. Soledade Junior	4	1989	9	7	M	496	3ºEnsino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13038	CHRISTOPHER ITALO MOREIRA GOMES	4	1988	4	24	M	23	2D	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14062	Rafael Henrique Brasil	4	1989	6	4	M	543	3a do médio	\N	\N	\N	42	\N	\N	\N	15	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11931	Lucas Comitre Martinez	4	1989	9	20	M	496	3º Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11488	Leonardo Inácio Lima de Oliveira	4	1988	12	20	M	274	Primeiro período	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11949	Gustavo Henrique do Prado Noivo	4	1989	10	7	M	496	2ºEnsino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11940	Fábio Yukio Roriumi	4	1989	18	10	M	496	3ºEnsino Médio 	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12995	FELIPE NUNES VAZ DE OLIVEIRA	4	1989	9	15	M	23	2A	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12239	DIEGO RAFAEL DE OLIVEIRA RAMOS	4	1990	6	3	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13980	Bruno Loiola Barbosa	4	1990	7	14	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14167	André Luís Beling da Rosa	4	1987	12	8	M	564	1º Semestre do Ensino Superior	\N	\N	\N	42	\N	\N	\N	35	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13523	Vitor Mendes Souza	4	1988	8	15	M	83	6ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11491	Vinicius Silva de Paiva	4	1988	3	1	M	274	Primeiro período	\N	\N	\N	42	\N	\N	\N	20	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14071	Tarcísio Dias Pereira	4	1987	6	7	M	543	3a do médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14068	Sirlene Ingrid de Resende Xavier	4	1988	7	14	F	543	3a do médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7850	Samuel Evangelista Lima de Oliveira	4	1988	4	1	M	379	3º Ano	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13000	SAMUEL JUN OKUNO KITAZUME	4	1990	7	17	M	23	2B	\N	\N	\N	42	\N	\N	\N	20	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13281	Renato Carriço R. dos Santos	4	1989	2	6	M	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11942	Patrick Claudino Bernardes	4	1987	12	25	M	496	3ºEnsino Médio 2005	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14585	Murilo Helder de Paula	4	1988	3	6	M	296	terceira	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11935	Murilo Alvarenga da Silva	4	1989	5	22	M	496	3ºEnsino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11932	Maylson de Melo da Silva	4	1988	1	25	M	496	3º Ensino Médio 2005	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10907	Marcus Vinícius Souza Costa	4	1988	1	25	M	416	1pSI	\N	\N	\N	42	\N	\N	\N	10	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14056	Marcela Cláudia Carvalho	4	1988	5	1	F	543	3a do médio	\N	\N	\N	42	\N	\N	\N	20	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11941	Magno Martins Motta	4	1988	1	18	M	496	3ºEnsino Médio 2005	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13001	MATHEUS EDSON RAMOS	4	1990	7	30	M	23	2B	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12983	MARCUS VINICIUS BRUN CAFEO	4	1990	4	21	M	23	2A	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12326	MARCELO R. HASHIMOTO	4	1990	9	16	M	487	2ª EM	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13598	Leonardo Romão Pereira	4	1989	6	16	M	83	5ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12241	LENNON CORREA CHAVES	4	1990	6	11	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11929	Kátia Yoshime Nakamura	4	1989	4	21	F	496	3ºEnsino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13006	KAREN MENEGHETI DE MORAES	4	1990	6	9	M	23	2B	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14001	José Ronaldo Fechine Feitosa Filho	4	1990	5	22	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11487	José Renato da Silva Júnior	4	1988	1	22	M	274	Primeiro período	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11938	Jeferson Siqueira de Souza	4	1988	5	18	M	496	3ºEnsino Médio 2005	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11705	JOÃO CARLOS RODRIGUES DE SOUZA JÚNIOR	4	1989	8	22	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	25	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11946	Henrique da Cunha de Moraes	4	1987	12	24	M	496	3ºEnsino Médio 2005	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14169	Gustavo Massaki Kuwaki	4	1988	10	21	M	564	1º Semestre do Ensino Superior	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11804	Gustavo E.C. Fujiwara	4	1988	6	3	M	13	Engenharia - Poli	\N	\N	\N	42	\N	\N	\N	15	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14078	Guilherme Marelato Campos	4	1987	10	24	M	372	1o - BCC	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13992	Filipe Alves Tomé	4	1989	7	23	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	25	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12663	Fabio Ricardo Silva	4	1987	8	22	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12654	FELIPE DE SOUZA FARIAS	4	1990	9	30	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	35	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11806	Daniel Brignani Rodrigues	4	1988	5	30	M	13	Bach em Física diurno	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12361	DENIS FERNANDO CIAFREIS	4	1989	8	9	M	23	3A	\N	\N	\N	42	\N	\N	\N	15	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12240	CRISTHYAN MARCEL RÊGO CARVALHO	4	1990	2	22	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	10	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13036	BRUNO MONTEIRO DOS SANTOS	4	1987	12	21	M	23	2D	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11479	Adir dos Santos Mancebo Júnior	4	1987	9	29	M	274	Primeiro período	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11700	ANDRÉ RICARDO MELO ARAUJO	4	1989	5	18	M	117	3ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11725	ANDREW DOURADO MARINHO	4	1988	10	15	M	117	3ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	10	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14073	Wellington de Souza Reis	4	1987	10	18	M	543	3a do médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14791	GUILHERME JUN ARIÊ	2	1992	11	19	M	122	8ª SÉRIE	\N	\N	\N	41	\N	\N	1	17	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12277	CASSIO KEITI MORI	2	1993	4	5	M	487	7ª EF	\N	\N	\N	55	\N	\N	1	18	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16072	Rafael Esteves Duarte  Couteiro	2	1993	8	20	M	259	7ª série	\N	\N	\N	67	\N	\N	1	16	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14012	Iohana Costa di Maggio e Alcantara	2	1992	12	11	F	527	7ª Série 2 - PA	\N	\N	\N	84	\N	\N	1	16	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16010	Victor C. de Souza	2	9999	99	99	M	207	8a. série	\N	\N	\N	99	\N	\N	1	19	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14097	Felipe Vieira	2	1993	4	21	M	516	7ª Série	\N	\N	\N	84	\N	\N	1	19	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15418	LISSANDRO CORDEIRO FERREIRA DA SILVA	2	1993	4	23	M	555	7ª	\N	\N	\N	99	\N	\N	1	17	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12284	MOON JIN KIM	2	1993	1	15	M	487	7ª EF	\N	\N	\N	113	\N	\N	1	18	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13744	Antônio Bruno C. Farias	2	1992	4	25	M	516	8ª série	\N	\N	\N	122	\N	\N	1	18	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14053	Karen L. P. Barros	2	1992	3	21	F	216	8ª Série do Ensino Fundamental	\N	\N	\N	113	\N	\N	1	17	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13769	Ismália Dulce Gonçalves Santiago	2	1992	6	26	F	516	8ª série	\N	\N	\N	113	\N	\N	1	19	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14349	Carlos Alberto Del Salto dos Santos	2	1992	6	22	M	262	8ª Série	\N	\N	\N	131	\N	\N	1	20	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14982	PEDRO H. CALVO	2	1992	4	30	M	487	8ª EF	\N	\N	\N	140	\N	\N	1	17	0	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12086	RODRIGO FERREIRA DA ROSA	2	1992	7	11	M	215	17MA3	\N	\N	\N	153	\N	\N	1	21	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13235	DANIELA MACÊDO DE MORAES	2	1992	12	28	F	571	1-7MA3	\N	\N	\N	153	\N	\N	1	16	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10319	Victor Hugo B. Longen	2	1993	3	1	M	7	7ª série - Ensino Fundamental	\N	\N	\N	163	\N	\N	1	19	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13404	LUCAS DE LUCENA SILVA	2	1992	11	27	M	527	7ª Série A	\N	\N	\N	169	\N	\N	1	17	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10274	Augusto Konrath	2	1994	1	18	M	408	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12356	WELLINGTON MARTINS MARIANO	4	1989	2	27	M	23	3B	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13170	Vitor Kawao Guedes	4	1988	2	28	M	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14709	Vinícius dos Reis Alves Ferreira	4	1989	7	21	M	5	segunda série	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14639	Vinicius Uliana Pires da Costa	4	1986	8	27	M	372	USC	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12321	Victor Je Yong Lee	4	1989	2	4	M	487	3ª EM	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10337	Thiago Camargo Kronig	4	1989	8	15	M	225	Terceira série do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12349	THAMINE THAADA YAMADA	4	1988	11	16	F	23	3B	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12038	Solon Cerqueira D'Estillac Leal	4	1987	10	23	M	521	1° semestre curso superior	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11928	Samiramis F. Gabriel	4	1988	11	13	F	496	3º Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13599	Saimon Lunardi	4	1988	12	2	M	83	6ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13206	Rubem Nakamura Carneiro	4	1988	9	24	M	512	3ª Médio em 2005	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12667	Rogerio Moreira de Andrade	4	1987	11	26	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13151	Rodrigo Minoru Takenti	4	1987	9	25	M	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11891	Ricardo Medeiros de Lima 	4	1988	4	4	M	282	1º Termo / BSI	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12656	RODRIGO FARIAS ARAUJO	4	1990	2	22	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12355	RAFAEL PAQUIER VENTURA	4	1988	12	22	M	23	3B	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14656	Paulo Henrique Graciano	4	1992	10	30	M	491	Segunda Série do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12901	Paulo Henrique Eli	4	1989	1	20	M	83	5ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13312	PAULO HENRIQUE DE LIMA SAUGO	4	1983	9	8	M	560	7ºsem-Adm.Habilitação ANALISE SISTEMAS	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11406	Nicolau Sarquis Aiex Marini Ferreira	4	1988	12	12	M	303	terceiro ano do ensino medio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14172	Massami Welington Kamigashima	4	1988	9	29	M	564	1º Semestre do Ensino Superior	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11893	Marcos Estevão Rota Junior	4	1988	1	25	M	282	1º Termo / BSI	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12662	Lorena Amada Vieira	4	1988	3	17	F	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10800	LUCAS MAGNO	4	1990	3	10	M	495	3ª	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10810	JOSIMAR JAIME FINAMORE	4	1986	11	25	M	495	3ª	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12652	FÁBIO JACAÚNA DA SILVA	4	1990	3	20	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14645	Fernando Araújo Fernandes	4	1988	12	18	M	14	1o. semestre EC	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12937	Felipe Mendonça de Souza Almeida	4	1989	1	12	M	90	8	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10808	FABIANO GOMES DE LAIA	4	1984	4	10	M	495	3ª	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12693	ERICK KENZI NAGAMACHI	4	1989	7	30	M	487	2ª EM	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12650	DANIEL SANTOS DA SILVA	4	1990	5	19	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13136	Cássio Soares Martins	4	1988	4	12	M	557	Prim. Sem. em Eng. da Computação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12661	Claudio Cesar Alves de Melo Franco	4	1988	3	15	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8014	CLEITON PEREIRA VASCONCELOS	4	1986	1	5	M	244	2° GRAU COMPLETO	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12373	BRUNO FERNANDES CASELLA	4	1988	11	13	M	23	3C	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14157	Antônio Augusto Alves de Figueiredo	4	1988	9	10	M	296	terceira	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13596	Angélica Medeiros de Costa	4	1989	9	9	F	83	5ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12938	Andre Alves Oliveira	4	1989	3	17	M	90	3 ano	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13602	Alessandro Oliveira de Jesus	4	1986	12	29	M	379	2º Módulo do Curso Técnico 	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10809	Aderivaldo de Souza Ferreira Junior	4	1988	6	26	M	14	1o. semestre EC	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13969	Abraão Barros Lacerda	4	1988	12	17	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12327	ALEXANDRE NOBUO KUNIEDA	4	1990	9	22	M	487	2ª EM	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12620	VICTOR ROBERTO GOMES DA CUNHA	2	1993	12	15	M	6	8.ª	\N	\N	\N	41	\N	\N	1	22	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2920	RODRIGO NUNES DIAS	2	1993	4	4	M	57	7ª B	ronudias@terra.com.br	\N	\N	32	1	\N	1	22	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9810	Letícia Duchein Ferreira	2	1993	4	26	F	8	sétima série	\N	\N	\N	32	\N	\N	1	17	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12088	HENRIQUE MINORU FREITAS	2	1992	2	1	M	215	18TA4	\N	\N	\N	32	\N	\N	1	19	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16087	Victor Hugo R. Rossini	2	1992	9	11	M	259	8ª série	\N	\N	\N	41	\N	\N	1	22	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2961	JULIANA MALACARNE DE PINHO	2	1992	10	30	F	57	8ª SÉRIE A	\N	\N	\N	32	\N	\N	1	21	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11478	PLÍNIO HENRIQUE CHAPARIN	2	1992	12	17	M	159	8	\N	\N	\N	41	\N	\N	1	18	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12294	CHRISTIAN EDUARDO DE U. SAIKI	2	1992	3	14	M	487	8ª EF	\N	\N	\N	41	\N	\N	1	20	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2960	JOSÉ PAULO MARQUES CAMARA	2	1992	9	2	M	57	8ª SÉRIE A	\N	\N	\N	41	\N	\N	1	22	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16031	Pedro Henrique Froto Agum	2	9999	99	99	M	207	8a. série	\N	\N	\N	55	\N	\N	1	18	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13191	Matheus Troina de Resende	2	192	2	17	M	40	8ª do Ensino Fundamental	\N	\N	\N	41	\N	\N	1	21	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10335	Ronan Felipe Jorge	2	1992	4	2	M	473	8ª B	\N	\N	\N	67	\N	\N	1	18	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12302	MICHEL SEUNG KUN LEE	2	1992	7	4	M	487	8ª EF	\N	\N	\N	55	\N	\N	1	16	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11243	CAMILA SAMEA MONTEIRO BEZERRA	2	1992	4	27	F	196	8ª Série - Master	\N	\N	\N	55	\N	\N	1	19	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15107	JÚLIA RODRIGUES DE ALMEIDA	2	1991	10	29	F	11	8ª	\N	\N	\N	55	\N	\N	1	18	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12292	BERNARDO M. ROCAMORA JUNIOR	2	1992	8	24	M	487	8ª EF	\N	\N	\N	67	\N	\N	1	19	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14600	Guilherme Salvador Vieira	2	1991	12	2	M	545	8a	\N	\N	\N	67	\N	\N	1	18	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13593	Naum Azeredo Fernandes Barreira	2	1992	2	5	M	527	8ªPI	\N	\N	\N	67	\N	\N	1	18	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13764	Gabriel de Lima Araripe	2	1992	8	8	M	516	8ª série	\N	\N	\N	67	\N	\N	1	18	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15367	TATIANA DE SÁ ROQUE	2	1992	12	27	F	555	7ª	\N	\N	\N	84	\N	\N	1	21	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16013	Paulo Ricardo de Souza Costa	2	9999	99	99	M	207	8a. série	\N	\N	\N	67	\N	\N	1	20	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13777	João Paulo Sousa Lucas	2	1991	11	19	M	516	8ª série	\N	\N	\N	67	\N	\N	1	21	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16092	Gabriela Schimidt Defende	2	1992	4	24	F	259	8ª série	\N	\N	\N	67	\N	\N	1	20	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2922	BRUNA FALCONERES DE ALMEIDA	2	1993	4	30	F	57	7ª SÉRIE B	\N	\N	\N	67	\N	\N	1	22	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2964	RAFAEL NADALETO LOPES	2	1993	2	10	M	57	8ª SÉRIE	\N	\N	\N	84	\N	\N	1	20	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14826	Luiza Almeida de Araújo	2	1992	3	10	F	367	8ª	\N	\N	\N	84	\N	\N	1	19	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14788	JOSNEI LUIS OLSZEWSKI JUNIOR	2	1993	3	17	M	122	7ª SÉIRE	\N	\N	\N	84	\N	\N	1	16	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11017	Thatiane Vichiato Breda	2	1991	9	24	F	473	8 E	\N	\N	\N	99	\N	\N	1	18	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11257	GELLY WHESLEY SILVA NEVES	2	1991	10	2	M	196	8ª Série - Master	\N	\N	\N	84	\N	\N	1	18	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1641	Rafael Cherman Schvinger	2	1992	2	24	M	153	8ª série	\N	\N	\N	99	\N	\N	1	21	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2921	LEONARDO GASPARINE MARQUES RODRIGUES	2	1993	4	25	M	57	7ª série B	\N	\N	\N	113	\N	\N	1	19	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2962	MARIANE CEREJA BRAZ	2	1992	5	17	F	57	8ª SÉRIE A	\N	\N	\N	99	\N	\N	1	21	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13190	Luiz Henrique Sampaio da Fonseca 	2	1991	12	12	M	40	8ª do Ensino Fundamental	\N	\N	\N	99	\N	\N	1	17	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12087	ALINE COSTA CUSTADIO	2	1992	2	4	F	215	18TA4	\N	\N	\N	99	\N	\N	1	22	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12111	FABIAN LAMMERS	2	1991	10	30	M	215	18MA2	\N	\N	\N	99	\N	\N	1	21	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13693	Samuel Abreu Gomes	2	1991	8	21	M	367	8ª	\N	\N	\N	99	\N	\N	1	22	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13846	Flávio F. Gondo	2	1992	7	10	M	216	8ª Série do Ensino Fundamental	\N	\N	\N	99	\N	\N	1	20	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12116	Anderson Luís Barbosa	2	1992	2	12	M	393	Ciclo IV - Final B	\N	\N	\N	113	\N	\N	1	17	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12063	LEONARDO AUGUSTO MIZOGUTI	2	1991	12	1	M	215	18MB2	\N	\N	\N	113	\N	\N	1	20	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16095	Natalia Toynon	2	1992	4	28	F	259	8ª série	\N	\N	\N	122	\N	\N	1	20	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14830	João Victor Souza Mendes	2	1992	5	8	M	367	8ª	\N	\N	\N	122	\N	\N	1	20	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15353	HUGO DE OLIVEIRA PEREIRA DAMASCENO	2	1992	11	15	M	555	7ª	\N	\N	\N	122	\N	\N	1	16	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16093	Nayara Petry de Andrade	2	1991	9	20	F	259	8ª série	\N	\N	\N	131	\N	\N	1	19	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2924	ANTONIO FERREIRA DIAS JUNIOR	2	1993	8	30	M	57	7ª série A	\N	\N	\N	122	\N	\N	1	20	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15378	RODOLFO NOBRE BITU DE MORAIS	2	1991	11	17	M	555	8ª	\N	\N	\N	140	\N	\N	1	16	0	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13750	Davi Jefferson de Castro e Silva	2	1991	7	17	M	516	8ª série	\N	\N	\N	140	\N	\N	1	17	0	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14514	Thomaz Bignotto	2	1992	9	22	M	545	7a	\N	\N	\N	148	\N	\N	1	16	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11236	HALANA RODRIGUES FREIRE ELOY	2	1992	7	9	F	196	7ª Série - Master	\N	\N	\N	140	\N	\N	1	18	0	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12307	WONG GUAN	2	1991	12	16	M	487	8ª EF	\N	\N	\N	153	\N	\N	1	19	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16094	Joyce Costa Faria	2	1991	11	26	F	259	8ª série	\N	\N	\N	148	\N	\N	1	19	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10386	ISABELLA  MARTIMBIANCO RIBEIRO	2	1992	8	7	F	48	8ª C	\N	\N	\N	158	\N	\N	1	16	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10480	Inácio M. Marchetti da Silva	2	1992	1	15	M	157	8ª Série	\N	\N	\N	153	\N	\N	1	21	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13572	Alexandre Lai	2	1993	2	16	M	527	7ªPI	\N	\N	\N	158	\N	\N	1	16	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16090	Danilo Alves da S. Benedito	2	1991	9	11	M	259	8ª série	\N	\N	\N	158	\N	\N	1	16	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14692	CHRISTORPHER KENGO NAGAO	2	1993	4	18	M	215	17TA3	\N	\N	\N	158	\N	\N	1	17	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15441	LARISSA BRITO SOUSA	2	1992	2	24	F	555	8ª	\N	\N	\N	163	\N	\N	1	16	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15963	Marcelo Passos Torreaba	2	1992	7	7	M	78	8EF	\N	\N	\N	166	\N	\N	1	16	0	16	266	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13189	DIEGO MARQUES JUAÇABA	2	1992	5	30	M	467	8ª SÉRIE ALFA	\N	\N	\N	171	\N	\N	1	16	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12274	RODRIGO MORIMOTO SUGUIURA	1	1994	2	2	M	487	6ª EF	\N	\N	\N	34	\N	\N	1	13	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14993	RAFAEL KAZUHIRO M	1	1995	6	9	M	487	5ª EF	\N	\N	\N	41	\N	\N	1	15	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10632	Paula Kantorowitz Battaglia	1	1995	9	2	F	153	5ª série	\N	\N	\N	34	\N	\N	1	11	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11863	DANILO KENJI SHIDO	1	1995	10	10	M	487	5 EF	\N	\N	\N	34	\N	\N	1	14	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15291	Hugo Rodrigues Martins Dantas	1	1993	10	5	M	555	6	\N	\N	\N	34	\N	\N	1	13	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12303	LOHANNE OLIVEIRA FORTE	1	1994	8	23	F	196	6ª Série - Master	\N	\N	\N	41	\N	\N	1	10	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16054	Guilherme Lopes Ferreira	1	1994	2	13	F	259	6ª série	\N	\N	\N	41	\N	\N	1	10	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14362	Ayrton Cesar de Barros	1	1994	10	19	M	517	sexta	\N	\N	\N	41	\N	\N	1	11	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2976	VINICIUS SANTIAGO GONÇALVES	1	1994	7	13	M	57	6ª SÉRIE B	\N	\N	\N	51	\N	\N	1	15	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15119	Henrique Zoqui Frugoli	1	1994	11	13	M	144	5ª Série	\N	\N	\N	41	\N	\N	1	15	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15960	Victor Menegucci Groterhorst	2	1992	7	7	M	78	8EF	\N	\N	\N	19	\N	\N	1	22	3	32	533	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13633	Daniel Gurgel do Amaral Mota	1	1994	4	8	M	527	6ªPI	\N	\N	\N	41	\N	\N	1	11	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13437	SERGIO LUIZ ARRUDA PARENTE FILHO	1	1994	2	3	M	527	6ª Série A	\N	\N	\N	51	\N	\N	1	11	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11657	JANAINA CARNEIRO AMERICANO DE BRITO	1	1994	12	15	F	467	6ª SÉRIE	\N	\N	\N	51	\N	\N	1	12	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13886	David Guimaraes Coelho	1	1994	7	20	M	527	6ª Série 2 - PA	\N	\N	\N	51	\N	\N	1	10	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13809	Ivan Silveira	1	1993	6	2	M	516	6ª Série	\N	\N	\N	51	\N	\N	1	10	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15092	RAFAEL ALMEIDA MEIRA PONSONI	1	1994	7	7	M	11	6ª	\N	\N	\N	51	\N	\N	1	14	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14222	Felipe Dias	2	1992	6	25	M	293	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15216	Ana Clara de Almeida Prado Caetano e Silva	1	1993	10	15	F	144	6ª Série	\N	\N	\N	51	\N	\N	1	10	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15990	Guilherme Silva	1	1994	7	7	M	78	5EF	\N	\N	\N	51	\N	\N	1	13	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13301	Davi Coelho Amorim	1	1994	3	23	M	367	6ª	\N	\N	\N	51	\N	\N	1	11	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14851	Carlos Magno Gomes Rocha	1	1993	10	16	M	367	6ª	\N	\N	\N	66	\N	\N	1	13	0	16	266	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16062	Maria Luisa Cunha alves	1	1994	7	27	F	259	6ª série	\N	\N	\N	68	\N	\N	1	13	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11306	Gabriel Ribeiro Reis	1	1993	12	3	M	511	6ª	\N	\N	\N	68	\N	\N	1	12	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15211	Bianca Katsumata de Souza	1	1994	7	15	F	144	6ª Série	\N	\N	\N	68	\N	\N	1	10	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14054	Rodrigo Alves Tomé	1	1994	5	15	M	516	6ª série	\N	\N	\N	79	\N	\N	1	14	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14454	Clara Aguiar Benedett	1	1994	6	28	F	552	6ª1ª	\N	\N	\N	68	\N	\N	1	13	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13733	Antonio Roger Galvão Nascimento	1	1994	1	6	M	527	6ªPI	\N	\N	\N	68	\N	\N	1	13	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15961	Renato Ferreira P. Junior	1	1994	7	7	M	78	5EF	\N	\N	\N	79	\N	\N	1	11	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13906	Rebeca Vale Andrade	1	1993	9	24	F	527	6ª Série 2 - PA	\N	\N	\N	79	\N	\N	1	10	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13887	Jose Lafaiete Costa Neto	1	1994	8	30	M	527	6ª Série 2 - PA	\N	\N	\N	79	\N	\N	1	10	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14539	Bruno Barsotti Milani	1	1993	11	4	M	545	6a	\N	\N	\N	79	\N	\N	1	12	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14525	Felipe da Costa Maciel	2	1991	12	8	M	545	8a	\N	\N	\N	32	\N	\N	1	20	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16009	Vinicius Amorim Theotônio	2	9999	99	99	M	207	8a. série	\N	\N	\N	41	\N	\N	1	20	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13412	GABRIEL HENRIQUE C. NOGUEIRA	2	1993	2	17	M	527	7ª Série E	\N	\N	\N	55	\N	\N	1	21	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16016	Ayrton Adão da Silva	2	9999	99	99	M	207	8a. série	\N	\N	\N	67	\N	\N	1	20	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11247	DENILSON ARAUJO DA PASCOA	2	1991	9	12	M	196	8ª Série - Master	\N	\N	\N	55	\N	\N	1	22	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13634	Victor Ishii	2	1993	8	5	M	527	7ªPI	\N	\N	\N	84	\N	\N	1	19	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15770	MARINA MERUVIA	2	1992	6	5	F	573	8ª SÉRIE	\N	\N	\N	113	\N	\N	1	19	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16023	Filipe Luiz B. de Rezende	2	9999	99	99	M	207	8a. série	\N	\N	\N	84	\N	\N	1	17	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15370	BRENO AUGUSTO CARDOSO BARROSO	2	1992	2	11	M	555	8ª	\N	\N	\N	84	\N	\N	1	20	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16015	Eduardo Furtado Gonçalves	2	9999	99	99	M	207	8a. série	\N	\N	\N	84	\N	\N	1	19	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10485	Charles Aparecido de Almeida	2	1992	9	2	M	157	8ª Série	\N	\N	\N	122	\N	\N	1	17	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16075	Caio A. Lourenco	2	1993	3	3	M	259	7ª série	\N	\N	\N	122	\N	\N	1	17	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12085	RODRIGO VON HORN RODRIGUES DA SILVA	2	1992	4	22	M	215	18TA2	\N	\N	\N	131	\N	\N	1	21	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13939	Levi Marques Gonçalves	2	1993	7	26	M	527	7ª Série A - PA	\N	\N	\N	131	\N	\N	1	16	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15371	DANIELLE SALES SILVA	2	1992	6	7	F	555	8ª	\N	\N	\N	131	\N	\N	1	17	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10320	Vinícius José de Souza Faqueti	2	1992	11	21	M	7	7ª série - Ensino Fundamental	\N	\N	\N	140	\N	\N	1	19	0	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13236	FELIPE BALABANIAN	2	1993	1	18	M	571	1-7TA2	\N	\N	\N	131	\N	\N	1	21	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13782	Obed Leite Vieira	2	1992	9	3	M	516	8ª série	\N	\N	\N	140	\N	\N	1	16	0	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14832	Antônio Flávio Gonçalves da Silva	2	1992	6	5	M	367	8ª	\N	\N	\N	140	\N	\N	1	17	0	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13426	JESSYKA SOARES A. MARTINS LUZ	1	1994	11	9	F	527	6ª Série A	\N	\N	\N	79	\N	\N	1	11	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11852	ISABEL NOBRE FEITOZA	1	1995	12	20	F	467	5ª SÉRIE	\N	\N	\N	79	\N	\N	1	11	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10434	VICTOR HILL SARAIVA LIMA	1	1995	6	9	M	488	5ª SÉRIE	\N	\N	\N	92	\N	\N	1	13	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2981	ANA PAULA CEREJA BRAZ	1	1994	5	21	F	57	6ª SÉRIE	\N	\N	\N	92	\N	\N	1	13	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13632	Lucas Silva Sydrião	1	1994	4	19	M	527	6ªPI	\N	\N	\N	92	\N	\N	1	12	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11862	DANILO HIKARI M WATANABE	1	1994	9	25	M	487	5 EF	\N	\N	\N	92	\N	\N	1	12	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16052	Victor Rezende Geraldini	1	1995	3	30	M	259	5ª série	\N	\N	\N	106	\N	\N	1	11	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10743	Daniela Lewinski	1	1993	10	10	F	153	6ª série	\N	\N	\N	92	\N	\N	1	13	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13644	Amadeu Cavalcante Filho	1	1994	1	27	M	367	6ª	\N	\N	\N	92	\N	\N	1	14	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15979	Priscila Tuppy	1	1993	7	7	F	78	6EF	\N	\N	\N	106	\N	\N	1	10	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13434	RAYSSA SA MACHADO	1	1993	12	28	F	527	6ª Série A	\N	\N	\N	117	\N	\N	1	10	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13729	Sarah Virgínia A. Girão	1	1995	9	19	F	527	5ªPI	\N	\N	\N	106	\N	\N	1	10	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11691	João Paulo Alves Veríssimo	1	1994	12	8	M	526	6ª Série	\N	\N	\N	106	\N	\N	1	12	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13679	River de Alencar Bandeira Coêlho	1	1994	5	28	M	367	6ª	\N	\N	\N	106	\N	\N	1	14	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13868	LUCIANO DROZDA  DANTAS MARTINS	1	1996	3	12	M	488	5ª SÉRIE	\N	\N	\N	106	\N	\N	1	10	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10437	LEONARDO ESSES NOBRE	1	1994	10	11	M	488	6ª SÉRIE	\N	\N	\N	106	\N	\N	1	11	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14101	Miguel Mayer Vaz	2	1993	1	8	M	516	7ª Série	\N	\N	\N	9	\N	\N	1	21	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
15379	STEPHANE HILDA BARBOSA LIMA	2	1992	2	25	F	555	8ª	\N	\N	\N	19	\N	\N	1	22	3	32	533	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
5804	GABRIEL COROCINE CAVALETTI	1	1994	5	15	M	57	6ª série B	\N	\N	\N	117	\N	\N	1	10	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12503	Maxsol Bochi Borges	1	1994	6	30	M	312	6ª B	\N	\N	\N	130	\N	\N	1	10	0	10	166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1708	Lucas Madeira	1	1993	11	18	M	7	6ª série - Ensino Fundamental	\N	\N	\N	117	\N	\N	1	12	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15982	Leonardo Y.  Kamigariti	1	1994	7	7	M	78	5EF	\N	\N	\N	117	\N	\N	1	10	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13876	Amanda Meneses Diniz	1	1994	5	12	F	527	6ª Série 2 - PA	\N	\N	\N	117	\N	\N	1	14	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15965	Daniel A. de Andrade Hara	1	1994	7	7	M	78	5EF	\N	\N	\N	117	\N	\N	1	11	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13447	BRUNO BRASILEIRO DE MOURA	1	1993	8	2	M	527	6ª Série E	\N	\N	\N	117	\N	\N	1	12	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4216	PEDRO EMANUEL BUMBA	1	1996	6	26	M	57	4ª SÉRIE A	\N	\N	\N	117	\N	\N	1	13	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10776	LUCAS COUTO MARANSALDI	1	1996	4	10	M	57	4ª SÉRIE A	\N	\N	\N	117	\N	\N	1	10	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15977	Julia Gastmann	1	1993	7	7	F	78	6EF	\N	\N	\N	117	\N	\N	1	10	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16049	Henrique Velasco	1	1994	10	11	M	259	5ª série	\N	\N	\N	117	\N	\N	1	15	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13896	Débora Nojiri de Moraes Arruda	1	1995	7	13	F	544	5a série	\N	\N	\N	117	\N	\N	1	11	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13927	Jéssica Latanzio Cimatti	1	1994	1	22	F	544	6a série	\N	\N	\N	130	\N	\N	1	10	0	10	166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10766	VITOR DE LAVOR SOARES	1	1996	6	17	M	57	4ª SÉRIE B	\N	\N	\N	138	\N	\N	1	12	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11212	LANA CAROLINA SILVA PEREIRA	1	1995	10	2	F	196	5ª Série - Gama	\N	\N	\N	130	\N	\N	1	11	0	10	166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2985	ANDRESSA DOS SANTOS ORTEGA	1	1994	5	30	F	57	6ª série	\N	\N	\N	130	\N	\N	1	11	0	10	166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12392	Rafael Augusto de Santi	1	1995	9	8	M	293	5ª	\N	\N	\N	138	\N	\N	1	10	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16046	Matheus Liner Martins de Souza	1	1995	4	14	M	259	5ª série	\N	\N	\N	138	\N	\N	1	10	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11693	Lorena Lima de Patrício Ribeiro	1	1994	7	1	F	526	6ª Série	\N	\N	\N	138	\N	\N	1	11	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11690	Josias Nascimento Cunha	1	1993	12	22	M	526	6ª Série	\N	\N	\N	138	\N	\N	1	10	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13479	Cecília Polhman	1	1994	10	14	F	540	6a série	\N	\N	\N	138	\N	\N	1	10	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15991	Paulo Froes	1	1994	7	7	M	78	5EF	\N	\N	\N	138	\N	\N	1	11	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10448	MATHEUS PESSOA COLARES	1	1996	1	8	M	488	5ª SÉRIE	\N	\N	\N	138	\N	\N	1	11	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14156	Giovanni Troiani Neto	1	1993	10	28	M	516	6ª	\N	\N	\N	138	\N	\N	1	11	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11226	YAGO PINTO NUNES	1	1994	1	30	M	196	6ª Série - Master	\N	\N	\N	149	\N	\N	1	10	0	8	133	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13941	Marina Pavan de Almeida	1	1994	7	30	F	544	6a série	\N	\N	\N	149	\N	\N	1	10	0	8	133	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5666	VIVIAN CARNEIRO BORTONE	1	1993	12	14	F	57	6ª série B	\N	\N	\N	149	\N	\N	1	15	0	8	133	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13952	Raissa Cristina Teixeira de Mello	1	1994	7	25	F	544	6a série	\N	\N	\N	155	\N	\N	1	10	0	7	116	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13892	Carolina Beatriz Amaral	1	1994	11	21	F	544	5a série	\N	\N	\N	155	\N	\N	1	10	0	7	116	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14663	Isabel Flesh Laforce	1	1994	4	19	F	552	6ª1ª	\N	\N	\N	155	\N	\N	1	11	0	7	116	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13542	Beatriz Venturini Sgavioli	1	1995	7	28	F	285	5ª série	\N	\N	\N	160	\N	\N	1	10	0	6	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13485	Olivia Moraes Ruberti	1	1994	8	29	F	540	6a série	\N	\N	\N	164	\N	\N	1	11	0	4	66	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10719	Miguel Heilberg	1	1995	9	12	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15106	STEFANO TOMMASINI	2	1991	1	13	M	11	8ª	\N	\N	\N	32	\N	\N	1	22	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15114	BRUNA ALMEIDA MEIRA PONSONI	2	1992	7	12	F	11	8ª	\N	\N	\N	32	\N	\N	1	20	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13228	BRUNO BASSO BRANDANI	2	1992	7	17	M	571	1-8MA4	\N	\N	\N	55	\N	\N	1	20	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11161	Swami Anand Sidharta Costa	2	1991	12	13	F	473	8 B	\N	\N	\N	113	\N	\N	1	17	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14990	VICTOR SACAGUTI	2	1992	10	6	M	487	8ª EF	\N	\N	\N	122	\N	\N	1	17	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13680	Renan da Silva Braga	2	1993	4	14	M	367	7ª	\N	\N	\N	113	\N	\N	1	18	0	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2923	VICTOR MORAIS PADILHA	2	1993	3	19	M	57	7ª série B	\N	\N	\N	131	\N	\N	1	18	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16089	Roberio S. Nunes	2	1991	7	23	M	259	8ª série	\N	\N	\N	148	\N	\N	1	19	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11642	ANA GABRIELLY ALVES PINHEIRO	2	1993	3	22	F	196	7ª Série - Master	\N	\N	\N	148	\N	\N	1	16	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13417	PAULO FERNANDO MOREIRA TORRES JUNIOR	2	1993	2	7	M	527	7ª Série E	\N	\N	\N	166	\N	\N	1	17	0	16	266	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13381	PATRICIA LEANDRO BEZERRA	2	1992	8	27	F	527	8ª Série A	\N	\N	\N	169	\N	\N	1	17	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11692	Leonardo Candido Moratti Cardoso	1	1994	3	4	M	526	6ª Série	\N	\N	\N	79	\N	\N	1	11	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12626	THAIS RIBEIRO BARROSO TORRES	1	1994	10	11	F	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10972	Sarah de Castro A. Tauil	1	1995	3	10	F	511	5ª	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13592	Raquel Nobre Araújo	1	1993	12	2	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13717	Rafael Pinheiro de Souza	1	1995	7	21	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13913	Rafael Anzuino Carrara	1	1995	6	23	M	544	5a série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13444	RENATA DE ANDRADE FARIAS	1	1994	8	27	F	527	6ª Série E	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16047	Paulo Ricardo Ackermann Junior	1	1995	6	23	M	259	5ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13947	Paula Anzuino Carrara	1	1993	4	5	F	544	6a série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10756	Mauricio Melighendler	1	1994	10	8	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13704	Matheus Juca Teles	1	1993	12	7	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13934	Marcela Banietti Rosa Pereira	1	1994	3	15	F	544	6a série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2982	MAURICIO MORAIS ALVES DE OLIVEIRA	1	1994	2	14	M	57	6ª série B	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12261	MATHEUS MORIMOTO SUGUIURA	1	1995	10	17	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13911	Luiz Otávio di Rienzo	1	1995	1	17	M	544	5a série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14448	Luiz Augusto Beduschi Pabst	1	1994	3	4	M	552	6ª2ª	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14865	Lucas Henrique dos Santos Tavares	1	1993	7	25	M	574	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15639	Luan Rúbio Sala 	1	1994	10	28	M	491	6ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13929	Jorge Galdino de Oliveira Neto	1	1994	6	6	M	544	6a série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11330	Igor de Castro Cunha	1	1993	10	26	M	511	6ª	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15756	ISADORA RIBEIRO DE OLIVEIRA	1	1995	12	27	F	573	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14133	Gabriela Galvão Montenegro	1	1995	7	19	F	516	5ª Série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13719	Felipe Camurça	1	1995	4	23	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13639	Dennyfer Deyse Sousa Saraiva	1	1995	3	12	F	367	5ª	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10747	Deborah Dzialoschinsky	1	1993	8	18	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1424	David Feher Radomysler	1	1994	12	8	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10420	DENIS BARBOSA DE LIMA	1	1994	2	8	M	488	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15382	CAIQUE RODRIGUES ERICEIRA LOBO	1	1995	12	12	M	555	5ª	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15521	Brenda Condado de Moraes	1	1993	12	16	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13673	Beatriz Soares Mota	1	1994	1	30	F	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15270	Beatriz Holanda Coelho	1	1994	8	25	F	555	6	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15127	Andre João Pedro de Oliveira	1	1994	12	5	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13069	Ana Luiza Fainé Gomes	1	1994	11	25	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11032	Altieres Ribeiro Faria	1	1994	8	1	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15985	Raul Dario	1	1994	7	7	M	78	5EF	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1528	Raphael Levy Ruscio Castro Teixeira	1	1994	7	29	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15562	Rafael Gouveia Lazarini 	1	1994	1	22	M	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15325	REBECA LOBO BORGES	1	1995	3	19	F	555	5ª	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12264	RAPHAEL HIKARO YNOUE	1	1995	10	15	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13535	Mayara Carolina A. Girão	1	1994	7	3	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1527	Mauricio Schapiro Ghisserman	1	1993	12	17	M	153	6 série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13900	Mateus Abreu de Albuquerque	1	1994	5	26	M	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16053	Mariela Aparecida Claro Martines	1	1994	9	15	F	259	5ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15314	Manuella Angeline Silva Oliveira	1	1994	10	8	F	555	6	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11191	MAXÊNIO DO MONTE FERRER	1	1995	9	25	M	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15131	Luis Otavio Barbosa	1	1994	11	18	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10755	Luana Szymonowicz	1	1994	1	5	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13629	João Pedro F. Sales	1	1994	7	2	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13559	José Guilherme Martin Avino	1	1995	7	10	M	285	5ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15052	Guilherme Carvalho Brito	1	1994	1	25	M	541	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13293	Gilmar Luiz Garcia Vilarinho Neto	1	1994	10	5	M	518	Fundamental	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15762	GUILHERME H. SEHN	1	1994	6	4	M	573	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13306	Fernando Adré do Nascimento Santiago	1	1993	12	26	M	518	Fundamental	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11631	FRANCISCO ISAIAS VIANA CRISOSTOMO DOS SANTOS	1	1994	2	13	M	196	6ª Série - Master	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13672	Bruno Rios Siqueira	1	1993	11	3	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13621	Arthur Medeiros de Albuquerque	1	1993	8	23	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12080	RUI LOPES GONÇALVES	2	1993	4	11	M	215	17MA4	\N	\N	\N	55	\N	\N	1	20	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12259	THOMAS P. ROSELLI	2	1993	1	23	M	215	17MB1	\N	\N	\N	67	\N	\N	1	16	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11467	RAPHAEL MACHADO ROSSI	2	1992	10	12	M	159	7	\N	\N	\N	55	\N	\N	1	21	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11465	IGOR ROSIELLO ZENKER	2	1992	12	10	M	159	7	\N	\N	\N	67	\N	\N	1	19	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14829	Thaís Vieira Rolim	1	1994	2	28	F	367	6ª	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10435	THIAGO VINICIUS PEREIRA SEABRA	1	1994	6	16	M	461	6ª SÉRIE VERDE	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11568	Roberta Costa de Souza	1	1996	9	4	F	350	3ª A	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14590	RODOLFO UHLMANN DOMINGOS	1	1994	3	18	M	215	16MA2	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10630	Paula Brick	1	1995	9	25	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11628	PEDRO IVO COELHO DE ARAUJO	1	1995	10	27	M	196	5ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15974	Nicolas Barbosa	1	1994	7	7	F	78	5EF	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15780	NIKOLAS SOARES FARIA	1	1994	6	4	M	57	6 SÉRIE	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10621	Michel Joelsas	1	1995	3	18	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11140	Matheus Cardelli de Souza Campos	1	1995	8	26	M	258	5ª	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14210	Mateus Augusto Gomes	1	1993	1	1	F	313	5ºD	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15122	Lucas Vinicius Olmedo	1	1994	11	16	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13678	Letícia Cordeiro Joca	1	1995	10	31	F	367	5ª	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10428	LUCAS TADEU FURQUIM	1	1994	6	29	M	461	6ª SÉRIE AZUL	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10741	LUCAS GALLANI RODRIGUES	1	1996	5	20	M	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13711	Karen Flaviane Feliz Lima	1	1995	1	30	F	527	5ªPI	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13665	Jéssica Matias Lewinter	1	1994	8	8	F	367	5ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15299	Joel Alves Soares	1	1993	4	7	M	555	6	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11850	JAMILLE SAMPAIO COSTA	1	1995	8	9	F	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14971	Henrique Belchior de Oliveira	1	1995	9	18	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12523	Gina de Simone Pallos	1	1993	11	1	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10932	FERNANDA KOATZ	1	1994	4	28	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10546	Elisabelle Ondina da Silva	1	1994	4	25	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1515	Daniel Grossmann	1	94	10	4	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13290	Claudio de Andrade Silva	1	1993	3	1	M	518	Fundamental 	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13885	Caio Weiss Amaral	1	1994	6	4	M	544	5a série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13424	CLARICE ESTACIO TRUMMER L. COSTA	1	1993	11	29	F	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11181	BRUNO FARIAS DA SILVA	1	1994	8	25	M	196	5ª Série  - Alfa	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13883	Athman Teixeira Alem	1	1992	5	31	M	544	5a série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13691	André Felipe Pinheiro de Souza	1	1995	8	15	M	367	5ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15268	AMANDA CAMPOS FONTENELE RODRIGUES	1	1994	12	3	F	555	5ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12806	Victor Gonçalves Meneguite	1	1993	6	30	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12267	VINCENT CHERNG HSI LEE	1	1995	3	15	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15519	Thaísa Amália Hernandez Bellotto	1	1933	11	2	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13668	Taís Aragão Sandora	1	1995	3	1	F	367	5ª	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15164	Stéfani Torres dos Santos	1	1992	11	30	F	512	7ªD	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10599	Rodrigo Goldenstein Schainberg	1	1995	10	18	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10676	Raquel Rafaela Azevedo	1	1994	10	4	F	473	5 D	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15453	Rander Henrique C. da Costa	1	1993	4	27	M	473	5 E	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10423	RODRIGO ALONSO SILVA	1	1994	7	11	F	461	6ª SÉRIE AZUL	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10779	MIKAEL PATRICK RODRIGUES DE ANDRADE	1	1995	12	17	M	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10995	Kaique Antônio de P. Castro	1	1992	2	14	M	313	6ªD	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13709	João Victor Rocha Maia	1	1995	3	26	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11274	João Manoel da Silveira Lara	1	1995	8	25	M	511	5ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15692	Jorge Cavalcanti Coelho Alves	1	1994	10	10	M	8	sexta série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15301	JULIO VALENTE COSTA	1	1993	11	12	M	555	5ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13867	JOÃO NOGUEIRA LIMA NETO	1	1994	8	21	M	488	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15144	Henrique Name dos Santos	1	1994	9	13	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14329	HENRIQUE BARBOSA NEVES	1	1994	4	9	M	5	6o	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12420	Geovane Gomes Silva	1	1995	6	26	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15975	Felipe C. M. Mouran	1	1994	7	7	M	78	5EF	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15973	Daniela M. Perez	1	1994	7	7	F	78	5EF	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14136	Claudio José de Carvalho Neto	1	1993	11	5	M	516	6ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16056	Camila Trevilato	1	1994	1	21	F	259	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12372	Caio Vidal Mourão	1	1995	7	12	M	318	5ª Série A	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10846	CAROLINE CRISTINA LIMA DE SOUZA	1	1994	7	14	F	373	6ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12434	Bruno Rodrigues de Magalhães Corrêa	1	1994	12	13	M	312	5ª C	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11398	Bianca Emídio de Paula	1	1994	12	2	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10609	Beatriz Wainstein Silber	1	1995	5	12	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10740	Ariel Lebensztajn	1	1994	2	5	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13915	Ana Carolina de Souza Mello	1	1994	3	30	F	544	6a série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12745	Acácio de Almeida Teixeira dos Santos	1	1994	8	22	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12021	ANA CARINA RODRIGUÊS GOIS	1	1995	3	18	F	488	5ª SÉRIE DO ENS. FUNDAMENTAL	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14943	AMANDA NARA R.SILVA	1	1992	4	7	F	5	6o	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14427	Vladia Sales Leite Silveira	1	1993	10	24	F	526	6ª Série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15435	RODRIGO SOARES VALENTE	1	1993	9	28	M	555	6ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13726	Matheus Cazuza de Lima	1	1994	9	18	M	527	6ª Série E - PA	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10858	MAURÍCIO ANTONIO DARCIE RAMIN	1	1995	6	9	M	48	5ª C	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3812	MATHEUS SANCHES PONTES	1	1995	6	16	M	57	5ª SÉRIE a	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12786	Luiza Benevides de Freitas 	1	1994	3	16	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13568	Letícia Freitas de Assis	1	1994	3	23	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10774	LAIS VITALI COSTA	1	1996	2	3	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15304	Kalil Jorge de Araújo	1	1994	4	14	M	555	6	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10707	Juliane Jampolsky	1	1995	7	3	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13303	José Claudinei Cardoso Junior	1	1994	6	22	M	518	Fundamental	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12948	JOSÉ ÁLLYSSON DA SILVA	1	1994	7	21	M	236	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10326	Isabela Santos Lanave	1	1994	3	11	F	7	6ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11447	ISABELA DE SÁ GALVÃO	1	1994	3	14	F	159	6	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10727	HUGO MARTINELLI CRUZ	1	1996	6	17	M	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12762	Guilherme Müller de Oliveira Alves	1	1994	5	1	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12759	Gabrielle Holanda Brayer	1	1994	8	25	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15287	GABRIELA VITORIA DE LIRO SILVA	1	1995	7	2	F	555	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15763	FABIO HENRIQUE CORA BRANDT	1	1994	2	9	M	573	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13873	Diego Sousa Rios	1	1993	9	21	M	518	Fundamental	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14397	DANTE ALIGHIERI MIRANDA DOS SANTOS	1	1995	2	17	M	179	7º ANO	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11420	DANIEL PEREIRA AYRES NETTO	1	1994	8	12	M	159	5	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15281	DANIEL FIRMINO OMENA	1	1994	10	1	M	555	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10889	Catharina Teston Vasconcelos	1	1995	3	13	F	258	5ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10883	Carolina Clepf Pagotto	1	1994	9	1	F	258	5ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13075	Carolina Chaves Pinheiro	1	1995	1	25	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13721	Carlos Magno Queiroz da Cunha	1	1994	9	12	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15404	CASIMIRO GOMES PEREIRA NETO	1	1994	10	20	M	555	6ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10701	CAROLINA RAMOS LEDESMA	1	1995	6	30	F	57	5ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10769	CAROLINA PLASTER PETRIS	1	1996	12	22	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12703	Bruno Teixeira Rodrigues	1	1994	6	3	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15402	BRENDA DA SILVA SANTOS	1	1994	5	28	F	555	6ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15214	Agata Siqueira Salles	1	1994	3	30	F	144	6ª Série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14297	ADRIANO XAVIER JUNIOR	1	1994	4	19	M	5	6o A	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13631	Weidda Thum Diogo de Sampaio	1	1995	11	24	F	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13914	Tatiana de Arruda Simões Grazina	1	1995	4	5	F	544	5a série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13487	Stéfano Affonso dos Santos	1	1994	6	17	M	540	6a série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16045	Roberto Falaguasta Nishimura	1	1995	7	4	M	259	5ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13436	RODRIGO BRÍGIDO DANTAS	1	1993	9	29	M	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12049	PEDRO MIHALY DE CAMARGO	1	1994	4	8	M	215	16MA3	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12734	Mariane Duarte de Oliveira 	1	1994	9	20	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12790	Maria Clara Amaral de Carvalho Sá Barreto	1	1993	11	29	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14537	Marcelo Paralta Fernandes	1	1995	7	8	M	545	5a	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16058	Maite Marti Ciancirullo	1	1994	9	23	F	259	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12730	Luiz Felipe Quintania Pinto	1	1995	4	6	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16004	Lucas Reges	1	9999	99	99	M	207	5a. série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13624	Leilane Soares Marques	1	1994	3	17	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2989	LUISA ONOFRE FEITOSA LIMA	1	1994	8	6	F	57	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11138	Júlia Lacava Astolpho	1	1996	2	5	F	258	5ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11220	JULIANA LIMA MARTINS JUCA	1	1994	7	22	F	196	6ªSérie - Gama	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16059	Giovana Zanferdini de Oliveira	1	1994	6	20	F	259	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12009	GISELLE CICERA HOLANDA ALVES	1	1993	11	28	F	196	6ª Série - Gama	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11689	Fernando Dantas Mamede	1	1995	12	14	M	526	6ª Série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13899	Felipe Gujel Jacob	1	1995	8	20	M	544	5a série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10692	FELIPE GONÇALVES TIMM	1	1995	5	25	M	57	5ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16068	Eginaldo Luis Elias	1	1993	12	26	M	259	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12752	Danielly dos Santos Lapa	1	1993	3	27	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1422	Daniela Nussbacher	1	1994	8	8	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10894	Celso Dagmar Milaneto Junior	1	1993	12	17	M	258	6ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
125	CASSIO RAMOS CAPRINI	1	1994	7	19	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10713	CAROLINE SIMOES CORREA	1	1995	10	31	F	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11418	Bruno Fontes Franceira	1	1994	12	15	M	159	5	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15381	BEATRIZ FRANCO RODRIGUES	1	1995	2	14	F	555	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15689	Alberto Miguel Talaveira Filho	1	1994	7	7	M	8	sexta série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12810	Yuri Tatsch Guia	1	1993	12	18	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15450	Thaís Lima da Silva	1	1994	6	6	F	473	5 E	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10544	Saulo Augusto Florence	1	1994	5	7	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13677	Sandra Maia Marques	1	1994	2	20	F	367	6ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13793	Samuel Aprígio Carvalho Maia Vale	1	1995	6	27	M	516	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15564	Rômulo Igor de Carvalho	1	1995	2	17	M	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10732	Rodrigo Vieira da Silva 	1	1995	6	29	M	473	5 D	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11045	Robson de Almeida Vitor	1	1995	2	14	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15443	Rebecca Nobrega Ribas Gusso	1	1995	5	17	F	483	5ª d	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13662	Raíssa de Souza Carvalho	1	1995	10	30	F	367	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13738	Rafaela Roismann	1	1994	3	3	F	318	6ª Série C	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12390	Pedro Carvalho Oliveira	1	1994	12	3	M	293	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16063	Nicole de Oliveira Nahas	1	1994	5	19	F	259	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16050	Nicole de Castro Silva Nicollela	1	1195	3	28	F	259	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11828	NICELLY BATISTA COSTA	1	1994	12	15	F	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12509	Mônica Ribeiro dos Santos Ramos	1	1994	2	22	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16051	Matheus Maciel	1	1995	9	12	M	259	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12391	Mariana dos Santos Sales	1	1995	9	19	F	293	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11866	Marcos V. Silva	1	1994	1	1	M	313	5ªE	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12432	Lícia Camila de Abreu	1	1995	2	24	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11393	Lucas José Sene 	1	1994	12	7	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15510	Lucas D'Angelo Santos	1	1994	3	23	M	497	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15152	Luca Peixoto Ribeiro da Silva	1	1992	10	21	M	512	7ªA	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10685	Luan Henrique Aparecido dos Santos	1	1994	5	30	M	473	6 A	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11570	Liriane Conceição Teixeira de Lima	1	1994	12	8	F	350	4ª A	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10892	Leonardo Prata Maciel	1	1994	8	16	M	258	6ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12148	Laís Caroline Fávero	1	1995	2	12	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10826	LETÍCIA DE SOUZA PIRES	1	1994	8	11	F	373	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10823	LEANDRO FERNANDES GERVÁSIO	1	1995	5	28	M	373	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10991	Jussara Correia da Silva	1	1994	2	21	F	313	6ªD	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12431	Josê Ângelo Galvani de Freitas Neto	1	1995	1	10	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16061	Jordana Alexia S. Santos	1	1994	7	4	F	259	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15158	Jayne Meireles da Silva	1	1993	3	14	M	512	7ªC	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12954	JOÃO SEVERINO DA SILVA SOBRINHO JÚNIOR	1	1994	7	20	M	236	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12953	JOÃO PEDRO SALES MONTEIRO	1	1994	11	10	M	236	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14191	Ingrid Laís Monreal	1	1993	12	28	F	293	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10966	Haliston Marques Torres	1	1995	5	25	M	511	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11871	HENRIQUE YOSHIO SHIRAIWA	1	1995	8	21	M	487	5 EF	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12202	Gustavo Felipe Ferreira	1	1994	9	25	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13556	Giovanni Villius Righetto Mockus	1	1994	8	3	M	285	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10522	Gabriela Apolinário	1	1993	10	22	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11756	Gabriel Alberto Da Silva	1	1994	6	10	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14594	GUILHERME LIVRERI STEIN MANPRIN	1	1994	4	25	M	215	16TA3	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10816	GABRIEL MONTENEGRO TÁVORA	1	1995	7	9	M	373	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10541	Fellipe Cavalcante Freitas	1	1994	7	23	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11580	Eugessicon José da Silva Lima	1	1993	3	15	M	350	5ª B (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13805	EVELINE CARVALHO DE BRITO	1	1994	12	12	F	467	5ª SÉRIE GAMA	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13648	Davi Rodrigues Chaves	1	1995	1	5	M	367	6ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11100	Carolina Rita R.	1	1993	10	26	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15546	Carlos Frederico do Santos Silva Neto	1	1994	2	26	M	497	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14589	CAROLINA AYUMI SATO	1	1995	1	28	F	215	15TA3	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14588	CAROLINA AYUMI SATO	1	1995	1	28	F	215	15TA3	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12950	CAMILLA LAILLA CASTRO BALTAZAR	1	1994	5	11	F	236	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10509	Bruna Rosa Dantas	1	1994	10	14	F	473	5 A   	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11766	Augusto Felipe Macedo 	1	1995	6	25	M	313	5°B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12417	Ana Carolina Silva Moraes	1	1995	5	3	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11112	Ana Carolina R. Ferreira B.	1	1993	7	7	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12512	Ana Carolina Alves	1	1993	9	6	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15545	Amanda Corrêa Pazzotti	1	1994	3	11	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10785	Ítalo Tobias de Souza Dantas	4	1988	12	23	M	490	1º período de Ciências de Computação	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10843	VINICIUS OLIVEIRA DE FIGUEIREDO	1	1994	12	15	M	373	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10788	Renato Hugo Silva de Almeida	4	1988	1	28	M	490	1º período de Ciências de Computação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10786	Marcelo de Barros Barbosa	4	1988	5	6	M	490	1º período de Ciências de Computação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10787	Jefferson Bruno de Oliveira	4	1988	4	11	M	490	1º período de Engenharia de Computação	\N	\N	\N	42	\N	\N	1	255	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15771	VITÓRIA H. CAUDURO	1	1994	7	27	F	573	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12802	Thais Santos Pinto 	1	1993	11	29	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12293	THAINA NOBRE BARROS RODRIGUES	1	1994	7	25	F	196	6ª Série - Master	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10645	Simone Giacomelli Politi	1	1994	11	5	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15437	SINTIQUE FRAGOSO ALVES	1	1994	5	10	M	555	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4218	ROMANA DONADI BENASSI	1	1995	12	27	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15321	RAFAEL LEITE SABOIA JACOME	1	1994	5	16	M	555	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15682	Nelson Akio Shirabe Junior	1	1995	8	18	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10720	Nathan Kuperman Semer	1	1994	12	23	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12792	Miriam Lopes Azevedo da Silva	1	1993	11	12	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15308	Lia Sobreira Diógenes Paiva	1	1994	1	22	F	555	6	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16002	Leonardo Lombardo Peixoto	1	9999	99	99	M	207	5a. série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11443	LUISA DANIEL DE MOURA	1	1994	1	7	F	159	6	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10709	Karen Lewinski	1	1995	1	20	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15679	Karen Hidalgo Faustini	1	1995	3	30	F	8	quinta série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13481	Karen Goes Lopes de Oliveira	1	1993	12	20	F	540	6a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12721	Julia Abreu Camarinha	1	1995	3	9	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15298	JOÃO CAETANO CORREIA DOS SANTOS	1	1994	11	6	M	555	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15070	JOANA MCLAUGHLIN DE FRANCISCO	1	1995	5	17	F	11	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2984	ISABELLE DAMBISKI PEREIRA DA SILVA	1	1994	5	13	F	57	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10772	IGOR BAITELO	1	1996	11	26	M	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15292	Humberto Egydio Queiroz	1	1994	7	1	M	555	6	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12711	Fabio da Silva Pereira Junior	1	1994	12	7	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15062	FELIPE ALVES CHIERIGHINI	1	1995	2	22	M	11	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14610	Emerson Leão de Andrade Silva	1	1993	2	7	M	545	5a	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11874	DANIEL MATOS DE ARAUJO	1	1995	4	29	M	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15764	DANIEL BARBOZA	1	1994	10	9	M	573	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12751	Bianca da Rocha Aquino	1	1991	10	30	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14462	André Luis Magalhães Soares	1	1993	10	24	M	112	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1386	Amanda Linker	1	1993	10	29	F	153	6ª Série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12692	Adrianne Oliveira Viana Lopes	1	1995	6	7	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12744	Victor Gabriel Lages Ferraz de Lima	1	1995	1	13	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15054	Victor Bertoloto Rocha Camargo	1	1993	12	19	M	541	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4985	Valter Barboza Lorenzo	1	1994	2	3	M	207	6a. série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1437	Thomas Grubman Neves	1	1993	8	9	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12799	Thaiana Holanda Alves	1	1993	3	24	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14768	THIAGO PEDRO TOSTES	1	1994	11	6	M	179	6º ANO	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12795	Ricardo Francisco do Nascimento	1	1993	8	4	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14429	Raquel Rocha de Oliveira	1	1994	10	13	F	112	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15319	RAFAEL EVANGELISTA PIMENTEL GOMES	1	1995	9	25	M	555	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13486	Paulo Gustavo Pulino Consorte	1	1993	12	19	M	540	6a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10722	Patrícia Kirsneris	1	1995	2	14	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14545	Matteo Bernardo Mascarenhas	1	1994	4	20	M	545	6a	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13912	Maria Luiza Cury de Barros	1	1994	11	8	F	544	5a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15394	MURILO CAVALCANTI SÁ DE ABREU	1	1994	8	17	M	555	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16003	Lucas de F. Maia	1	9999	99	99	M	207	6a. série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12727	Leticia da Costa Silva	1	1995	8	14	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13088	Leonardo Vieira de Oliveira e Cruz	1	1994	9	6	M	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12295	KEZYA DE MORAIS GUANABARA	1	1993	7	25	F	196	6ª Série - Master	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13159	Joaquim Vanderlito Gomes Franklin Neto	1	1993	5	25	M	40	6ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15250	JONATAS CHAGAS SALES MESQUITA 	1	1994	8	21	M	196	6ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13905	Henrique Pássaro Pompilio	1	1995	1	5	M	544	5a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12716	Guilherme Moreira Rodrigues Cardadeiro	1	1995	5	18	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15288	Gabriela Costa e Silva	1	1994	1	7	M	555	6	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12969	Fernanda Pardo Campos Freire	1	1995	3	24	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10751	Fernanda Golovaty Asnis Weber	1	1993	12	21	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11450	FELIPE JAMAL PEREZ AZZAM	1	1994	1	21	M	159	6	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12004	EVELINY ANGELA SOARES SILVA	1	1995	1	15	F	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1513	Caio Priszculnik	1	1993	11	6	M	153	6ª Série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12700	Bianca Pinto Garofalo	1	1993	2	25	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15690	Beatriz Begnini Borsato	1	1994	5	11	F	8	sexta série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15273	ARTHUR BARBOSA LIMA	1	1995	2	24	M	555	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15380	ANDERS0N CUNHA MARTINS	1	1995	3	3	M	555	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14538	Victor Rabechi Borgi	1	1995	2	15	M	545	5a	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10955	Vinícius Daruni Carloni Barbosa	1	1995	12	6	M	511	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10585	Victor P.Felix	1	1994	4	2	M	473	6ª C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12265	VICTOR EITI YAMAMOTO	1	1994	12	22	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13828	Thiago Barreto Ximenes	1	1993	8	29	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15565	Tatiane Barberá Gallego 	1	1995	5	8	F	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10838	THAIS RODRIGUES DE SOUZA	1	1994	12	19	F	373	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11185	TAISY CATARINE SILVA PAIXÃO	1	1993	12	6	F	373	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12491	Stefânia Pérri Zavagli	1	1993	11	10	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13889	Sarah Carolina do Amaral Souza	1	1995	9	19	F	318	5ª Série A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11785	Sabrina Emídio De Paula	1	1993	11	19	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15153	Rodrigo Pereira de Oliveira	1	1992	11	20	M	512	7ªA	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10951	Rafael Clemente	1	1995	5	18	M	511	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12524	Priscila Rocha Silva	1	1993	8	21	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11543	Micaela Caetano da Silva	1	1995	5	25	F	350	3ª B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10524	Maycon Henrique Ramos Bairral	1	1994	5	7	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11566	Mauro Rocha do Nascimento	1	1996	4	5	M	350	4ª A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12465	Matheus Reis de Souza	1	1995	4	28	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10828	MATHEUS NICOLAS DIAS OLIVEIRA	1	1994	8	22	M	373	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14996	MARK T. CHU	1	1995	11	13	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11091	Luciano Herédia Júnior	1	1994	4	1	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13687	Lucas Sousa Cavalcante	1	1994	11	20	M	367	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11170	Lucas Henrique de Oliveira	1	1994	7	29	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14725	Lidiane Dias Branco Ribeiro	1	1993	6	8	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10570	Leandro Lima Silva	1	1993	8	5	M	473	6 E	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13657	Laís Fabrício de Oliveira Cunha	1	1994	4	26	F	367	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10824	LUCAS PASSOS LIRA	1	1993	4	25	M	373	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14717	Kamila Ribeiro Prado	1	1993	12	11	F	312	6ª B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10989	Juliana Souza Santos 	1	1993	8	23	F	313	6ªD	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10682	Juliana Godoy dos Santos	1	1993	5	26	F	473	6 A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10959	João Pedro Sanches	1	1994	1	12	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11289	Ivan Ribeiro Barreto da Costa	1	1995	5	5	M	511	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12362	Iago Carvalho de Araújo	1	1994	12	5	M	318	5ª Série D	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11169	Heber Souza do Nascimento Alves	1	1995	4	11	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14107	Gustavo Osteiro The	1	1995	1	19	M	516	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15527	Gustavo Laranjeira Wierzba	1	1994	1	6	M	497	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11062	Gustavo Ferreira Paiva	1	1995	2	3	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10515	Gebry Wendel Dorta 	1	1993	5	8	M	473	6 D	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12377	Gabriel Souza Amaral	1	1995	7	21	M	318	5ª Série C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11571	Fábio Barbosa da Silva	1	1995	10	26	M	350	5ª A (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10677	Franciele Cristina Carvalho	1	1993	11	8	F	473	6 A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10518	Franciele Andreza Mariano	1	1993	10	25	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10654	Edson Ap. de Souza Filho	1	1993	8	26	M	473	6 A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10849	ELISA RIBEIRO PINTO DA SILVA	1	1993	12	31	F	373	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14425	Davi Lima Mesquita	1	1993	9	8	M	526	6ª Série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10579	Christiellen Ap. Moreira	1	1994	5	6	F	473	6ª C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15566	Catharine Momenti	1	1995	4	10	F	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13291	Carlos José de Andrade Silva Filho	1	1994	4	2	M	518	Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13470	Caio de Oliveira Fanti	1	1995	1	26	M	540	5a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13023	CAROLINE SCHERMA DE CARVALHO	1	1994	11	16	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13017	CAROLINA PODBOI BAGGIO	1	1995	6	2	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15535	Breno D'Angelo	1	1995	2	19	M	497	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11787	Bianca Cristina De Morais	1	1993	9	2	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11320	Beatriz Zeitune de Souza Toledo	1	1994	12	1	F	511	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10845	BRUNO RODRIGUES MENDES	1	1994	3	10	M	373	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15514	Artur Cunha Dubeux Navarro	1	1994	4	26	M	497	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14360	Ana Paula Fiumana Scoparo	1	1994	3	7	F	517	sexta	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15567	Ana Flávia Bergamaschi	1	1995	4	3	F	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11868	Ana Carolina de Oliveira Rocha	1	1994	1	1	F	313	5ªE	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15154	Amanda de Souza Silva	1	1993	11	9	F	512	7ªB	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13467	Amanda Vitória Moraes Padilha de Araújo	1	1995	6	14	F	540	5a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10549	Adriele M. Machado Candido	1	1994	3	21	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13014	ANDRÉ BOLOGNA DE CASTRO CARDOSO	1	1994	9	30	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10847	CAROLINA TAVARES ABDALAH	1	1994	2	21	F	373	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11401	Bruna Michele Gomes Marques	1	1994	8	16	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13009	AMANDA BERGAMIN MITO	1	1993	12	30	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11429	WILBERT OULEE	1	1995	7	11	M	159	5	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1405	Victor Rawet Dotti	1	1994	3	5	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11134	Victor Pucinelli Paffaro	1	1995	5	25	M	258	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12028	VINICIUS MIAZAKI	1	1995	2	13	M	215	15MA2	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14874	Thiago Belfiore Vicari	1	1994	6	17	M	285	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5042	Thayná Vieira de Souza	1	1994	10	11	F	207	6a. série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16067	Thais Mantovani	1	1994	3	31	F	259	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10760	Tally Lichtensztejn Tafla	1	1994	2	5	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12627	THIAGO CARNEIRO MEDEIROS	1	1995	1	21	M	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10746	THAINA GONÇALVES DE FREITAS PRADO	1	1996	10	22	F	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10784	TADEU AUGUSTO CHAINÇA RODRIGUES	1	1996	9	14	M	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1531	Rodrigo Kagan	1	1994	6	5	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16007	Raphael dos Santos	1	9999	99	99	M	207	5a. série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11430	RICARDO PALOU	1	1994	11	8	M	159	5	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12010	RENATO AMARAL BARBOSA 	1	1994	4	30	M	215	16EC	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11877	OSIAS DA PONTE COSTA JUNIOR	1	1995	6	19	M	196	5ª Sérei - Master	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13456	Matheus Abrahão Lima Oliveira	1	1994	2	20	M	112	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13457	Marianny Rêgo Basilio	1	1994	12	4	F	112	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10711	Mariana Kuhn	1	1995	5	7	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4223	MARIANA FOGGETTI NIERI	1	1996	6	29	F	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10777	MARIA VITÓRIA BASTOS MESSIAS	1	1995	10	27	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12209	MARCEL DE PAULA CANDIDO	1	1993	5	26	M	57	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14769	Luis Otávio de Paiva Ribeiro	1	1994	10	31	M	312	5ª C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14190	Letícia Martins Liberalli	1	1994	7	22	F	293	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16069	Leticia Lucas de Maceno	1	1994	2	12	F	259	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14392	LUIZA TRAMONTIN SANTIAGO	1	1995	8	15	F	179	6º ANO	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14852	LEONARDO CORSI MENEGALI	1	1994	11	24	M	122	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12169	Karina Marques Ferreira	1	1994	12	2	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16000	Júlio César Costa da Silva	1	9999	99	99	M	207	6a. série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13141	Juliana Verzani Lima de Almeida	1	1995	7	8	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12437	João Vitor Mendes Santos	1	1995	5	31	M	312	5ª C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14883	João Vitor Araujo Saccardo	1	1993	11	12	M	285	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16066	Jorge Henrique Correa dos Santos	1	1994	6	2	M	259	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12704	Janniely Castro Pereira	1	1994	8	23	F	112	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11436	JOÃO VICTOR SANTOS PELOSI	1	1995	2	8	M	159	5	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13768	JONAS BARRA NIOVA DE MELO	1	1993	11	28	M	215	16EC	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15998	Hofenan Sherman Nunes	1	9999	99	99	M	207	6a. série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12156	Giovani Leandro Marçal Oliveira Passos	1	1992	3	2	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12779	Geam Saraiva Santos	1	1994	9	22	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10703	Gal Goldwaser 	1	1995	9	1	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10935	Gabriela Zimberg	1	1993	8	5	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11432	GABRIEL CUNHA E SOUZA	1	1994	8	29	M	159	5	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15781	FERNANDA OLIVEIRA COSTA FRANCISCO	1	1996	1	16	F	57	4 SÉRIE B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14434	Eloan Hipolito de Lima	1	1994	6	27	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14216	Edson Rovay Neto	1	1994	11	22	F	313	5ºE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10351	ELIZANDRA CRISTINA DA SILVA 	1	1995	5	11	F	48	5ª A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10869	ELISAMA JUNQUEIRA FERREIRA 	1	1995	8	23	F	48	5ª D	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12951	DÉRIK FELIPE RIBEIRO SANTIAGO	1	1993	7	27	M	236	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10896	David Lane Bruno	1	1993	7	25	M	258	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10865	DIRCEU LOCATELLI JUNIOR	1	1995	1	5	M	48	5ª C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1514	Carolina Metzger	1	1994	7	27	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1388	Carlos Gilbert	1	1994	4	6	M	153	6ª Série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13595	CARLOS ADEMIR CARDOSO BARROSO FILHO 	1	1995	7	14	M	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12299	CAIO VITOR SAID TORRES	1	1994	2	4	M	196	6ª Série - Master	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12772	Bárbara Castro de Oliveira	1	1995	1	24	F	112	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12411	Bárbara Bueno Silva	1	1994	9	19	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10854	BEATRIZ BIANCO DE OLIVEIRA	1	1995	5	23	F	48	5ª C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13155	Anna Clara Paiva Capelli Ivantes	1	1994	5	18	F	40	6ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13449	Alessandra Ferreira Ribeiro	1	1994	9	30	F	112	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10695	ANDREI DOMINGUEZ ALONSO FERREIRA	1	1993	12	20	M	57	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10369	ANA MARIA PACETTI	1	1994	11	11	F	48	6ª C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11442	ALESSANDRA Z. VAIANO	1	1994	1	29	F	159	6	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13216	Ricardo Ambrósio Curvo Filho	2	1993	10	23	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10902	Wellis Dalin de Souza Garcia	1	1994	4	27	F	258	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10958	Tayná Pinheiro Vilhena	1	1995	3	31	F	511	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15060	ROBERTO CHIERIGHINI	1	1995	1	31	M	11	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13435	RENAN GALVÃO OZORIO	1	1994	8	16	M	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15534	Marina Athanasio	1	1995	2	23	F	497	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12970	Julia Canassa Oliveira	1	1995	3	31	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15149	Fabrício Schneider Martins	1	1994	5	12	M	512	6ªB	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14341	FILIPE VARGAS ROSA	1	1994	2	21	M	5	6o	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12709	Eric Vinicius Souza Moreno de Mattos	1	1993	12	19	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11285	Caroline de Paiva Abrão Carloni	1	1995	5	2	F	511	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13881	Arthur Maccari Nascimento e Silva	1	1995	1	8	M	544	5a série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13476	Vitor Yoshimoto	1	1995	4	29	M	540	5a série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10332	VINICIUS NUNES CAPRINI	1	1994	9	11	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12740	Rômulo da Silva Costa	1	1993	12	29	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12796	Rodrigo Garcia de Oliveira	1	1993	9	20	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15147	Robson Soares de Vargas	1	1994	6	27	M	512	6ªA	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12739	Rafael dos Santos Cerio	1	1995	2	19	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15436	ROSA MAYÃ TOMAZ PINTO	1	1994	7	14	F	555	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15072	RODOLFO CASTILHO CHIERIGHINI	1	1994	10	16	M	11	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11171	Pablo Henrique França de Souza	1	1995	11	8	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15343	Newton Luiz Cordeiro B. Filho 	1	1995	4	12	M	555	6	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13938	Mariana Mascarenhas Orasmo Fontana	1	1994	2	16	F	544	6a série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12789	Marcos Felipe Alves de Almeida	1	1994	4	9	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11298	Marcela Carvalho Pasqua	1	1995	6	2	F	511	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15315	MARINA VALERIO SANTIAGO DA SILVA	1	1994	5	18	F	555	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13932	Lívia Tayar Pimentel	1	1993	9	18	F	544	6a série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12731	Luiza Lages Martins Lopes	1	1995	1	14	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12941	Luiz Antonio Pessatte Azzolino	1	1994	12	5	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13910	Lucas da Silva Souza	1	1994	10	6	M	544	5a série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14363	Lucas Vieira Rezende	1	1994	1	30	M	517	sexta	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15526	Laura Carvalho Cunico	1	1994	7	14	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12782	Larissa Nunes Santos Silva	1	1994	6	2	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11197	Lainara Moreira de Jesus	1	1995	3	9	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12724	Karina Saadi Carvalho	1	1994	9	7	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12780	Karin Ferreira Antunes 	1	1994	1	26	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14154	Kaique Jun Anonni Kushima	1	1995	4	4	M	517	quinta	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15071	JÚLIA SIOLI DE REZENDE LARA	1	1994	10	12	F	11	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13480	João Miguel e Silva Neto	1	1994	3	25	M	540	6a série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14450	João Leopoldo Moui Prim	1	1994	3	12	M	552	6ª1ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13428	JOSÉ ROBERTO LABORDA DA SILVA	1	1993	10	19	M	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12781	Izabelle Bruna Abo-Gaux de Martino	1	1995	3	16	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11110	Ivan Diogo Picoli	1	1994	2	23	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15145	Italo Dias Taboza	1	1994	8	10	M	517	sexta	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12966	Isabella Polatto Roque	1	1995	5	16	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12765	Igor Renato da Fonseca Vasques	1	1993	3	18	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15523	Henry de Lima Nascimento	1	1994	11	27	M	497	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12715	Gisele Duarte dos Santos	1	1995	2	1	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11291	Gabriel Rodrigues Lopes	1	1994	11	28	M	511	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12753	Fernanda Martins de Lima	1	1993	5	22	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11947	Felipe Salazar	1	1995	11	22	M	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13079	Fabiana Coutinho Bodrim	1	1994	12	6	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15280	Djailson Rocha	1	1994	1	29	F	555	6	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12707	Dennys Henrique Rodrigues	1	1995	3	7	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15424	DEBORA RODRIGUES MARINHO	1	1995	4	24	F	555	7ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15063	DANIEL DUARTE MARCHETTI	1	1995	3	31	M	11	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15384	CRISTIANE SARAIVA MAIA	1	1995	8	28	F	555	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15278	CAMILA FERNANDES DE LIMA	1	1995	8	4	F	555	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15076	BEATRIZ H. TOCACHELO	1	1995	3	22	F	11	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14128	Antônio Augusto Lima Araújo Filho	1	1994	8	30	M	516	5ª Série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12749	Anaís Bandeira Martins	1	1993	11	20	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13533	Ana Áurea Araújo Lima	1	1994	2	20	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13423	ARIEL MARTINS ANDRE	1	1994	1	18	M	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15399	ANDERSON DE OLIVEIRA SILVA	1	1993	11	9	M	555	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14333	ALANA BRUNA RUFINO LEONEL	1	1994	2	16	F	5	6o	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13477	Zacarias Gonçalves Bráz	1	1994	8	18	M	540	5a série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14497	VANDRÉ VINÍCIUS DE OLIVEIRA BANDEIRA	1	1994	7	2	M	467	6ª SÉRIE GAMA	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10656	Tiago Dantas de Santana	1	1994	2	16	M	473	6 A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10841	TIFFANY CAROLINE DE SANTANA MATOS	1	1995	1	9	F	373	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10425	THIAGO PEDRO ALVES	1	1993	4	20	M	461	6ª SÉRIE AZUL	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11821	THIAGO AURÉLIO RODRIGUES	1	1995	8	28	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13214	THAMIRES MACHADO COSTA LUZ	1	1994	12	29	F	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13584	Sofia Beatriz Dias de Oliveira	1	1994	6	9	F	482	6ª série C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11544	Salvatório José de Santana	1	1992	5	3	M	350	3ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13213	SIDNEI DE PAULO JUNIOR	1	1994	5	25	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14292	Regina Celly de Almeida e Silva Pinheiro	1	1995	7	27	F	488	5ª Série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13521	Rebeca Gomes de Morais	1	1995	6	11	F	318	5ª Série A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11578	Rayana Honorato da Costa	1	1997	6	25	F	350	3ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11575	Rafaela Nascimento da Silva	1	1997	4	25	F	350	2ª B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13212	RODRIGO DE CAMARGO SOUZA	1	1994	5	1	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14213	Poliana Lima de Paula	1	1994	1	1	F	313	5ºE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10669	Paulo  Henrique Delgado de Oliveira	1	1994	6	30	M	473	6 A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13211	PEDRO RODRIGUES NETO	1	1993	3	12	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10688	Nicolas Bernardo dos Santos	1	1993	11	12	M	473	6 A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13671	Natália Rocha Furtado	1	1995	4	26	F	367	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13252	NIVALDO DONIZETE L. FILHO	1	1994	11	19	M	59	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10427	NAILA RAYANNE VIEIRA DO NASCIMENTO	1	1994	8	6	F	461	6ª SÉRIE AZUL	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11022	Matheus  M. de Britto	1	1995	6	16	M	473	5 D	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11567	Marcilio Rocha Nascimento	1	1997	5	3	M	350	2ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10829	MAYKON MADEIRA GOMES	1	1995	2	16	M	373	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11183	MARCUS VINICIUS GONÇALVES DE OLIVEIRA	1	1994	3	15	M	373	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14850	Lêda Micheline Dias de Castro	1	1995	9	1	F	367	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14629	Lucas Olivati	1	1994	3	8	M	482	6ª série A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10569	Letícia Fernandes	1	1994	11	9	F	473	6ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10530	Leticia J. Daniel Badia	1	1994	1	12	F	473	6 D	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11179	LUCAS TARANTO PEREIRA	1	1994	3	1	M	373	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10439	LUCAS RIBEIRO ALBUQUERQUE	1	1995	8	7	M	488	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10721	Kassiana Cristina Silverio da Costa 	1	1995	3	2	F	473	5 D	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10822	KAREN SCAZUZO DE CARVALHO LIRIO LUZ	1	1995	5	2	F	373	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11872	José dos Reis de Carvalho	1	1994	1	1	M	313	5ªE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11577	José Rodrigo da Encarnação	1	1991	4	10	M	350	5ª C (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15451	Joice Domingues de Oliveira	1	1995	6	16	F	473	5 E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14953	Indaiana Aparecida Teixeira	1	1993	10	20	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14202	Guilherme Duarte Constantino	1	1995	5	14	M	313	5ºE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15525	Gabriela Gonzalez Gonçalves	1	1994	2	18	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12641	Gabriela Barbosa de Carvalho	1	1995	8	6	F	318	5ª Série B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10850	GABRIEL CUQUEJO ALVES	1	1993	11	19	M	373	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10687	Fábio Henrique Dias da Silva	1	1994	1	15	M	473	6 A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13210	Flávia Mallaco Moreira	1	1995	4	27	F	318	5ª Série B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15446	Felipe Lovato Santana	1	1995	10	24	M	483	5ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11582	Eugecicleide da Silva Lima	1	1995	5	29	F	350	4ª A (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10525	Dhennis W. F. Bueno	1	1994	2	23	M	473	6 D	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11918	Daniel Lolling Cerri Hebling	1	1994	1	14	M	482	6ª série C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10576	Cleber Pereira dos Santos Junior	1	1994	9	26	M	473	6 E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15511	Caio Montibelle Pereto	1	1994	3	22	M	497	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10848	CAROLYNE CORREIA LEAL	1	1993	11	15	F	373	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13257	CARLA DE LIMA BARBOSA	1	1994	12	27	F	59	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13574	Amanda Baungartner	1	1994	5	9	F	482	6ª série C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11549	Alice do Nascimento Nunes	1	1996	9	24	F	350	3ª B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15444	Alice Simoes de Oliveira	1	1995	7	26	F	483	5ª D	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14636	Alexsandro Rosa Januário	1	1995	1	1	M	313	5ªE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13258	ANA LAURA Q. MINCHILO	1	1994	10	31	F	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10442	VICTOR GABRIEL RUSSO GALVÃO	1	1994	4	27	M	488	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10839	TATIANA DE ABREU PIRES DE ANDRADE	1	1995	6	2	F	373	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11585	Roberto Carlos Filho	1	1994	12	31	M	350	4ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11187	RENAN SALDANHA ANTUNES DIAS	1	1994	4	9	M	373	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10563	Otavio Luís Vidal 	1	1994	10	19	M	473	6 E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10832	NELSON LUÍS LOPES FERREIRA	1	1993	10	6	M	373	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12364	Barbara Mari Miyahara	1	1995	3	19	F	318	5ª Série D	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13233	MATHEUS PERSEGHETTI SARTORI	2	1993	5	30	M	571	1-7MA2	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10888	Vinicius Ribeiro	1	1995	1	5	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11428	VITÓRIA NAZZONI BISTULFI	1	1995	2	11	F	159	5	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13786	VIKTOR LENSCH	1	1993	11	18	M	215	16MB2	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11461	VICTÓRIA VICENTIN	1	1995	10	19	F	159	5	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15956	VALDÍZIA DE FÁTIMA LIMA DE SOUSA	1	1995	5	28	F	236	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11069	Thaís Isabele Ribeiro de Almeida	1	1994	6	12	F	313	6ªB	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16043	Ivany Gana	2	1992	7	6	F	78	8EF	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12637	THABATA EMANOELLE DE LIMA	1	1994	7	27	F	215	15EC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10228	Steffy Leventhal Lucki	1	1994	3	7	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10758	Stefanie Heilbut Serson	1	1994	6	14	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14878	Sidney Aparecido Piva Junior	1	1994	4	1	M	285	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10603	Samantha Wexler Blanc	1	1995	8	14	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12162	Rosângela Aparecida dos Anjos	1	1994	11	7	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10635	Rony Levy	1	1995	11	16	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10601	Rodrigo Schleif	1	1995	3	1	M	153	5ª  série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10880	Renan Felipe Pimentel	1	1995	7	31	M	258	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11003	Regiane Emanuele Sant' Ana	1	1995	8	31	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12947	ROBSON ADRIANO GUERREIRO MAIA	1	1995	2	18	M	236	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12961	RAIMUNDO KAIO RODRIGUES LIMA	1	1993	9	18	M	236	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11103	Natally Rodrigues Silva	1	1993	12	18	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11435	NATÁLIA LEOPOLDO E SILVA ABDALLA	1	1994	12	28	F	159	5	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16060	Matheus Franco	1	1994	4	15	M	259	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10885	Mateus Carneiro Pires Nascimento	1	1994	1	7	M	258	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11106	Marcos Antônio Lopes	1	1991	7	6	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11046	Lucas Ferreira da Silva	1	1994	11	26	M	313	5ºE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14873	Lucas Chamati Pereira Carneiro	1	1994	4	12	M	285	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14879	Leonardo Buscariollo	1	1994	5	31	M	285	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11074	Laura Caroline Alencar Nazaré	1	1994	3	9	F	313	6ªB	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11784	Karoline F. Santos	1	1994	3	24	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12161	Jéssica Beatriz de Matos	1	1994	7	21	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12956	JOSÉ EDINARDO CAMPÊLO BESSA FILHO	1	1994	8	29	M	236	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15959	JENNIFER NAOMI NAGOO	1	1994	11	30	F	215	16TA3	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16064	Italo Luan D. de Almeida	1	1994	9	19	M	259	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11218	ISMAEL CHAVES RODRIGUES	1	1994	5	2	M	196	6ª Série -Gama	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11200	INGRID ALEXANDRE DE FREITAS	1	1995	3	21	F	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11800	Hiago da Rocha Pedro 	1	1993	6	25	M	313	5°E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11392	Guilherme H. Albo de Oliveira	1	1994	3	31	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10877	Gabriel Prestelo Gomes da Silva	1	1995	1	24	M	258	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10893	Gabriel Leonardo C. dos Santos	1	1995	9	8	M	258	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12157	Gabriel Cairo Resende	1	1994	10	26	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13770	GUSTAVO FERREIRA SILVA	1	1993	10	4	M	215	16EC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12050	GUILHERME COMPAGNOLI LEME	1	1994	5	12	M	215	16MA3	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11434	GABRIELA ROYA POTYE	1	1995	2	10	F	159	5	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13143	GABRIEL DE MORAES FERREIRA	1	1995	3	10	M	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11006	Fábio Henrique Cristiano	1	1995	4	12	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10954	Francieli Luiza  Ap. Perri	1	1994	1	21	F	313	6ª E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11396	Felipe Ribeiro Calé	1	1994	12	14	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14766	Everton dos Santos Ferreira	1	1993	10	4	M	216	6ª Serie do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11040	Ester Aparecida Ferreira	1	1993	10	22	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14881	Eduarda Fragnan Carrara	1	1993	7	4	F	285	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11195	ERICA MARIA CALIOPE SOBREIRA	1	1994	11	21	F	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11108	Douglas Neves Eleotério	1	1994	5	17	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11394	Diego Rodrigues da Silva	1	1994	5	18	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12497	Deividson Falconi Nicola	1	1994	2	5	M	312	6ª B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12513	Daniela Souza Damasceno	1	1993	10	6	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12489	Daiane Vital Silva	1	1993	10	5	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14186	Cassia L. Tamashiro	1	1995	1	1	F	293	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12481	Carina Cristiane Silva	1	1994	12	4	F	312	5ª F	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11089	Carina  G. Fantini	1	1995	5	2	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12436	Camila Fernandes Correia	1	1994	8	24	F	312	5ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12149	Camila Aparecida da Silva	1	1995	7	24	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10947	Ana Paula Cândido	1	1992	11	14	F	313	6ª E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12467	Ana Carolina dos Santos	1	1995	3	27	F	312	5ª E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12515	Ana Carolina Magalhães	1	1993	9	7	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12463	Ana Carolina Faria Brazão Pinheiro	1	1995	7	3	F	312	5ª E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14175	Amanda Sayeri Gushiken	1	1995	11	7	F	293	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13544	Vinicius Venanzi	1	1995	1	6	M	285	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12741	Tainara Pinheiro da Cruz	1	1994	6	27	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14619	Sandriele Barbosa Pantoja	1	1994	10	9	F	112	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10600	Rodrigo Schenkman	1	1995	3	9	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10633	Raphael Zinger	1	1995	8	12	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
131	RENAN RICARDO PETRI FREIRE	1	1994	3	27	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15683	Pedro Luiz Alves Quintella	1	1995	4	5	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12775	Nadson Garcia Cavalcante	1	1994	9	28	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10718	Michel Radomysler	1	1995	8	30	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15681	Mateus Cruz Capello	1	1995	7	7	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13152	Marcella Monte-Mor Martini	1	1995	7	3	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10333	MATEUS PRATES BÔA	1	1994	8	19	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14657	MATEUS DIRR RICARTO NEPOMUCENO	1	1994	3	12	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10596	Luciana Gurevich	1	1995	1	15	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12728	Lorena Amorim Maito	1	1995	3	24	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10775	LETHICIA DE SOUZA RUIZ	1	1996	10	3	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10710	Kevin Banach 	1	1994	11	18	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10594	Júlia Rosenblatt	1	1995	7	7	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10350	JÉVERSON HENRIQUE BORGES 	1	1994	11	18	M	48	5ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15678	João William de Miranda Garcia	1	1995	4	18	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10592	Henry Avi Salzman 	1	1995	8	29	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13132	Gustavo Henrique Cordeiro Vicente	1	1995	7	6	M	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11948	Gustavo Bittencourt	1	1995	12	28	M	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10704	Giuliana Graicer	1	1995	6	14	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14621	Gisele Almeida Machado	1	1995	6	27	F	112	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15073	GABRIELLA MATTEUCCI MATARAZZO	1	1994	12	6	F	11	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10871	GABRIELA NOGUEIRA DA CUNHA 	1	1994	9	15	F	48	5ª D	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10614	Flavia Waiswol	1	1994	12	21	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14413	Fernanda Soares Alves	1	1993	8	31	F	112	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10612	Fernanda Rozman	1	1995	2	11	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12712	Fernanda Barreto Rodrigues	1	1996	2	1	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10748	Eduardo Mitelman	1	1993	1	6	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13157	Débora Salgueiro de Menezes	1	1994	7	11	F	40	6ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1389	Deborah Nimtzovitch Cualhete	1	1994	5	13	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10610	David Rosset	1	1994	12	14	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10912	David Rocha Macêdo	1	1994	3	3	M	54	Sexta	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15684	Danilo Martinelli do Valle	1	1995	2	20	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14332	DANILO FRANCISCO DOS SANTOS	1	1992	11	30	M	5	6o	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15674	Clovis Benossi Neto	1	1995	6	29	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10697	Bruno Eli Salzman	1	1995	8	29	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10742	Bruna Kirszenworcel	1	1994	4	10	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15673	Bruna Hummig	1	1995	2	17	F	8	quinta série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15691	Bruna Carolina Rodrigues de Lima	1	1994	10	8	F	8	sexta série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14786	BRUNO LA PASTINA CUSIN	1	1996	5	1	M	122	4ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1419	Anna Carolina Krongold	1	1994	9	12	F	153	6ª Série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10587	André Gruc Lezerrovici	1	1995	3	17	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12777	Anderson Rayan Cardoso de Oliveira	1	1995	6	7	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13064	Ana Carolina de Moraes Bueno	1	1995	12	16	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1590	Alan Leonel Hercman	1	1992	10	1	M	153	6ª Série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10853	ANA CLARA MARTINS FERNANDES 	1	1996	3	29	F	48	5ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10860	ANA CAROLINA  F. CASTRO E SILVA	1	1995	8	27	F	48	5ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14615	Marcos Willian Moreira Marinho	1	1993	11	4	M	112	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10617	Letícia Rubinstein Cavalcanti	1	1995	3	29	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15685	João Henrique Tófoli Vasconcelos	1	1995	4	7	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10706	Jairo Rytenband	1	1994	9	11	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15676	Guilherme Martins Scaff	1	1995	1	27	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10714	DANIEL PEREIRA ZITEI	1	1996	3	24	M	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10694	Bruna Esther Veisid	1	1995	5	14	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10589	Bruna Barzilay Ghisserman	1	1995	6	1	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15688	Sarah Giora Mariano de Souza	1	1994	7	1	F	8	sexta série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15687	Letícia Terra Alves Gomes	1	1994	9	16	F	8	sexta série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14415	Elton Douglas da Silva Sousa	1	1996	5	4	M	112	4ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10911	Thaina Bruna F. Silva	1	1994	6	11	F	54	sexta 	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14132	Lucas Brito Maia	1	1994	3	26	M	516	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15285	FABRICIO ANTONIO FREIRE ARAUJO	1	1995	6	19	M	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12748	Alexia Zangerolane Zacconi	1	1993	7	15	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14533	Vinicius Foresti	1	1994	9	19	M	545	6a	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12979	Thiago Zaccaria Ribeiro	1	1994	10	10	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13958	Thiago Arruda Godoy	1	1993	5	22	M	544	6a série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12742	Thalles Moraes de Oliveira	1	1995	6	22	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12804	Tainá Ribeiro Côrtes	1	1994	1	25	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12798	Shallanna Cunha Tosta	1	1994	4	1	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13474	Rodrigo Mariano Balestro	1	1995	8	15	M	540	5a série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12738	Rafael da Silva Bispo dos Santos	1	1993	5	16	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15324	RAYANA CRISTINA DE MORAIS SILVA	1	1995	9	26	F	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15323	RAIMUNDO RODRIGUES MARQUES DOS SANTOS	1	1995	3	10	M	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15327	Priscila Calles Prata Braga	1	1994	8	8	F	555	6	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11282	Pedro Henrique Ribeiro Flório	1	1994	9	8	M	511	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13949	Pedro Henrique Padilha de Abreu	1	1994	5	10	M	544	6a série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15322	Pedro Gabriel Suprimio de Almeida	1	1993	8	1	F	555	6	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13623	Pedro Angelo de Figueiredo A. Passos	1	1994	12	29	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12793	Paulo Roberto de Lima Serra da Conceição	1	1994	4	6	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15156	ODonnel Cristoff	1	1993	1	30	M	512	7ªB	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13482	Mário Henrique Candiotto dos Santos	1	1993	10	5	M	540	6a série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12968	Mariá Tank Ladevig	1	1995	2	6	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12732	Marcos Paulo Estevão da Silva	1	1995	1	12	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15316	MATHEUS BALREIRA GOMES	1	1995	3	5	M	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15311	MARIA ALICE ARAGÃO FELICIO RODRIGUES LIMA	1	1995	8	15	F	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15434	MARESSA LORENNA FERREIRA TURRINI	1	1994	7	27	F	555	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11952	Lucas de Lima Nascimeto	1	1995	7	7	F	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12726	Leonardo da Silva Teixeira	1	1994	7	30	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15406	LARA NAYADE C. DE LIMA	1	1994	7	5	F	555	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12723	Juliana dos Santos de Souza	1	1995	4	12	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13785	José Ivan Lima Jr	1	1995	9	22	M	516	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13543	José Antonio de Faria Neto	1	1994	3	10	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15300	JULIA COVAS QUEIROZ	1	1994	10	4	F	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15295	JAQUELINE ALVES SOARES	1	1994	3	27	F	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12767	Ivete Leticia da Silva Tavares	1	1993	11	23	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12766	Isys Ribeiro Tubino de Azevedo	1	1993	7	12	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13652	Ingrid Filizola Soares Machado	1	1994	8	20	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15290	IARA RICARTE BARROS MONTEIRO	1	1995	12	3	F	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15405	IARA MARIA LIMA NEPOMUCENO	1	1991	5	27	F	555	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12763	Hugo Silva Carvalho	1	1992	10	25	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11314	Gustavo Carvalho Pedrosa	1	1994	7	18	M	511	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11331	Guilherme Gratieri Maciel	1	1993	7	9	M	511	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13902	Guilherme Geraldo Lage	1	1994	12	19	M	544	5a série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11295	Guilherme Andrade Vasconcellos	1	1995	2	9	M	511	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12757	Gabriel Ribeiro Felippe	1	1992	2	5	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12756	Gabriel Felipe Galante de Souza	1	1993	8	2	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14536	Fernando de Moraes Teruel	1	1994	2	22	M	545	6a	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15162	Fernanda da Silva Ferreira	1	1993	1	28	F	512	7ªD	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14327	FERNANDA RIBEIRO SILVA	1	1994	3	26	F	5	6o	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13923	Diego Soares de Melo Costa	1	1993	1	5	M	544	6a série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15430	DAVI VICTOR CAVALCANTE RIBEIRO	1	1993	10	13	M	555	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13920	Carolina de Carvalho e Freita	1	1991	4	27	F	544	6a série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12705	Carolina Passos de Oliveira Bernardes	1	1994	12	9	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13445	Bruno Parente Leitão de Castro	1	1993	8	11	M	526	6ª Série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15151	Bruno Melo dos Santos	1	1994	8	2	M	512	6ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12702	Bruna de Magalhães Vinagre	1	1995	7	7	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15275	Brenda Alley Nobrega Foggia	1	1994	4	17	F	555	6	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12750	Bernard Alvares Luz Matos 	1	1993	9	10	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15276	BEATRIZ RIBEIRO DE ARAUJO ALENCAR	1	1995	3	28	F	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11958	Antonio Felipe Gesing Rosa	1	1995	1	12	M	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13422	ALESSANDRA FAÇANHA BEZERRA	1	1994	1	20	F	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13438	ADRIANE IBIAPINA DE ANDRADE	1	1994	7	25	F	527	6ª Série E	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15383	ADRIANE ABREU DE VASCONCELOS	1	1994	7	9	F	555	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14544	Vitoria Rocha Zatoni	1	1994	3	28	F	545	6a	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11230	Thaís Maria de Oliveira	1	1995	4	23	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11768	Thaís Maria Madeira	1	1995	6	26	F	313	5°C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14954	Talita Francisca Costa Cândida	1	1994	1	1	F	313	5ªD	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11547	Taina de Oliveira Silva	1	1994	5	30	F	350	3ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10840	THIAGO FERNANDES DE SOUZA	1	1994	9	6	M	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11781	Samanta Letícia Rezende	1	1994	11	3	F	313	5°E	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11583	Rhaldney da Silva Alves	1	1997	6	18	M	350	3ª A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11908	Raphael Sartori Santos	1	1993	7	18	M	482	6ª série A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10517	Raiphi Viola Lopes	1	1994	8	25	M	473	5ª C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11216	Poliana Diemert de Oliveira	1	1994	9	30	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10520	Paulo Rogerio Ferrasso	1	1994	6	23	F	473	6 D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10967	Paulo Roberto Vieira Filho	1	1994	4	12	M	511	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14232	Paulo Henrique A. de Paula	1	1994	1	1	M	313	5ºE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10835	POLIANA MONTEIRO GOMES	1	1994	3	9	F	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10833	PATRÍCIA GUEDES LEITE DE ANDRADE	1	1993	12	26	F	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10834	PATRICK MARTINS IUNES PEREIRA	1	1994	9	24	M	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10652	Natália Gomes da Silva	1	1994	5	4	F	473	6 A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10831	NATHALIA DIAS DE SOUSA	1	1995	9	1	F	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11584	Mateus José Leônidas dos Santos	1	1999	8	9	M	350	1ª E	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10948	Mateus Fagundes Senedese	1	1994	9	20	M	511	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11924	Mariano Gabriel Steinberg	1	1994	2	2	M	482	6ª série C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10664	Marcelo Mateus Santos Oliveira	1	1993	3	7	M	473	6 A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10542	Marcela Borsato Colosso	1	1994	6	4	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11180	Leticia Marinho Maia	1	1995	6	12	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11397	Leonardo Marchelli Ribeiro	1	1994	12	24	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11204	Leonardo Luiz Bernardes	1	1995	6	28	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10431	LUCAS ARAUJO RUYS	1	1994	2	5	M	461	6ª SÉRIE VERDE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11178	KARINE DE OLIVEIRA LUZ	1	1994	2	18	F	373	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15532	Júlia Teixeira Vicentini	1	1995	5	5	F	497	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11873	João Paulo de Souza Bueno	1	1994	1	1	M	313	5ªE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15537	Jonas Cavenati Ninni	1	1994	7	24	M	497	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11606	Jessica Mikaele Lopes Freire	1	1994	3	10	F	350	6ª A (Esc. Beira Rio)	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10533	Jean Pabla Bosco	1	1994	1	23	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11830	JULIANNY NAYARA SIEBRA	1	1994	11	24	F	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10821	JORGE AMON SIMAS RIBEIRO	1	1995	3	24	M	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11173	JHONATHAN DE ALMEIDA SANTOS	1	1994	4	3	M	373	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10558	Isabele Cristine de Oliveira	1	1994	1	18	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13871	INGRID MOREIRA FELINTO DE OLIVEIRA	1	1994	9	7	F	488	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10424	IGOR SCHMIDT FURLAN	1	1994	3	9	M	461	6ª SÉRIE AZUL	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11761	Húdson Corrêa Cruz	1	1994	4	7	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10818	HELOÍSE SALLES RIBEIRO AFFONSO	1	1995	6	21	F	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15447	Guilherme Israel da Silva	1	1995	7	18	M	483	5ª C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12376	Gabriela Vallilo Fazenda	1	1994	12	22	F	318	6ª Série C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10543	Gabriel Luis P. Silverio	1	1993	11	5	M	473	6 D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10510	Francielle Cristina Madalena Silva	1	1993	11	19	F	473	6 D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13208	Fernanda Itkes Vale	1	1994	9	15	F	318	5ª Série B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11919	Felipe Valentim Sittolim	1	1993	8	10	M	482	6ª série C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11865	FERNANDO TAKEDA	1	1995	11	8	M	487	5 EF	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12144	FELIPE CREPALDI	1	1994	5	28	M	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11278	Everton Kleber Ribeiro	1	1993	10	5	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12369	Desireé Rodrigues Plaça	1	1995	7	24	F	318	5ª Série A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11192	Daniel Lucas de Oliveira Alves	1	1995	3	9	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10814	DANIEL GONÇALVES DA ROCHA	1	1995	6	2	M	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10679	Camila Tainá de Oliveira	1	1994	11	29	F	473	6 A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10440	CAROLINE RAZERA FERREIRA	1	1994	10	20	F	461	6ª SÉRIE VERDE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14196	Bianca Carolina A. da Rocha Vidigal	1	1995	1	17	F	313	5ºc	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10813	BRUNA NERI TEIXEIRA	1	1994	3	8	F	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15560	Antonio Carlos Chierati Junior	1	1995	4	15	M	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14449	Anna Carolina Porto O. M. Carvalho	1	1995	6	29	F	318	5ª Série B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10568	Amanda G. Marcondes 	1	1993	12	6	F	473	6 E	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14312	Allef Silva Castro	1	1994	3	23	M	488	5ª Série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10844	AGHATA AZULAY MELLO DE SOUZA	1	1994	7	30	F	373	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11838	ADELMA MARIA ROSAL BATISTA 	1	1995	6	23	F	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14890	Marina Magro Togashi	2	1992	5	28	F	285	8ª série	\N	\N	\N	67	\N	\N	1	17	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12266	VICTOR THEG LIN	1	1995	2	24	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1439	Victor Nowicki Szapiro	1	1994	3	27	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11105	Talita das Dores Urbano	1	1993	11	9	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10759	Stephanie Natenzon	1	1994	3	24	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10723	Stephanie Christine Malfatti  Bezerra	1	1995	8	1	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10962	Simone Alexandre Cortez	1	1993	8	16	F	313	6ª E	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10639	Sharon Gonik	1	1995	1	4	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12457	Sarah Jéssica Vicente	1	1995	7	7	F	312	5ª D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10316	Samuel H.Y.Park	1	1993	6	22	M	258	7ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11152	Rodrigo Silva de Oliveira	1	1995	1	18	M	258	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11052	Richard Ananias Avelar	1	1995	7	22	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16006	Rafael Maciel	1	9999	99	99	M	207	6a. série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14681	RICARDO PETERZE STEINBERG	1	1993	12	18	M	215	16TA3	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11073	Pâmela Carolina Lopes	1	1994	8	17	F	313	5ºE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11101	Pâmela Araújo	1	1994	4	30	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11043	Priscila de Souza	1	1993	9	22	F	313	6ªB	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12482	Patrícia Ribeiro de Paula	1	1995	4	19	F	312	5ª F	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12422	Patrick Aparecido dos Santos Imbrizi	1	1995	12	21	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11421	PATRICIA ANONIO FREDIANI	1	1995	5	9	F	159	5	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14880	Octavio Cesar Fonseca	1	1993	10	8	M	285	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10623	Nathan Zavataro Nigri	1	1995	2	13	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10884	Murilo de Albuquerque Duarte Rabelo Lampório	1	1994	11	23	M	258	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11414	ROBSON DUARTE DE CASTRO	4	1987	1	17	M	495	3ª	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13553	Michelle Toaldo Pistori C. Vasques	1	1995	2	4	F	285	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14689	Michele Ribeiro dos Santos	1	1994	1	1	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11076	Matheus Avelino da Silva	1	1995	3	24	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11102	Maristela de oliveira Carvalho	1	1994	6	16	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14700	Marina Gabrielle Gomes Batista	1	1994	1	1	F	312	5ª D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10998	Maria Cláudia de Lima	1	1995	3	22	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12514	Marcelo Martins Filho	1	1994	8	14	M	312	6ª C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14174	Marcella Biomonte	1	1995	12	5	F	293	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11095	Maira Elizabete dos Santos	1	1993	9	23	F	313	6ªc	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11425	MARIANA SANTINAN	1	1995	3	4	F	159	5	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10898	Luiz Filipe A. Meneguetti	1	1993	6	1	M	258	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10986	Luiz Fernando Silva e Silva	1	1993	7	27	M	313	6ªD	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11083	Lucas Moisés Eleoterio	1	1992	1	18	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12492	Luana Tainá da Costa Bevilacque	1	1994	2	1	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12507	Leonardo da Silva Geraldo	1	1994	7	20	M	312	6ª C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11632	LUCAS ROCHA DE OLIVEIRA	1	1994	9	16	M	196	6ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12019	LUCAS MENDES LEITE	1	1994	9	20	M	215	15TA1	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10988	Kevin Nasareth da Silva 	1	1994	6	2	M	313	6ªD	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12945	KAROLINE RODRIGUES LIMA	1	1996	11	15	F	236	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11384	Juliana Evangelista de Oliveira	1	1994	5	24	F	313	6ªB	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11383	Josiane Gonçalves	1	1994	6	17	F	313	6ªB	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11215	JOSE JAIRTO CARNEIRO FILHO	1	1995	5	17	M	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11213	JORGE RIBEIRO DA SILVA	1	1994	11	27	M	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15958	JONATHAN GUEDES	1	1995	1	9	M	215	15TC1	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11025	Guilherme Ferreira Paiva	1	1995	2	3	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16048	Giovane de Mello de Souza	1	1995	5	27	M	259	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10993	Giovana Andresa Melo	1	1994	6	21	F	313	6ªD	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11098	Gabriele Ap. dos Santos	1	1994	4	16	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12191	Gabriela Rodrigues Silva Gomes	1	1995	7	17	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14684	GUILHERME SANTOS STEAGALL PERSON	1	1994	2	17	M	215	16MA1	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11075	Flávio Araújo da Silva	1	1993	9	3	M	313	5ºE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14176	Fernanda Caroline de Souza	1	1995	11	27	F	293	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12498	Felipe Oliveira Cardoso	1	1994	6	29	M	312	6ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12488	Daniella de Melo Teófilo	1	1993	7	28	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12518	Daiane Araújo dos Santos	1	1994	1	15	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14194	Caroline Marques de Melo Rocha	1	1994	4	3	F	293	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12522	Caroline Cristina Rosa Ribeiro do Valle	1	1993	7	2	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14178	Carlos José Gonçalves de Lima Júnior	1	1995	10	12	M	293	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11064	Camila Cristina de Morais 	1	1994	1	31	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12428	Bruno Felipe Diogo Victor	1	1994	8	5	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12493	Amanda Helena da Silva	1	1994	4	29	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12632	ARTHUR LARA CEBOLLINI	1	1995	4	27	M	215	15TA1	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12942	ANA MICHELLE DOS SANTOS MAIA	1	1994	10	18	F	236	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4444	Matheus Radespel Vaz	2	1988	4	18	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15340	WANESSA COSTA BARBOSA ABDALA	1	1995	3	17	F	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14416	Rogerio de Meneses Delgado	1	1995	7	12	M	112	4ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15333	Roberta Maia de Vasconcelos	1	1994	2	8	F	555	6	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10342	RAFAEL ALVES MOREIRA	1	1994	3	3	M	48	6ª A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14418	Paula Burgarelli Alves de Aguiar	1	1993	11	13	F	112	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10782	PABLO HENRICK BARBARA	1	1996	5	13	M	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14614	Nohan da Silva Vitor	1	1993	7	9	M	112	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14335	NICOLE SUÍVES STARLING	1	1994	5	30	F	5	6o	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10780	NATALIA CANTUARIA DA SILVA	1	1996	12	18	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12733	Maria Elisa Bezerra Viana da Silva	1	1995	2	28	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15426	MARIANA BARRIO CARDOSO	1	1994	11	21	F	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14442	Luan da Silva Almeida	1	1993	8	10	M	112	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12785	Luan Lima Santos Braga	1	1994	1	7	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12783	Layssa Chaves de Andrade	1	1994	4	1	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15306	Lara Arruda Vieira Costa	1	1994	9	18	M	555	6	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10773	KIMBERLY MAZAGAO FERREIRA	1	1995	12	2	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10730	JULIA FRAGA DE FREITAS GUIMARAES	1	1996	5	28	F	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14253	JONATHAN H. A. PEREIRA	1	1995	12	19	M	5	5º 	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10593	Isabela Jungerman Chusid	1	1994	12	27	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15677	Isabela Bendine Gastaldi	1	1995	5	1	F	8	quinta série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10616	Ilan Wajsfeld	1	1995	4	24	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12717	Igos Eiras Teixeira Langoni	1	1994	11	23	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13084	Hanna Fagerlande Amendoeira	1	1994	12	17	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1522	Haim Fridman	1	1994	4	20	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15675	Gian Lucca Mortari Abrahão da Silva	1	1992	11	7	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12714	Gabriela Cristina de Assis Oliveira Novaes	1	1994	12	10	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2990	GABRIELA ALVES DO NASCIMENTO	1	1994	4	16	F	57	6ª série B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15066	GABRIEL COELHO RANGEL	1	1994	12	8	M	11	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10753	Fernando Roger Lowenthal	1	1994	1	3	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12754	Fernanda Mota Canuto Oliveira	1	1993	6	26	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1392	Felipe Gruc Zyman	1	1994	3	28	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14623	Euler Silva dos Santos	1	1995	5	3	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10700	Dafne Chitman	1	1995	2	26	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10698	Caroline Mihailovici	1	1995	3	19	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13072	Camila Diniz Silva	1	1995	8	30	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15755	CAMILA THOMÉ	1	1995	7	24	F	573	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14428	Bianca Rodrigues Sarmento	1	1995	3	30	F	112	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10608	Beatriz Dzialoschinsky	1	1995	9	30	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10265	BEATRIZ RODRIGUES DE OLIVEIRA	1	1995	3	26	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12696	Ana Carolina Feliz Ferreira	1	1995	2	21	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12747	Alexandre Luiz de Souza Chaves 	1	1993	4	19	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10768	ANA BEATRIZ CRUZ MAXIMO	1	1996	12	21	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12366	ALEXANDRE FERNANDES FREITAS	1	1995	8	20	M	57	5ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12807	Vinicius dos Santos Fernandes	1	1994	4	9	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12805	Thiago Rodrigues Feijão	1	1992	12	16	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12800	Tathiana dos Santos Flexa	1	1992	7	27	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15348	TATIANA VIEIRA CORDEIRO BATISTA	1	1996	5	16	F	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15326	SARA SILVESTRE FARIAS	1	1995	1	20	F	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11953	Rômulo Fischer	1	1995	3	9	M	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14785	MAURA DE ARRUDA BOTELHO COLTURATO	1	1995	3	13	F	122	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15391	MARCELO CAVALCANTI SÁ DE ABREU	1	1994	8	17	M	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14439	Luziana Printes Marques	1	1994	12	8	F	112	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12773	Leonardo Saraiva Santos	1	1992	6	27	M	112	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13161	Larissa Diniz Gonçalves	1	1994	5	5	F	40	6ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10371	LUIS FELIPE MENGALI	1	1994	2	6	M	48	6ª C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15069	ISABELLA BARBOSA RUGGERI	1	1995	3	4	F	11	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15065	GUSTAVO STEINER GANDINI	1	1995	3	22	M	11	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10750	Felipe Hanna Braun	1	1993	10	4	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10590	Bruna Zekcer Kleiman	1	1995	6	13	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12694	Amanda Teixeira Areal	1	1995	3	8	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1385	Alexandre Zaccai Polati	1	1993	2	11	M	153	6ª Série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10874	ANELISE BORGES FERNANDES 	1	1995	9	6	F	48	5ª D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14300	WELLINGTON LOURENÇO BORGES	1	1994	5	11	M	5	6o	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11223	Vinícius de Sousa	1	1995	5	21	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13520	Victor Araújo Soriani	1	1995	3	4	M	318	5ª Série A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10584	Valter Martins Júnior	1	1994	5	9	M	473	6ª C	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13815	Samuel Vieira Nobre	1	1994	6	25	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10521	Rafael de Oliveira	1	1994	4	27	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10495	Rafael Isidoro Borges 	1	1994	6	19	M	473	 6 D	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10836	RASLAN BLANCO TAVARES DE OLIVEIRA	1	1995	3	24	M	373	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14607	Pedro Henrique Borgatti Faria	1	1995	6	14	M	545	5a	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10566	Paloma de O. Barbosa	1	1994	2	25	F	473	6ª C	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14968	PEDRO JORGE DE ALCANTARA E BOURBOM JÚNIOR	1	1994	4	29	M	488	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10535	Natiele H. da Silva	1	1994	7	15	F	473	6 D	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11783	Narla Sarah Sene Francisco	1	1993	1	25	F	313	5°E	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10488	Michele Carolina Gomes	1	1994	12	20	F	473	5ª C	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11168	Matheus Pinto de Almeida	1	1995	6	27	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10487	Matheus Costa Barbosa	1	1995	10	5	M	473	5ª B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14160	Matheus Cesario Gimenes	1	1995	9	20	M	517	quinta	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15557	Maria Clara Sciarra Fiorin	1	1995	7	14	F	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10498	Marco Alexandre Castellani Júnior	1	1995	7	26	M	473	5 A   	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11798	Marcio Marcelino Filho	1	1993	12	17	M	313	5°E	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10827	MARIANA DE ABREU PIRES DE ANDRADE	1	1995	6	2	F	373	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15454	Luís Felipe de Oliveira	1	1994	9	26	M	473	5 E	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14956	Luiz Gustavo dos Reis Honório	1	1994	8	23	M	313	5ªE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11270	Luique Augusto Rosa Damazio	1	1993	11	20	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13473	Lucca Salvatore de Medeiros	1	1995	1	27	M	540	5a série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15449	Lucas do Carmo Santos	1	1994	8	24	M	473	5 E	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10999	Lucas da Silva Bosso	1	1995	5	8	M	473	5 D	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14604	Lucas Pedro Vitti	1	1994	11	2	M	545	5a	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14548	Leonardo Degasperi Pegaia	1	1995	7	24	M	545	5a	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10508	Laís Costa de Oliveira e Silva	1	1994	1	15	F	473	6 D	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11182	LUIS FERNANDO MAIA SANTIAGO	1	1993	12	10	M	373	6ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15307	LOUISE SANFORD FEITOSA DED OLIVEIRA	1	1995	11	13	F	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15303	LARA MARIA AMARO BRANDÃO	1	1995	7	26	F	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11402	Kaique Henrique dos Santos 	1	1993	12	13	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15159	Juliana de Ávila Silva	1	1992	9	29	F	512	7ªC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11228	Joyce de Sousa Teles da Luz	1	1995	9	30	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10819	JOHNY HENRIQUE QUEIROZ DOS SANTOS	1	1993	9	9	M	373	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11553	Isabele Batista Costa	1	1995	5	16	F	350	3ª A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10691	Ingridi Conceição de Carvalho	1	1995	7	25	F	473	5 D	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15166	Ighor Henrique O.dos Santos	1	1992	1	28	M	512	7ªD	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14231	Heber Felipe Coelho de Souza	1	1994	1	1	M	313	6ºE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11172	HELLEN VENCESLAU FERREIRA DA SILVA	1	1994	2	24	F	373	6ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10528	Gabriela Vieira Corrêa	1	1994	12	3	F	473	6 D	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11258	Felipe de Souza	1	1993	4	7	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13442	FLAVIO VINICIUS C. VIANA	1	1993	12	4	M	527	6ª Série E	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12973	Egisto Parronchi Neto	1	1994	11	3	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10422	ELISA SOUZA DEZAN	1	1995	6	19	F	461	5ª SÉRIE VERDE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10673	Douglasciel Souza de Oliveira	1	1993	10	16	M	473	6 A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15146	Danielli Minuzzo da Silva	1	1994	4	22	F	512	6ªA	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10815	DAVID PEREIRA DE ANDRADE LEMOS	1	1990	8	2	M	373	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11812	DANILO DA SILVA MOTA SILVEIRA	1	1993	2	1	M	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11789	Cléber Gabriel Rocha Petroline	1	1993	7	26	M	313	5°E	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15561	Carmine dos Santos de Oliveira	1	1994	12	19	F	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11221	Bruno Mendes Alves	1	1994	10	28	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11752	Bruno Cístolo Ribeiro	1	1993	8	5	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11385	Bruna Cristina da Silva	1	1994	1	27	F	313	6ªB	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11399	Ana Lúcia Ferreira dos Santos	1	1994	12	7	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11202	Ana Cristina dos Santos Costa	1	1995	4	17	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15528	Aluísio Pestana Júnior	1	1994	3	9	M	497	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13879	Alan Lopes do Amaral	1	1991	12	2	M	544	5a série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13465	Adauto Luís Ribeiro da Silva	1	1995	1	12	M	540	5a série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15429	ANA ALICE FERNANDES FERREIRA	1	1994	7	26	F	555	6ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15269	AMANDA RODRIGUES DOS ANJOS	1	1995	7	9	F	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15344	ALESSANDRA VIEIRA DE ABREU	1	1995	11	8	F	555	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4367	Junara Ferreira Silva	2	1992	7	11	F	5	8o A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12971	Vitor Zambello	1	1995	6	4	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12635	SARAH CRISTINA C. SILVA	1	1995	3	1	F	215	15EC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11415	Rafaela Castro	1	1995	12	18	F	159	5	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15672	Paula Kikuchi Miyazaki	1	1994	7	28	F	8	quinta série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12735	Paula Cristinne Pinheiro Labuto	1	1993	10	23	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14695	PEDRO ALCANTARA FOZ	1	1994	5	21	M	215	16TA1	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11193	PALLOMA GONCALVES BARROSO TEIXEIRA	1	1995	3	14	F	196	5ª´Série - Gama	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12027	NATASHA DINIZ NARDINI	1	1995	4	6	F	215	15MA3	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11049	Mauro César Plácido 	1	1993	10	5	M	313	6ªB	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11093	Marília Lívia de Souza	1	1995	1	18	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15251	MARIA WALESKA PEREIRA ALVES 	1	1994	1	1	F	196	5ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11050	Luis Flávio Alves Filho	1	1994	10	2	M	313	5ºE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12729	Lucas Tadeu Costa da Veiga	1	1994	10	1	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14721	Leila Aparecida de Souza Batista	1	1994	2	9	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12510	Laís Gabriela Evangelista Santos	1	1994	8	11	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12516	Larissa de Souza Machado Mota	1	1993	9	3	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11269	LARISSA MOURA BARBOSA	1	1994	12	1	F	196	6ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10754	Keren Kaczelnik	1	1994	9	29	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11099	João Paulo Silva Gomes	1	1993	8	20	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12343	Henrique Sá Galvão	1	1995	6	27	M	159	5	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11023	Gislaine Silva de Oliveira	1	1995	11	25	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12504	Gabriel Fernandes Martins	1	1994	3	8	M	312	6ª B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11422	GIOVANNA C. NASTASI	1	1995	9	6	F	159	5	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12354	Felipe Gonçalves Pessoa	1	1994	11	3	M	318	5ª Série B	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11769	Douglas Eleotério	1	1992	10	13	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10611	Dennis Steinmetz	1	1995	6	19	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13903	Daniel Rodrigues Carvalho 	1	1995	3	25	M	216	5ª Serie do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14781	DAVID CASSIMIRO DE MELO	1	1995	6	26	M	179	6º ANO	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15283	DANIEL MATOS CALLAND	1	1995	5	21	M	555	5ª	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11077	Clarice Queiroz Martins	1	1994	10	11	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11054	Ana Carolina M. da Silva	1	1995	2	1	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12290	YAE DO CHOI	2	1993	10	26	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10613	Fernando Westmann Del Poente	1	1995	9	6	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10749	Eitan Gottfried	1	1994	8	22	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11092	Divina de Oliveira	1	1990	11	16	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11104	Camila Alves da Silva	1	1993	11	23	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15957	BRUNO GOMES CARDOSO	1	1994	11	26	M	215	15EC1	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10627	Patrick Liberman	1	1995	7	27	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11107	Leonardo Pereira Lima	1	1994	6	23	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12625	DANIEL FREIRE MOITA DA SILVA	1	1995	6	15	M	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16041	Walter Madeira da Silveira	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14035	Viviane Heloise Kayano	2	1992	4	3	F	544	8a série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14603	Vinicius Silva Tanganeli	2	1992	4	13	M	545	8a	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15227	Ricardo Iannone Tarcha	2	1992	6	25	M	144	8ª Série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12129	Rebeka Spadottin	2	1992	7	9	F	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16034	Rafael Henrique Xavier Pellegrino Fonçalves	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13229	RODOLFO HENRIQUE MARCHIORI	2	1991	12	19	M	571	1-8MA4	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10447	LUCAS SENE OSTE	2	1992	10	15	M	461	7ª SÉRIE AZUL	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11885	LUCAS BERNARDO MARINHO	2	1991	11	8	M	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13981	Kim Affonso Chedid	2	1993	12	2	M	544	7a série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14369	GEORGE LUCKAS MORAIS BERNARDO	2	1992	12	10	M	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14935	DIEGO AUGUSTO TEIXEIRA RIBEIRO	2	1993	1	24	M	5	7o	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16019	Caio Leandro Suzano Massa	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15969	Bruna Vieira Belamino de Oliveira	2	1991	7	7	F	78	8EF	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14445	Andrei Pinto da Rocha	2	1991	8	18	M	112	8ª Série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13351	Vinissius G. Wendt	2	1991	8	22	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13237	VERÔNICA PRICOLI SCHEEL	2	1993	1	15	F	571	1-7TA3	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14463	Thiago Vinicius Vieira	2	1992	5	22	M	552	8ª1ª	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10457	THIAGO ISSAMU FUKUMIZU	2	1992	6	9	M	461	8ª SÉRIE AZUL	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13232	PAULO HENRIQUE DE LIMA PICCA	2	1992	8	18	M	571	1-7MA1	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11640	OHANNA LARISSA FRAGA PEREIRA	2	1993	3	21	F	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15361	KAIRO BONFIM CHAVES	2	1993	10	15	M	555	7ª	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15354	IARA ANDRADE DE OLIVEIRA	2	1993	3	22	F	555	7ª	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15374	HIROSHI THIAGO HATTA REGAL	2	1992	6	11	M	555	8ª	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2927	GUILHERME LOMBARDI RODRIGUES	2	1991	12	22	M	57	7ª SÉRIE A	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11057	Wesley Coelho de Souza	1	1995	6	10	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15972	Thales Sinelilina	2	1991	7	7	M	78	8EF	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13781	Saimon Silva Souza	2	1995	1	25	M	516	7ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1642	Rodrigo Hakim das Neves	2	1991	6	13	M	153	8ª série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14477	Richard de Souza Trindade	2	92	4	8	M	90	8	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8058	Raquel Mitie Harano	2	1992	12	10	F	8	oitava série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16012	Raphael Ricardo Silva dos Santos	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14359	Raissa Leika Sato Yamamoto	2	1991	10	16	F	262	8ª Série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10306	Pedro Luís Meneghim Júnior	2	1993	1	8	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1662	Patrícia Heilberg	2	1991	8	30	F	153	8ª série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14938	NAYARA CAROLINE BATISTA RESENDE	2	1993	6	11	F	5	7o	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13349	Luís Filipe W. Guth	2	1991	2	21	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13838	Lucas Desidério	2	1992	7	21	F	216	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14020	Livia Maria Bezerra Martins	2	1993	8	2	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10479	Leonardo Donizetti Fanti	2	1992	2	8	M	157	8ª Série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16014	Lara Guimarães Fernandes Peres	2	9999	99	99	F	207	7a. série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11229	LUCAS ALVES RAMOS	2	1993	7	8	M	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13619	Isabelle V. Liberato	2	1992	1	13	F	527	8ªPI	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15356	IVNA MARIA BASTOS VASCONCELOS	2	1993	6	24	F	555	7ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13771	Fágner Leite Sales	2	1991	8	14	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15996	Felipe Van	2	1992	7	7	M	78	7EF	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14556	Ely Dantas Andrade	2	1993	9	10	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13660	Daniel Moraes Ramos Studart	2	1992	11	4	M	367	7ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14342	Bruno Henrique Stein	2	1991	9	5	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13654	Beatriz Almeida Guerra	2	1992	9	26	F	367	7ª	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14245	BERNARDO GUIMARÃES OLIVEIRA	2	1992	3	16	M	5	8o	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13356	Augusto de L. B. Nascimento	2	1991	3	31	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13667	Andrezza Ribeiro Fretes	2	1992	10	2	F	462	8ª série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10315	Abner Alex T. Vidigal	2	1993	2	12	M	258	7ª série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11252	ANDREW BRAGA RODRIGUES	2	1991	10	22	M	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11820	ALAIN ADRIAN BLANDI	2	1993	6	24	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16074	Wilian M. Guarnieri	2	1992	8	17	M	259	7ª série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12115	Vinicius Pertile	2	1991	8	8	M	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10308	Victor Felisbino Santana	2	1993	1	4	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14983	VICTORIO TARAHASHI CHU	2	1993	11	24	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12011	VICTOR DANIEL VASCONCELOS 	2	1993	1	13	M	196	7ª Série - Gama	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13994	Tulio Colombo Corrêa	2	1992	11	28	M	544	7a série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13589	Thaís Pinheiro Guerra Furtado	2	1992	4	14	F	527	8ªPI	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10941	Thais  Knittel	2	1992	9	4	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12300	TUANY KAORI NAKAMA	2	1992	3	7	F	487	8ª EF	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10307	Ronan Vilela Santana	2	1992	8	2	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13853	Rogério Malveira Barreto	2	1992	7	9	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12400	Rodrigo de Oliveira	2	1991	4	28	M	473	1 série do ension médio	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14313	Ricardo Altarugio Barbanera	2	1992	1	31	M	545	8a série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16035	Renato Simões da S. Mendes	2	9999	99	99	M	207	7a. série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12915	Paola Sant'Anna Lopes Mendes	2	1991	10	4	F	90	8	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14215	Karina Miyuki Suzuki	2	1992	11	11	F	293	7ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14350	Julio César dos Santos	2	1992	12	7	M	262	7ª Série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13379	JOÃO PAULO RAMALHO MOREIRA	2	1992	2	1	M	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12099	JOÃO C. TELES DE MENEZES 	2	1991	10	5	M	215	18MA1	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13833	Ian Cavalcante Rogério	2	1992	8	17	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13643	Gleycianne Arruda de Freitas	2	1990	1	1	F	367	7ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1599	Gabriela Ghelman	2	1993	2	24	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15962	Fábio Tsaneo R. Suyahara	2	1992	7	7	M	78	8EF	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13855	Francisco Angelo Cabelo	2	1992	4	27	M	216	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15226	Filipe Stripari Avante	2	1992	5	3	M	144	8ª Série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14490	Felipe Ferreira de Barros Ujiie	2	92	4	28	M	90	8	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
295	FELIPE DARCIE PEREIRA 	2	1992	5	3	M	48	8ª C	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12280	ELDER MASSAHIRO YOHIDA	2	1993	2	3	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10259	EDUARDA PALHETA DE FREITAS	2	1993	1	30	F	6	7.ª	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15573	Catarina Brunhara Batista 	2	1992	12	26	F	491	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15694	Carlos José Alves Nunes	2	1992	8	16	M	8	oitava série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11353	Antônio Leandrini Neto	2	1992	4	30	M	511	8ª	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12117	Adriele Ribeiro dos Santos	2	1992	6	4	M	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11359	Ângela Cruvinel Guidorizzi	2	1991	7	15	F	511	8ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14476	Jonathan Costa da Silva	2	92	2	28	M	90	8	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15767	JOHANN FENSTERSEIFER	2	1991	11	18	M	573	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13056	Gabriel Silveira Lajtavary	2	1994	4	11	M	541	8ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13996	Alicia Serra Vasconcelos	2	1992	9	30	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15109	YARA M. P. DE OLIVEIRA	2	1991	9	5	F	11	8ª	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16038	Victor Gomes de Lima	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13345	Vanderlei Thome	2	1991	3	3	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13033	VICTOR TEIXEIRA NORONHA	2	1992	3	6	M	236	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14534	Thiara Godinho Almeida	2	1991	8	28	F	112	8ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15368	TIAGO DE CARVALHO WATERLOO	2	1992	10	28	M	555	7ª	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14032	Rogean Rodrigues Nunes Filho	2	1993	4	30	M	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10486	Raoni Henrique Mozer Xavier	2	1992	9	10	M	157	8ª Série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14685	RODRIGO LEAL	2	1992	3	12	M	215	18TA2	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13384	RAÍZA MARIA DE OLIVEIRA TELES	2	1992	7	30	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13382	RAFAEL FREIRE SILVA	2	1992	9	5	M	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14666	Priscila de Souza Nunes	2	1993	6	7	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13990	Priscila de Jesus Cesar	2	1993	3	1	F	544	7a série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13122	Pedro Eduardo Muniz Flores	2	1993	3	25	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16030	Paulo Henrique C. Teixeira	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15994	Paulo Carvalho	2	1991	7	7	M	78	8EF	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16079	Patricia Scaranaro Tenelli	2	1993	10	7	F	259	7ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14024	Mariana Brasil Sa	2	1993	4	2	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13343	Marcos Scherer	2	1991	11	17	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14592	Marcos Rogério Simões	2	1992	8	1	M	545	8a	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12054	MICHELE FERREIRA DE MORAES	2	1991	8	28	F	215	18EC	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14669	MARCOS A. F. C. SOARES	2	1993	11	17	M	571	1-7TA4	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11511	Leandro Augusto Mancini Alves	2	1992	1	24	M	313	8ªA	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15768	LUIZ FELIPE WETZEL	2	1991	11	6	M	573	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10329	LUCAS SARAIVA CARVALHO DE SOUZA	2	1993	3	24	M	57	7ª série B	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12769	João Vitor Bentes Corrêa	2	1992	9	1	M	112	7ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13186	José de Araújo Resende Neto	2	1992	3	25	M	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14498	Jessica Luciani Vigeta	2	1993	2	23	F	552	7ª2ª	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14358	Isabela Cristina B. Cardoso	2	1992	8	25	F	262	8ª Série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15699	Humberto Luiz Lafuente Gonçalves	2	1993	1	12	M	8	oitava série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9812	Guilherme Fernando da Silva Lopes	2	1992	2	16	M	8	oitava série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13491	Gabriel Cerqueira Cesar Nolasco	2	1993	10	26	M	540	7a série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1596	Fabio Wainstein Silber	2	1993	5	17	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11817	FRANCISCO RAFAEL DE SOUSA	2	1993	1	10	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15102	FABIANA YOSHINAGA TONHOLO SILVA	2	1992	9	26	F	11	8ª	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15427	NATALIA SOUZA NORO	1	1994	10	12	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10303	Drielly Fernanda da Rocha Camargo Nascimento	2	1993	7	16	F	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15978	Daniela Fajer Rosa	2	1991	7	7	F	78	8EF	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10456	DIEGO KENJI KACUTA CORREA	2	1993	2	12	M	461	7ª SÉRIE VERDE	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11653	DIEGO CAPELO VITORIANO	2	1992	1	17	M	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
455	DANILO FELIPE SILVA LOPES	2	1993	4	19	M	29	7ª série B	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15989	Cassio dos S. Souza	2	1991	7	7	M	78	8EF	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13856	Carla Tenecy Povoas Soares	2	1992	5	12	F	516	8ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11641	CARINE BAIMA DE MELO	2	1992	10	13	F	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14451	Bárbara Tiergarten	2	1993	3	7	F	552	7ª2ª	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13374	BÁRBARA LIMA BASTOS	2	1992	9	24	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14387	André Christofoletti de Almeida	2	1993	7	14	M	545	7a série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15992	Ana Carolina Rojas	2	1991	7	7	F	78	8EF	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13371	ANA ELISA FROTA MATOS PRADO	2	1992	10	31	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14117	Rayssa Nogueira	2	1991	9	19	F	516	8ª Série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14355	Pedro Henrique de A. Ferreira	2	1993	8	27	M	262	7ª Série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13495	Manoela Gonçalves Maldonado	2	1992	11	5	F	540	7a série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14868	Jakson Lira de Jesus	2	1993	2	23	M	574	7ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15766	JUAREZ FILHO	2	1994	9	8	M	573	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14250	JOSÉ HUMBERTO DE O. FILHO	2	1992	1	5	M	5	7o	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14535	GERITSA VIANA SOUSA	2	1991	12	13	F	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15769	BERNARDO DIAS	2	1992	12	11	M	573	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14203	Andréa Tieme Higa	2	1992	10	27	F	293	7ª	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16017	Ana Carolina dos Santos Rodrigues	2	9999	99	99	F	207	8a. série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13666	Érica Beatriz C. Colares	2	1993	5	14	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16077	Vinicius de P. Pereira	2	1993	3	22	M	259	7ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15980	Victor Santana Melo Silva	2	1992	7	7	M	78	7EF	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14984	VICTOR YUP Y	2	1993	2	20	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14485	Tatiane Vieira Leite	2	92	3	23	F	90	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14753	Tatiana Silva Soares	2	1993	3	6	F	516	7ª Série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14925	THAYANE CARDOSO TOMÉ	2	1991	7	21	F	5	8o	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12913	Stephanie da Silva Melo	2	1991	12	16	F	90	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12065	STEPHASNIE KOBORI BELCK	2	1993	6	4	F	215	17MB2	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15971	Rafael H. Shimoni	2	1992	7	7	F	78	7EF	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16033	Rafael E. S. de Freitas	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10392	ROBERTA CRISTINA DA CRUZ 	2	1992	4	4	F	48	8ª B	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11304	PÂMELA RABELO SANTANA DA SILVA	2	1992	5	22	F	373	8ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15981	Nicolas Saveriano Dadi	2	1991	7	7	M	78	8EF	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15112	NATÁLIA TRABUCO DO AMARAL	2	1991	10	19	F	11	8ª	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13314	NATÁLIA ANGÉLICA MOREIRA OLIVEIRA	2	1991	10	7	F	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13775	Márcio Henrique Alves Roberto	2	1991	12	3	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14513	Matheus Moita Roatt	2	1992	5	13	M	545	8a	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14894	Mariana Alves Barbosa	2	1992	2	11	F	285	8ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15987	Marcelo Chan Fuwet	2	1991	7	7	M	78	8EF	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10355	MARIANE DARCIE 	2	1991	12	13	F	48	8ª A	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
442	MANOELA LOMBARDI SANTANA	2	1993	11	21	F	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16024	Leonardo Corrêa de Azevedo	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15376	LUCAS NOGUEIRA RIBEIRO	2	1991	12	22	M	555	8ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14927	LORRANA CAROLINA DE ARAUJO	2	1992	5	1	F	5	8o	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13780	João Marcos Vasconcelos Landim	2	1992	7	9	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14522	José Matheus S. Aiello	2	1991	12	17	M	545	8a	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15481	Jessica Santos Barbosa	2	1992	12	6	F	548	8ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14105	JUSTUS MAAS	2	1992	5	2	M	571	1-8MB1	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15352	HANNAH VICENTINI VITORIANO SILVA	2	1993	8	2	F	555	7ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12118	Guilherme Pinarel	2	1991	11	8	M	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16021	Felipe Castro Valicele	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12401	Fabrício Ferreira da Silva	2	1991	3	25	M	473	1 série do ension médio	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14394	FELIPE ANDRÉ SILVA AUGUSTO	2	1993	12	29	M	179	8º ANO B	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15372	ERISON MARGOMANTE AIRES	2	1992	11	9	M	555	8ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15173	Denis Benhur de Freitas Nunes	2	1992	1	25	M	512	8ªB	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15968	Bruno R. P. G. de Souza	2	1992	7	7	M	78	7EF	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14665	Beatriz Ximenes Mendes	2	1992	11	18	F	527	7ª Série 2 - PI	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11114	BRUNO AIRES RIBEIRO BRINGEL	2	1993	9	7	M	6	7.ª	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13585	Amanda Sampaio Bôtto Paixão	2	1991	10	24	F	527	8ªPI	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13588	Allyne Setubal Bittencourt Zimpect	2	1991	8	21	F	527	8ªPI	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14083	Alex Sales	2	1992	11	20	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13230	VICTOR THANBICHLER PADILHA	2	1993	11	8	M	571	1-7MA1	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10310	Thiago Ricardo Giomo	2	1993	1	6	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15187	Thais Pereira dos Santos	2	1991	9	11	F	512	8ªD	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14929	THAYSE MAYER ROSA PERES	2	1992	5	25	F	5	8o	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14505	Paulo Eduardo Moser Loos	2	1993	5	6	M	552	7ª2ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11305	PRISCILA COSTA CARNEIRO	2	1991	2	13	F	373	8ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12285	PEDRO SEUNG DO CHANG	2	1993	1	20	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11857	PAULO WESNEY DA SILVA COSTA	2	1993	8	18	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15179	Marieli Custódio	2	1992	8	5	F	512	8ªC	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16025	Lucas Gomes Padilla Neto	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
194	LOUISE AMALFI FIORITE 	2	1992	10	8	F	48	8ª C	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11348	José Matheus Pinati Ávila	2	1992	9	4	M	511	7ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13111	José Alfredo Zóccoli Filho	2	1993	1	15	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10516	Jaqueline Nágila Cardoso	2	1993	2	10	F	473	7 D	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13812	JOSÉ DE BRITO VIEIRA NETO	2	1993	8	11	M	467	7ª SÉRIE ALFA	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12924	Gustavo Bresciani Alves Sampaio	2	1991	11	6	M	90	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12341	GUILHERME MATHEUS DE OLIVEIRA ARAGÃO	2	1992	5	11	M	488	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13093	Diógenes Sanches Batista	2	1993	12	19	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10532	Cíntia Parajará Scholz	2	1993	6	26	F	473	7 D	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11658	CARLOS DIEGO MOREIRA RUFINO	2	1993	6	15	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13590	CAMILLA ANTONIELI VEQUI	2	1993	9	28	F	467	7ª SÉRIE GAMA	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15986	Bryan L. Salinas Carrillo	2	1992	7	7	M	78	7EF	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12333	Beatriz Affonso dos Santos Haddad	2	1992	1	15	F	159	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14018	Lucas Lentini H. de Oliveira	2	1992	2	27	M	544	8a série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13772	Yuri Basilio Cardoso	2	1992	8	18	M	516	7ª	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12338	THAÍS AMANDA RIBEIRO DE OLIVEIRA LEMOS	2	1992	3	30	F	488	8ª SÉRIE DO ENSINO FUNDAMENTAL	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10314	Rubens A. Rodrigues Jr.	2	1992	2	28	M	258	7ª série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14504	Ronnei Delgado Neves	2	1992	3	10	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10681	Raffaela de Oliveira Pereira	2	1993	2	10	F	473	7 E	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14295	RAFAEL DE PAIVA MARTINS	2	1992	7	21	M	5	8o A	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12535	Pedro Zavagli Suarêz	2	1992	10	9	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14438	Paulo Estevão Possas de Mello	2	1992	2	16	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10483	Patrícia Moreira de Souza	2	1992	3	5	F	157	8ª Série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14913	PAULO CESAR LEAL BERNARDES	2	1991	12	11	M	5	8o	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11326	Nathalia Teixeira Candido	2	1992	4	15	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13663	Mikaelly Dall'osto Parisi	2	1992	5	28	F	462	8ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12079	MAYRA DEL RICOLO CAMPAGNA	2	1992	4	5	F	215	18TA3	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14510	MARIA LUIZA DE SENA DUARTE PACHECO	2	1993	12	10	F	179	8º ANO	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15760	MANUELLA SCHNEIDER	2	1992	7	18	F	573	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14986	JULIA CURI AMANANTE	2	1992	9	9	F	487	7ª EF	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13650	Iara Lima Bezerra	2	1993	4	28	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11345	Gabriel de Queiroz Ferreira Renido	2	1993	10	7	M	511	7ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14390	FELIPE FRANÇA CAVALCANTE	2	1991	12	5	M	179	9º ANO F	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11509	Eduardo Felipe De Souza	2	1992	4	13	M	313	8ªA	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14870	Cauê Marinho	2	1993	6	8	M	574	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15350	CAROLINA BANDEIRA DE SOUSA	2	1993	3	4	F	555	7ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13358	Bruno Antonio Simonini dos Santos	2	1990	7	14	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13554	Anny Carvalho Thorp	2	1993	7	11	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15094	AMANDA ROLIM PEREZ	2	1992	9	14	F	11	7ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14643	ALLEF MORAIS CARLOS	2	1993	11	1	M	179	8º ANO	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11826	ALAN BATISTA DE OLIVEIRA	2	1993	5	19	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12879	Thayssa Osuna Quaglietta Corrêa	2	1991	10	16	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14209	Tatiane Lusivo Rosa	2	1992	12	8	F	293	5ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11316	THAIS COELHO VILLAR	2	1992	6	6	F	373	8ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10655	Stevão Gustavo Prado de Morais	2	1993	5	10	M	473	7 E	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14738	Simone Rodrigues de Moraes	2	1993	1	19	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15369	STERFERSON ALEXANDRE JUNIOR	2	1993	2	3	M	555	7ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14916	SIDNEY SÁVIO FERREIRA DE ALMEIDA	2	1991	8	15	M	5	8o	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11843	Rafael Ribeiro Zagari	2	1991	9	9	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13020	REBECA CANUTO DE SOUSA	2	1994	10	27	M	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13695	Pedro Vinícius Guerra	2	1991	10	30	M	367	8ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14782	NATÁLIA BUSNELLO DE DONNO	2	1992	9	18	F	122	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13842	Maurélio Carvalho do Nascimento	2	1991	6	5	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12768	Marcos Vinícius Bentes Corrêa	2	1992	9	1	M	112	7ª série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14576	Luis Mario B. P. Borges	2	1992	2	20	M	527	8ªPI	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12563	Liliane de Sousa	2	1993	7	19	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15571	Larissa Angelo Pereira 	2	1992	11	8	F	491	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10684	Lalesca Piolo	2	1993	10	8	F	473	7 E	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11262	LUCIANO AMADO SOUZA LOURENÇO	2	1993	4	12	M	373	7ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15500	Jéssica Ribeiro da Conceição	2	1992	12	15	F	548	7ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15492	José Ramon Lopes da Silva	2	1991	11	28	M	548	8ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13360	Joel Molling	2	1991	2	8	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11510	Jaqueline Meira Cruvinel Da Silva	2	1992	4	21	F	313	8ªA	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12887	Isabelle Souza Mantini	2	1992	4	28	F	90	8	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11347	Heber Augusto Nogueira	2	1993	1	10	M	511	7ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11904	Giuliana Nogara Andreatta	2	1992	4	8	F	7	8ª série - Ensino Fundamental 	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11255	GRAZIELLE GONÇALVES DE SOUZA	2	1994	5	22	F	373	7ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11251	GILBERTO DA SILVA RIBEIRO JUNIOR	2	1993	6	30	M	373	7ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10293	Fernando Semprebom de Oliveira	2	1992	10	1	M	393	Ciclo IV - Inicial B	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11121	Felipe Henrique Viana	2	1993	3	25	M	313	7ªC	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11245	EMERSON WESLEY DE FREITAS CORDEIRO	2	1991	11	20	M	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12533	Caio Fellipe Gomes Batista	2	1993	6	17	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2926	CAULI FERNANDES OLIVEIRA	2	1992	2	19	M	57	8ª SÉRIE A	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11881	CAIO RICHARD ABREU MENEZES	2	1993	7	20	M	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11512	Bianca Narciso De Souza	2	1992	3	3	F	313	8ªA	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14926	BRENO DE OLIVEIRA SOUZA	2	1992	12	7	M	5	8o	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10626	Ana Carolina Ribeiro 	2	1992	8	3	F	473	7 B	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14606	ANDRÉ DELLA LATTA CARTOXO	2	1992	5	8	M	215	18TA4	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15670	Victoria Eduarda Vasconcelos Liberato	2	1992	5	11	F	492	8ª série do ensino fundamental 	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11030	Victória Colosso de Oliveira	2	1992	9	18	F	473	8 B	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13004	Ricardo Peixoto dos Santos	2	1993	3	2	M	541	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14479	Priscila Monteiro dos Santos	2	91	6	24	F	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1620	Philip Zucker	2	1993	5	2	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12305	PAOLLA BRENDA MOTA MAGALHÃES	2	1992	9	30	F	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13340	Otto E. Kern	2	1989	2	4	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
456	OTÁVIO SCOPEL CAMPAGNARO	2	1993	4	22	M	29	7ª série B	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13645	Nithyananda A. Furtado	2	1993	7	16	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10658	Mayara Medeiros Ulbrich	2	1993	3	18	F	473	7 E	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11333	Mariana Emiliano Silva	2	1993	9	11	F	511	7ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14909	MARLON HENRIQUE DE SOUZA	2	1992	3	23	M	5	8o	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10378	MARIA CLARA ROQUE 	2	1993	4	29	F	48	7ª C	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13494	Loerst Estevan Vitor Gonçalves dos Santos	2	1993	2	25	M	540	7a série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15358	JONATAS DIAS FONSECA	2	1993	8	2	M	555	7ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14296	JESUS VAZ DE OLIVEIRA JUNIOR	2	1993	12	1	M	5	7o A	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14252	ISABELLA CRISTINA DE ARAÚJO	2	1992	1	13	F	5	8o	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1576	Hugo Metzger	2	1993	3	2	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15415	HERICK LOPES DE MELO	2	1991	11	28	M	555	7ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13974	Flavia Marques Lopes	2	1993	8	24	F	544	7a série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11234	FLAVIA MOURA DE AGUIAR	2	1993	4	30	F	196	7ª Série - Gama	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14008	Expedito de Oliveira Leite Filho	2	1993	8	4	M	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12927	Davidson Santana Paiva	2	1992	2	15	M	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13490	Daniel Francisco Vitorino Rocha	2	1993	6	17	M	540	7a série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16040	Calebe Pimentel	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15108	CAROLINE DANTAS DE SOUZA	2	1992	6	3	F	11	8ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1592	Bruno Krauthamer	2	1993	9	23	M	153	7ª Série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10477	Bruno Cezar	2	1991	8	22	M	157	8ª Série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14960	Bianca Lopes de Souza	2	1992	2	16	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13398	BRUNO ARAÚJO LIMA	2	1993	6	18	M	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14531	ANGELO GOMES GUIMARAES	2	1992	3	28	M	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12081	ANDRÉ CITRONI PALMA	2	1992	4	2	M	215	18MA2	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11337	Yulia Kamei Saito	2	1993	10	12	F	511	7ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15482	Wanderson da Silva	2	1991	10	30	M	548	8ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14918	WENDER YUKIO GUIMARÃES KENMOTI	2	1992	4	16	M	5	8o	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13326	VIVIAN APARECIDA DE SOUZA KRAUS	2	1992	4	15	F	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12817	Thiago Amorim Garuzi	2	1993	5	22	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13234	TOMÁS TROMBETTA DE LIMA RAEDER	2	1992	10	15	M	571	1-7MA3	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15636	Rodolfo Cadamuro Felipe 	2	1992	12	22	M	491	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15228	Roberta Gligorovick	2	1992	2	20	F	144	8ª Série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13540	Raul Sousa Paz	2	1993	5	30	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15485	Raquel Malvão dos S. S.	2	1991	11	30	F	548	8ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14597	RAFAEL BENFICA RIBA	2	1993	2	19	M	215	17MA1	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14667	Natalia Sampaio de Rezende	2	1992	10	13	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15186	Nataiele Patrício e Silva	2	1991	12	21	F	512	8ªD	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10670	Monique da Silva Monteiro	2	1991	10	13	F	473	7 E	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1604	Michelle Dratcu	2	1993	3	14	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16078	Mariane Leonel dos Santos	2	1992	11	7	F	259	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14922	MATEUS MONTANDON LIMA	2	1992	2	11	M	5	8o	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12833	Leticia Luna dos Santos	2	1991	12	4	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12899	Jairo de Souza de Senna	2	1991	1	28	M	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13163	JOAO EDSON MOREIRA PESSOA FILHO	2	1992	7	5	M	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13354	Henrique Stoffel	2	1991	1	25	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12996	Gustavo Abrahão Furlan	2	1992	10	9	M	541	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13183	Gabriel Azevedo Macedo	2	1991	9	19	M	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12828	Fabricio Siqueira Moreira	2	1992	10	21	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12827	Fabricio Franciscus de Oliveira Santos	2	1992	8	27	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10394	FRANCINI M. DE ALMEIDA 	2	1992	1	30	F	48	8ª B	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11287	Evelyn Kim Grossi	2	1993	1	10	F	504	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13338	Diego Rodrigo Weber	2	1991	6	23	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10937	Camila  Geber Blinder	2	1993	4	2	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14044	Beatriz Lima Nogueira	2	1992	8	17	F	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13965	Beatriz Helhammer Christiansen	2	1993	3	29	F	544	7a série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15101	BRUNO CUTER ALBANESE	2	1992	5	8	M	11	8ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14474	Amanda Silva Soares	2	90	7	31	F	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13586	Yuri Dimitri Ribeiro Lima	2	1992	7	2	M	527	8ªPI	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11260	TIAGO RODRIGUES ROCHA	2	1992	6	18	M	196	8ª Série - Alfa	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10388	TAISE DE LOURDES JORGE	2	1991	9	24	F	48	8ª C	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15097	TAIANE MARIA FRANCISCHINELLI	2	1992	11	22	F	11	7ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11841	Scheila Franciele Reis	2	1991	7	24	F	313	8ªD	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14928	SAMANTHA BRÁULIO FREIRE	2	1992	3	9	F	5	8o	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13352	Ruan Saltiel	2	1991	11	2	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1583	Renata Politanski	2	1993	3	18	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14488	Renata Ferreira Baes	2	92	6	2	F	90	8	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10940	Rafael Cohen	2	1993	4	2	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
145	RUAN PIMENTEL ROCHA	2	1991	10	4	M	29	8ª série B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13195	Nathalia Magalhães Cordier Leite	2	1991	12	19	F	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12575	Maurício Henrique Flório da Silva	2	1993	1	31	M	312	7ª E	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11164	Matheus Gregória Honório	2	1992	9	3	M	473	8 B	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15225	Mariana Oliveira de Abreu	2	1991	9	13	F	144	8ª Série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
244	MICHELY   KETLYN TREVISAN DE ABREU	2	1993	3	9	F	48	7ª D	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11302	MAURO FORMOSO PAULINO DA SILVA	2	1990	11	13	M	373	8ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14952	MARINA SALLA MARCHIORI	2	1992	1	24	F	122	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
240	MARIANA DE SANT'ANNA DE OLIVEIRA 	2	1993	5	4	F	48	7ª D	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12871	Leticia Salomé Buayi Figueiredo	2	1992	3	13	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11294	LETÍCIA ALMEIDA RABELO	2	1992	2	20	F	373	8ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12869	Kayanne Gaspar Braga	2	1991	10	14	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15758	JÉSSICA THOMÉ	2	1994	1	22	F	573	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14508	João Vasconcelos de Castro Júnior	2	1991	8	12	M	112	8ªsérie	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12195	Josué Carlos Corrêa	2	1993	4	9	M	157	7ª Série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12557	Josiane Cristina Pereira	2	1992	10	16	F	312	7ª C	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14530	Jordânia Isis Nogueira de Carvalho	2	1991	10	4	F	112	8ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16082	Jessica Fernandes Tibagy	2	1993	1	15	F	259	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1655	Ivy Engel	2	1992	1	23	F	153	8ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14907	ISABELA RIBEIRO SILVA	2	1992	1	4	F	5	8o	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14239	INGRID DA SILVA ALVES	2	1992	9	18	F	5	8o	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12865	Henrique Arêas Casimiro	2	1991	8	5	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11569	Girlane Gomes Estevão	2	1990	3	17	F	350	7ª D (Esc. Amor Divino)	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14887	Giovanna Maria Pereira	2	1992	2	18	F	285	8ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11129	Gabriel Henrique Albo de Oliveira	2	1993	2	26	M	313	7ªC	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14550	GUILHERME PEREIRA SILVA	2	1993	1	22	M	571	1-7MA3	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15096	GIESELA INGE DRECHSLER	2	1992	12	26	F	11	7ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14853	GABRIEL LOURENÇO LOPES	2	1992	8	3	M	122	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10403	Felipe Alves	2	1991	5	10	M	313	8°C	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
189	FREDERICO MACHADO DE PAULA 	2	1991	9	18	M	48	8ª C	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13753	FERNANDO HENRIQUE D. FAMÁ EDEL	2	1992	7	7	M	571	1-7TA4	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15229	Eduardo Luiz Rossini	2	1992	4	11	M	144	8ª Série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11130	Denise Marcelino da Silva	2	1992	12	8	F	313	7ªC	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10672	Davi Aparecido dos Santos Júnior	2	1993	3	6	M	473	7 E	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15466	Danilo Borges Ferrante	2	1992	11	15	M	262	7ª Série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12092	DANIELLE KOELTLER A. KOSLOVSKY	2	1992	4	14	F	215	18MA3	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13563	Caroline Toaldo Pistori Corrêa Vasques	2	1993	7	7	F	285	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14356	Bruno Daniel Leite Rodrigues	2	1993	6	22	M	262	7ª Série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13336	Bruna Winter Jung	2	1991	6	28	F	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13231	BRUNA DE SOUSA FERREIRA	2	1991	2	3	F	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12962	BIANCA RODRIGUES MAIA	2	1993	9	16	F	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1673	Andréia Liuchy	2	1992	4	27	F	153	8ª Série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12599	Amanda Queiroz Rabelo	2	1992	4	27	F	312	8ª E	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14407	Alex Cardoso da Costa	2	1992	3	25	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4405	ANA CAROLINA MALAGUTTI	2	1992	11	19	F	48	8ª C	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10443	ALEXANDRE WESLEY ELBERT LOPES	2	1993	1	19	M	461	7ª SÉRIE AZUL	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11794	Paulo Guilherme De Carvalho	2	1191	3	20	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12870	Lauane dos Santos Ferreira	2	1992	6	1	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11815	LUCAS VIANA DA PONTE	2	1992	1	6	M	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11018	Jéssica S. de Freitas	2	1991	10	24	F	473	8 F	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14447	Juliane Marreco Ferreira	2	1991	7	21	F	112	8ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11526	Guilherme Felipe De Siqueira Moreno	2	1993	4	15	M	313	7ªD	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12093	GIULIANA LEONHARDT	2	1993	2	26	F	215	17TA4	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12185	Emmanuel T. Ferraz Faria	2	1992	8	5	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12873	Pedro Henrique Costa de Veiga 	2	1992	7	15	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12925	Thiago Teixeira Marques Correa	2	1991	8	25	F	90	8	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14375	Victor França Giembinsky	2	1993	7	29	M	517	setima	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12287	VICTOR AUGUSTO CHEN	2	1993	1	11	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12842	Thais Marenda Ferreira	2	1992	8	1	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12172	Thaianny Laleska Damito Fernandes	2	1994	1	22	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14961	Suellen Fernanda Ferreira	2	1991	7	4	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11301	Shirley Maciel Marques	2	1992	12	12	F	504	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10629	Ronan Perreira	2	1993	8	11	M	473	7 E	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14502	Rodrigo Henrique Frischknecht	2	1993	14	24	M	552	7ª2ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15541	Rodolpho Esberard Baena Ferreira	2	1992	8	23	M	497	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13307	Rodolfo Aparecido de lima	2	1993	8	11	M	518	Fundamental	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13117	Renata Vanini	2	1993	7	27	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12839	Raphael Marinho Clemente Santoro	2	1992	12	10	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10529	Rafaela Cristina Osti de Freitas	2	1993	9	30	F	473	7 D	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13192	REBECA MATOS NASCIMENTO 	2	1992	3	19	F	467	8ª SÉRIE ALFA	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13319	RAONÍ FELIPE DE ALMEIDA ANDRÉ	2	1991	11	15	M	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13987	Pedro Berbel Rodrigues da Paz	2	1993	1	20	M	544	7a série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12838	Paulline de Oliveira Tavares	2	1991	12	26	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12171	Nayara Urias Bueno	2	1993	5	27	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15364	NILZETE MARIA PINHEIRO ALVES VASCONCELOS	2	1992	11	5	F	555	7ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13539	Mateus Fontenele	2	1994	2	21	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11529	Mateus Fernando Galdino Rocca	2	1993	1	4	M	313	7ªD	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12836	Marina Esteves de Oliveira	2	1993	5	10	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11366	Mariana Pereira Jacob	2	1992	2	11	F	511	8ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14019	Marcelo Tiburcio Camargo Filho	2	1992	6	17	M	544	8a série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11339	Marcela Cristina Marquezani Ferreira	2	1992	8	2	F	511	7ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10620	Maike Thieres do Carmo	2	1992	12	11	M	473	7 A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12193	Maicom Rodrigues Costa	2	1993	1	23	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15493	Luiz Felipe Carvalho de Souza	2	1991	9	19	M	548	8ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10624	Lucas dos Santos Vilas Boas	2	1993	5	29	M	473	7 A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13659	Lucas Souza Pereira	2	1992	5	14	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11303	Lucas Fernandes Silva	2	1992	11	9	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12178	Luan Expedito Bueno	2	1993	4	19	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12829	Juliana Barbosa Sardinha	2	1992	12	17	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13979	João Luiz Brancalhone Filho	2	1993	7	1	M	544	7a série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11524	Jorge Felipe De Almeida Rocha	2	1993	2	28	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11021	Jefferson Luís Viola	2	1992	1	17	M	473	8 E	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13610	Jefferson Glauco Maciel Zysko	2	1992	9	3	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15490	Jean da Costa dos Santos	2	1991	10	18	M	548	8ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13831	Jards de Sousa Ferreira	2	1991	12	28	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10540	Jair Aparecido Sinotti Júnior	2	1993	5	13	M	473	7 D	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14226	Hyago Luiz Damito Fernandes	2	1993	2	26	M	313	8ºB	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12670	Guilherme de Oliveira Santos	2	1993	4	26	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11751	Gabriel Zavagli e Lemos	2	1991	5	31	M	313	8°B	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14628	Gabriel Hermes	2	1993	1	10	M	545	7a	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14524	Fernando Erico Georgetti	2	1992	4	24	M	545	8a	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12848	Felipe de Lima dos Santos Medeiro	2	1991	8	21	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13971	Felipe Alegretti Maestrello	2	1992	12	26	M	544	7a série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10450	FABIO MONTEBELLO JUNIOR	2	1992	10	7	M	461	7ª SÉRIE VERDE	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15505	Danilo de França	2	1992	9	2	M	548	7ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10618	César Augusto Palandi Carneiro 	2	1993	5	20	M	473	7 B	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14048	Claudio Gurgel Pinheiro	2	1992	2	14	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14563	Caroline Carvalho do Nascimento	2	1992	11	30	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11516	Camila Pio Ferreira	2	1992	4	14	F	313	7ªE	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11796	Cairo César De carvalho Lima	2	1991	1	21	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10551	Caetano Ferian Neto	2	1993	4	7	M	473	7 C	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14507	Beatriz Schnaider Tontini	2	1993	5	28	F	552	7ª1ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12824	Barbara Pineiro Lima	2	1994	1	6	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14002	Arthur Jordan de Azevedo Tone	2	1992	12	18	M	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11741	Ariene de Oliveira 	2	1992	4	7	F	313	8°B	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10661	Anthony Moreira	2	1993	4	20	M	473	7 E	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14713	Ana Flávia Magalhães	2	1993	4	23	F	313	7ªC	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11497	Ana Carolina Martins Lima	2	1992	8	20	F	313	7ªA	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12821	Amanda Lopes Sampaio	2	1993	4	20	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11506	Alexandre Ribeiro Bueno	2	1992	4	27	M	313	8ªA	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15347	AMANDA PONTES EGYDIO	2	1992	2	22	F	555	7ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12914	Thamires Novo Silva	2	1992	6	2	F	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12205	Thais Carradori Boyago	2	1993	4	24	F	157	7ª Série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12912	Thaina Fialho Silva de Sousa	2	1992	6	10	F	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15253	TAYRONNE ARAUJO GOMES	2	1994	1	1	M	196	8ª Série - Gama	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12201	Suzane Renata Preto de Godoy	2	1991	12	26	F	157	7ª Série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11880	SOLON DE HOLANDA VIEIRA NETO	2	1992	12	16	M	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13993	Rodrigo Demartini Capelini	2	1993	8	16	M	544	7a série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10391	RANIERI HENRIQUE DA SILVA 	2	1991	10	20	M	48	8ª B	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14676	Paulo Vitor Schmitz Maragno	2	1993	1	26	M	552	7ª1ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15475	Patrick Lima Galvão	2	1991	7	30	M	548	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14915	PEDRO HENRIQUE AFONSO DE PAULO	2	1991	8	15	M	5	8o	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13570	Nathália Lopes Sanchez	2	1992	9	18	F	285	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14611	Mauricio Alves da Silva	2	1991	3	25	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14512	Matheus Missen Ramos Ribeiro	2	1993	8	28	M	545	7a 	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16027	Luiz Felipe Romero da Silva	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1579	Lucia Extrakt Norman	2	1993	1	23	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13361	Lucas Breunig	2	1990	10	11	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12903	Levy da Silveira de Araujo	2	1991	7	4	M	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14740	Kairo Phellipe Ramos Fernandes	2	1991	1	17	M	312	7ª D	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13466	Jéssica Lorenna de Souza Nogueira	2	1992	5	10	F	112	8ª serie	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14235	JÚLIO CESAR ALVES JUNIOR 	2	1993	7	11	M	5	7o	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15478	Juliene Alves Souza	2	1991	12	1	F	548	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11492	José Augusto Albuquerque Garcia	2	1993	6	21	M	313	7ªA	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10270	JULIANA RIBEIRO FERNANDES	2	1992	12	6	F	6	7.ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10365	JOÃO PAULO DE AGUIAR 	2	1993	2	24	M	48	7ª A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13402	JOÃO PAULO ARCANJO MEDEIROS	2	1992	10	20	M	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15375	IRLAN PABLO ANSELMO FROES	2	1991	2	2	M	555	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14515	Henrique Moita Roatt	2	1992	5	13	M	545	8a	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11241	GUILHERME HENRIQUE NASCIMENTO ALVES	2	1992	7	20	M	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14393	GENIVAL VELOSO DE FRANÇA NETO	2	1992	12	23	M	179	8º ANO	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15759	GABRIELA BONFANTI	2	1993	4	5	F	573	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16086	Eduardo Duarte Diana	2	1993	2	9	M	259	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15696	Débora Simões da Silva	2	1994	2	11	F	8	sétima série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
195	DÉBORA MARIA CÓPPOLA RODRIGUES 	2	1992	10	16	F	48	8ª C	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13353	Diego Spengler	2	1991	3	3	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1572	Deborah Paiva Carlessi	2	1993	7	18	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13848	Danilo Monteiro dos Reis	2	1993	9	15	M	216	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14443	Daniel Farias dos Santos	2	1992	5	9	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10358	CÍNTIA APARECIDA DOS SANTOS 	2	1991	6	15	F	48	7ª A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13181	Carlos Eduardo Lopes da Costa Assis	2	1991	11	13	M	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14291	CRISTIAN AUGUSTO CARNEIRO	2	1993	7	4	M	5	7o D	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13362	Bibiana Fuzer da Silva	2	1990	11	9	F	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16039	Asaph Paizante Santos da Silva	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1609	Andre Waissmann	2	1993	3	11	M	153	7ª Série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14734	Ana Carolina Manoela Inácio	2	1992	9	20	F	312	7ª A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12553	Amanda Célia dos Santos	2	1992	2	23	F	312	7ª C	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12820	Alessandra Thomé Pereira	2	1993	2	9	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4384	ANA PAULA DOS REIS LOCATELLI	2	1993	6	8	F	48	7ª A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16084	Thiago G. Fernandes	2	1992	3	1	M	259	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13197	Raianne Ramos	2	1993	3	23	F	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12197	Paulo H. Bioto	2	1992	8	3	M	157	7ª Série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12905	Patricia Cristina Pinto Soares	2	1990	2	25	F	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15479	Marco Antonio da Conceição dos S. Lima	2	1991	7	3	F	548	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10367	MARÍLIA BIANCHETTI CARDOSO	2	1992	7	1	F	48	7ª A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14444	João do Nascimento Farias Júnior	2	1992	4	6	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14487	Iris Alves da Silva	2	92	4	28	F	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15355	IGOR GENTIL CUNHA LEITE	2	1993	1	1	M	555	7ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15416	IAGO BARBOSA DE CARVALHO LINS	2	1994	1	25	M	555	7ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13450	Hugo Cézar Matos	2	1990	5	29	M	112	8ª serie	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14759	Gabriel Fernando Ribeiro	2	1991	12	18	M	312	8ª D	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15494	Fábio Xavier da Silva	2	1991	4	4	M	548	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14446	Fernanda de Castro Souza	2	1991	11	15	F	112	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15468	Adriana Soler	2	1992	2	12	F	262	8ª Série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12818	Yuri Nigri Ferreira	2	1992	2	5	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14959	Viviane Garcia Dias Conceição	2	1991	7	10	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13964	Vitor de Almeida Pereira Lemos	2	1993	5	14	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11268	VEIBSON GOMES DA SILVA	2	1992	3	5	M	373	7ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10642	Tamires de Almeida Prado	2	1993	2	9	F	473	7 A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11163	Talita Helena Siqueira	2	1992	7	22	F	473	8 B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11655	THARLELES DOS SANTOS CAMARGOS	2	1993	2	8	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13327	TAINARA MIRELA DE BRITO	2	1991	11	20	F	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11753	Solismar  dos Santos Barbosa	2	1992	2	6	M	313	8°B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10640	Sheila Cristina da Silva	2	1993	12	19	F	473	7 E	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10519	Salua Bosso de Oliveira	2	1992	12	5	F	473	7 D	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12675	Romilson Braga Teixeira	2	1992	9	25	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11008	Richard Matheus Baptista de Lima	2	1992	7	14	M	473	8 F	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15180	Rafael Ferreira Martins	2	1992	1	15	M	512	8ªC	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11264	RODRIGO EMMANUEL SALLES RIBEIRO AFFONSO	2	1992	11	18	M	373	7ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12346	Pedro Henrique F. Rosário	2	1993	1	2	M	318	7ª Série B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15569	Patrícia Barberá Gallego 	2	1993	2	16	F	491	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11532	Nayra Reis Cintra Agripino	2	1993	1	7	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11849	Natã de Sales Somaggio	2	1991	11	10	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11534	Natália Morais Pereira	2	1991	12	24	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11332	Luiz Felipe Gonçalves Silva	2	1993	1	14	M	511	7ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10663	Lucas Juliano Figueiredo	2	1992	12	14	M	473	7 B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11493	Lucas Bento Martins	2	1993	1	2	M	313	7ªA	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15178	Lauren Jaques da Silva	2	1992	2	4	F	512	8ªC	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15572	Jônatas Spósito Callió	2	1992	10	30	M	491	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11026	Jéssica Maria Augusto Balbino	2	1992	7	25	F	473	8 B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10651	Jéssica Françoso Labigalini	2	1993	10	14	F	473	7 B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15185	Juliana Bessa Martins	2	1992	5	8	F	512	8ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14565	João Pedro Sotero Rodrigues	2	2006	7	12	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10648	Josilma Maria Brito da Silva	2	1992	3	24	F	473	7 E	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11256	JULIANA FLAUZINO DE OLIVEIRA	2	1990	12	19	F	373	7ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13636	Isabela Vera dos Anjos	2	1993	6	16	F	462	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11499	Iasmim Da Silva Magalhães	2	1993	2	17	F	313	7ªA	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14373	Hugo Gabriel Dorathioto Rodrigues	2	1993	8	18	M	517	setima	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15184	Gieisla Santos da Cunha	2	1992	9	30	F	512	8ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13100	Gabriela Pouso de Almeida Sésso	2	1993	6	7	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11847	Gabriel dos Santos Dias	2	1992	6	23	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10453	GIOVANI DUTRA DE MENESES 	2	1993	3	16	M	461	7ª SÉRIE VERDE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10418	Francisco Antônio Ferreira Júnior	2	1991	11	28	M	313	8° D	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11321	Filipe do Nascimento	2	1992	3	23	M	504	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12691	Fernando Urias Neto	2	1993	11	12	M	313	7ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11318	Felipe Sacramento Vilas Boas	2	1993	9	13	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11284	FILIPE LUZ VITOR MARTINS	2	1992	6	30	M	373	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11281	FABIO PINTO MOREIRA	2	1991	3	29	M	373	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10646	Emanuelle Fuini Costa Diniz	2	1993	5	5	F	473	7 A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11887	EDVARDO SÉRGIO MAIA FREITAS FILHO	2	1991	8	17	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11762	Doralice dos Santos Martins	2	1992	1	15	F	313	8°B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11764	Denise dos Santos Martins	2	1992	1	15	F	313	8°B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11028	Daniela Ribeiro Golfetto	2	1992	6	11	F	473	8 B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10660	Daniela Cassiano 	2	1993	1	22	F	473	7 B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11514	Daiane Inocêncio Silva	2	1992	7	7	F	313	7ªE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13331	DAVI LUIS CAETANO	2	1992	6	15	M	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13080	Christian Veloso de Queiroz	2	1993	11	29	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15538	Cauê Felchar	2	1992	9	25	M	497	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11533	Bianca De Carvalho Silva	2	1992	12	30	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13816	BRENDA DE FÁTIMA RIBEIRO MENDES	2	1993	5	13	F	467	7ª SÉRIE GAMA	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13661	Arielle Aparecida Morimoto	2	1992	9	20	F	318	8ª Série A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11352	Antônio Carlos S. Júnior	2	1991	12	28	M	511	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15181	Andrielle de Paula Rodrigues	2	1992	4	19	F	512	8ªD	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11020	Anderson dos Santos S. Almeida	2	1992	6	29	M	473	8 E	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11011	Ana Carolina Bino	2	1992	6	28	F	473	8 E	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10412	Alliny Leite dos Santos	2	1991	5	22	F	313	8°C	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10666	Aline Aparecida Leandro	2	1992	9	1	F	473	7 E	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11277	ARMINDO ABEL VILELA CARVALHO	2	1992	8	21	M	373	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13328	ANDRESSA FRANCELINO DOS SANTOS	2	1991	9	22	F	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11162	|Kris Erick de Oliveira	2	1992	7	11	M	473	8 B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1626	Vivian Nahon Nassi	2	1993	1	23	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13849	Victor Hugo	2	1992	9	8	M	216	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14912	VINICIUS MOURA ALBUD PENA	2	1992	1	21	M	5	8o	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1586	Thomas Maghidman	2	1993	7	16	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12878	Thaís Ferreira de Almeida	2	1992	2	11	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14549	TIAGO RODRIGUES GUIMARÃES SILVA	2	1991	6	15	M	236	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10356	THAÍS ESTEFÂNIA  SORCE	2	1992	8	26	F	48	8ª A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10396	TAMIRES CRISTINA SABINA	2	1991	9	6	F	48	8ª B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12877	Samara Pinheiro da Cruz	2	1991	12	21	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15469	Raissa Jamal Rodrigues	2	1992	2	22	F	262	8ª Série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12619	RAISSA AIRES RIBEIRO BRINGEL	2	1992	5	21	F	6	8.ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12023	PRISCILA KÜHL ZOGHBI	2	1994	3	26	F	6	7.ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13032	PEDRO VICTOR DIÓGENES DA GUIA	2	1992	6	9	M	236	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14808	NATHALIA PONTES DE DEUS 	2	1991	11	4	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1603	Marjorie Mirocznik Wladimirski	2	1993	9	3	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15700	Marcello Augusto Gavino	2	1992	7	10	M	8	oitava série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14247	MELIZE MENEZES SANTOS	2	1992	10	23	F	5	8o	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14251	MATHEUS CARDOSO DE OLIVEIRA	2	1991	6	10	M	5	8o	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14294	MARLLON VINÍCIUS REIS ALVARENGA	2	1992	5	5	M	5	8o C	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15753	MARINA RODRIGUES FERREIRA	2	1992	9	2	F	11	7ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16083	Luan Spanding de Queiroz Lino	2	1993	7	24	M	259	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14347	Liao Chih Hsiang	2	1992	12	22	M	216	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10387	LUIS EDUARDO CHED BALARIM ARAUJO 	2	1992	4	15	M	48	8ª C	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14921	LORENA FERREIRA BENFICA	2	1992	3	20	F	5	8o	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14886	João Pedro Silvestre	2	1992	12	8	M	285	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12867	Jessica Luz Seixas	2	1991	3	23	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12012	JOAO VICTOR FALCAO DE FARIAS	2	1993	2	8	M	196	7ª Série - Gama	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10478	Ivaldo Francisco da Silva	2	1992	7	24	M	157	8ª Série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15697	Gustavo Vargas Braum	2	1993	8	17	M	8	sétima série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8027	Gabriel Trindade Caviglione	2	1992	6	23	M	8	oitava série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12589	Gabriel Rios Sarrassini	2	1992	7	16	M	312	8ª D	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14891	Gabriel Fragnan Carrara	2	1992	1	3	M	285	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14893	Gabriel Felipe Oréfice	2	1992	1	20	M	285	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14892	Gabriel Cerini Ferreira	2	1991	12	3	M	285	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14795	GIOVANA DA SILVA FERREIRA	2	1993	8	27	F	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10943	Felipe Goldenberg 	2	1992	10	2	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10938	Fabio Zatz de Oliveira	2	1193	7	3	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11250	FILIPE DE OLIVEIRA GOMES	2	1992	7	20	M	196	8ª Série - Gama	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14790	FERNANDA JOLY MACEDO	2	1992	12	7	F	122	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
193	FELIPE LANGE DE FARIA 	2	1992	2	17	M	48	8ª C	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14941	FABRICIO LEONARDO SILVA	2	1993	5	29	M	5	7o	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14613	Eloise de Sá Sousa	2	1992	7	21	F	112	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1594	David Ferber	2	1991	12	5	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12631	DANIEL ROCHA CHAVES	2	1992	4	14	M	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16071	Cassio Mercaldi Fachi	2	1993	4	4	M	259	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16080	Caroline Diana	2	1992	10	9	F	259	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14867	Carlos Henrique Rosa	2	1992	7	22	M	574	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14532	Camilla Abreu da Silva	2	1991	12	10	F	112	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14896	Caio Augusto Silva	2	1992	5	4	M	285	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14807	CAIO ROSCELLY BARROS FAGUNDES 	2	1991	8	5	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14481	Beatriz do Vale Martins	2	92	5	24	F	90	8	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14224	André Luz Coleti	2	1992	5	2	M	293	8ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12206	Andressa Fabiana Silva	2	1993	12	10	F	157	7ª Série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13359	Ana Paula Feix	2	1991	7	6	F	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11466	ALESSANDRO BIGONI	2	1992	8	4	M	159	7	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14810	ADRIANO ROCHA BAIENSE PEREIRA 	2	1991	10	4	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12886	Tatiane Gomes Machado	2	1992	5	2	F	90	8	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15820	Ruan César Silva Sales	2	1992	9	25	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16029	Michael Lopes Rodrigues da Silva	2	9999	99	99	M	207	7a. série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10393	JULIANA DE SORDI DOS SANTOS	2	1992	9	9	F	48	8ª B	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12203	Carlos Henrique Ap. Manzo	2	1993	10	9	M	157	7ª Série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13576	Bianca Lima Magalhães	2	1993	3	14	F	285	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12030	THIAGO HENRIQUE DA COSTA PINTO	2	1993	12	26	M	6	7.ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1601	Leo Kaufman Dias Baptista	2	1993	3	22	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13571	Washington Roberto da Silva Neto	2	1993	5	2	M	285	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11757	Vinícius Henrique do Nascimento	2	1991	1	20	M	313	8°B	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14070	Vinicius Freire de Oliveira	2	1991	9	13	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12576	Thábata Tamires Silva	2	1993	6	25	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12561	Thaís Araújo Vieira	2	1993	5	29	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10554	Thalles Vichiato Breda	2	1993	5	21	M	473	7 C	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14958	Stephanie Pacheco Vettorato	2	1992	2	18	F	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10625	Samara Simões 	2	1993	5	30	F	473	7 E	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11845	Rômulo Pinho da Silva	2	1991	9	16	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11007	Roberta M. Storari	2	1991	9	14	F	473	8 D	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15574	Rafael Aparecido Joanini	2	1991	9	20	M	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11824	RENATO LOPES SILVA	2	1993	7	15	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14028	Nicole Claire Bindler	2	1992	10	20	F	544	8a série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14963	Mábila Thaina Gonçalves Souza Santos	2	1991	10	1	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11738	Michely Carolini Souza	2	1992	10	23	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14229	Mauro José de Souza Silva	2	1992	1	28	M	313	8ºA	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12999	Matheus Vitor Becker	2	1993	9	9	M	541	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13984	Matheus Naracci Guedes	2	1993	2	28	M	544	7a série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13814	Matheus Belchior	2	1994	12	15	M	516	5ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12835	Marcelle de Luca Tosto	2	1992	10	16	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11263	MATHEUS DA SILVA TIRADO	2	1992	10	10	M	373	7ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12831	Leonardo Dantas Barreto	2	1992	9	3	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13332	LORENA SIQUEIRA THOMAZ LEITE	2	1992	6	12	F	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15483	Kawhander Santana P. da Silva	2	1991	7	7	M	548	8ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11292	KAIO SÉRGIO CORREA DA SILVA	2	1992	8	8	M	373	8ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10686	Jéssica Solange Massarotti	2	1992	10	3	F	473	7 E	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15497	Jéssica Ferreira de Almeida Silva	2	1992	7	17	F	548	7ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15171	Jonas dos Santos Alves	2	1992	5	28	M	512	8ªA	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15169	Jaqueline dos Santos da Silva	2	1992	8	23	F	512	8ªA	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12669	Jakson Douglas Genarino Bueno	2	1990	8	4	M	313	8°F	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15439	JADIEL REIS DA SILVA	2	1991	12	31	M	555	8ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15472	Igor Diogo Videres Batista	2	1992	10	7	M	548	8ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13605	Iago Cunha Matos 	2	1991	10	21	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15570	Helena Florentina Gomes	2	1993	5	21	F	491	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12683	Haroldo Nogueira Silvério Júnior	2	1993	6	21	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14368	Gustavo Correa Dias Labriola	2	1993	2	17	M	517	setima	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14965	Graciele de Fátima Silva Cardoso	2	1991	6	30	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12814	Gabriella Santos de Borja Reis	2	1991	8	19	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11341	Gabriela D. Seleghim	2	1992	9	16	F	511	7ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14543	Gabriel Mangiapane de Camps Silva	2	1993	4	4	M	545	7	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13400	GIOVANNE BARRA GONÇALVES	2	1993	2	26	M	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11201	GABRIEL BARELA MACIEIRA CAETANO	2	1993	8	19	M	373	7ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14379	Felipe de Souza Bonati	2	1992	4	17	M	517	oitava	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11562	Fabiana do Nascimento Nunes	2	1993	6	5	F	350	7ª B (Esc. Amor Divino)	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11505	Erick W. Dos Santos	2	1992	1	11	M	313	8ªA	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12188	Elvis Héliton De Melo Lima	2	1993	4	20	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15174	Eduardo Leal Conceição	2	1991	9	16	M	512	8ªB	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11167	Edmar Victor Daniel	2	1992	5	4	M	473	8 C	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12189	Douglas Madeira Dos Santos	2	1993	4	3	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15487	Douglas Farias de Paula	2	1991	2	7	M	548	8ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12173	Daniela Cristina Silva Martins	2	1993	1	27	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13317	DIESLEI FERNANDO BRANQUINHO DOS SANTOS	2	1990	5	2	M	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11322	Cibele Fernandes	2	1992	3	16	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15499	Carlos Brendon Santos dos Anjos	2	1993	6	1	M	548	7ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14453	Bruna Luiza de Oliveira	2	1993	9	10	F	552	7ª2ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10628	Antônio da Silva Júnior	2	1992	11	26	M	473	7 A	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14081	André Parente	2	1992	11	27	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10536	André Brianti Panizollo	2	1993	8	12	M	473	7 D	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10678	André Alex Leme Filho	2	1992	9	1	M	473	7 E	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11013	Ana Paula Bino	2	1992	6	28	F	473	8 E	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11122	Ana Caroline Gomes	2	1993	7	7	F	313	7ªC	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12822	Amanda Peixoto Ferreira	2	1993	3	2	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12994	Alexandre Arana Nunes	2	1993	6	4	M	541	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13318	ANDRÉ GARCIA	2	1991	9	20	M	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11842	ANA CRISTINA LIMA RODRIGUES	2	1992	3	31	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13995	Vitor Amaral de Souza Santos	2	1993	11	6	M	544	7a série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1588	Yasmin Klein	2	1993	1	28	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14553	Yasmin Carlos Carvalho	2	91	12	13	F	90	8	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14817	YHAN KEPPLER PIRES NEVES 	2	1993	2	5	M	562	SÉTIMA 	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12843	Victor Hugo Gomes Veiga	2	1993	2	26	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10482	Thais Fernandes	2	1992	10	23	F	157	8ª Série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15488	Samuel Souza Silva de Oliveira	2	1991	11	14	M	548	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15484	Rodrigo da Silva Lopes	2	1991	10	3	M	548	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15365	REBECA SALES ROCHA SUCUPIRA	2	1994	3	1	F	555	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14207	Priscila Marques	2	1992	5	1	F	293	7ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13991	Porphirio Teixeira Alem	2	1992	6	10	M	544	7a série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14789	PAULA GABRIELLE SANTOS ALMEIDA	2	1992	12	12	M	122	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15495	Nathan Marzulo Martins	2	1992	6	22	M	548	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14518	Marina Cunha Hussni	2	1992	9	19	F	545	7a	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15474	Maira Cristina dos Santos 	2	1991	6	6	F	548	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11883	MARINA BARBOSA GOUVEIA	2	1993	5	19	F	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15363	MAGNUM MACHADO CAVALCANTE	2	1992	5	11	M	555	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12832	Leonardo Marinho Clemente da Rocha 	2	1992	10	3	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15442	LUCAS HENRIQUE FERRAZ BAIA	2	1990	2	13	M	555	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15765	JOÃO OCTÁVIO C. DA SILVA	2	1992	4	29	M	573	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12849	Frederico Fernandes da Anunciação 	2	1992	8	17	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16020	Everton Chaves P. Barbosa	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10484	Eliete Corrêa	2	1990	12	29	F	157	8ª Série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14806	ETYELE ROQUE MUNIS 	2	1991	7	7	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1593	Dasha Barg Pinto	2	1993	7	23	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13463	Daiane Chysler Costa dos Santos	2	1993	9	9	F	112	7ª serie	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12967	DIÊGO HENRIQUE GADÊLHA PEIXOTO	2	1993	2	26	M	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10354	DIOGO DE SORDI ROSSETO 	2	1991	5	29	M	48	8ª A	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12909	Casia Esmeralda Paz	2	1991	6	24	F	90	8	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1612	Carol Lafer Matandos	2	1993	7	30	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15955	CARLOS RAVEL SILVA SANTOS	2	1993	2	5	M	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14009	Bárbara Sewaybricker Munhoz	2	1991	10	12	F	544	8a série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16088	Andre Vecchi Pereira	2	1992	5	10	M	259	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13488	Ana Rute de Paiva	2	1992	12	6	F	540	7a série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12204	Alisson Ap. Rodrigues	2	1993	10	1	M	157	7ª Série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14612	Adriana Mousinho Cativo	2	1991	11	22	F	112	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12146	ANA PATRÍCIA KUTSCHAT	2	1993	10	5	F	215	17MB2	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12198	Vitor de Lima Ferraz	2	1991	5	18	M	157	7ª Série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12550	Verônica da Silva Benfica	2	1993	4	17	F	312	7ª C	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13008	RÉRISON DE SOUSA OLIVEIRA	2	1993	10	25	M	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14031	Rodrigo Fernandes Bernal	2	1992	2	19	M	544	8a série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15473	Roberto Augusto Soares Júnior	2	1992	10	7	M	548	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12875	Roberta da Rocha Aquino 	2	1990	3	26	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11373	RENNAN LOPES OLIO	2	1992	6	2	M	48	8ª C	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14529	RAMON FREIRE CORREA 	2	1993	4	9	M	196	7ª Série - Alfa	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16081	Paula Diana Bettiol	2	1993	7	17	F	259	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1636	Marina Dias Vital	2	1991	11	8	F	153	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10939	Marina Ajzen Perez	2	1992	6	19	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11884	MATEUS HENRIQUE MENDES	2	1992	12	29	M	196	7ªSérie - Master	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15501	Lucas Pereira da Rocha Ferreira	2	1992	12	9	M	548	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16026	Lucas Guariento	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14417	Laila Janna Canto Tavares	2	1992	12	3	F	112	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15486	Jéssica Patrícia Rodrigues	2	1991	10	18	F	548	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15498	Juliana da Silva Alves	2	1993	2	5	F	548	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12830	Juliana Figueiredo Barboza	2	1992	11	6	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12549	Jamil Vidigal Júnior	2	1993	10	31	M	312	7ª C	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13978	Giovana Velo Moreira Ribas	2	1990	9	3	F	544	7a série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13751	Giego Henrique Rodrigues de Lima	2	92	6	17	M	90	8	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13972	Fernanda Heleno Randazzo	2	1992	12	29	F	544	7a série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11468	FELLIPE AUGUSTO GALETI MAURO	2	1992	11	7	M	159	7	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15351	ELTON DOS SANTOS VERAS	2	1994	1	15	M	555	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14441	Diêgo Moreira da Silva	2	1991	9	20	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15504	Bruno Bezerra do Nascimento	2	1992	9	20	M	548	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10942	Andrea Koatz	2	1992	3	22	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13836	Amanda Domiciano	2	1992	4	18	F	216	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14945	ÉRICA REIS CARVALHO	2	1992	4	8	F	5	8o	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13688	Felipe Carneiro Correia Montenegro	1	1994	5	11	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15543	Yago Abner Favaretto	2	1992	5	30	M	497	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14780	YATHIAIA CRISTINA MELO DOS SANTOS	2	1992	2	14	F	179	9º ANO B	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11530	Wellington Placidino De Almeida	2	1992	10	7	M	313	7ªD	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13325	WILSON ALVES DA ROCHA	2	1992	4	18	M	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12056	WESLEY ROCHA DOS SANTOS	2	1991	7	27	M	215	18EC	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13604	Thiago Yudd Rocha Yamate	2	1992	6	9	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12573	Thainá Ribeiro	2	1992	12	17	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13469	Talita dos Santos Costa	2	1993	5	15	F	112	7ª serie	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11266	THIELLE SIMAS RIBEIRO	2	1993	9	15	F	373	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11308	THAIS CAROLINA GOMES	2	1992	1	14	F	373	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12690	Renata de Oliveira Lima	2	1992	12	8	F	313	7ªE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1624	Renata Galbinski Abraham	2	1993	10	22	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15177	Renan Souza dos Santos	2	1992	6	27	M	512	8ªB	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11816	ROZANA FERNANDES DA SILVA ALMEIDA	2	1992	1	1	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11659	ROBERTO EUDES PONTES COSTA FILHO	2	1992	5	30	M	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13315	RHÔNALD ALEXANDRE ALVES FRANCO	2	1991	11	10	M	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11336	Pedro Rezende Magalhães	2	1993	4	5	M	511	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15547	Paulo Rogério Pires de Oliveira Filho	2	1991	8	27	M	497	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11328	Natasha Imaculada Conceição	2	1992	2	18	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14030	Mylena Euler Baboza da Silva	2	1993	11	22	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13217	Monyke Mendes Gouveia	2	1994	1	7	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12682	Mateus Lopes Gois	2	1993	4	25	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16028	Marcio de O. Santiago Filho	2	9999	99	99	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11299	MATHEUS COSTA MACHADO	2	1991	7	15	M	373	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12196	Luana Aparecida Simões	2	1993	4	8	F	157	7ª Série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10407	Lisandra de Jesus Antônio	2	1991	8	2	F	313	8°C	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11259	LEANDRO CARDOSO MEIRELES MATTOS	2	1992	6	24	M	373	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10408	Kédima Prince de Andrade	2	1991	12	23	F	313	8°C	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10647	Jéssica Ludmila Armani	2	1992	10	7	F	473	7 A	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14380	Juliana Senna Massoni	2	1991	12	12	F	517	oitava	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14386	Jacqueline Ferlete Romera	2	1991	11	13	F	517	oitava	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11288	JULIO CESAR DA SILVA SANTOS	2	1992	4	27	M	373	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14575	Imelda Angelim Sucupira	2	1991	6	11	F	516	7[	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13115	Iasmim Carvalho Alves	2	1993	7	5	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11286	ISABELLA MONTENEGRO TÁVORA	2	1992	7	17	F	373	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16085	Hugo Henriuqe Diana	2	1993	3	11	M	259	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15002	HENRIQUE PARAÍZO DE MELLO	2	1992	10	8	M	215	17EC	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11507	Gustavo Ribeiro Gonçalves	2	1992	3	21	M	313	8ªA	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11005	Gislaine  Oliveira Santos	2	1992	2	21	F	473	8 D	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11203	GABRIELA ANDRADE PAZ	2	1992	7	7	F	373	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11508	Franciele Da Silva Corrêa	2	1992	2	13	F	313	8ªA	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10665	Fernando Henrique de Oliveira Langieri	2	1992	12	18	M	473	7 E	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1573	Fernanda Machado Cyon	2	1992	12	2	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15183	Felipe Santos Ramos	2	1991	9	18	M	512	8ªD	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16022	Felipe Menezes Arantes	2	9999	99	99	M	207	7a. série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13411	FERNANDO ANTONIO COELHO LIMA FILHO	2	1993	5	10	M	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14783	FERNANDA DE ARRUDA BOTELHO GORSKI	2	1993	4	27	F	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14964	Erika Mariane dos Santos	2	1991	10	30	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12601	Douglas Alves Ferreira	2	1992	5	12	M	312	8ª E	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14378	Dexson Jose Ferro	2	1992	2	19	M	517	oitava	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1595	Deborah Wainsztok	2	1993	2	15	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10619	Dayana Dalvana Borges	2	1993	11	25	F	473	7 E	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10317	Daniella Sophia Leal	2	1992	4	2	F	258	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11759	Cleiton da Silva Nascimento	2	1991	1	20	M	313	8°B	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11500	Carolina Gouvêa Da Costa Vieira	2	1993	2	4	F	313	7ªA	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14736	Carlos Roberto Martins	2	1992	1	1	M	312	7ª C	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13102	Bárbara Rayssa da Silva Flores	2	1993	6	15	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11125	Angélica Paulista da Silva	2	1993	3	5	F	313	7ªC	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12586	Angélica Cristina Martins	2	1990	7	26	F	312	8ª C	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15822	Ana Carolina Pereira do Nascimento	2	1991	5	23	F	312	8ª A	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14745	Alexandre Augusto Garcia	2	1992	10	23	M	312	7ª D	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14750	Adriele Tamaira Vicente da Silva	2	1993	6	11	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11190	ALAN ABREU DE OLIVEIRA	2	1992	7	1	M	373	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13690	Felipe Rolim Freitas Mota Maia	1	1993	9	4	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13870	JÉSSICA VITÓRIA REGINA ALVES ACÁRIO	1	1994	10	8	F	488	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11520	Wilian Rodrigues Silva	2	1993	7	17	M	313	7ªE	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10384	RHAISSA M. ALVES	2	1993	8	24	F	48	7ª D	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12911	Priscilla Machado Borgatti	2	1991	7	13	F	90	8	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13985	Paulo Sérgio Godoi Corrêa Júnior	2	1993	2	26	M	544	7a série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12908	Natasha Sousa Dias	2	1992	10	15	F	90	8	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15821	Marília Luzia Cândida Dias	2	1990	12	13	F	312	8ª A	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11528	Julio Lourenço da Silva Martins	2	1990	6	23	M	313	7ªD	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11290	JULLYANA MARTINS BRAGANÇA SANTOS	2	1993	3	8	F	373	8ª	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10390	JESSICA PEREIRA DE SOUZA	2	1992	7	7	F	48	8ª B	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14228	Iara Ananias Silva	2	1992	11	11	F	313	7ºB	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14370	Gustavo Tiake Morimoto	2	1992	10	9	M	517	setima	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14957	Camila da Silva Martins	2	1991	8	10	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12811	Bianca Maria Santos de Borja Reis	2	1993	4	27	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12823	Andressa Salutto Gomes 	2	1992	6	19	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14805	AMANDA DE SOUZA OLIVEIRA 	2	1992	3	18	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14747	Wesley Augusto Ribeiro da silva	2	1992	7	24	M	312	7ª E	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11315	WILLIAN SILVA DE PAULA MENEZES	2	1991	11	9	M	373	8ª	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15477	Vinicius Moreira Rigueira	2	1992	10	3	M	548	8ª	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12819	Vinicius Bastos Cruz	2	1990	6	19	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14818	VICTOR COUTINHO DE ALCANTARA 	2	1993	3	16	M	562	SÉTIMA 	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10657	Tiago Willian da Silva	2	1992	6	24	M	473	7 B	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12548	Thaís Cristina Marques	2	1993	2	2	F	312	7ª B	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15506	Sabrina Soares dos Reis	2	1990	2	1	F	548	7ª	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10318	Ricardo Sophia Leal	2	1993	4	16	M	258	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13758	Raiane Silva da Penha	2	92	1	30	F	90	8	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13330	PAULO HENRIQUE MARÇAL ANACLETO	2	1992	4	22	M	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12885	Nathalia Assis Porfirio	2	1992	3	5	F	90	8	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12578	Mariane Julião Brito	2	1991	7	6	F	312	8ª A	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12857	Marcos Paulo do Valle Alves Lima	2	1991	12	2	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8063	Marcel Augusto Sastre Dias	2	1992	7	28	M	313	7ªC	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11790	Luis Fernando De Sales	2	1990	6	12	M	313	8ºF	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12872	Luis Felipe de Souza Krassius do Amparo	2	1990	12	3	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12855	Lucas Dias Machado	2	1990	5	19	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11834	Leandro Gonçalves	2	1991	11	8	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14920	LORENA ARAUJO SILVA	2	1992	11	30	F	5	8o	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14014	Julia Ruiz	2	1991	12	18	F	544	8a série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14422	Jacimara da Cruz Valério	2	1992	8	11	F	112	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
192	JULIANA COETTI BASSO	2	1991	10	13	F	48	8ª C	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14493	Helder Feijão Cardoso	2	1991	11	26	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16073	Gustavo Furlan Guimaraes	2	1993	7	12	M	259	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10653	Gislaine Cristina Sartoratto	2	1993	5	24	F	473	7 E	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14763	Geraldo Luiz Miranda Neto	2	1991	12	5	M	312	8ª D	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12540	Gabrielli Antonelli de Oliveira	2	1993	2	1	F	312	7ª A	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10622	Gabriel Domingos dos Santos Junior	2	1992	4	9	M	473	7 B	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11523	Fábio César da Silva	2	1992	3	3	M	313	7ªE	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15496	Felipe Antonio Pinto Queiroz	2	1992	6	3	M	548	7ª	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11199	FLAVIA FORTUNATO VIEIRA DE SOUZA	2	1993	8	11	F	373	7ª	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12059	FELIPE COSTA FERREIRA	2	1992	8	22	M	215	17EC	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11788	Espedito Augusto De Castro Filho	2	1990	9	12	M	313	8ºF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11889	EMMANUEL LUIZ MOREIRA SIQUEIRA	2	1991	7	2	M	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12572	Deborah Natália	2	1993	1	14	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15695	Danilo Casanova Corcini Simão	2	1992	10	6	M	8	oitava série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14475	Bruna Diana Peixoto	2	90	11	19	F	90	8	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13329	BEATRIZ PEREIRA DA SILVA	2	1991	8	13	F	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12574	Arthur Gonçalves	2	1991	11	18	M	312	7ª E	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12864	Anna Maria Vieira da Silva	2	1992	5	29	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14435	André Luiz Vinhas Mendes	2	1990	5	7	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13108	Anaíra Reis Jorge da Cunha	2	1993	5	28	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11159	Ana Paula Ribeiro	2	1992	4	11	F	473	8 B	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15489	Alisson Michel V. Silva	2	1991	12	6	M	548	8ª	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12547	Agnaldo Carloni Bolonha Júnior	2	1993	4	20	M	312	7ª B	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14934	ANA GABRIELA MACHADO DRIGO	2	1993	8	27	F	5	7o	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14674	Eduardo Schmidt	2	1992	9	11	M	552	7ª1ª	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13872	LEONARDO FERREIRA BARROS	1	1994	6	27	M	488	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11996	TAMIRES CERQUEIRA LARA	1	1995	7	25	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11600	Israel Eustáquio Lopes da Silva	1	1994	10	7	M	350	5ª A (Esc. Marcos de Barros Freires)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11599	Emmeson Dysson C. dos Santos	1	1992	5	10	M	350	6ª A (Esc. Jorn. Costa Porto)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11645	EDUARDO SOUSA TELLO	1	1995	2	14	M	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11647	ANA CAROLINA DE AZEVEDO SALAS ROLDAN	1	1994	8	15	F	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12770	Áurea Sena dos Santos	2	1993	5	27	F	112	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12880	Vinicius Abud Contino Vianna	2	1991	11	4	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14855	RAISSA FERRAZ MASCHIETTO	2	1993	5	15	F	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14494	Plínio Marcus Ferreira Lima da Paixão	2	1991	1	2	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15176	Peterson Lucas Nunes Feijo	2	1991	12	30	M	512	8ªB	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14784	PAULA DE ARRUDA BOTELHO COLTURATO	2	1993	5	10	F	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11127	Nayara Aparecida da Silva	2	1992	5	23	F	313	7ªC	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13010	Matheus Ribeiro Mendes Andreotti	2	1993	8	27	M	541	7ª série	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12834	Lucas Rodrigues Cunha	2	1993	6	12	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10321	Eduardo Nicolau da Costa Filho	2	1992	7	15	M	7	7ª série - Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14819	EDINETE DA SILVA CUNHA 	2	1990	7	2	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1611	Carla Goldenberg Gilbert	2	1993	8	17	F	153	7ª Série	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12564	Anelise Dias Silva	2	1993	4	21	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11311	VINICIUS ALMEIDA GONÇALVES	2	1991	11	13	M	373	8ª	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11646	VICENTE JANDERILSON ALVES DAMASCENO	2	1992	4	15	M	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11597	Tales de Lima Pedrosa	2	1993	5	17	M	350	7ª A (Esc. Decisão)	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12876	Ricardo dos Santos Soares 	2	1992	3	30	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1582	Rafael Heilberg	2	1993	2	23	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14506	Pedro Conceição Godinho Junior	2	1991	10	17	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12776	Mayara Ferreira da Silva	2	1992	7	7	F	112	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14908	MARLY DA SILVA LEITE	2	1992	2	4	F	5	8o	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11755	Luíz Marcelo Pereira	2	1986	9	30	M	313	8°B	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15503	Luana Felipe de Lima	2	1992	4	22	F	548	7ª	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11498	Leonardo Silva Balena	2	1992	9	27	M	313	7ªA	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11515	Leandro Wágner Da Silva	2	1992	11	28	M	313	7ªE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13015	LUCAS JOSÉ MENDES DOS SANTOS	2	1993	4	24	M	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11296	LETÍCIA DA SILVA CARNEVALLE	2	1992	10	19	F	373	8ª	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13451	Krizzamm M. Pereira Alvarenga	2	1994	8	12	M	112	7ª serie	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15480	Kelvin Lopes A.	2	1991	7	6	M	548	8ª	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15357	JAMILLE CAVALCANTE DE PAULA	2	1993	1	30	F	555	7ª	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14966	Franciele Aparecida Ushikawa	2	1992	3	10	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12190	Estefani Aparecida da Silva	2	1992	11	14	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12906	Douglas Menezes Frederico	2	1991	10	15	M	90	8	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15502	Diogo Miranda Costa	2	1992	12	24	M	548	7ª	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12541	Diego Ferreira de Almeida	2	1992	12	31	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12847	Daniele Garcia de Oliveira	2	1991	7	6	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1570	Daniela Nimtzovitch Cualhete	2	1992	10	10	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14802	DOUGLAS MELLO HEMERLY DE SOUZA	2	1991	9	22	M	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
247	DANTARA RAYANE GONÇALVES MARTINSBIANCO	2	1991	11	5	F	48	8ª B	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14801	BÁRBARA RODRIGUES DA SILVA  	2	1992	11	6	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12207	Bruno Moura Fagionato	2	1990	7	1	M	157	7ª Série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11360	Ana Carolina Gratieri Maciel	2	1991	6	15	F	511	8ª'	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11598	Alysson dos Santos Lima	2	1993	10	7	M	350	7ª A (Esc. Especial)	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14816	 VICTOR DE FREITAS ALMEIDA 	2	1992	8	17	M	562	SÉTIMA 	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11535	Mirele Aparecida Inocêncio	2	1993	7	31	M	313	7ªD	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1580	Marcelo Nulman Perez de Lyra	2	1992	11	25	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10364	MAYARA DE SOUZA BIANCHETTI 	2	1993	10	20	F	48	7ª A	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14496	Lucas Vinicius Fernandes Coelho	2	1992	9	5	M	112	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14489	Igor Lima Bezerra	2	92	1	9	M	90	8	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1630	Elisa Cassorla Passamanik	2	1992	7	31	F	153	8ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13323	DÉBORA RODRIGUES DE QUEIROZ	2	1991	3	23	F	508	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10292	David Felipe Abrante	2	1993	1	25	M	393	Ciclo IV - Inicial B	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14289	VITOR HUGO DE OLIVEIRA	2	1992	9	4	M	5	7o C	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14756	Thaís Juliana B. da Silva	2	1991	6	30	F	312	8ª A	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14346	Rodrigo Kimelblat	2	1993	7	25	M	216	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14388	Ricardo Soeiro	2	1992	4	27	M	517	oitava	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13493	Laura dos Reis Sant´Ana Basilio	2	1990	11	14	F	540	7a série	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10269	ALAN SOUZA DA SILVA	2	1991	5	17	M	6	7.ª	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11595	José Gomes da Silva Neto	1	1993	5	7	M	350	6ª A (Educandário Desenvolver)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12525	Tamíris Cristina Nunes Teófilo	1	1994	6	7	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11985	TIAGO BARBOSA SANTOS	1	1995	1	2	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11667	THAIS RODRIGUES NOGUEIRA	1	1995	4	18	F	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15603	THAIS G. SUHETT	1	1995	7	9	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11986	RODRIGO DIAS CORRÊA	1	1995	10	4	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14455	RENATO DUCCI	1	1995	5	2	M	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11652	REBECA BAIMA SANTOS	1	1993	9	16	F	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15602	RAQUEL CAMPOS PEREIRA	1	1995	9	2	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12452	Pedro Rogério Escudero Filho	1	1994	12	17	M	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11994	NEWTON CEZAR RODRIGUES JUNIOR	1	1995	11	20	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12529	Monique Laís de Souza Teixeira	1	1994	5	30	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12530	Matheus Lamim dos Santos	1	1994	8	23	M	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11995	MAUREANE SILVA PEDROSO	1	1995	4	16	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15601	MATHEUS VIDIGAL	1	1995	6	16	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11966	MATHEUS PEREIRA DE LIMA	1	1995	8	14	M	355	5ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11980	LUAN ROBERTO ROSA	1	1993	12	26	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12091	LARISSA LAYARA LINS DE SIQUEIRA SILVA	1	1995	11	8	F	171	5ª SÉRIE D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12526	Juliane Aparecida Ribeiro	1	1994	5	17	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12456	Jorge Felipe de Souza	1	1995	6	21	M	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15599	JOÃO GUERINI	1	1994	8	11	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13580	Isabela Vieira de Oliveira	1	1994	6	30	F	482	6ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15432	ITALO MATHEUS NOGUEIRA DEE AMORIM	1	1993	8	26	M	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14687	Hermínio R. Júnior	1	1992	1	1	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15598	GIOVANNI PERSIO	1	1994	8	11	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15597	GABRIELA C. RODRIGUES	1	1995	7	28	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15596	GABRIEL S. SOUZA	1	1995	1	21	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13609	Fernando Furtado de Melo Neto	1	1995	2	8	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15595	FELIPE MOULIN	1	1995	1	10	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11981	FELIPE DE JESUS SILVA	1	1995	4	7	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11982	FABRICIO DE ALMEIDA VIEIRA	1	1995	11	10	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12461	Evelyn Andrade de Lima	1	1994	3	9	F	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13608	Eduardo Castro Barbosa	1	1994	8	31	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12455	Dário Mateus Gomes Neto	1	1992	4	21	M	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13612	Dhaine Tiepo	1	1995	6	30	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12453	Caroline Mariana Reis Silva	1	1995	6	22	F	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11967	CAMILA DA ROSA SILVA	1	1995	3	1	F	355	5ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15594	CAIO	1	1994	8	12	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15593	BRUNO LOPES	1	1995	7	27	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11987	BRENDA CAROLINE SIMÕES RODRIGUES	1	1995	1	3	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15592	BERNARDO	1	1995	6	10	M	533	6ª S (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13578	Yuri Lopes Falcão	2	1992	11	21	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13583	Débora Nobre Araújo	2	1992	8	19	F	527	8ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12089	WEDER DONIZETE DOS SANTOS SILVA JUNIOR	2	1993	3	10	M	171	7ª SÉRIE D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11649	VITÓRIA GRÍDVIA BANDEIRA	2	1992	10	15	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14906	TARCILA FLORENÇA CONTAGEM	2	1992	4	28	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12629	STEPHANIE SOUSA DE MARIA LIMA	2	1992	9	7	F	196	7ª Série - Gama	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12130	Rodrigo de Almeida Toquini	2	1993	2	22	M	393	Ciclo IV - Inicial B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11648	RODRIGO GROSSI CAVALCANTE MILFONT GARCIA	2	1992	6	2	M	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12630	RAFAEL MARCAL PARENTE	2	1991	12	26	M	196	8ª Série - Gama	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14483	Nathan Gabriel Pires da Silva	2	92	2	8	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13594	Luciano Luca R. Zornitta	2	1992	4	17	M	527	8ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13569	Luciano Baldini Cardoso	2	1992	2	28	M	59	8a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12458	LETICIA AMANCIO 	2	1993	8	19	F	355	7ª SÉRIE A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12454	JOSÉ EUCLIDES ROCHA 	2	1992	10	11	M	355	7ª SÉRIE A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11650	ISADORA DE SOUZA MAIA LIMA	2	1992	3	9	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14486	Gustavo Ogg Ferreira M. Tavares	2	92	4	23	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12539	Geovana Daniela Souza Ferreira	2	1993	5	20	F	312	7ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14482	Gabriel Aguiar de Souza	2	90	2	16	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12538	Flávia Borges Moraes	2	1993	6	20	F	312	7ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14480	Fernanda Neves da Cunha	2	91	10	22	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12035	FELIPE EL BANNA SALDANHA	2	1993	3	9	M	6	7.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12119	Elson de Aguiar	2	1991	12	26	M	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12032	CARLOS ROBERTO BARBOSA DA SILVA JUNIOR	2	1992	5	8	M	6	7.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13591	Bruno Mesquita Ponte	2	1993	10	20	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14478	Bianca Fernandes da Silva	2	91	10	31	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11983	VICTOR QUARTEROLI RAMOS GOMES	1	1995	12	1	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15050	Sara de Oliveira	1	1994	4	25	F	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15610	SAMYRA DE F. Z. CASTELLO	1	1994	4	13	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15634	Rafaela Golçalves Mota	1	1992	11	16	F	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15874	ROBSON CLEITON DE SOUZA	1	1986	5	25	M	480	6ª SERIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15199	Maria Paula Santille Borges	1	1995	12	29	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13527	Marcio Breno Bedê Silva Aguiar	1	1994	12	10	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15608	MARIANNA C. D. SIQUIERA	1	1994	1	25	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15197	Luciana Luchesi Rodrigues Alves	1	1995	3	17	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14290	PAOLA EUGÊNIO	2	1992	12	9	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15204	Lucca Crocce	1	1995	5	30	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15215	Lia Tesser Grizzo	1	1994	7	15	M	144	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15205	Leonardo Perez Candioto	1	1995	4	26	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15202	Leonardo Baccari Ortigoza	1	1995	8	22	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15614	LUCAS M. DA SILVA	1	1994	1	12	M	533	6ª S(EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12687	Kaique Munhoz 	1	1994	3	9	M	313	6°A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15206	Julia Galvão Rocha de Sousa Cardoso	1	1995	6	6	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15635	José Francisco de Souza Junior	1	1994	3	14	M	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12685	Jairo Luíz de Lima Junior	1	1993	11	2	M	313	6°A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15208	Itamara Ackermann Epifanio	1	1995	1	5	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15213	Isabella Mulero Faracco	1	1994	3	30	F	144	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15609	ISIS B. LOPES	1	1994	4	21	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15611	IGOR SAMPAIO	1	1994	6	30	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15210	Gabriela Pereira Rodrigues	1	1994	7	22	F	144	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15613	GUSTAVO F. G. PINTO	1	1993	10	26	M	533	6ªS (EF0	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15752	ENRICO SANTOS CANDUCCI MOLINA	1	1997	11	13	M	175	4a. Série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15612	EDUARDO I. BRAGA	1	1994	4	22	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13528	Dominik Barros Brito	1	1994	1	27	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15866	DINÁ RAIRA BORGES E SILVA	1	1997	7	4	F	480	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15615	DENISE	1	1994	7	12	F	533	6ªS(EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15606	DANIEL	1	1994	2	10	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15212	Bruna Correa da Silva	1	1994	7	23	F	144	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15875	BRUNA RENATA LORENÇO DE OLIVEIRA	1	1995	7	2	F	480	6ª SERIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15616	BRUNA	1	1993	11	18	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15607	BIANCA S. MOREIRA	1	1994	2	8	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15203	Aristides Auler do Santo Neto	1	1994	12	1	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15880	ANTONIO JONHLENNO DA SILVA	1	1990	10	10	M	480	6ª SERIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10262	ANDRÉ LUIZ DE ALCÂNTARA ANDRADE	1	1994	5	14	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15882	ADNA PRISCYLLA S. NOLASCO	1	1992	9	26	F	480	6ª SERIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15048	Yana Cristina Coelho Pereira	2	1991	8	11	F	192	8ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12678	Savio Fonseca Nobrega Veloso	2	1990	9	11	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15221	João Pedro Magalhaes Capelini	2	1992	2	23	M	144	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15223	Vanessa Thiago Custodio	2	1991	11	23	F	144	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12671	Thiago Renan Castilho Pinto	2	1992	8	28	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12668	Robson de Paula Ferreira 	2	1990	5	30	M	313	8°F	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12684	Renata de Oliveira Cunha	2	1992	5	7	F	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12686	Priscila Izabel de Oliveira	2	1992	9	9	F	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15222	Nicolas Fernando de Oliveira	2	1992	8	20	M	144	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15115	Marcos Paulo Ilha Oliveira	2	89	10	1	M	479	Oitava Serie Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15218	Leonardo Simoes Agapito	2	1993	2	20	M	144	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12673	Leonardo Cassiano P. de Santana	2	1993	2	16	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12681	Larissa Graziele Januário da Silva	2	1993	7	14	F	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12676	Juan Pedro Baena Cassal	2	1992	10	3	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15858	JACKELINE RODRIGUES DE SOUZA	2	1992	3	27	F	480	8ª SERIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12672	Gustavo Rocha Moreno Sanches	2	1993	2	1	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15219	Guilherme Zucato	2	1992	4	25	M	144	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15860	GABRIELLA DIANA DE SOUZA	2	1994	1	23	F	480	6ª SERIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15220	Felipe de Lima Siminoni	2	1992	8	23	M	144	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10413	Douglas Flório Ubeda  Almeida	2	1992	4	1	M	313	8° E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12688	Bryan Serpa Gomes	2	1993	2	12	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15049	Bruno de Araújo Fonseca	2	1993	6	1	M	192	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15207	Ariane Fiamengui Massola	2	1995	4	27	M	144	5ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12545	André Francisco da Silva	2	1993	4	18	M	312	7ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12680	Alex Junio da Silva Santos	2	1991	7	17	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15881	ANA PAULA DA SILVA	2	1989	5	9	F	480	7ª SÉIRE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15871	ANA LUIZA SILVA DE MEDEIROS	2	1991	11	19	F	480	8ª SERIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15872	ADRIEL GOIS DE CARVALHO	2	1990	10	16	M	480	8ª SERIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15751	THIAGO MALUF	1	1996	5	7	M	175	4a. Série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10468	ISABELLA BERMUDES MODENESE	1	1994	12	21	F	29	6ª série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10506	Vera Ruth Simões Pinto	1	1994	9	9	F	473	5 A   	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11156	Rafael de Souza	1	1994	10	22	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11035	Maria Beatriz Ferreira Emídio	1	95	7	13	F	313	5ºE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11194	Igor Matheus de S. Santos	1	1995	3	17	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11086	Vivian Lima dos Santos	1	1995	5	2	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11145	Vitória Calim dos Santos	1	1995	4	17	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11153	Vinícius Pimentel	1	1994	11	20	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11177	Veronica Fernandes	1	1995	8	11	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10960	Valquíria Aparecida Fortunato	1	1993	2	3	F	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10996	Tiago Gonçalves Fontes	1	1995	6	6	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11004	Tiago Carlos Cauzine	1	1995	2	8	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11148	Thiago B. Carile	1	1994	11	4	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11094	Thaís Aguilhera Miranda	1	1995	7	20	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10492	Thainara Bueno Coito	1	1995	1	13	F	473	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11000	Tatiane Gonçalves de Alfenas	1	1994	2	23	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10499	Rodrigo Pessutto	1	1995	2	16	M	473	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10978	Resiele Thaís de Paula	1	1994	5	17	F	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11024	Rafaela Juliana Barbosa	1	1995	5	9	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10500	Rafaela B. dos Santos	1	1994	3	23	F	473	6 D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11155	Rafael de Souza	1	1994	10	22	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11146	Rafael P. Brito	1	1994	9	16	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10975	Paulo Sérgio de Souza	1	1993	10	5	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11081	Natália Alves da Silva   	1	1994	9	5	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11034	Michele Ferreira Olímpio	1	1994	7	13	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10497	Matheus Henrique de Oliveira	1	1995	4	12	M	473	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10982	Marina Souza Azarias	1	1994	5	10	F	313	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10565	Mariana Felicio de Godoy	1	1994	5	16	F	473	6ª C	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10971	Marcos Pacheco Ribeiro	1	1994	3	7	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11157	Marcelo Augusto de Oliveira Mathias	1	1995	11	11	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11151	Marcela B. G. Fernandes	1	1994	6	22	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10985	Maicon da Costa Inácio	1	1994	5	7	M	313	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11072	Luiz Augusto Nascimento Castro	1	1994	9	22	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11029	Luciene de Jesus Alabarse	1	1995	2	12	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10956	Lucas Henrique Borges	1	1994	2	14	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11084	Lucas Constantino de Castro	1	1995	7	9	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11082	Letícia da Silva	1	1995	5	13	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10981	Letícia Marcolino Miquetti	1	1994	2	6	F	313	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10264	LAÍS BARBOSA DE NORONHA	1	1994	7	22	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10267	LARIZA OLIVEIRA DE SOUZA	1	1994	7	8	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11071	Jéssica dos Santos	1	1995	1	2	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10990	Jéssica Souza Graciano	1	1993	9	15	F	313	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10504	Isabela de Cássia Pedroso	1	1993	12	13	F	473	6 D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10974	Heitor Segura de Araujo	1	1995	6	23	M	511	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11113	Heber Henrique da Silva	1	1994	5	6	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11154	Guilherme C. Ribeiro	1	1994	11	23	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10977	Gisele Thaís de Paula	1	1994	5	17	F	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10987	Gabriela Coelho de Souza	1	1993	9	11	F	313	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11002	Franciele de Cássia Pereira Alves	1	1994	12	23	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10261	FERNANDO HENRIQUE VASCONCELOS DOS SANTOS	1	1994	4	5	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11097	Emerson Ap. Máximo	1	1992	2	8	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10965	Donizeti Aparecido da Silva	1	1994	6	6	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11019	David A. da Silva Bárbara	1	1995	2	11	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11149	Daniel M. Losnach	1	1995	1	19	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11010	Daniel Henrique Alves Mendes	1	1995	3	19	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10260	DALMO TSUYOSHI VENTURIERI	1	1994	3	2	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10266	CAMILLA DE LIMA SOPHES BORGES	1	1993	9	6	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11068	Breno de Oliveira Vidigal	1	1995	8	18	M	313	5ºE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10994	Angélica Torres	1	1993	9	18	F	313	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11078	Anderson Andrade Matias	1	1995	6	29	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10949	Adriane Cristina Vitor	1	1993	9	14	F	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10451	ANTÔNIO MATEUS BARRETO GONDIM	1	1993	10	6	M	488	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10271	ANDRESA OLIVEIRA DE MENEZES	1	1994	12	18	F	6	5.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11165	Thiago Lira da Silva	2	1992	1	20	M	473	8 B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11166	Ronan Felipe Jorge	2	1992	4	2	M	473	8 B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11009	Mariana Dias da Silva	2	1991	3	10	F	473	8 F	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11016	Kátia Regina Xavier	2	1988	5	29	F	473	8 E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11027	Daniela Ribeiro Golfetto	2	1992	6	11	F	473	8 B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10992	Wérverton Ap. de Araújo	1	1994	1	18	M	313	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11438	VICTÓRIA CORBAN PIERANGELLI	1	1995	2	15	F	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11184	Tainara Cézar da S. Cruz	1	1994	11	12	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11437	THIAGO MILLON COELHO DE MAGALHÃES	1	1994	9	14	M	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11586	Suesivania Siqueira da Silva	1	1995	7	7	F	350	5ª B (Esc. Rita Lessa)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11551	Rafaela Estevam da Silva	1	1993	5	2	F	350	1ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11542	Rafael Estevam Lima da Silva	1	1996	4	1	M	350	3ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11426	RENATA SIMIONI CASANOVA	1	1995	6	26	F	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11219	RAYANE SILVA DE ARAUJO  LIMA	1	1993	8	17	F	196	6ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11618	RAFAEL HERNANDEZ	1	1995	9	30	M	355	5ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11538	Priscila Maria dos Santos	1	1995	5	23	F	350	5ª B (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11572	Michele Alane da Silva Nóbrega	1	1994	12	14	F	350	5ª B (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11564	Maria Vanessa da Silva	1	1994	7	8	F	350	3ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11556	Maike François Araujo Ventura	1	1994	2	5	M	350	3ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11186	MATHEUS FERNANDES MOURÃO	1	1995	6	27	M	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11439	MARIANNA EBOLI	1	1993	12	29	F	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11433	LÍVIA DE CASTRO LINHARES	1	1994	9	30	F	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11208	Lucas Philip Reaiche	1	1995	3	30	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11329	Lara Léllis	1	1994	6	19	F	511	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4383	LIVANCLIR AMBERTON DE CASTRO SOUSA	1	1994	3	22	M	355	6ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11579	Karolina do Nascimento Nunes	1	1995	6	8	F	350	5ª A (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11557	Karina Alves Porfirio da Silva	1	1995	2	9	F	350	5ª B (Esc. Rita Lessa)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11423	KAIQUE FERREIRA GUIMARÃES	1	1995	2	6	M	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11235	Juarez Augusto da Silva Junior	1	1993	1	13	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11558	João Vitor Alves da Silva	1	1996	3	24	M	350	1ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11581	Joseilton Pereira Virginio Júnior	1	1995	3	7	M	350	4ª A (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11555	Jose Carlos Manoel da Silva	1	1995	6	7	M	350	2ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11210	Jefferson R. M. Belido	1	1995	4	5	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11613	JUAN CARLOS SIMÕES MACIEL	1	1995	5	13	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11573	Isaque Fernandes dos Santos	1	1997	9	26	M	350	1ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11342	Igor Matheus de Souza Santos	1	1995	3	17	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11431	ISABELA DE MORAES EVANGELISTA	1	1995	11	14	F	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11545	Felipe Trindade Neves	1	1995	9	12	M	350	3ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11574	Felipe Mateus dos Santos	1	1995	11	4	M	350	3ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11589	Felipe Francisco da Silva	1	1991	8	27	M	350	6ª A (Esc. Marcos de Barros Freires)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11548	Fabio Bevenuto dos Santos Junior	1	1997	1	1	M	350	3ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11207	Evelyn Vieira Pinto	1	1989	5	8	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11563	Diego da Silva Braz	1	1995	8	26	M	350	3ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11565	Davi José da Silva	1	1992	11	23	M	350	5ª C (Esc. Rita Lessa)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11587	Danily Candido da Silva	1	1994	9	30	F	350	4ª A (Esc. Roberto Silveira)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11324	Daniela Bonfim Melo	1	1994	8	18	F	511	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11224	DAVI BRAGA VALENTE	1	1994	1	17	M	196	6ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11205	DANIELLE CIPRIANO ROLIM	1	1995	1	13	F	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11440	CAIO C. MUROSA	1	1994	1	19	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11419	CAIO BONALDI	1	1995	4	16	M	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11603	Breno Heitor Barbosa de Carvalho	1	1995	4	20	M	350	5ª A (Esc. Movimento Criativo)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11325	Ana Carolina Borges Magalhães	1	1994	5	11	F	511	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11605	Allan Ribeiro da Silva	1	1999	4	15	M	350	1ª A (Esc. Singular)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11540	Alisson Horácio de Almeida	1	1995	12	25	M	350	1ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11238	Aline Maria  da Silva Santos	1	1993	2	25	F	504	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11222	ARTEMIS NORONHA BARROS	1	1994	8	6	F	196	6ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11427	ANITA SIMIONI CASANOVA	1	1995	6	26	F	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11521	Vitor Ramon Rocha	2	1992	7	22	M	313	7ªE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11517	Thales Diego M. M Pereira	2	1993	11	27	M	313	7ªE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11340	Mateus Alves Madeira de Souza	2	1993	4	10	M	511	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11504	João Marcelo Dos Santos	2	1992	3	23	M	313	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11239	JULIANA BRAGA CELESTINO	2	1992	11	5	F	196	8ª Série - Gama	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11338	Izabela Ferreria Bini	2	1992	10	29	F	511	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11519	Iasmim Silva Basílis	2	1993	3	10	F	313	7ªE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11237	INGRID GUILHERME DA SILVEIRA	2	1991	10	21	F	196	8ª Série - Gama	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11527	Fabrízia De Paula Santos	2	1992	10	27	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11503	Fabiane Ramos Da Silva	2	1992	6	23	F	313	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11196	ERITON RODRIGUES DE AZEVEDO	2	1991	10	3	M	373	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11335	Daniel R. M. Reis	2	1993	6	8	M	511	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11518	Anderson Douglas De Souza	2	1992	4	27	M	313	7ªE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11594	Welldson Henrique Santos Lins	1	1994	2	26	M	350	6ª A (Esc. Brig Eduardo Gomes)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11620	SÉRGIO LUIS QUEIROS F.	1	1995	5	29	M	355	5ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11665	RICARDO MAIA TEIXEIRA DE SOUZA	1	1995	12	28	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11663	RICARDO MAIA TEIXEIRA DE SOUZA	1	1995	12	28	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11635	RENATO SERGIO SILVA ALVES	1	1994	5	20	M	196	6ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11767	Paula Camargo Flauzino	1	1993	11	29	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4374	PEDRO RODRIGUES NETO	1	1993	3	12	M	355	6ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11779	Natália  Clemente	1	1994	4	11	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11770	Nataly Cristina Rosa	1	1993	11	26	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11630	NICOLE ANDRADE FURTADO	1	1996	1	27	F	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11776	Michele R. Oliveira 	1	1994	9	11	F	313	5°E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11602	Marcela Ribeiro da Silva	1	1994	6	13	F	350	6ª A (Esc. Prof José Vicente Barbosa)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11616	MAYARA FERNANDA SILVA	1	1995	8	28	F	355	5ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11617	MATHEUS FELIPE DOS SANTOS	1	1995	9	9	M	355	5ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11615	MARCELO FERREIRA SANTOS	1	1995	5	26	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11633	LUCAS RODRIGUES BERNARDO	1	1994	5	15	M	196	6ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11780	João Marcelo Martins de Almeida	1	1993	9	6	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11688	José Cláudio Gomes de Freitas Neto	1	1994	7	6	M	526	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11765	Jonas Augusto De Lima Luiz	1	1993	11	10	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11619	JOSÉ SANTIAGO JUNIOR	1	1995	1	19	M	355	5ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11629	JOSE EDIVAM ANDRADE CAVALCANTE JUNIOR	1	1995	10	7	M	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11687	Italo Machado Santos Lima	1	1994	3	14	M	526	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11686	GUILHERME ALEXANDRE SCAVONE SANTOS RATO	1	1995	6	30	M	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11774	Fernando D. de Carvalho Junior	1	1995	1	12	M	313	5°	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11683	FABIANA FINELLI FABENI	1	1994	9	27	F	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11772	Evelyn de Melo Lima 	1	1995	3	19	F	313	5°C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11758	Elisabete Lorette	1	1994	6	4	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11609	DANIELA PALOMA CAVALHEIRO DE ALMEIDA	1	1995	6	24	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11748	Cesar Augusto Camargo	1	1992	8	30	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11614	CARLOS EDUARDO C. STRUMINSKI	1	1995	5	15	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11750	Angélica Helena Martins	1	1993	9	12	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11782	Alisson Felipe R. Magalhães	1	1994	1	13	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11778	Aline Cristina Jesus 	1	1993	11	18	F	313	6°D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11634	ANTONIO GOMES DA ROCHA NETO	1	1993	6	26	M	196	6ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11607	ANDERSON APARECIDO F.	1	1995	10	4	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11611	AMANDA DOS SANTOS MARTINS	1	1995	2	6	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11749	Tyago Luíz Damito Fernandes	2	1993	2	26	M	313	8°B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11704	Suly Teixeira Barbosa	2	1993	1	25	F	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11760	Sara Danieli Ferreira Paiva	2	1992	6	11	F	313	8°B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11695	Ricardo Goes de Meira	2	1993	4	15	M	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11728	Raquel Arana de Aquino	2	1992	7	31	F	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11714	Rafael Saraiva Aragão	2	1991	10	17	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11699	Melissa Melo Lins Cavalcante	2	1993	9	19	F	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11727	Maria Helena Lima D'oran	2	1992	6	15	F	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11702	Luiz Afonso Oliveira Araújo	2	1991	8	6	M	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11754	Lucas Rocha Rezende	2	1992	11	15	M	313	8°B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11701	Levi Costa Erhich	2	1993	7	4	M	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11722	Kevin Mailho Coe	2	1993	3	12	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11729	Karine Kelly Rangel de Andrade Monte	2	1991	12	6	F	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11734	Joel Siqueira Bloc Boris	2	1992	4	8	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11708	Jeová Farias Sales Rocha Neto	2	1993	5	26	M	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11716	Isaac Bezerra da Silva	2	1992	2	4	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11732	Guttemberg Laureno Jucá	2	1992	7	9	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11745	Gleice Queli Silva	2	1993	3	12	F	313	8°B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11726	Felipe Magalhães Gomes de Andrade	2	1992	7	1	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11730	Felipe Galvão de Macedo	2	1992	31	22	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11717	Felipe Dias de Carvalho	2	1991	1	11	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11643	FRANCISCO DAVI GUIMARAES ALMEIDA	2	1992	9	17	M	196	7ª Série - Gama	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11724	David Mapurunga	2	1991	10	20	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11706	Davi Freire Silvino	2	1992	10	22	M	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11746	Danilo de Souza Greco	2	1992	5	21	M	313	8°B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11720	Caio Martins Menezes Neves Mayrink	2	1992	5	21	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11731	André Morais Duarte de Vasconcelos	2	1991	12	14	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11744	André Luiz Garcia Junior	2	1993	2	28	M	313	7ºD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11709	Alexandre Alencar de Andrade Feitosa	2	1993	4	23	M	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11610	TATHIANE ALMEIDA SANTOS	1	1995	2	10	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12268	WILLIAM MU SUNG LEE	1	1995	8	21	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11799	Valdiney José Flauzino 	1	1992	10	7	M	313	5°E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11989	VIRGILIO MACEDO	1	1994	12	23	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11998	VINICIUS LUIS DE OLIVEIRA PEREIRA	1	1993	4	26	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12166	Robson de Oliveira Magalhães	1	1993	4	19	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12278	RENATO SOUSA ROCHA FILHO	1	1994	7	6	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11823	RAFAELA GROSSI CAVALCANTE MILFONT GARCIA	1	1994	3	5	F	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12263	PEDRO TSON ANG TJIN	1	1995	8	6	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11858	PAULA SAMILLY DANTAS MENESES	1	1994	6	4	F	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12002	PATRÍCIA ALCÂNTRA PIRAJÁ	1	1993	9	30	F	488	6ª SÉRIE do ENSINO FUNDAMENTAL	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12168	Natali Gomes Guimarães da Silva	1	1994	11	29	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12163	Morais Vinícios Costa de Oliveira	1	1995	7	1	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11791	Maria Fernanda  de Lima 	1	1993	9	17	F	313	5°E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12260	MATHEUS BORGES FONTÃO CORDEIRO	1	1995	6	24	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11822	MARYLIA SOUSA LUCENA	1	1994	3	17	F	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11977	MARIANA DE FÁTIMA FERNANDES	1	1995	7	30	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11979	MARCELO MAGNO 	1	1995	6	22	M	355	5 ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12167	Luiz Gustavo Silva Simão	1	1995	6	16	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11978	LUIZ GUSTAVO CHAVES DE OLIVEIRA	1	1994	3	26	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11819	LIA BASTOS LOPES	1	1995	4	20	F	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12258	LAWRENCE JINDDO LUO	1	1995	2	17	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12257	KIMBERLY YEN KIM	1	1995	11	14	F	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11854	KARINE OLIVEIRA DA COSTA	1	1993	9	27	F	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12256	KAREN MYE TAIRA MAEDA	1	1995	2	22	F	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11851	JÚLIA DE FÁTIMA SANTOS DA SILVA	1	1995	1	28	F	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11793	Julio César Lopes 	1	1993	12	16	M	313	5°E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12158	João Lucas Ribeiro Moreno	1	1994	11	8	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12159	Jonathan Gomes Nogueira	1	1994	12	6	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11797	Jhenifer Kathleen Moreira Kogawa	1	1994	12	13	F	313	5°E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12174	Jenifer Vitória Agnelo Vilas Boas	1	1993	8	17	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11856	JULLYANA FAÇANHA DE FREITAS	1	1993	9	3	F	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11999	JOÃO PAULO DIAS DE JESUS	1	1994	5	5	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11808	JOSEPH SELIM SKAF	1	1993	4	15	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12273	HARVEY HAO	1	1994	8	24	M	487	6ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12153	Gabriela Cristina da Silva	1	1994	9	4	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12152	Flávio Augusto Messias Silva	1	1995	1	25	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11805	Felipe Navarro Romero Miguel	1	1994	10	17	M	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11992	EZEQUIEL ROCHA LUCAS	1	1995	1	1	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12001	ELAINE OLIVEIRA BRIZOLA SILVA	1	1995	8	3	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11786	Daniela da Silva Marques	1	1994	2	23	F	313	5°E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11840	DANIEL DE REZENDE DAMASCENO	1	1994	5	5	M	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11777	Bruna Araújo Godói	1	1994	2	8	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11905	BARBARA FRANCHIN DE BONILHA	1	1994	11	12	F	465	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12269	ARNALDO  SUGUI FILHO	1	1994	12	7	M	487	6ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11990	ANDERSON DA SILVA MARINHO	1	1993	8	23	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11993	ANA CLAUDIA CAMARGO	1	1994	6	7	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12005	AIRTON CESAR PINHEIRO DE MENEZES	1	1996	1	18	M	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12135	Thâmia Portela de Carvalho	2	1992	5	28	F	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11853	Tchésley Felipe Cardoso de Paula	2	1991	1	5	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12279	RENATA MARIANA OLIVEIRA BARROS	2	1992	1	9	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11836	PRISCILLA DE ALMEIDA FERREIRA	2	1991	9	30	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11844	PRISCILA HONORATO VIANA 	2	1992	6	17	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11832	Lívia Maria Miquelin	2	1992	4	18	F	313	8ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12133	Luan Gouvea Mendes	2	1992	4	20	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12134	Lia Quindere Sabadia	2	1991	9	1	F	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12018	LUIZ FLÁVIO DA ROCHA DIAS FILHO	2	1993	8	3	M	6	7.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11848	LEON TORRES DE OLIVEIRA	2	1994	3	5	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11859	LARA ALENCAR  FURTADO 	2	1991	2	5	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11813	KALEU GILVANNI QUEIROZ DE OLIVEIRA	2	1993	7	19	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11837	Jhonatam Willian Evangelista	2	1991	4	24	M	313	8ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11846	JOÃO TEÓFILO MONTE COELHO NETO	2	1992	11	1	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11839	Izabela Bueno de Paiva	2	1991	6	25	F	313	8ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11835	DULCE ANDRADE TERCEIRO 	2	1992	11	15	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11833	DANIELE FERNANDES MENDONÇA	2	1992	4	10	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12275	ANDRÉ SILVA FRANCO	2	1993	8	2	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11818	WINNY ALCÂNTARA LINHARES	1	1994	10	24	F	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13041	THARIK ÁVILA RAMOS	1	1995	3	6	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12622	TALES CUNHA DE SOUSA	1	1993	10	28	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12486	Rogério Lourenço Lopes	1	1993	2	6	M	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13053	RENAN CARRARO MANCINI	1	1994	12	1	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12495	Paulo Henrique Camargo Lúcio	1	1993	5	24	M	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12393	Mariana Marin Rotelli	1	1995	2	22	F	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12421	MAYARA VERGUEIRO SALTES RUIVO	1	1994	1	6	F	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13039	MATHEUS DENÓFRIO PORTO	1	1995	1	5	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12499	Lívia Carolina de Rezende Santos	1	1994	4	13	F	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12415	Lucas Gabriel Agneto Silva	1	1994	11	11	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12607	LUIZ MARCOS GARCIA REIS JUNIOR	1	1994	6	12	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12610	LUIZ FELIPE ALBUQUERQUE DA SILVA	1	1994	3	6	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12614	LUIZ ANTONIO ARAÚJO DE MENDONÇA JÚNIOR	1	1994	4	21	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13052	LUISA PORTO ROSOLEN	1	1995	1	3	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12414	LUCAS CASSIANO DE OLIVEIRA	1	1994	8	4	M	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12412	LARISSA ABRAHAO CORREA	1	1994	4	12	F	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13051	LARA ROCHA COMIN	1	1995	1	24	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13049	LAIS BONFOGO LENTZ	1	1995	3	17	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12408	JANAINE APARECIDA DE OLIVEIRA	1	1994	2	5	F	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12407	JAINE MACEDO FERREIRA	1	1993	12	3	F	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12406	JACKSON FERNANDO FERREIRA CAMARGO	1	1994	11	18	M	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12405	ISAQUE APARECIDO RODRIGUES	1	1993	12	15	M	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13037	HALLYSSON VINICIUS BEZERRA	1	1994	11	4	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12485	Gustavo Mariano Dias	1	1995	5	21	M	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12368	Geraldo Soares Cordeiro Filho	1	1995	4	17	M	318	5ª Série D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13048	GUSTAVO VILLELA TAUFIC	1	1995	2	7	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13044	FÁBIO ALBERS JUSTINO	1	1995	6	3	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12494	Franciele Aparecida Prudente Pires	1	1994	8	31	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12395	Fernando Yamashiro Garcia	1	1995	3	2	M	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12621	FLÁVIA YUMIE SAGANE VERAS	1	1993	9	22	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13045	FERNANDA CANCIAN TENDOLINI	1	1994	9	26	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13031	FELIPE RÊGO SACCHI	1	1994	9	1	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12609	FELIPE PINTO FARINELI VIVAS	1	1994	4	17	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12404	FELIPE APARECIDO OLIVEIRA LUIS	1	1994	10	31	M	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12416	Emanuel da Silveira Rodrigues	1	1994	9	10	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12608	DANIELA SIQUEIRA CRUZ	1	1994	8	25	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12403	CLAUDINEI LARA DA CRUZ JUNIOR	1	1994	3	16	M	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13028	CINTHIA HELENA FINATO	1	1995	1	11	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12615	BETINNA GUIMARÃES DOS SANTOS	1	1994	4	19	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12484	Ana Paula Campos da Cunha	1	1995	7	25	F	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12177	Ana Cláudia da Silva Valderramos	1	1995	6	4	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12413	Ana Beatriz Costa de Oliveira	1	1995	12	21	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12394	Adriano Silva dos Santos	1	1991	7	6	M	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13043	ANNA CLARA PIRES	1	1995	6	13	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12882	Wesley Moreira de Menezes Barboza	2	1991	3	5	M	90	8	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12605	Renato Lima de Souza	2	1991	5	17	M	312	8ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13046	Welinton Garcia de Paula Assis	2	1992	4	10	F	566	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12883	Vinicius Rainha Pacheco	2	1990	10	12	M	90	8	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13105	Renan Phelipe Santos Vilela	2	1993	5	26	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12617	RODRIGO CASTELLO BRANCO MELLO MIRANDA	2	1991	11	22	M	6	8.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12176	Liliane Oliveira Do Nascimento	2	1993	5	5	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12603	Lauriene Zeitune Oliveira	2	1992	3	29	F	312	8ª F	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12183	José Luiz de Souza Santos	2	1993	8	18	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12180	Jenifer Estefani Prince De Sales	2	1992	9	7	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12194	Janaína Fernanda S.  Alípio	2	1992	12	15	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13098	Janaina Segatto Melo	2	1993	9	24	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13035	Ivan Campos Damha Pedroso	2	1992	10	30	M	541	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13096	Gustavo dos Santos Mágio	2	1993	4	23	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12184	Grace Cristina Silva Dos Reis	2	1992	8	8	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13042	Felipe Luciano Costa Carneiro	2	1992	3	16	F	566	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12179	Diego Ferreira Da Silva	2	1993	1	30	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12602	Diego Amaral da Silva	2	1991	11	9	M	312	8ª F	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12606	DOMINGOS MAX DO CARMO BASTOS JUNIOR	2	1993	12	1	M	6	7.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12604	Ariene Silva Ramos	2	1991	8	6	F	312	8ª F	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12182	Aline S. De Moura	2	1992	12	24	F	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13050	Abel Alves da Silva Júnior	2	1992	2	10	M	566	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12379	Thatiany K. de Abreu	1	1994	9	29	F	318	5ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13263	TULIO CESAR FERREIRA	1	1994	8	3	M	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13243	THATIANA FRANCKLIN FLORESTA	1	1996	5	1	F	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13246	TAYNÁ KIMBERLY	1	1996	9	19	F	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13268	SAMUEL VINICIUS M. SILVA	1	1994	4	26	M	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13364	Rayan Fabbri Casagrande	1	1994	12	5	M	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13262	NATALIA DE SOUZA SILVA	1	1994	5	5	F	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13790	Matheus Gonçalves Tavares	1	1994	6	20	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13365	Matheus Ferreira de Melo	1	1995	5	21	M	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13797	Marla Rochana Braga Monteiro	1	1993	11	27	F	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13271	MAYARA CAROLINE S.AMANCIO	1	1994	5	9	F	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13432	MARINA PONTE RIBEIRO	1	1994	3	3	F	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13267	MARINA LOBATO BORGES	1	1992	2	10	F	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13431	MARIA CECÍLIA DE O. MANNARINO	1	1994	6	26	F	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13430	LUISA GOMES VIANA	1	1993	10	12	F	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13247	LARA CANDIDO DE SOUZA	1	1996	8	6	F	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13250	KAREN HELOANY TORRES	1	1995	11	17	F	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13796	João Pedro Gurgel	1	1993	10	17	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13261	JANAINA CRISTINA G.BERTO	1	1994	1	9	F	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13425	INGRID ELEUTÉRIO PINHEIRO	1	1993	9	21	F	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13254	IGOR PEREIRA C. DA SILVA	1	1994	11	8	M	59	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13272	HALLAF MAXWELL DOS SANTOS	1	1994	4	26	M	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13249	GUSTAVO GARCIA MARQUES	1	1996	4	22	M	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13253	GUSTAVO AUGUSTO OLIVEIRA	1	1994	10	6	M	59	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13266	GABRIELLLY SILVA FERREIRA	1	1994	2	12	F	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13256	FRANGIE KALLAS DE ANDRADE	1	1995	10	3	F	59	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13441	CAROLINA DE PAIVA FARIAS	1	1993	7	9	F	527	6ª Série E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13260	CARLOS EDUARDO GONTIJO PEREIRA	1	1994	4	1	M	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13440	BRUNO VIEIRA RODRIGUES	1	1994	7	12	M	527	6ª Série E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13273	BRENDA LETICIA SILVEIRA DOS SANTOS	1	1994	1	30	F	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13534	Amanda Vasconcelos de Barros	1	1994	6	19	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13255	ANA PAULA S.GUIMARÃES	1	1994	7	11	M	59	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12919	Bruno Silva Costa	2	1990	10	14	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13248	ANA LUIZA DE OLIVEIRA	1	1996	3	18	F	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13244	ADRIENNY HELEN GARCIA	1	1996	7	30	F	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13396	YASMINE LIMA DE OLIVEIRA AQUINO	2	1992	1	14	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13280	DOUGLAS TADEU DA SILVA	2	1991	10	28	M	59	8a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13277	YAN DIAS SILVEIRA	2	1993	3	15	M	59	7a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13421	YAGO AZEVEDO CUSTÓDIO	2	1993	4	12	M	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13054	Willian Torsani Andrade	2	1992	4	16	M	566	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13420	VERONICA LILIAN PARENTE NORONHA	2	1994	2	15	F	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13409	TIAGO SOUSA CASTRO	2	1993	6	7	M	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13275	TAYSLA CRISTINA DE SOUZA	2	1994	3	13	F	59	7a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13395	SERGIO ALEXANDRE BARREIRA FORTE	2	1992	6	12	M	527	8ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13549	Renata Pimenta de Novaes Castelo Branco	2	1993	7	20	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13427	Rayla Farias de Lucena	2	1992	1	16	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13279	RODRIGO MEIRELES DE OLIVEIRA	2	1992	2	27	M	59	8a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13407	RENATA CARDOSO REIS MOURA	2	1993	3	29	F	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13406	REBECCA AMORIM BASTOS	2	1992	11	8	F	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13418	RAIMUNDO HENRIQUE M. BITTENCOURT	2	1993	5	17	M	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13394	NATASHA CARVALHO PEREIRA DA SILVA	2	1991	8	10	F	527	8ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13405	NATALYA STEFANNY ABUCATER RODRIGUES	2	1992	12	14	F	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13334	MYRIAM RUTH DA SILVA MAGALHÃES	2	1993	7	19	F	6	8.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13416	LUIZ DE ARAÚJO FARIAS NETO	2	1993	9	17	M	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13333	LAURA FIGUEIREDO DE MIRANDA	2	1993	8	14	F	6	7.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13415	JONATHAN PORTO CAVALCANTE LIMA	2	1993	8	3	M	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13401	ISABELLA SILVEIRA DE ALMEIDA	2	1993	8	12	F	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13414	INGRID CAROLINE V. PITTA PINHEIRO	2	1993	3	16	F	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13413	IGOR BRASIL CARVALHO PASSOS	2	1992	10	21	M	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13547	Francisco Xavier Barbosa Neto	2	1993	2	27	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13760	Danilo Teixeira Gonçalves	2	92	7	8	M	90	8	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13410	DIEGO DOS SANTOS DE CASTRO	2	1993	5	17	M	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13278	DANILO SANTOS DE OLIVEIRA	2	1991	7	16	M	59	8a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13397	BRUNA CELUTA MAIA AMARANTE	2	1993	3	18	F	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13274	BLISA LUDMILA ALVES	2	1991	7	1	F	59	7a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13298	Anderson Alves da Silva	2	1993	9	8	M	518	Fundamental	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13350	Aline Barbosa Luiz	2	1989	4	12	F	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13552	Alberto Almeida Barros	2	1993	8	13	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13791	Vitória Brena Soeira Fonteles	1	1995	2	16	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14146	Victor Cardozo Restivo	1	1992	9	18	M	568	7ª série E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13712	Thays Pimentel Gomes	1	1994	4	20	F	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13617	Suyanne Guimarães Castro Palmeira	1	1994	4	28	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13720	Sarah Anne Silveira Sampaio	1	1995	6	18	F	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13718	Samya Saraiva Alves	1	1996	2	27	F	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13714	Pedro Costa Melo	1	1994	5	24	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13901	Nicoly Marques de Castro	1	1993	11	25	F	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13664	Nicolle Lima de M. Santos	1	1995	2	15	F	367	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13822	Matheus Queiroz	1	1995	7	11	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13703	Matheus Chaves Oliveira	1	1994	6	26	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13813	Mateus Alves Santos	1	1994	1	11	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13799	Marina Natercia C. do Nascimento	1	1995	5	9	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13897	Mariana Oliveira Martins	1	1994	6	5	F	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13895	Mariana Moraes Frota	1	1993	12	1	F	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13810	Madson Alex dos Santos Almeida Junior	1	1995	5	9	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13802	MARIANA COELHO OLIVEIRA	1	1995	5	24	F	467	5ª SÉRIE GAMA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13808	Luiza Lorena Maria Lobo	1	1995	4	25	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13804	Lucas Romão Alves Vasconcelos	1	1995	2	10	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13702	Lucas Rios Ferreira Gomes	1	1994	9	5	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13715	Lucas Nunes Ruchinhaha	1	1995	2	13	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13700	Lucas Holanda Correia Lima	1	1994	7	9	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13706	Lucas Gonçalves Machado da Rocha	1	1994	11	8	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14121	Lucas Coelho Rodrigues	1	1994	8	27	M	516	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13806	Luana Anastácia Braga de Oliveira	1	1994	11	29	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13708	Louise Garcia Xerez Silva	1	1993	11	4	F	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14104	Larissa Meira Wanderley	1	1995	5	31	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13824	Lara Miryan Taumaturgo Fabrício	1	1995	5	7	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13697	Karolina Sousa Pinheiro	1	1994	3	25	F	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13707	Jurandi Vieira de Magalhaes Neto	1	1994	10	30	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13658	João Vasconcelos de Souza Neto	1	1994	4	19	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13807	José Stefano M. Gomes	1	1993	7	19	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13696	Jose Parente Prado Neto	1	1994	2	11	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13705	Joao Pedro Inacio dos Reis	1	1994	10	4	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13803	Jefferson Maia de Souza	1	1994	4	21	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13694	Igor Pinho Saraiva	1	1994	3	27	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13681	Iana Aragão Esmeraldo	1	1994	10	27	F	367	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13692	Iago Teles Garcia	1	1993	11	9	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13819	Hugo M. Paz	1	1994	4	28	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13713	Gustavo Sobreira Camilo Soares	1	1994	10	24	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13723	Gustavo Nogueira de Paiva	1	1994	1	26	M	527	6ª Série E - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13651	Gilberto Loiola de Alencar Dantas	1	1993	10	30	M	367	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13670	Germana Morais Lira	1	1995	3	5	F	367	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14153	Gabriel Nakamura	1	1993	6	1	M	568	7ª série E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14111	Felipe Linhares de Sousa	1	1994	8	26	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13722	Erika Guedes de Sousa Lima	1	1993	8	25	F	527	6ª Série E - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13674	Emanuel Mendes Soares	1	1993	12	9	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13798	Davi Maia	1	1993	12	22	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14147	Arthur Arnal Gomes	1	1992	9	25	M	568	7ª série E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13820	Andreza Dias de Souza Parente	1	1995	10	2	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13811	Anderson Lima Colares Cavalcante	1	1993	10	1	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13823	Amanda Vaida Rocha Rolim	1	1995	8	13	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14110	Alexandre Oliveira Ribeiro	1	1994	12	17	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11795	Alexander Kaique de Souza	1	1993	12	16	M	313	5°E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14093	Vicente de Castro	2	1993	3	5	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14033	Sam Louis Bindler	2	1991	1	22	M	544	8a série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14103	Rodrigo Santiago	2	1992	5	22	M	516	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14112	Paulo Matheus Borges	2	1991	2	5	M	516	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14145	Natália Mendonça Porto Soares	2	1993	3	25	F	516	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14144	Marcela O'Grandy Melo	2	1991	6	17	F	516	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14109	Lissa Beltrão	2	1991	12	5	F	516	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14092	José Vivaldo	2	1993	6	4	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13558	Felipe Noronha Lechiu	2	1993	11	6	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14098	Carlos Eduardo Ponte 	2	1993	9	21	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14099	Caio Souza	2	1993	5	13	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14119	Andréa Barreto	2	1992	4	23	F	516	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13653	Ygor Rebouças Serpa	1	1994	2	9	M	367	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14280	WILLIAN EDUARDO S. FRAZÃO	1	1994	4	7	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14283	WALDIR MAX  JUNIOR	1	1994	7	8	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14542	Viviani Monaliza Gomes	1	1995	4	24	F	545	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14130	Victor Nunes Landim	1	1993	8	10	M	516	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14270	THAYNÁ CAROLINE	1	1995	5	2	F	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14131	Rodolfo Ramalho Franca Flores	1	1994	12	6	M	516	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14192	Renan Gomes Pinto	1	1993	7	28	M	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14125	Rebeca Bezerra Teixeira	1	1994	5	22	F	516	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14268	RODRIGO SANTOS	1	1994	3	1	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14330	ROBERTO F. NEVES	1	1994	6	6	M	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14281	RAFAELA DOS SANTOS OLIVEIRA	1	1995	5	5	F	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14139	Paula Ponte Moreira	1	1995	3	24	F	516	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14263	PEDRO HENRIQUE F. RODRIGUES	1	1993	9	20	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14129	Natália Gonçalves Ferreira Marinho	1	1995	2	22	F	516	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14115	Matheus de Freitas Vasconcelos Estevão	1	1995	2	19	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14135	Lucas Meneses Lima	1	1995	3	29	M	516	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14134	Larissa Monteiro G.N Eufrásio	1	1993	3	8	F	516	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14284	LUIZ FELIPE SANTOS M.	1	1995	8	21	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14279	LORENA RIBEIRO DOS SANTOS	1	1995	5	8	F	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14282	LEE JUN FAN SOUZA TIAGO	1	1995	8	21	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14277	KARINA LAYANE DA SILVA	1	1993	5	26	F	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14241	JORDÃO CARNEIRO COSTA	1	1993	12	17	M	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14124	Igor Torres Fernandes	1	1993	11	10	M	516	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14266	GUSTAVO RAFAEL ALVES DIAS	1	1994	9	29	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14261	GUSTAVO OLIVIERA BORGES	1	1995	5	30	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14254	GABRIEL MENEZES	1	1993	11	26	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14256	FILIPE DA SILVA OLIVEIRA	1	1994	9	28	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14273	FERNANDA COSTA FARIA	1	1995	3	27	F	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14328	DENNER AUGUSTO BARRETO DA SILVA	1	1994	11	9	M	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14240	CLEITON AMELES DA CUNHA	1	1993	9	14	M	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14208	Bruna Nascimento Castro	1	1993	1	1	F	313	5ºE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14137	Beatriz Nogueira Caldas	1	1994	9	17	F	516	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14509	BRUNO MÁXIMO MENEZES DE LIMA	1	1994	9	19	M	179	7º ANO E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14276	BRENO BATISTA ALVES	1	1995	6	24	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14200	Alice de Oliveira Kokuta	1	1993	10	6	F	293	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14118	Alberto Vitor Bezerra Araújo Souza	1	1994	3	13	M	516	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14260	ANA CRISTIN A S. VIEIRA	1	1995	12	1	F	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14113	Átila Oliveira	2	1991	9	17	M	516	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14511	Tales Fontenele Frota	2	1992	11	5	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14122	Rossely Gusmão	2	1991	7	6	F	516	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14138	Matheus Correia Fortes	2	1993	6	28	M	516	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14517	Mariana Pimentel Carvalho	2	1992	8	30	F	545	7a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14521	Luis Gustavo Bruno Locatelli	2	1992	12	21	M	545	7a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14116	Letícia Cremasco	2	1992	6	15	F	516	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14016	Leticia de Holanda Matos Sousa	2	1992	11	19	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14090	Leandro Peixoto	2	1993	4	28	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14400	LUCAS FARIAS GONÇALVES DA SILVA	2	1992	3	23	M	179	9º ANO C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14287	KÊNIA FERNADES DE OLIVEIRA	2	1992	8	5	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14285	JÉSSICA FARIA ROCHA	2	1992	2	5	F	5	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14456	JULIENE COSTA	2	1993	9	8	F	465	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14246	JEFFERSON B. BORGES	2	1991	10	20	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14399	JASMINNE FERNANDES MASCARENHAS	2	1994	4	13	F	179	8º ANO C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14244	ISABELA KOPPERSCHIMIDT DE OLIVEIRA	2	1993	4	15	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14005	Guilherme Arantes de Achilles Mello	2	1993	2	25	M	318	7ª Série C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14211	Giuvanni Franzoni Longo	2	1993	5	14	M	293	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14385	Giuseppe Tropi Somma	2	1992	6	5	M	517	oitava	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14527	FELIPE PINHO OLIVEIRA	2	1993	2	22	M	196	7ª Série - Alfa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14523	DIEGO DANIEL VIEIRA TORQUATO	2	1992	3	14	M	196	7ª Série - Alfa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14396	CÉSAR MENDONÇA GUERREIRO DA SILVA	2	1993	5	19	M	179	8º ANO A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14221	Cleber Carabette	2	1991	11	8	M	313	8ºE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14205	Ciana Regina Duque	2	93	4	29	F	293	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14206	Allan Henrique Guedes Viana	2	1993	9	8	M	293	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14219	Adriano Obeid	2	1992	5	29	M	293	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14391	ALLISSON LIMA RODRIGUES	2	1992	2	20	M	179	9º ANO F	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14238	ALINE VIEIRA GOMES	2	1992	6	10	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14257	YURI SANTIAGO BORGES	1	1993	3	20	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15064	VINÍCIUS MARIOTTO ROLIM PEREZ	1	1995	7	3	M	11	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15057	VICTOR VIANNA DE ANDRADE LIMA	1	1995	4	28	M	11	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14704	Tatiana Cintia Fernandes da Costa	1	1995	1	16	F	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14559	Silvio Cesar Vieira Torres	1	1994	11	7	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14702	Raul Oliveira da Cruz	1	1994	1	1	M	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14697	Rafael de Sousa G. Lima	1	1993	6	20	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15040	Patrick Silva dos Reis Nascimento	1	1994	12	29	M	192	5ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14699	Mário G. Ap. Brasileiro	1	1994	11	2	M	312	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14560	Monique P. de Castro	1	1994	11	15	F	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14694	Michele Lais de Souza Teixeira	1	1994	5	31	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14562	Matheus fontenele M. Muniz	1	1994	7	24	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15043	Matheus dos Reis Bravim	1	1993	8	13	M	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14729	Mariane R. Alves da Silva	1	1994	7	29	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14696	Luis Guilherme O. Carvalho	1	1994	9	2	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14698	Ludimila V. M. de Souza	1	1995	4	15	F	312	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15041	Leonardo Oliveira Colares	1	1994	7	2	M	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15053	Laura Bellintani de Freitas	1	1994	5	27	F	541	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14646	LUCAS DE ARAÚJO SOARES MENDONÇA	1	1995	4	17	M	179	6º ANO	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14701	Jéssica Ap. da Cruz Cesário	1	1995	7	24	F	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14546	Julia Rodrigues Curcio	1	1995	6	30	F	545	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15051	Iago Ribeiro	1	1995	9	20	M	192	5ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14728	Hilda N. Bósio Silva	1	93	11	30	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14691	Gustavo M. Prado	1	1994	12	26	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15058	GUILHERME NOVAES DE SALLAS	1	1995	8	25	M	11	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14944	GABRIEL NESRALA BASTOS	1	1994	2	21	M	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15061	FELIPE POMPEU GUIMARÃES	1	1995	6	23	M	11	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15059	ELIAS CASTILHO LOUCATELLI	1	1995	6	16	M	11	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15042	Diego Dadalto Costa	1	1994	7	31	M	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14631	Carolina de Souza Montezel	1	1994	1	31	F	482	6ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14714	Camila Salcedo Faxini	1	1994	3	22	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14561	Arthur Mariano Torres	1	1995	2	14	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14731	Andressa Pereira Pedro	1	1995	8	27	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14708	Ana Beatriz C. de Túlio	1	1995	3	10	F	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14727	Alisson Victor J. V. Silva	1	1993	9	20	M	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14752	Aderson Dionísio	1	1994	11	2	M	516	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14923	WILLIAM DOUGLAS SILVA	2	1992	1	4	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14917	ULISSES FAGUNDES DE SOUZA	2	1992	3	25	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14744	Trajano de Souza Pinto	2	1987	2	5	M	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14931	THAIS CRISTIANE DE OLIVEIRA SILVA	2	1993	5	14	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14668	Sara Albino Vitoriano	2	1993	6	17	F	527	7ª Série B - PI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14739	Sabrina C. Dias Inácio	2	1992	6	8	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14751	Renata Camila P. de Oliveira	2	1992	8	24	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14749	Rafael Barreira de Brito	2	1993	3	1	M	312	7ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14939	RAFAEL DE SOUZA GONÇALVES	2	1993	10	21	M	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14677	Pedro Henrique Nunes	2	1993	5	24	M	552	7ª1ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14641	PABLO AUGUSTO CANDIDO PAIVA	2	1992	1	8	M	179	8º ANO E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14746	Natalina Ap. M. C. da Silva	2	1992	7	23	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14735	Marcus Vinícius G. magalhães	2	1992	7	27	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14757	Lorrayne C. Silva Santos	2	1992	5	31	F	312	8ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14558	Leonardo Vitor G. do Nascimento	2	1993	9	23	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14905	LUDYMILA DE AVILA CASTRO	2	1992	4	29	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14741	Jaqueline S. rezende	2	1992	1	1	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14919	ILZA CAROLINA SILVA DE OLIVEIRA	2	1991	11	19	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14564	Heloísa Alves Barbosa	2	1993	10	4	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14903	GERMANO GONÇALVES PEREIRA E TEIXEIRA	2	1992	1	26	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14932	GABRIELA CUNHA E SOUZA	2	1993	3	5	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14732	FILIPE MOREIRA LIMA	2	1990	11	5	M	467	7ª SÉRIE GAMA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14742	Elieni Consueni Batista	2	1993	2	12	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14743	Denise Fátima Mariano dos santos	2	1993	4	3	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14914	DIOGO HENRIQUE BORGES	2	1992	3	30	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14660	Beatriz Cristina Silva	2	1993	3	22	F	59	7a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14937	BRUNA DOS SANTOS BENFICA	2	1993	7	23	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14933	BRUNA DE FATIMA OLIVEIRA SOARES	2	1993	5	9	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14748	Andressa F. de Oliveira	2	1992	12	23	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14755	Ana Carolyna R. T. Silva	2	1992	5	15	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14733	Ademir de Oliveira P. Filho	2	1993	2	5	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14924	ANA VITÓRIA PINHEIRO CAMPOS	2	1992	1	20	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14710	Vanessa Ariele Pioli	1	1991	8	27	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15377	Richard Martini da Silveira	1	1993	4	29	M	512	7ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15135	Renan Ustulin Parisi	1	1994	11	19	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15087	RENATO VIEIRA DE MELLO NETO	1	1994	2	3	M	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15118	Patrick Martins Alves	1	1995	8	10	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15120	Oscar Sajovic Neto	1	1994	11	24	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15126	Natalia Cristina do Rio de Carvalho	1	1995	2	1	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15318	NAGELA LIMA FERREIRA DA SILVA	1	1993	11	30	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15116	Milton Curi Falcão	1	1994	12	28	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15148	Marconi Joaquim Teixeira	1	1994	4	18	M	512	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15083	MARINA FRANCO CINTRA DE ALMEIDA	1	1994	6	21	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15313	MARILIA CAMPOS MUNIZ	1	1995	3	2	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15392	MARIANA MELLO LEITÃO	1	1995	4	20	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15075	MARIANA BERCHT RUY	1	1995	7	6	F	11	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15085	MARIA CLARA H. BALBONI	1	1994	6	15	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15086	MARCELA ROLIM PEREZ	1	1994	3	2	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15136	Lucas Santa Rosa Freire	1	1995	4	10	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15142	Lucas Fernando Chicheto Brancaglião	1	1995	6	29	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15310	LUCAS PESSOA BALBINO	1	1994	11	1	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15390	LUCAS PEREIRA DA ROCHA	1	1995	2	26	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15309	LUCAS MACEDO TARGINO	1	1994	5	10	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15079	LUANA RIBEIRO LOBATO	1	1994	1	2	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15305	LINTON FELDER LINHARES FRANCA	1	1994	11	1	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15067	LARISSA ESTEFANO DE ANDRADE	1	1995	10	30	F	11	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15139	Julia Helena Tury Blumer	1	1995	10	16	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15294	João Paulo Sousa Bulcão	1	1993	1	6	M	555	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15124	João Guilherme de Callis Simões	1	1994	7	18	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15141	João Felipe Gromboni	1	1995	9	27	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15302	José Ney Alves Feitosa Neto	1	1994	1	11	M	555	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15081	JULIANNA CANDIANI BISONI	1	1993	11	21	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15387	JOSÉ LUCAS A. DE CARVALHO	1	1995	12	13	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15388	JOSE LUCAS CASTRO LEITE	1	1995	6	8	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15296	JOANA SOARES BRANDAO	1	1993	10	15	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15386	JENUAN MONTEIRO DE MACEDO LIRA	1	1995	9	20	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15082	ISABELLA TORDIVELLI GONZALES	1	1993	8	30	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15080	ISABELLA MARTINS	1	1993	10	27	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15293	INGRID THAYNA DED FREITAS ACACIO	1	1995	8	4	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15289	HANNA NOGUEIRA MAIA	1	1995	10	7	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15286	Gabriel Henrique Pereira Machado	1	1993	5	8	M	555	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15078	GIULIANNA GODINHO	1	1993	12	7	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15068	GABRIELA NICOLETI DE FREITAS	1	1995	6	30	F	11	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15282	Felipe de Queiroz Oliveira Rodrigues	1	1993	7	15	M	555	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15143	Felipe Baccarin Marangoni	1	1995	1	24	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15161	Faline Garcia dos Santos	1	1992	9	29	F	512	7ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15899	Ellen Mika Shinjo	1	1993	12	28	F	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15132	Davi Campanhã	1	1994	9	20	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15133	Bruno de Godoy	1	1995	2	17	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15150	Bruno Gonçalves Cardoso	1	1993	10	30	M	512	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15129	Beatriz Caciola Furlanetto	1	1995	3	15	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15140	Ariane Cristina Catto	1	1995	4	11	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15137	Arantxa Montenegro Morcuende	1	1995	6	16	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15130	Ana Laura Lombardi Barbarossa	1	1995	10	18	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15267	Ana Carolina Martins Dantas	1	1994	1	16	F	555	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15274	ARTUR MENEZES FRANCA	1	1995	3	9	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15113	VITÓRIA MARIOTTO ROLIM PEREZ	2	1991	12	19	F	11	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15104	VICTOR HUMBERTO QUEIROZ ROSA	2	1991	9	9	M	11	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15366	ROMMEL JAVÃ LIRA DEE ALMEIDA	2	1993	5	24	M	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15123	RICARDO F. GANDINI	2	1993	1	2	M	11	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15110	MARINA VIANNA DE ANDRADE LIMA	2	1992	7	5	F	11	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15362	LUCA MILERIO ANDRADE	2	1992	9	9	M	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15360	JULIO CESAR CAVALCANTE DE PAULA	2	1993	1	30	M	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15103	JOÃO VINÍCIUS RICCI BRUNI	2	1991	8	8	M	11	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15100	GUSTHAVO MEIRELLES DALLA	2	1992	11	11	M	11	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15373	GUILHERME WELTER BEZERRA	2	1992	4	9	M	555	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15105	GUILHERME MANOEL MAGALHÃES	2	1992	5	1	M	11	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15111	GABRIELA BRASIL ALVES	2	1991	8	5	F	11	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15099	FELIPE SOARES DE ALMEIDA	2	1992	12	26	M	11	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15349	CARLO LIMA CESCONETTO	2	1993	1	14	M	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15345	ADSON IURY TELES CARDOSO	2	1992	8	17	M	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15084	STEPHANY B. MARQUES	1	1993	10	29	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15895	Rafaela dos Passos	1	1994	5	3	F	189	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15654	Quéssia da Silva Baptista	1	1994	6	11	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15892	Paulo Vitor Fernandes Lourenço	1	1995	11	3	M	189	5ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15894	Natália Duarte Chuka	1	1995	4	12	F	189	5ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15811	Marilia Daniela Araujo	1	1992	4	23	F	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15843	MARIA AMINADABE COSTA DA SILVA	1	1993	2	2	F	480	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15807	Lucas de Oliveira Lima	1	1992	1	11	M	510	8ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15891	Lincoln Tadashi Warikoda	1	1995	11	30	M	189	5ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15653	Karen Saline Miguel	1	1993	8	21	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15632	Jéssica Souza da Silva	1	1994	2	2	F	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15890	Gustavo Henrique de Siqueira de Oliveira Souza Lima	1	1995	4	11	M	189	5ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15898	Gabriela Harumi Harano	1	1994	7	5	F	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15897	Gabriel Moleiro Carlette da Silva	1	1994	4	16	M	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15749	GABRIEL GUIÇARDI	1	1996	4	13	M	175	4a. Série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15812	Fernando Henrique Fonseca Araujo	1	1992	2	18	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15805	Fernando Camargo	1	1992	11	26	M	510	8ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15815	Eder Kurovski da Silva	1	1992	6	7	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15631	Denilson Golçalves Soares	1	1994	7	23	M	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15803	Danilo Eduardo Queiroz Pedro	1	1990	7	1	M	510	8ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15889	Daniel Meleiro Macedo	1	1995	10	24	M	189	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15652	Damares Apareceeida de Oliveira	1	1994	3	16	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15814	Cleiton Pereira	1	1991	7	18	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12474	Cauê Augusto Sanchez	1	1992	3	6	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15651	Caroline Maria Godoy Rubio	1	1993	10	12	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15804	Bruna Brenda L. Sena	1	1992	3	14	F	510	8ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15809	Arcturus Sirius Simão Shimitd	1	1990	7	28	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15893	Ana Luiza Correia Barbosa de Moraes	1	1995	3	12	F	189	5ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15808	Allan Augusto F do Nascimento	1	1991	10	26	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15655	Aline P. Nascimento	1	1993	11	13	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15802	Alexander Shinji Mori	1	1992	4	7	M	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15659	William Rafael de Souza Ribeiro	2	1991	7	12	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15662	Weslei do Carmo Araújo	2	1991	4	7	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15660	Wellington Saraiva	2	1992	4	24	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15951	VERUSKA RAYANE C. DA SILVA	2	1991	9	21	F	480	8º SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15742	Thiara Raitz	2	1992	2	26	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15747	Thiago Andrei Uber	2	1992	8	18	M	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15664	Tailane Novaes da Silva	2	1992	3	4	F	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15952	THUANNY CRISTINY GALDINO  VERISSIMO	2	1994	3	24	F	480	8º SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15665	Samuel Paulino Gomes	2	1992	5	6	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15950	SERGILANA MUNIZ DA SILVA 	2	1991	8	26	M	480	8º	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15736	Patricia Adriane Luzzi	2	1992	5	8	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15729	Pablo Danilo Mota	2	1993	10	14	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15728	Luiz Felipe de Oliveira	2	1993	2	16	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15666	Lucas de Jesus Santos	2	1992	6	30	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15741	Jéssica Negherbon Novoa	2	1992	2	13	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15748	Jéssica Fernanda Tancon	2	1992	10	7	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15727	Jussara Dalcastgne	2	1993	5	21	F	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15896	Juliana Naomi Warikoda	2	1993	10	15	F	189	7ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15746	Jonathan Barth	2	1992	6	25	M	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15739	Jaquelini Luana Devegili	2	1992	1	26	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15738	Jaquelini Luana Devegili	2	1992	1	26	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15658	Jaime Wilson Gabriel	2	1992	2	26	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15726	Jackson Ariel Schiochet	2	1993	8	26	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15855	JESSICA KELLY PEREIRA	2	1991	5	15	F	480	8ª SERIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15745	Guilherme Augusto Linhares Vendrami	2	1991	12	11	M	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15735	Gisele Roberta Dürcksen	2	1992	12	11	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15734	Gabriel Luiz Tamanini	2	1992	10	4	M	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15661	Douglas Felipe Moreira Mendes	2	1992	1	29	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15737	Dorita Wenceslau	2	1992	1	24	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15733	Daniele Cristina Doege	2	1992	3	31	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15732	Daniela Thayse Schwartz	2	1992	8	27	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15744	Camila Pamela Florencio Catão	2	1991	10	14	F	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15725	Caio Willian Travaglia	2	1993	10	18	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15743	Autiéres Ryan Hoe	2	1992	6	10	M	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15656	André Weslen Santos Nascimento	2	1992	1	26	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15731	Alan Felipe Dalmaso	2	1992	6	24	M	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15810	Vanderley Junior	1	1991	12	18	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10899	Vinnicyus Fornazza Costa	1	1993	9	15	M	258	6ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12165	Paula Souza Cordeiro	1	1994	8	26	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12520	Victor Hugo Chagas França	1	1993	12	13	M	312	6ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15056	NICOLE BATISTIM OSWALD	1	1994	12	28	F	11	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10903	Matheus Leite Luz	1	1994	5	18	M	258	6ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13097	Marina de Andrade Silveira	1	1995	6	5	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12409	Marco Aurélio Antônio	1	1994	10	7	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12508	Marcelo Henrique Torres	1	1992	5	21	M	312	6ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13548	Leonardo Peralta Piassi	1	1995	7	27	M	285	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12164	Larissa Zavagli Ramos	1	1992	10	27	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10861	LUIS GUILHERME MARTINS BIANCO PASSONI	1	1995	10	27	M	48	5ª C	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10352	LARISSA DA SILVA 	1	1995	9	19	F	48	5ª A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12506	Jônatas Gabriel Souza Moraes	1	1993	10	29	M	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10878	Felippe Augusto Oliveira Brito Patutti	1	1995	7	5	M	258	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14187	Fabio M.Grespan	1	1995	1	1	M	293	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13076	Dario Rodrigues Figueira de Castro	1	1994	3	26	M	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10591	Daphne Mazuz	1	1995	10	27	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10745	Danielle Polster	1	1994	8	22	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12500	Daniela Aparecida dos Santos Sobrinho	1	1994	3	24	F	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15907	Daianne Camillo de Souza	1	1994	10	2	F	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12490	Ana Paula Leite	1	1994	6	16	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12943	ANDRESSA VIEIRA DE SOUZA	1	1995	6	11	F	236	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12546	Vinícius Faria Venâncio	2	1992	4	30	M	312	7ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12501	Vergínea Luana de Matos	1	1993	10	23	F	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12519	Thaís Antônia Ribeiro Pereira	1	1994	4	26	F	312	6ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11973	RENATA MIRANDA SILVESTRE	1	1995	7	22	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12439	Pâmela Pallazi Corrêa	1	1995	2	24	F	312	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11327	Pedro Souza Gabriel	1	1993	10	30	M	511	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12517	Maciel de Castro Júnior	1	1994	1	2	M	312	6ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12441	Letícia Cássia Corrêa	1	1994	8	16	F	312	5ª C	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12502	Jéssica Daniele Silva de Castro	1	1994	4	26	F	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12468	Isabela Cristina Garcia	1	1994	8	31	F	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14189	Guilherme Correa Magalhães	1	1995	1	1	M	293	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10702	Daniel Diskin	1	1995	1	7	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15902	Camila Rodrigues Alves	1	1994	5	13	F	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12402	CAROLINE SANTOS	1	1993	9	17	F	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11141	Bárbara V. Vieira	1	1994	10	5	F	258	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15903	Marcela Rufo Soares	2	1992	7	24	F	189	8ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12440	LUIZ GUSTAVO FIUZA 	2	1993	3	18	M	355	7ª SÉRIE B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15905	Isadora  Faria Falótico	2	1992	2	1	F	189	8ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15906	Francine Gabriele Melo Barros	2	1992	9	21	F	189	8ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12438	DANIEL DE CARVALHO GALHOTI	2	1993	1	14	M	355	7ª SÉRIE B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12542	Cássio Guilherme Azevedo Amaral	2	1990	11	10	M	312	7ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15904	Caroline Laís de Moraes	2	1992	7	16	F	189	8ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12351	BRUNO ROCHA ROMA	4	1989	8	19	M	23	3B	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12342	Pedro Henrique Cavalheiro	4	1989	2	15	M	522	segunda série -ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11892	Franciele Silva Furlani Mendonça Camargo	4	1988	11	24	F	282	1º Termo / BSI	\N	\N	\N	42	\N	\N	\N	70	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11901	Adilson Direne Atalla	4	1987	9	29	M	282	1º Termo / BCC	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12960	Mariana Pellegrini Bertacini	1	1995	4	20	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12952	Maria Fernanda Bertanha Giusti	1	1995	6	13	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12972	Marcelo Santoro Alvarenga	1	1994	12	2	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12974	Luis Henrique Garcia	1	1995	6	17	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12976	Livia de Castro Boschiero	1	1995	5	8	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12965	Leticia Camarini de Toledo	1	1995	8	2	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12977	João Paulo Namura Wysocki	1	1994	12	12	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12957	Giovanni Degan Bechara	1	1995	10	5	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12946	Giovana Maluf Mosqueiro	1	1994	12	1	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12611	GABRIELA CASANOVA ATAÍDE DOS SANTOS	1	1994	8	9	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12949	Felipe Gustavo Risso	1	1994	12	7	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12612	ALDENOR SANTANA PEGADO NETTO	1	1994	2	23	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12552	Ítala Gonçalvez Rocha	2	1993	1	4	F	312	7ª C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12090	RICARDO JUNQUEIRA SALVADORI	2	1992	12	31	M	215	17TA2	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11522	Diego Galvão De Oliveira	2	1993	2	20	M	313	7ªE	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12583	Diego Aparecido de Oliveira	2	1990	8	20	M	312	8ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12594	Yara Gomes Vieira	2	1992	5	9	F	312	8ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6803	Victor Fernandes Malveira	2	1992	11	30	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12581	Thallyz Custódio Pereira	2	1991	5	10	M	312	8ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15995	Renato Ordás	2	1991	7	7	M	78	8EF	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12100	RENATO BEKMESSIAN WIDMER	2	1992	4	11	M	215	18MA1	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12083	RAPHAEL LOCATETTI	2	1990	10	27	M	215	18EC	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12551	Pâmela Rezende Santos	2	1993	6	16	F	312	7ª C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12554	Natália Fernandes Schimidt	2	1993	12	29	F	312	7ª C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14353	Márcio José Oliveira Júnior	2	1992	9	3	M	262	7ª Série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12588	Márcia Cristina da Cruz	2	1991	9	28	F	312	8ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12858	Michelle Santos Araujo	2	1992	3	17	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12544	Marcos Henrique da Silva	2	1992	12	13	M	312	7ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12856	Marcelo Ottoni Pinto Junior	2	1992	9	2	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14682	MARJORIE STEINMAIER	2	1992	6	22	M	215	18MA4	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13817	MARIA BETHÂNIA CONCEIÇÃO FERREIRA	2	1992	8	19	F	215	17EC	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12568	Lívia Marques	2	1992	8	21	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12559	Lorrane Alves Ferreira	2	1993	3	16	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14602	LAURA YAMAGUIBASHI	2	1993	2	11	F	215	17TA3	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12057	LAIS CRISTINA DA SILVA	2	1991	9	19	F	215	18EC	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6783	Kaique Rodrigues	2	1992	11	1	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12571	Jéssica Bonfim	2	1992	7	4	F	312	7ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12854	Juliana Pereira Telles de Menezes	2	1991	9	14	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12852	Juan Henrique Rial Jordão	2	1990	2	6	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12590	Josiani Ariele de Paula	2	1992	3	23	F	312	8ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6754	Jeanny Cordioli	2	1993	3	6	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12585	Isabella Nayara Dias da Silva	2	1990	11	2	F	312	8ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12851	Ilanna Moreira Caponi	2	1991	1	19	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14690	IGOR MANZAR	2	1992	11	30	M	215	17TA2	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6740	Hellem Cristina Silveira	2	1993	10	3	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6733	Guilherme Henrique Fustinoni Tonetto	2	1992	11	17	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12587	Gabriela de Assis Silva	2	1992	5	28	F	312	8ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12582	Gabriel de Souza Ferreira	2	1991	7	31	M	312	8ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14595	GUSTAVO L M COIMBRA	2	1992	3	2	M	215	18TA4	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12593	Filipe Augusto Silva Alves	2	1992	5	22	M	312	8ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12567	Fernanda Tavares de Oliveira	2	1993	3	21	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12555	Fernanda Ferreira	2	1992	5	5	F	312	7ª C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6730	Edson Rodrigues da Cunha Junior	2	1992	7	27	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14988	ERICA	2	1993	9	29	F	487	7ª EF	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12577	Deangelys Beani da Silva	2	1990	6	14	F	312	8ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12579	Crislaine Maria Silva	2	1991	4	5	F	312	8ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12580	Camila Helena Inácio dos Santos	2	1990	9	3	F	312	8ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12566	Bruna Silva Pellozo	2	1993	2	25	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12846	Breno Augustus de Andrade	2	1990	4	15	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12569	André Gonçalvez	2	1991	11	18	M	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12560	Ana Caroline Galdino de Paulo	2	1992	8	13	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12562	Amanda Ribeiro Cunha	2	1993	1	18	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12543	Aline Trindade Rezende	2	1992	11	15	F	312	7ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12556	Aline Portela dos Santos	2	1993	4	10	F	312	7ª C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12845	Alexandre Rocha da Silva 	2	1991	3	7	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9663	Sabir Ribas	4	1988	1	8	M	379	3º Ano	\N	\N	\N	42	\N	\N	1	165	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12963	Natalia Fadel	1	1995	6	22	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15529	Guilherme Pereira Gribler	1	1994	8	5	M	497	5ª série	\N	\N	\N	166	\N	\N	1	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13962	Victória Barreiros Lauria	1	1994	4	4	F	544	6a série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16008	Rubens Resende Fernandes	1	9999	99	99	M	207	6a. série	\N	\N	\N	166	\N	\N	1	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11065	Rafael Ribeiro	1	1991	5	4	M	313	6ªB	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10890	Edson Noriaki Shimozono	1	1994	6	28	M	258	5ª	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13655	Camila Uchôa Macahado	1	1994	8	28	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13795	Rodrigo Esmeraldo Loureiro	1	1994	11	15	M	516	5ª	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13302	Rafaela Jie Bang	1	1994	3	31	F	518	Fundamental	\N	\N	\N	166	\N	\N	1	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13433	PAMILLI LEANDRO BEZERRA	1	1993	11	26	F	527	6ª Série A	\N	\N	\N	166	\N	\N	1	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13294	Lennon Felipe Moretti	1	1994	1	5	M	518	Fundamental	\N	\N	\N	166	\N	\N	1	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15297	João Pedro de Araújo Figueira	1	1994	2	15	M	555	6	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13924	Guilherme Henrique Kayano	1	1994	3	12	M	544	6a série	\N	\N	\N	166	\N	\N	1	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12511	Ana Carolina Ribeiro Vigatti	1	1994	2	23	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12155	Nathali Cristina da Silva Martins Pereira	1	1995	8	30	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10514	Júlio César de Camargo Momesso	1	1995	3	22	M	473	5ª C	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12383	Iago Israel	1	1994	4	11	M	318	6ª Série B	\N	\N	\N	166	\N	\N	1	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10548	Gabriela R. Claudino	1	1994	2	6	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11554	Vanessa Katia Cavalcanti	1	1995	6	14	F	350	1ª C	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14151	Ivens Cardoso Pinheiro	1	1994	5	30	M	516	6ª	\N	\N	\N	166	\N	\N	1	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13638	Debora Oliveira Severiano	1	1994	9	13	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14123	Pedro Lucas Moreira Pires de Brito	1	1994	5	1	M	516	6ª	\N	\N	\N	166	\N	\N	1	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12397	CARLOS ALBERTO DE CARVALHO FERREIRA	1	1997	3	11	M	57	5 SERIE	\N	\N	\N	166	\N	\N	1	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10900	Cauê Chacon Deajute	1	1994	1	10	M	258	6ª	\N	\N	\N	166	\N	\N	1	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13478	Camila Cristina Rosa	1	1994	8	12	F	540	6a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15517	Vinícius Mizobuti	1	1993	9	24	M	497	6ª série	\N	\N	\N	166	\N	\N	1	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15445	Thais Lullez	1	1995	1	10	F	483	5ª D	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10534	Thairone Lauri Bairral	1	1994	2	18	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13446	SARA HILDA SOUZA SARAIVA	1	1993	11	17	F	527	6ª Série E	\N	\N	\N	166	\N	\N	1	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15533	Rodrigo Arruda Lopes	1	1995	1	10	M	497	5ª série	\N	\N	\N	166	\N	\N	1	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14655	Marina Brasil Pintarelli	1	1994	1	21	F	552	6ª2ª	\N	\N	\N	166	\N	\N	1	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15999	João Vitor G. de Oliveira	1	9999	99	99	M	207	6a. série	\N	\N	\N	166	\N	\N	1	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13300	Gabriel Jie Bang	1	1995	2	7	M	518	Fundamental	\N	\N	\N	166	\N	\N	1	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14503	Diogo Dreher	1	1994	9	1	M	552	6ª1ª	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11912	Amanda Cristine Tavares	1	1994	1	29	F	482	6ª série B	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13348	Tiago Roos de Oliveira	2	1990	1	5	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13339	Sâmara Knorst	2	1991	2	21	F	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14411	Rodrigo Costa Monte	2	1992	3	19	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13545	Priscila de Jesus Rocha	2	1993	1	28	F	112	7ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13471	Marlana de Souza Campelo	2	1993	1	1	F	112	7ª serie	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13337	Luiza Hörle Mombach	2	1991	5	6	F	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13342	Ivan Andreis	2	1991	6	3	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14436	Flávio Coutinho da Silva	2	1991	1	30	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14414	Eliney Farias Pereira	2	1991	8	13	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14605	ERIKA CASÃO	2	1992	12	26	F	215	17TA3	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12062	DANIELA FEITOSA NASCIMENTO	2	1992	7	23	F	215	17EC	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13347	Cristian Berwian	2	1990	6	4	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12061	BRUNA AP. CARDOSO DE MOURA	2	1992	11	14	F	215	17EC	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12070	AMANDA GAMEIRO BIASIOLI	2	1992	5	5	F	215	18TA3	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13783	ALÍCIA MAELAN REICHARDT BARRAYCOA	2	1993	5	10	F	215	17MB1	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13283	Thiago Roberto M. do Amaral	4	1988	8	2	M	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13296	Wellington Willian de Arruda	1	1994	6	15	M	518	Fundamental	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13019	ROBSON FERNANDES DA SILVA	4	1988	9	15	M	23	2C	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13022	MAYSA SANTO ANDRÉA	4	1990	1	23	F	23	2D	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13357	Gerson Luís Weber	4	1987	6	23	M	288	Médio completo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13286	Antonio Carlos Mantovani	4	1988	7	14	M	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13287	Thiago Araki Moriama	4	1988	5	5	M	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13288	Rodrigo Melgar Rodrigues	4	1987	5	20	M	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13289	Robson Amaral Bacarin	4	1988	4	27	M	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13219	Murilo de Sá Gesuino	4	1989	10	24	M	83	5ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13013	LAIS MILENE GOMES DIONIZIO	4	1990	8	11	F	23	2C	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13003	EVANDRO BARBOSA CARREIRA	4	1990	12	21	M	23	2B	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13240	André Fontana	4	1988	11	2	M	519	3	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13218	Alan Peruch Casagrande	4	1989	6	27	M	83	5ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	15	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11698	YURI DA COSTA ALBUQUERQUE	4	1989	11	9	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	15	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13773	RODRIGO DOMINGOS LOCATELLI	1	1994	2	7	M	215	16EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12037	BRUNO FERREIRA ALCARO	1	1994	3	13	M	215	16MA3	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12029	BEATRIZ PASCHOAL BRANCO	1	1994	6	22	F	215	16MA2	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14569	Yuri Regis de Freitas	2	1991	10	27	M	527	8ªPI	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15170	RAPHAEL CARVALHO SOMAN	2	1992	9	28	M	119	9º Ano	\N	\N	\N	173	\N	\N	1	21	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13007	Luigi de Oliveira Prada	2	1992	12	7	M	541	7ª série	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13403	LEANDRO LIMA SOBRAL	2	1993	5	28	M	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13295	Everton Henrique de Arruda	2	1992	6	25	M	518	Fundamental 	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12123	Camila Niitsu de Lima	2	1992	1	3	F	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15172	ANA LAURA LOURENÇO GASPAR	2	1992	5	28	F	119	9º Ano	\N	\N	\N	173	\N	\N	1	22	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15255	ANA CAROLINA GODOY AMARAL	2	1995	7	11	F	119	6º Ano	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13541	Raphael Abrantes de Oliveira	2	1992	2	26	M	527	8ªPI	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13292	Pollyana Garcia Vilarinho	2	1993	8	6	F	518	Fundamental	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11472	VITOR RAMALHO BARDAUIL	2	1991	10	23	M	159	7	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15258	GIOVANE NAVARRO ROCHA	2	1993	11	13	M	119	7º Ano	\N	\N	\N	173	\N	\N	1	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15448	Andre Luiz Almeida Rocker	2	1993	9	20	M	483	7ª A	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14084	Victor Lemos	2	1992	10	30	M	516	7ª Série	\N	\N	\N	173	\N	\N	1	20	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15256	MATHEUS PEGORIN PINHEIRO	2	1995	2	10	M	119	6º Ano	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13376	GABRIEL MAGALHÃES TEIXEIRA FEIJÃO	2	1991	4	5	M	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13025	Thais Carvalho Brito	2	1991	10	22	F	541	8ª série	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13341	Rodrigo Zimmermann	2	1991	3	5	M	288	8ª série completa	\N	\N	\N	173	\N	\N	1	21	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13498	Paula Regina Zamuner Zéca	2	1993	8	6	F	540	7a série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12340	NARA GABRIELA DE MESQUITA PEIXOTO	2	1993	2	5	F	488	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14437	Jessica Cardoso Queiroz	2	1991	8	21	F	112	8ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13378	INDIRA PONTE RIBEIRO	2	1991	11	4	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15254	Fabio Moreira Montini	2	1992	1	20	M	545	8a	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12398	Sílvio José Santana	2	1991	1	1	M	473	1 série do ension médio	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15160	GIOVANNA FERREIRA CAMILO	2	1993	11	26	F	119	7º Ano	\N	\N	\N	173	\N	\N	1	20	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15163	DANIEL SANTIAGO RODRIGUES	2	1993	3	10	M	119	8º Ano	\N	\N	\N	173	\N	\N	1	22	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15157	BRUNO PIRES MENICUCCI	2	1994	6	13	M	119	7° Ano	\N	\N	\N	173	\N	\N	1	20	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15168	VINÍCIUS GOMES DA SILVA	2	1992	2	3	M	119	9º Ano	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14796	NATHÁLIA ALVES FRAZON	2	1994	3	25	F	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15265	MARIEL TAVARES DE OLIVEIRA PRADO	2	1992	5	11	F	119	9º Ano	\N	\N	\N	173	\N	\N	1	22	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14662	Lucas Takase Sasaki	2	1992	11	21	M	527	7ª Série 2 - PI	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14094	Jonas Rocha	2	1993	1	10	M	516	7ª Série	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13131	EDUARDO MATHEUS	2	1981	10	24	M	571	1-8MA1	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12381	Danilo Pallamin de Almeida	2	1993	2	17	M	318	7ª Série A	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13999	Ana Paula Corrêa Oliveira	2	1991	10	3	F	544	8a série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14106	Walber de Oiveira	2	1991	7	24	M	516	8ª Série	\N	\N	\N	173	\N	\N	1	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15556	Rafael Ponce Pereira da Silva	2	1993	4	3	M	539	7ª série	\N	\N	\N	173	\N	\N	1	22	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10305	Paloma Aparecida Alves	2	1993	6	17	F	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15702	NATHAN HENRIQUE BARBUTTI BROLEZE	2	1994	10	22	M	119	6º Ano	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14023	Mauro Augusto de Souza Mello Neto	2	1992	1	16	M	544	8a série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15671	Mariana Oliveira Braga de Morais	2	1992	8	6	F	492	8ª série do ensino fundamental 	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15576	Mariana Guedes de Oliveira Franco	2	1992	5	19	F	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15175	MURILO PERETO	2	1992	4	14	M	119	9º Ano	\N	\N	\N	173	\N	\N	1	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13538	Letícia Fernandes de Oliveira	2	1992	9	17	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15263	LILLIAM ROCHA PENHA	2	1991	10	21	F	119	9º Ano	\N	\N	\N	173	\N	\N	1	22	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13187	João Paulo Giro Cardoso	2	1991	12	9	M	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11469	JULIANA MIRKHAN	2	1993	6	5	F	159	7	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15491	Horácio Alberto N. Ginzo	2	1992	2	27	M	548	8ª	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13016	Gustavo Franceschi Aleixo	2	1993	3	12	M	541	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15165	FERNANDO DA SILVA BAUTZ	2	1993	4	19	M	119	8º Ano	\N	\N	\N	173	\N	\N	1	22	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12892	Eduardo Ferreira Domingos	2	1992	5	25	M	90	8	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15966	Douglas Oliveira Lopes	2	1991	7	7	M	78	8EF	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11355	Mateus Marcelini Silveira Ribeiro	2	1991	8	26	M	511	8ª	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13492	Kate Cristiane Shizumi Honda Nakano	2	1992	9	21	F	540	7a série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14528	Jade Santos Silva Bueno	2	1992	8	9	F	545	8a	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14640	GUILHERME BRITTO DE SOUZA	2	1992	10	7	M	179	9º ANO	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10313	Felipe Takano	2	1992	10	16	M	258	7ª série	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10312	ANTONIO WELLINGTON SENA SAMPAIO	2	1988	2	11	M	244	8ª série do Ensino Médio	\N	\N	\N	173	\N	\N	1	22	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13779	THOMAS SCHIMIDT MOREIRA	1	1994	3	21	M	215	16MB1	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14336	EZEQUIEL MOISÉS RIOS	1	1994	6	24	M	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15018	Bharbara Pereira Santos	1	1993	9	21	F	192	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14337	MARIANA VIEGAS GRECO DE OLIVEIRA	1	1994	1	24	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4418	PAULO ROBERTO DELL ANHOL	1	1994	4	24	M	355	6ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14302	ISABELA ANDRADE BORGES	1	1994	12	5	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1400	Micaela Burcatovsky Trostchansky	1	1994	10	5	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14338	LOREN GIFFONI BORGES FONTES	1	1993	10	24	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14334	LAURA PAULA PAIVA SILVA	1	1993	6	5	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1431	Karen Zatz Oliveira	1	1994	9	27	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
127	ICARO BARBARIOLI FERREIRA	1	1994	1	3	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1427	Fábio Dratcu	1	1994	4	12	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14339	EDUARDA OLIVEIRA MANEIRA	1	1994	3	4	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14303	BÁRBARA VAZ MENDES	1	1992	4	4	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13884	Bruna Lima Nogueira	1	1994	6	13	F	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13880	Beatriz Abreu de Castro Figueiredo	1	1993	8	19	F	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1677	Daniela Joelsas	2	1992	1	19	F	153	8ª série	\N	\N	\N	55	\N	\N	1	19	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1631	Gustavo Brandão Roll 	2	1992	1	6	M	153	8ª série	\N	\N	\N	153	\N	\N	1	18	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12863	Viccenzo Amorim Maito	2	1991	8	11	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1606	Ronny Feldman Singal	2	1993	6	5	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14218	Milena Lopes G. Moura	2	1992	4	1	F	293	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12860	Raphael Marçal Barroso	2	1992	5	19	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14459	Marcos Antonio Cardoso Junior	2	91	4	15	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14469	Gabrielly Rocha Toledo	2	92	2	1	F	90	8	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1645	Tamara Atias	2	1992	4	23	F	153	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1640	Philipp Zinger	2	1991	8	9	M	153	8ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6800	Patricia Luzia Zanela	2	1993	10	23	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14461	Amanda Luisa Silveira Fonseca	2	92	3	20	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14799	MATHEUS PIMENTEL KLOCKER	2	1993	6	3	M	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14217	Maristela Leyko F. Nomura	2	1992	3	5	F	293	8ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13565	Diego Bertolucci	2	1991	10	15	M	285	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14470	Cristiana Martins de Matos	2	91	12	14	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14457	RAFAEL COSTA RANCO	2	1992	1	24	M	465	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14214	Jair Simões de Castro	2	1993	2	18	M	293	7ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14212	Gabriel 	2	1993	2	18	M	293	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14458	David da Costa Coelho	2	91	5	29	M	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12862	Thamiris de Souza Corrêa	2	1992	2	5	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14468	Renan Duarte Pereira Cordeiro	2	90	10	11	M	90	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1690	Mauricio Wainsztok	2	1992	6	18	M	153	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14472	Leonardo Lenilson. Galvão da Silva	2	91	2	6	M	90	8	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6790	Kleber de Souza Amaral	2	1990	6	27	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14344	Thomas Bündler	2	1990	9	5	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1607	Thelma Rosset	2	1992	10	29	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12861	Thamiris Sant'anna da Costa	2	1989	11	12	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14464	Thais Cristina Liberato	2	93	3	1	F	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1667	Schaika Barg Pinto	2	1991	10	10	F	153	8ª série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12859	Raphael Candido Alves	2	1990	4	4	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14467	Rafael Silveira de Souza	2	91	8	8	M	90	8	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12884	Priscila Nogueira de Azevedo	2	1992	4	14	F	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14204	Milena Tieme Arashiro	2	1992	10	26	F	293	7ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14471	Michel Angelo Guedes Vieira	2	92	4	7	M	90	8	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14465	Marcela Cristina Z. de Carvalho	2	91	8	29	F	90	8	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14460	Jessica de Jesus Santos	2	90	4	19	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1577	Jayme Barzilay Ghisserman	2	1993	4	16	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14248	GUSTAVO ANTONIO PEREIRA	2	1991	12	2	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12866	Fellipe Venceslau Tito 	2	1991	3	27	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14466	Eloa de Souza Freitas	2	91	8	31	F	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14410	Brenno Pinheiro Dias	2	1992	8	5	M	112	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14345	Oscar Arthur Gernhardt Neto	4	1988	11	4	M	288	3° ano médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13960	Ederson Leal C. Brilhante	4	1990	4	25	M	288	2° ano ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13937	Vanderlei Langer Spies	4	1975	1	1	M	288	ensino médio completo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13933	Tiago Fick	4	1982	6	24	M	288	ensino médio completo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13874	Raphael Zanguettin Parra	4	1986	10	10	M	372	1o - BCC	\N	\N	\N	42	\N	\N	1	120	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13930	Gustavo Spiering	4	1988	5	9	M	288	ensino médio completo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14348	Gustavo Cardoso da Silva e Lima	4	1988	4	16	M	372	1o - BCC	\N	\N	\N	42	\N	\N	\N	70	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13935	Cassiano Kähne	4	1982	3	27	M	288	ensino médio completo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1435	Tatiana Schapiro Veiga	1	1994	10	18	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13689	Vitor Souza Pereira	4	1990	7	31	M	462	2º ano - Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1521	Gabriela Cshapiro	1	1994	12	7	F	153	6 série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1394	Gabriela  Hazan Trigo	1	1994	8	5	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15248	Mariana Orate Menezes da Silva	1	1994	7	7	F	262	6ª Série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12634	VITOR HUGO FERREIRA DA SILVA	1	1995	4	3	M	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
135	THIAGO FORECCHI GIOVANNI	1	1994	2	2	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1868	Gabriela Arcuschin de Oliveira	1	1994	8	29	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14999	NICOLAS KEPPELER	1	1995	6	16	M	215	15MB1	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1525	Marina Kuhn	1	1993	9	22	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12075	LEONARDO GAMEIRO BIASIOLI	1	1995	3	15	M	215	15MA3	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14980	GUSTAVO CITRONI PALMA	1	1995	7	24	M	215	15MA1	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15230	Nathan Ken Anonni Kushima	1	1995	4	4	M	517	quinta	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14979	Fernando Aires	1	1981	7	24	M	411	ultimo ano	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14981	BEATRIZ DE PAULA	1	1993	11	28	F	215	16EC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1421	Ariel Cordoval Rosenblatt	1	1994	6	7	M	153	6ª Série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1511	Amir Boukai Lencastre	1	94	6	4	M	153	6ª Série	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1617	Julio Brandão Roll	2	1993	2	24	M	153	7ª série	\N	\N	\N	41	\N	\N	1	20	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14997	UBIRITAN CIPRIANO CARVALHO	1	1995	7	1	M	215	15TA4	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12640	SABRINA DA SILVA BRITO	1	1994	9	26	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14828	Raíssa Matias Lewinter	1	1994	8	8	F	367	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15233	Rayane Bergamini Chyla	1	1995	4	12	F	483	6ª B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12048	LUCAS LOBATO VIEIRA DE MORAES	1	1995	1	1	M	215	15MA1	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15000	LIZANDRA DA COSTA ARAÚJO	1	1994	7	24	F	215	15EC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4509	Giovana Soares Bueloni	1	1994	7	7	F	78	6EF	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12025	FLAVIA SCHENK BERTOLI	1	1995	4	11	F	215	15MA2	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14994	FILIPE C. SIMÃO	1	1994	4	8	M	487	6ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14998	DOMINIK KELLER	1	1995	6	23	M	215	15MB1	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15249	Bruno Henrique H. Marques Oliveira	2	1992	7	18	M	262	8ª Série	\N	\N	\N	131	\N	\N	1	16	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15241	Vanessa Oliveira de Souza	2	1991	11	16	F	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15240	Renan Gustavo dos Santos Corrêa	2	1990	6	20	M	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1589	Adam Mazuz	2	1993	5	3	M	153	7ª Série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1571	Déborah Kenez Damiani	2	1993	6	2	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15244	André O. Beraldo	2	1988	8	31	M	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1598	Fernanda Bachman	2	1993	10	12	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15238	Drielen Lemes da Silva	2	1991	9	10	F	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1581	Patrick Feldman Singal	2	1993	6	5	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15239	Caroline de Oliveira Tavares	2	1991	7	26	F	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4568	Arthur fernandes Smolarsky	2	1993	7	7	M	78	7EF	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
437	TÁSSIA NATALI PANDOLFI MANTOVANI	2	1993	5	28	F	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1619	Marcel Levy	2	1993	7	20	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15245	Anderson Moreira Bento	2	1988	10	29	M	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
434	PEDRO VICTOR TELLIS GONÇALVES SALLES	2	1993	6	29	M	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6747	Iago Pereira Sgrignolli Simao	2	1992	12	4	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14827	Jéssica Nogueira Josino	2	1991	9	9	F	367	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1587	Vanessa Giersztajn	2	1993	4	12	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15231	Tatiane Gomes Guimarães	2	1992	6	20	F	483	8ª B	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10284	Rafaela Toledo Patrocinio	2	1991	10	6	F	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6797	Michael Andrew Mestrinier	2	1993	3	19	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1602	Marina Arcuschin de Oliveira	2	1993	2	16	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1578	Julia Muller	2	1993	3	27	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15243	Gabriela França dos Anjos	2	1991	3	29	F	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4616	Gabriel Luís Scheffer Renestiner	2	1993	7	7	M	78	7EF	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15235	Diego Roberto da Silva Origa	2	1988	9	28	M	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10281	Celso José Gonçalves Filho	2	1992	8	2	M	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15236	Caroline de Fátima Ribeiro	2	1992	2	6	F	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10285	Bruna Cristina Baliani	2	1991	11	21	F	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1608	Andre Spector Antunes	2	1993	5	31	M	153	7ª Série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10282	Amanda Schimidt	2	1991	9	26	F	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15234	Victor Mocelin	1	1995	10	9	M	483	5ª B	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1714	Willy de Lázari Araujo	4	1988	2	10	M	225	Prim Ano Informática FATEC	\N	\N	\N	42	\N	\N	1	125	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14978	Thiago Braga Marcilon	4	1988	10	12	M	559	Primeiro semestre da faculdade	\N	\N	\N	42	\N	\N	\N	60	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14835	Francisco Antônio Fontenele Filho	4	1989	9	16	M	367	2º	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14991	Nicolas de Araujo Moreira	4	1988	2	11	M	516	3o Ano	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1918	Leonardo Dezordi de Jesus	4	1989	6	26	M	283	5o Semestre de 7	\N	\N	\N	42	\N	\N	1	95	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14834	Yuri Cruz da Silva	3	1991	1	28	M	367	1º	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15330	Ramon Silveira Freire	1	1993	7	4	M	555	6	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15337	VITOR DANTAS MENDES	1	1995	2	17	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15335	Rodrigo Lima Dantas	1	1994	9	15	M	555	6	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15338	Roberta Maia de Vasconcelos	1	1994	2	8	F	555	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10339	OLÍVIA SHAD MANDARO	1	1994	4	28	F	29	6ª série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15470	Barbara Zafani	1	1993	12	6	F	262	6ª Série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15459	Carlos Henrique Santiago	1	1993	4	9	M	473	6 B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15463	João Pedro de Morais	1	1994	2	4	M	473	6 D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15471	João Pedro Varanda	1	1994	6	29	M	262	6ª Série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12034	JOÃO HENRIQUE LODYGENSLEY GOMIDE	1	1995	6	28	M	215	15MA4	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15456	Carlos  Henrique de Araújo Ferreira	1	1994	8	16	M	473	5 E	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15591	ARTHUR PASSINI DE PAULA	1	1994	12	20	M	533	6ª(EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15458	Raísa Maria da Silva	1	1994	10	25	F	473	5 E	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15455	Vanessa Aparecida Machado	1	1994	11	20	F	473	5 E	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15334	VICTOR AUGUSTO DE AMORIM MEDEIROS	1	1994	6	28	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15342	Thays de Vasconcelos Lima	1	1993	4	14	F	555	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15339	Thaise Delmiro de Sousa	1	1994	2	28	F	555	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15332	TULIO DE CARVALHO QUEIROZ	1	1995	6	29	M	555	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15465	Renan Mubarack de Oliveira	1	1995	4	15	M	262	5ª Série	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15944	NAELSON FRANCISCO DE SOUZA 	1	1994	9	1	M	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15668	Mariana Moreira Costa	1	1994	6	18	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15939	MABILLY FREIRE LOPES	1	1993	9	14	F	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15936	LEILA FERREIRA DA SILVA 	1	1990	12	3	F	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15643	Júlia Genaro de Lima 	1	1995	10	25	F	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15624	ISABELA L. LORENZONI	1	1994	5	16	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15934	IGOR LUIZ DE OLIVEIRA	1	1995	5	7	M	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15669	Danilo César Dias Da Costa 	1	1991	10	1	M	491	6ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14599	BEATRIZ CARVALHO DE MELO	1	1995	3	3	F	215	15MA4	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15457	Ana Caroline Rottoli 	1	1994	9	30	F	473	5 E	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15590	ANNA VITÓRIA BOLDT BERGER	1	1995	8	8	F	533	6ª (ENSINO FUNDAMENTAL)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10340	ALANA BARROSO DE JESUS RIBEIRO	1	1994	4	19	F	29	6ª série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16096	Lenisa de Mello e Souza	2	1993	3	16	F	259	7ª série	\N	\N	\N	84	\N	\N	1	21	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15581	Vinicius dos Santos 	2	1992	10	24	M	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15586	Rodolfo Pirondi Coviello	2	1992	1	14	M	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15667	Márcia Soares de Souza	2	1991	5	25	F	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15589	Amadeu Bonfante 	2	1992	6	12	M	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15935	LAUBNI FERREIRA DA SILVA	2	1992	3	10	M	480	8º	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10251	GABRIEL CASTELLO BRANCO MELLO MIRANDA	2	1993	7	16	M	6	7.ª 	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15462	Laís Verena Haro  de Lima	2	1993	6	9	F	473	7 F	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10636	Rafaeli Buzzani 	2	1993	3	20	F	473	7 E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11473	THOMÁS SENA	2	1992	9	29	M	159	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15246	ADRIANA CUNHA DE SOUZA RAMALHO DE VECCHI	2	1992	5	15	F	11	8ª	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15942	MARIA LUANA FERREIRA DOS SANTOS 	2	1991	6	15	F	480	8º	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15582	Samuel Wallace Boer dos Santos 	2	1992	2	17	M	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15583	Otávio Dorigan Predrazzoli	2	1992	8	31	M	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15587	Mariana Cristina Fiorini Diniz	2	1991	12	9	F	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15578	Lívia Pereira Massabni 	2	1992	3	6	F	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15461	Kaique jean Alves de Toledo	2	1993	6	14	M	473	7 F	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15460	Kaique jean Alves de Toledo	2	1993	6	14	M	473	7 F	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15588	Jéssica Maria Pirondi	2	1992	5	15	F	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11346	Carolina Ferreira Martins de Oliveira	2	1992	9	26	F	511	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15580	Amanda Massabni Massaroppe 	2	1991	11	21	F	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15946	ROSIANE ALINE DA SILVA	3	1984	11	6	F	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10761	Victor Levi	1	1993	10	19	M	153	6 série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15947	SABRINA MARQUES DE OLIVEIRA	4	1985	10	28	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15943	NAIDE MARIA DE LIMA 	4	1958	12	18	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16097	Marcio Costa	4	1989	10	25	M	42	3ª	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15940	MARKIOLKI DE SOUZA FERNANDES	4	1985	12	13	M	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15938	MARIA ROSILANE MAIA DE CARVALHO	4	1981	5	18	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15941	MARIA GISELE DE SOUZA	4	1987	9	14	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15937	ILCICLEIDE DE OLIVEIRA DINIZ	4	1986	3	16	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15948	STÊNIO RAFAEL RODRIGUES LOPES 	3	1989	9	7	M	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3081	Tiago Donizete dos Santos	4	1988	9	30	M	225	PréVestibular	\N	\N	\N	42	\N	\N	1	145	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15007	Nathalia Santos Andrade	1	1995	7	1	F	192	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10287	Victor Soares Gaspar	2	1992	6	30	M	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14182	Samantha Raphaely O. Pontes	1	1993	5	25	F	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11404	Rodrigo Marques de Oliveira	1	1994	11	7	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15014	Pedro Falcão de Albuquerque	1	1995	1	7	M	192	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14180	Nicolas Alexandre Silva de Carvalho	1	1995	7	7	M	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11395	Nelson Tadeu da Silva Júnior	1	1992	10	22	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14184	Natália Ribeiro S.	1	1995	4	18	F	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14183	Natália Dianno	1	1995	7	22	F	293	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11389	Michele Thais Araújo Martins	1	1994	5	7	F	313	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14171	MONALISA FREITAS DE BRITO	1	1994	7	3	F	488	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11400	Lucas Paulazini de Souza	1	1994	7	4	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11403	Lucas Moraes Silva	1	1994	10	10	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11390	Jéssica Silva dos Santos	1	1994	9	8	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15015	Henrique Basílio Machado	1	1994	10	14	M	192	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11391	Guilherme V. Franchi	1	1994	2	22	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14188	Gabriela de França Vizroli	1	1995	1	1	F	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11387	Edson Flávio de Sousa	1	1993	8	25	M	313	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15016	Carolina Coutrin da Silva	1	1995	7	19	F	192	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15010	Bruno Moura Tavares	1	1994	9	24	M	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15009	Bruno Mian Silva	1	1993	12	29	M	192	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14185	Bruna Nogueira	1	1995	4	22	F	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11388	Alessandro Paulino Silva	1	1992	2	21	M	313	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10690	Alan F. Batista	1	1994	7	16	M	473	6 A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12898	Victor Barroso Raul	2	1991	9	7	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11358	Sofia Ferrarini Nabuco	2	1992	9	22	F	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11351	Samuel Almeida Santos de Oliveira	2	1992	4	22	M	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12891	Raphael de Araujo Peixoto	2	1991	9	10	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11357	Paulo Silva Melo	2	1992	2	20	M	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11364	Mateus Marcelini Silveira Ribeiro	2	1992	10	28	M	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11361	Mariana Pizzo de Paula	2	1991	9	22	F	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11354	Lívia Cristina Palos	2	1991	12	20	F	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11356	Luis Eduardo Palmeira Sales	2	1991	7	29	M	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12904	Lucas de Lima Ribeiro	2	1992	5	12	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12890	Ingrid Rosemary Silva Garcia	2	1992	1	28	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11368	Guilherme R. Flório	2	1991	9	3	M	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12902	Guilherme Pereira de Azevedo Vieira	2	1992	4	15	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11365	Guilherme Augusto de Lima	2	1991	11	10	M	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12888	Fernanda de Almeida Mansores	2	1993	5	28	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10300	Eduardo Aparecido do Couto	2	1993	1	13	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10288	Douglas de Sousa Dourado	2	1991	9	7	M	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15013	Davi Nogueira Vicentini	2	1992	11	20	M	192	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11349	Carolina Teixeira Martins de Oliveira	2	1992	9	26	F	511	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15017	Arthur Batista Caliman	2	1992	4	20	M	192	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12595	André Philipe Tavares Preto	2	1991	1	24	M	312	8ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12598	André Filipe Ribeiro de Almeida	2	1991	8	28	M	312	8ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11367	Aline Rodrigues Pedroza	2	1991	11	26	F	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13514	Wellington Lucas Dias da Siva 	3	1987	9	20	M	518	Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14181	Victória Pereira Guerra	1	1995	1	22	F	293	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14776	Magno Charles da Silva	4	1987	4	21	M	379	2º Módulo Curso Técnico Instrumentação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12658	Juliana Lacerda Leite	4	1985	5	24	F	59	1a Superior	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13506	Tiago Gonçalves da Silva	4	1988	3	20	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3079	Marcelo Moreira de Carvalho Junior	4	1988	8	29	M	225	Terceira Série EM	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3080	Lucas Frassi Orides	4	1989	4	18	M	225	Terceira Série EM	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14779	Gustavo Henrique de Souza Fonseca	4	1986	3	26	M	498	1a	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10341	FÁBIO DE OLIVEIRA SOARES	4	1988	8	5	M	29	3° ano A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12660	Diorgenes Cicero da Silva Peres	4	1987	9	7	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13508	Diego Ferreira dos Santos	4	1987	11	11	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13507	Danilo Souza Almeida	4	1987	12	28	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12659	Caroline Gonçalves da Silva Nascentes	4	1988	5	17	F	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13505	Breno Cristovão Rocha	4	1986	10	21	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14777	Alan Augusto D´Avila de Oliveira	4	1988	2	13	M	498	1o	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12664	Vitor Rafael de Oliveira Guimarães	4	1987	4	20	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11592	Gilson Ricardo da Silva	1	1996	2	27	M	350	4ª A (Esc. Serra da Prota)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15196	Ricardo Ximenez Ikegame	1	1995	10	2	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12528	Pedro Henrique Leite	1	1992	8	24	M	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10550	Pamela Aparecida Scaglia	1	1994	1	14	F	473	6 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12445	Maicon Mateus	1	1992	3	13	M	312	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12444	Maicon Mateus	1	1992	3	13	M	312	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11675	MURILO DE PIERRE	1	1995	8	21	M	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10552	Luana C. Fernandes 	1	1994	7	19	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11416	Flávia F. Ferreira	1	1995	4	12	F	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11997	DANIELE BRENDA FERNANDES DA COSTA	1	1994	9	17	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12448	Caetano Greco Neto	1	1994	9	16	M	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12447	Caetano Greco Neto	1	1994	9	16	M	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15900	Bruno Prado	1	1993	8	30	M	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10726	Bruna de Almeida Bernardes 	1	1994	11	25	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12521	Bianca Silva Vieira	1	1993	9	13	F	312	6ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11773	Alef Martins Perdigão	1	1993	11	3	F	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12345	Samuel Rodrigues Rabay	2	1992	12	6	M	59	7a Serie	\N	\N	\N	99	\N	\N	1	\N	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10286	Valdete Aparecida Godoi	2	1991	9	30	F	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10290	Maicon Souza Oliveira	2	1991	10	22	M	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10926	Larissa Lucas de Ávila	2	1992	11	30	F	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12449	ISABELE BATISTA LOUREIRO	2	1993	8	12	F	355	7ª SÉRIE B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11590	Nadynne Pastoriza dos Santos	2	1993	2	24	F	350	8ª A (Esc. Decisão)	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10925	Mirna dos Santos Oliveira	2	1993	5	25	F	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10927	Thor João de Sousa Veras	2	1993	3	6	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12335	Carolina de Castro Linhares	2	91	11	30	F	159	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12446	TAMARA FIUZA PERUCIO	2	1993	10	26	F	355	7ª SÉRIE B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10294	Sarah Cristina de Oliveira	2	1992	11	5	F	393	Ciclo IV - Inicial B	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11475	NATALIE USSIFATI ROCHA	2	1992	5	27	F	159	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10289	Murilo de Campos Lourenço	2	1991	9	16	M	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10299	Maristela Tolentino	2	1992	8	14	F	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12534	João Inácio Coragem Smargiassi	2	1992	12	7	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10929	Josuel de Souza 	2	1992	9	20	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10301	Isabela Rodrigues Florindo	2	1993	6	23	F	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10924	Hellen Marcela Goulart de Souza	2	1993	6	13	F	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10928	Filipe Fernandes dos Santos	2	1994	7	2	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10930	Djanira Rodrigues Nascimento	2	1992	1	28	F	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10923	David Rocha ferreira	2	1993	7	10	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10297	Chrystian Féola Nizio	2	1992	7	6	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10295	Bruna Emerich Eller	2	1992	11	20	F	393	Ciclo IV - Inicial B	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15192	Tiago Guimarães Vargas	3	1989	12	26	M	512	2ºMA	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11413	SANDRO LÚCIO PASCOAL MARTINS	3	1986	11	28	M	495	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15193	Moisés Alexandre Gomes	3	1990	7	17	M	512	2ºMB	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15191	Matheus Zocolotto G. Bueno 	3	1990	2	5	M	512	2ºMA	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11411	MICHELLE CAMILLO MAGALHÃES	3	1988	9	13	F	495	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12036	JOÃO PAULO UCHÔU LEITE	3	1990	10	9	M	488	1º SÉRIE DO ENSINO MÉDIO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11410	FREDERICO MARTINS PEDROSO JÚNIO	3	1988	7	19	M	495	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10728	Yasmin Silva Norbiato	1	1995	1	10	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11409	Daniel dos Santos Marques	4	1988	7	21	M	303	terceiro ano do ensino medio	\N	\N	\N	31	\N	\N	1	125	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12033	Yuri Barrozo Brandão Azambuja	4	1988	3	24	M	521	1° semestre curso superior	\N	\N	\N	42	\N	\N	\N	75	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12044	Fernando Vanin Silva	4	1987	9	12	M	142	1° módulo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11656	Gabriel Nobrega de Lima	4	1987	10	16	M	153	Ens Medio Completo 2005	\N	\N	\N	42	\N	\N	1	210	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12330	Lívia Silveira Netto Pommering	4	1989	10	24	F	522	segunda série -ensino medio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12653	WALLACE RAMOS DE SOUZA	4	1989	12	26	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11407	Vinícius Gonçalves Melo	4	1989	4	21	M	303	terceiro ano do ensino medio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12797	Renan Eugênio Capuvilla	4	1987	4	1	M	321	3ª Ens. Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12331	Nathanael Ramos Montanez	4	1990	10	29	M	522	segunda série -ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12396	MATEUS LEONEL SOLTO ALONSO	4	1988	5	18	M	23	3B	\N	\N	\N	42	\N	\N	1	100	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12787	Lucas Diniz Bizzari	4	1990	2	2	M	321	3ª Ens. Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12332	João Lucas Palma	4	1989	5	20	M	522	segunda série -ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12655	JUSCELINO DE MATOS SAMPAIO FILHO	4	1990	9	6	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	1	145	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12242	Carlos Eduardo Rosa Machado	4	1988	6	21	M	96	1o semestre	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11412	WILIAN DOUGLAS DOS SANTOS	3	1987	10	5	M	495	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13614	Mateus e Silva Bessa	1	1995	1	26	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13616	Marcos André Araújo  Accioly Filho	1	1994	10	17	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13613	Luana Mosca Galdino da Silva	1	1995	2	19	F	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12451	Leonardo Germano Madeira	1	1994	10	25	M	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12442	Giovane Zanta de Oliveira	1	1993	3	21	M	312	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13635	Daniel Uchôa Brandão	1	1993	9	4	M	367	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12527	Daiani Cristina Lopes	1	1994	12	25	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13198	DIEGO DE OLIVEIRA BISERRA	1	1994	10	22	M	355	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13196	BRUNO HENRIQUE DOS SANTOS	1	1994	5	8	M	355	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12450	Ana Lívia Soares Cardoso	1	1994	10	20	F	312	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13194	ANDERSON ALVES BOZOKI	1	1994	5	2	M	355	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12124	Danilo Rodrigues dos Santos	2	1991	9	19	M	393	Ciclo IV - Final B	\N	\N	\N	67	\N	\N	1	20	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12122	Carmine Lombardi	2	1991	12	10	M	393	Ciclo IV - Final B	\N	\N	\N	99	\N	\N	1	17	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12128	Talles Henrique Santos Leite	2	1991	12	21	M	393	Ciclo IV - Final B	\N	\N	\N	163	\N	\N	1	18	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12120	Lucas Roberto do Nascimento	2	1991	8	18	M	393	Ciclo IV - Final B	\N	\N	\N	166	\N	\N	1	18	0	16	266	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14223	Willian Hirata Ide	2	1992	8	31	M	293	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13074	VITÓRIA CARRARO MANCINI	2	1992	11	19	F	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13089	VANESSA ELISA PINHEIRO	2	1993	3	21	F	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12537	Pedro Zavagli Suarêz	2	1992	10	9	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12031	IGOR BARRETO RAMPAL	3	1991	5	25	M	488	1º SÉRIE DO ENSINO MÉDIO	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12532	Nayane Cristina Ribeiro	2	1993	4	19	F	312	7ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14243	MARIANA MINDIM MELO	2	1993	8	5	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12531	Kaíque Arakaki Gomes	2	1992	12	18	M	312	7ª A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13640	Katheryne Simone Simões	2	1992	7	3	F	462	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13087	Kallyl Reis Fonseca	2	1993	10	11	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13335	KARINE DRUMOND LOUREIRO	2	1991	11	27	F	6	8.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14227	Jéssica Maria Fernandes	2	1992	1	2	F	313	8ºB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13071	JENNYFER KAROLLINE BEZERRA	2	1993	6	23	F	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13641	Isaac Aragão do Nascimento	2	1993	3	5	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13091	GABRIEL FURLAN REBESSI	2	1992	7	20	M	309	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12126	Felipe Padela da Silva	2	1992	8	19	M	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13070	EDUARDA BARBOZA MURER	2	1992	10	31	F	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12121	Camila Sales Nascimento	2	1991	10	31	F	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12926	Ana Caroline Nunes e Silva	2	1992	4	20	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12114	Adilson Gomes dos Santos	2	1991	8	10	M	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13067	AUGUSTO ANTEGHINI OAZI	2	1993	4	10	M	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13066	AMANDA MATTOS ANTUNES	2	1993	4	25	F	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12068	Rodrigo Tofoli Honório	3	1991	6	26	M	505	Primeira Série do Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12073	Marina Silveira Carvalho Alves	3	1991	11	11	F	505	Primeira Série do Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12071	João Otávio dos Santos Mota	3	1991	7	10	M	505	Primeira Série do Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12066	José Augusto Forni	3	1990	7	20	M	505	Primeira Série do Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15861	FRANCISCA JÉSSICA TEIXEIRA DA SILVA	3	1991	6	15	F	480	1° ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15864	ERICA DAIANE RODRIGUES	3	1990	3	23	F	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15867	CLAUDEANO AUGUSTO DE SOUZA	3	1988	6	30	M	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12076	Amanda Caetano Tanaka	3	1991	10	11	F	505	Primeira Série do Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15877	ANA CLAUDIA BATISTA RODRIGUES	3	1992	3	17	F	480	8ª SERIE	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13615	Matheus Anastacio de Oliveira Lima	1	1995	4	29	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13073	Wilgton Cris Ribeiro	4	1988	4	22	M	566	3ª série Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13603	Tiago Sampaio Fernandes	4	1988	3	31	M	379	2º Módulo do Curso Técnico	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12046	Pedro dos Reis Martins	4	1987	4	11	M	142	1° Módulo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13573	Paulo Henrique Passos Moreira	4	1988	10	8	M	59	3a Colegial	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13086	Natália Domingos Pelissari	4	1989	7	12	F	566	3ª série Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15859	ITAMARA AMIKAELLA DA SILVA ARAÚJO	4	1990	11	28	F	480	2° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15876	FLAVIA NATALIA BENTO DA SILVA	4	1986	11	5	F	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15863	FERNANDO FRAKLIN DE OLIVEIRA	4	1974	7	9	M	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15862	FAGNER BENTO DA SILVA	4	1989	11	7	M	480	2º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15865	EHELLEN HEVELHIN FERNANDES CANDIDO	4	1987	2	2	F	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15633	Danilo César Dias Da Costa 	4	1991	10	1	M	491	6ª Série do Ensino Fundamental	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12722	Charles de Freitas Garcia	4	1988	7	8	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15868	AUGUSTO CEZAR DE OLIVEIRA	4	1984	2	16	M	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15869	ARIELE LIRA DOS SANTOS	4	1989	4	14	F	480	2° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15870	ANTONIO PAULO SOUZA SILVA	4	1987	5	2	M	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15878	ADRIANA MARIA DE CASTRO	4	1984	10	9	F	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12074	Tatiana Valério Alves	3	1990	12	10	F	505	Primeira Série so Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12047	William Pereira Ferreira	4	1989	4	5	M	142	1° Módulo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14201	Victor Hugo Bueno Giovannetti	1	1994	6	13	M	293	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14792	CATHERINE MARTINS VAUROF	1	1995	6	14	F	122	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
128	IGOR DO ESPÍRITO SANTO BIANCA	1	1993	12	13	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15645	Thiago Amorim de Souza	1	1993	4	7	M	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15046	Thalita Santos Tiago	1	1995	6	29	F	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15640	Sheila S. B. da Silva	1	1994	1	28	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15019	Rúbia Souza Del Pupo	1	1994	5	8	F	192	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15029	Morgana Carneiro da Silva	1	1993	5	2	F	192	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15648	Michele Aparecida de Castilho	1	1994	6	28	M	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15031	Matheus de Vasconcellos Martins	1	1994	10	28	M	192	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15025	Marcella Minchio Vilella	1	1995	2	1	F	192	5ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15647	Luiz Carlos C. Junior	1	1994	2	18	M	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15032	Lucas Moreira da Silva	1	1994	1	1	M	192	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15045	Lucas Dornelas Vidal	1	1993	11	13	M	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15642	Luana de Souza Botelho	1	1994	11	11	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14794	LUCAS IANCKI PAULINO	1	1994	1	8	M	122	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15750	LUCAS EDUARDO MARTINS	1	1996	6	17	M	175	4a. Série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15644	Joice Maria Teixeira	1	1994	8	30	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14199	Jade Simões de Castro	1	1994	4	15	F	293	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10330	HELDER RODRIGUES VERVLOET	1	1994	7	16	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15638	Giovana Marcela Guimarães Alves	1	1994	6	16	F	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
123	GUILHERME BATISTA ROSALÉM FRAGA	1	1994	6	23	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15641	Flávia da Silva Oliveira	1	1993	10	11	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15024	Fernando Guimarães Silva	1	1994	4	13	M	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15026	Carolina Siqueira Lima	1	1994	9	24	F	192	5ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14195	Caio Guerra de Oliveira	1	1994	12	19	M	293	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14793	BEATRIZ BENINE CÔRTES	1	1994	11	26	F	122	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15030	Aron de Araújo	1	1993	8	22	M	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14193	Andressa Miwa Sadamitsu Shotus	1	1994	5	19	F	293	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15033	Amanda Gonçalves Amaral	1	1994	8	5	F	192	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14995	ANDRE AN	1	1995	5	9	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15028	Rumy Cristiane Barbosa Yamaguchi	2	1993	7	12	F	192	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15034	Rafael Lima de Almeida	2	1992	12	3	M	192	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15023	Lívia Giro Mayrinck	2	1993	6	24	F	192	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15022	Lucas Castelo Branco Santos de Almeida	2	1992	1	2	M	192	8ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15038	Larissa Esteves de Almeida	2	1993	8	27	F	192	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15020	Karina Schaeffer	2	1993	5	30	F	192	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14249	JULIANA DE FARIA LINHARES	2	1993	4	14	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
433	JOÃO VICTOR HYBNER RIOS	2	1993	4	26	M	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15037	Igor Coelho Borges	2	1993	7	29	M	192	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
142	HENRIQUE AMORIM OLIVEIRA	2	1992	7	8	M	29	8ª série B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14985	FELIPE CORDEIRO	2	1993	2	17	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15036	Caio Vinicius Kefler da Silva	2	1993	1	31	M	192	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14804	CHEYENNE BARROS BARCELOS 	2	1991	4	27	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14798	BRUNNA DE DONNO	2	1993	6	14	F	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15027	Ana Clara Fernades Rocha	2	1992	10	10	F	192	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15035	Aline Soares	2	1993	12	5	F	192	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14197	Victor Jun Higa	1	1994	5	27	M	293	6ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13529	Juliana Magalhaes	4	1989	2	28	F	283	5o Semestre de 7	\N	\N	\N	31	\N	\N	1	100	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12666	Pedro Henrique de Melo Sousa	4	1988	7	3	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14969	nedson gomes dos santos 	4	1974	3	8	M	560	7º sem-analise de sistemas	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15217	Regis Prado Barbosa	4	1990	5	6	M	516	2o Ano do Ensino Médio	\N	\N	\N	42	\N	\N	1	285	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14974	Linsley da Costa Oliveira Dias	4	1988	10	21	M	323	Calouro Concluinte ensino médio até 2005	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14955	Thiago Morais Silva	4	1990	5	28	M	568	2ª série do Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13512	Rodrigo Augusto Cardoso da Silva	4	1990	3	24	M	283	3o Semestre  de 5	\N	\N	\N	42	\N	\N	1	145	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14975	Natasha Sayuri Dias Nakashima	4	1988	4	3	F	323	Calouro Concluinte ensino médio até 2005	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13511	Mateus Paquesse Pellegrino	4	1990	5	6	M	283	3o Semestre de 7	\N	\N	\N	42	\N	\N	\N	20	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14976	Fábricio de Souza Farias	4	1988	3	10	M	323	Calouro Concluinte ensino médio até 2005	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14800	Fabio Kazuhiro Goto	4	1988	1	1	M	296	terceira	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15194	Carlos Roberto da Silva Pairet	4	1989	11	30	M	512	3ºMD	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15884	CARLOS ALBERTO DE OLIVEIRA	4	1962	3	9	M	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14973	Bruno Cruz Cilento	4	1993	11	12	M	571	1-7ta2	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15879	ANTONIO AIRTON FÉLIX DO NASCIMETNO	4	1984	7	7	M	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15883	ALAN ALFREDO DE SOUZA LOPES	4	1987	11	24	M	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10513	Lucas Alves Oliveira	1	1995	6	9	M	473	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10562	Jussara Alice de Melo	1	1993	2	24	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10667	Wesley de Andrade Rodello	1	1994	5	23	M	473	6 A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10671	Victor Palmeira Monteiro	1	1994	8	4	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10537	Thairone Lauri Bairral	1	1994	2	18	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10586	Silvia Nara Moura Dias da Silva	1	1993	12	18	F	473	6 E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10539	Roberson H. Pedroso	1	1994	1	21	M	473	6 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10556	Rick Wiliam Scholl	1	1994	1	20	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10547	Renata Caroline dos Santos Barbosa	1	1994	1	14	F	473	6 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10574	Renan R. da Silva 	1	1994	6	19	M	473	6ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10674	Paulo Henrique de Castro	1	1994	8	5	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10527	Pamela Miguel Rodrigues 	1	1993	9	4	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10526	Mariana Lauri de Oliveira	1	1993	9	5	F	473	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10531	Marco Aurelho Martins	1	1992	3	5	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10538	Luis Felipe Tenório	1	1993	8	15	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10494	Lucas Rafael Mantoan	1	1994	11	28	M	473	5 A   	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10491	Luana Ribeiro Lopes	1	1995	6	23	F	473	5ª C	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15047	Caio Silva Peres	1	1994	3	11	M	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10659	Brenda Belini	1	1994	6	28	F	473	6 A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10511	Andressa Aparecida Parizi	1	1995	4	29	F	473	5ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10564	Yonara Eloy da Costa	2	1993	6	21	F	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10650	Patrícia Alessandra Silva de Almeida	2	1992	8	5	F	473	7 E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10405	Daniele Cristina Mariano	2	1991	12	23	F	313	8°C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10399	VALDERUBENS SOARES DIAS JUNIOR	2	1993	1	4	M	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10404	Thyago Washinton Souza	2	1991	9	19	M	313	8°C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10571	Thafnis Lira da Silva	2	1993	6	4	M	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10637	Silmara Climaco de Freitas 	2	1993	12	13	F	473	7 B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10643	Raifi Aparecido Machado	2	1992	6	29	M	473	7 E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10649	Pedro Guilherme F. de Godoi	2	1992	11	15	M	473	7 A	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10523	Mayra Adelina Santana	2	1993	8	23	F	473	7 D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10400	MARCELO CARDOSO MARQUES	2	1993	6	20	M	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10675	Letícia Ortolan	2	1993	9	18	F	473	7 E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10398	LAURA LIMA GUAITOLINI	2	1993	10	18	F	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10634	Kaique Donisete Rita	2	1993	2	1	M	473	7 A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10581	Jéssica Maria	2	1993	6	29	F	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10641	Juarez Luís Padavini	2	1993	5	10	M	473	7 B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10557	Jaqueline de Oliveira Lino	2	1993	6	14	F	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10561	Jainifer Stephanny da Cruz Morais	2	1992	10	10	F	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
435	HUGO BARROSO	2	1993	11	14	M	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10545	Guilherme Fidélis	2	1992	9	4	M	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10411	Guilherme Augusto da Silva Alipio	2	1991	5	5	M	313	8°C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10575	Gleiciany Stephanie Prascedes	2	1993	12	8	F	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10406	Francisco Alexandre Gomes Ruiz	2	1991	9	10	M	313	8°C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10644	Franciele Fernanda Cecon	2	1993	9	6	F	473	7 B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10567	Franciele Cristina da Silva	2	1993	6	24	F	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10410	Felipe Benedetti Lima	2	1991	6	20	M	313	8°C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10414	Eliézer Geraldo da silva 	2	1989	12	24	M	313	8° E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10578	Danilo Ap. de Oliveira	2	1993	4	28	M	473	7 C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15508	Daniele David Cassini	2	1990	12	10	M	548	8ª	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10409	Cristian Lorrane Souza Azarias	2	1991	5	20	M	313	8°C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10401	CAEL BONFIM MOTTA	2	1993	7	29	M	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10417	Bárbara R. Maciel	2	1991	10	19	F	313	8° E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10416	Breno Henrique de Souza	2	1991	5	18	M	313	8° E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5633	GUILHERME CROCE RUAS	3	1990	8	25	M	57	1º EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10507	ARTHUR AMERICANO GODOY DE FREITAS RAMOS	3	1990	8	25	M	57	1º EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10583	William Cleverson de Oliveira	1	1992	6	26	M	473	6 E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10476	Luiz Felipe Cardoso Pereira	4	1990	1	5	M	469	2º Colegial	\N	\N	\N	42	\N	\N	\N	55	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10272	Leandro Dias Pagotto	4	1988	7	15	M	96	1o Semestre	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10397	Lucas Machado Rocha	4	1988	1	28	M	493	Curso Médio concluído	\N	\N	\N	42	\N	\N	1	80	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10606	Estevão dos Santos Gedraite	4	1989	8	31	M	469	3º Colegial	\N	\N	\N	42	\N	\N	\N	55	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10257	Diego Gottselig	4	1988	12	4	M	22	1º Semestre	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10469	LEONARDO LUCAS SOARES	4	1989	1	30	M	488	3º SÉRIE DO ENSINO MÉDIO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10273	Gustavo Macedo Mustafé	4	1988	1	15	M	96	1o Semestre	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10461	Fernando Roberto Proença. 	4	1988	3	4	M	59	1a Superior	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10475	Felipe Cunha Gomes	4	1990	1	13	M	469	2º Colegial	\N	\N	\N	42	\N	\N	\N	55	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11056	Talita M.S. Cavalcante	1	1994	2	10	F	313	5ºE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11044	Ronaldo Marques Júnior	1	1994	11	13	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10913	Roberto Nunes Martins	1	1994	12	6	M	54	Sexta	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10696	Raique Zacariotto	1	1995	5	2	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11048	Paula Daniele Ap. Garcia	1	95	3	9	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11060	Natanael Ap. Ramos Marcelino 	1	1994	11	12	M	313	5ºE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11036	Michele D. Mazzilli	1	1995	4	12	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10705	Mariana Mosswkayan Borges	1	1995	6	1	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11038	Lorena Oliveira Lopes	1	95	8	6	F	313	5ºE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10680	Leticia Ap. Almeida Molinari	1	1995	2	12	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10887	Leonardo Henrique dos Santos	1	1994	11	12	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11061	Júlio César Oliveira Júnior	1	1994	12	29	M	313	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10717	Julio C. Santos Oliveira	1	1995	1	27	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10689	João Batista Pierozzi Junior	1	1994	10	11	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11067	José Carlos Benedetti Martins	1	1995	1	6	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10724	Jonas H. Cintra de Souza 	1	1995	5	9	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11055	Guilherme Henrique de Carvalho 	1	1994	9	2	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11111	Geraldo Mateus Gomes Neto	1	1994	3	3	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11058	Fábio Antônio Marquês	1	1995	2	3	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10914	Felipe Noronha Portella	1	1993	1	20	M	54	Sexta	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11063	Eduardo dos Reis Geraldo	1	1995	3	21	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11066	Déborah de Oliveira Dias	1	1995	5	15	F	313	5ºE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10897	Daiana Cordeiro de Lima	1	1993	2	20	F	258	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10725	Caic Csar Campos dos Santos	1	1994	8	30	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11115	BÁRBARA SIQUEIRA MONTEIRO	1	1994	8	8	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11090	Bianca Carolina A. da Rocha 	1	1995	1	17	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10699	Beatriz de Oliveira Luppi	1	1995	1	23	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10879	Beatriz Oliveira Abreu do Amaral	1	1995	6	29	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10901	Beatriz Cagliari de Paula	1	1994	3	9	F	258	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15707	Ariél Tancon	1	1995	4	25	M	343	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10715	Anderson Gabriel Gimenes	1	1994	11	13	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10708	Anderson Gabriel Gimenes	1	1994	6	6	M	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11047	Anderson Alves de Lima G.	1	1994	2	22	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10683	Amanda de Fátima Bueno	1	1994	12	5	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10467	MAZZON ROQUE MAIA DE SOUSA	3	1990	11	7	M	488	1ª SÉRIE DO ENSINO MÉDIO	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10915	Rafaela Menezes dos Santos	2	1993	9	7	F	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10917	Pablo Crístian de Souza	2	1993	6	28	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10919	Melissa Emily Souza de Araújo	2	1993	6	1	F	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10916	Matheus M.ferraz	2	1994	7	10	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10918	Lucas Freire da Silva	2	1993	1	10	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10921	João Lucas Almeida de Oliveira	2	1993	10	13	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11116	HYURI CORREA DA SILVA	2	1993	9	15	M	6	7.ª 	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11119	GABRIELA DO NASCIMENTO BERNARDO	2	1993	1	6	F	6	7.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11118	ERICKA FERNANDA DA COSTA BITAR LIMA	2	1992	2	19	M	6	7.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10793	TAINÃ MARCOS SILVA	3	1990	5	17	M	495	2ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10790	ESDRAS AURÉLIO DA COSTA	3	1989	11	24	M	495	2ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10791	ELAINE SOARES BRITO	3	1990	4	9	F	495	2ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10806	DANIEL SIMÕES REIS	3	1990	3	5	M	495	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10805	BRUNA A. SILVA TEIXEIRA	3	1985	9	22	F	495	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10807	ABNER AUGUSTO GUERRA DE FREITAS	3	1988	9	19	M	495	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11042	Tiago Luiz da Silva Omett	1	1995	2	3	M	313	5ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10905	Régis Reis Freitas	4	1987	11	20	M	416	1pSI	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10909	Rafael Rodrigues da Silva	4	1988	4	26	M	416	1pSI	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10798	LEANDRO FRANÇA	4	1989	4	28	M	495	3ª	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11131	Diego Abrão Ferreira Mendes	4	1988	9	6	M	14	1o. semestre EC	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10764	DANIEL ROCHA FURTADO	4	1989	2	7	M	488	3º SÉRIE DO ENSINO MÉDIO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11158	Carolina Moraes dos Santos	4	1989	6	1	F	225	Terceira Série Ens Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10906	Bernardo Lucien Sousa Petitjean Fusco de Souza Guerra	4	1988	5	24	M	416	1pSI	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11088	Amanda Ferreira de Lima	4	1989	2	10	F	225	Terceira Série Ens Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7851	Allan de Paula Rúbio	4	1988	3	31	M	379	3º Ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10908	Adriana Basílio Henriques Paiva	4	1987	8	24	F	416	1pSI	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10802	VINÍCIUS ZANETTI CIRINO	3	1989	8	16	M	495	2ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10799	ÉTTORE BUZZO	4	1989	4	10	M	495	3ª	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11673	MARIANA LIMA CONSTANTINO	1	1994	11	30	F	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11309	Raquel Pereira Rios	1	1994	11	7	F	511	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11494	Tiago Santos Bernardes	2	1992	11	9	M	313	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11246	Maiara Aparecida Souza	1	1994	5	29	F	504	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11312	Guilherme A. A. Lazzarini	1	1994	2	22	M	511	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11135	Amanda Pinheiro Baptista	1	1995	3	6	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11455	RODRIGO LUIZ	1	1994	1	7	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11381	Wesley Salvador Ribeiro	1	1993	10	27	M	313	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11454	TIAGO MARMO	1	1994	5	21	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11457	SHARON S. CARVALHO	1	1993	12	4	F	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11273	Rodrigo Silva de Almeida	1	1994	5	24	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11275	Raul Vitor Moreira	1	1994	8	12	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11261	Rafaela Souza 	1	1994	2	25	F	504	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11452	REBECA CORREALI	1	1993	12	28	F	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11453	RAFAELA MONTESI	1	1993	10	21	F	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11451	RAFAEL MORAES	1	1993	11	20	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11137	Pedro Henrique V. Marques	1	1995	3	24	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11144	Marina Cristina F. dos Santos	1	1995	4	19	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11240	Mariane Stephaine Silvério Alves	1	1994	1	9	F	504	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11674	MARCELO PAES DE IFGUEIREDO	1	1994	10	30	M	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11300	Luiz Guilherme Leandrini	1	1994	12	8	M	511	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11536	Lucas Eduardo Lins Barbosa	1	1995	2	10	M	350	5ª B (Esc. Amor Divino )	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11317	Leonardo Lima Gomes	1	1994	3	8	M	511	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11445	LUCAS CHAVES	1	1994	2	20	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11249	Itauã Del Rio Albernaz Lemes	1	1993	11	12	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11462	ISABELA MENEZES	1	1995	3	17	F	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11265	HELMITON REBOUCAS DE AZEVEDO JUNIOR	1	1995	8	28	M	196	5ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11244	Guilherme Augusto dos Santos	1	1994	4	4	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11449	GUILHERME BERGER BRASIL	1	1993	11	19	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11280	Felipe Henrique de Oliveira	1	1994	6	25	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11441	FERNANDO S. CARANORA	1	1993	6	18	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11464	FERNANDO GODOY	1	1995	7	31	M	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11463	FERNANDA BISCARO A. 	1	1995	3	1	F	159	5	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11139	Erick Solera Santos	1	1994	12	8	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11460	DANILO V. VALVERDE	1	1994	7	3	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11133	Cesar Nobuo M. Ishiuchi	1	1995	9	6	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11142	Caroline Cintra Bertolini	1	1994	9	2	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11458	BEATRIZ CAMARGO SILVA	1	1994	1	8	F	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11143	Atina Barbis	1	1994	12	1	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11254	Antonio Carlos Lopes Ribeiro	1	1994	6	13	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11272	Allan da Silva Carvalho	1	1994	5	16	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11313	Roberson Filipe Lemes Nascimento	2	1992	5	19	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11470	PAULA MENDONÇA SENRA	2	1993	7	1	F	159	7	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11474	PATRÍCIA TEIZEN PRADO	2	1192	9	31	F	159	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11502	Mauro César Da Silva	2	92	3	28	M	313	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11248	MATEUS SILVEIRA DE LEMOS	2	1991	12	4	M	196	8ª Série - Gama	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11531	Laís Mendes Gomes de Souza	2	1993	6	29	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11501	Laura Caroline De Souza	2	1992	6	8	F	313	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11297	Jéssica Martins Morais	2	1993	3	2	F	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11736	Juliano Amodeo Boese	2	1992	9	8	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11471	JOÃO PAULO STEFANO LEITE	2	1992	3	4	M	159	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11307	Herbert Alisson Nogueira	2	1993	9	23	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11310	Felipe Deodato dos Santos Souza	2	1992	8	16	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11126	Douglas Henrique Tripoloni	2	1993	5	20	M	313	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11128	Diego Bevilacqua de Almeida	2	1993	7	9	M	313	7ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11735	Bárbara Chaves de Alencar	2	1992	6	10	F	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11496	Ana Carolina R. S. Valente	2	1993	7	7	F	313	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11737	Alessandra Da S. Santiago	2	1993	1	7	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11459	YASMIN P. EL ABIACI	1	1994	4	11	F	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11525	Welber Henrique de Camargo	4	1989	6	12	M	472	Terceira	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11374	Leon Lucas Prestes Ribeiro	4	1988	1	9	M	14	1o. semestre EC	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11377	Diego Henrique Sampaio de Souza	4	1988	1	12	M	493	Curso Médio concluído	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11376	David Edenir de Brito Marcon	4	1989	1	31	M	14	1o. semestre EC	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11375	Willian Roger de Menezes	4	1988	1	25	M	14	1o. semestre EC	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11971	MATEUS YUNG ALIAGA	1	1995	4	16	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11869	Lais de Souza Campos	1	1994	1	1	F	313	5ªE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11875	LIA LOPES BENEVIDES	1	1995	8	25	F	196	5ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11972	KARINA APARECIDA RODRIGUES DE SOUZA	1	1994	11	26	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11974	KAREN APARECIDA RODRIGUES DE  SOUZA	1	1994	11	26	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12150	Júlia Carla Castro Silva	1	1993	10	6	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11969	JOSÉ SANTIAGO JUNIOR	1	1995	1	19	M	355	5 ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12255	JENIFFER KIM	1	1995	7	10	F	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12143	GABRIEL GHERARDI LEX RODRIGUES	1	1995	7	4	M	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12142	GABRIEL FRANÇA	1	1994	8	23	M	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12141	GABRIEL BATISTA LIMA	1	1995	6	27	M	465	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11867	FRANCISCO MUTARELLI	1	1995	9	21	M	487	5 EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11864	FERNANDA FERREIRA BARRETO	1	1994	12	5	F	487	5 EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11976	BRENDA CRISTINA DA SILVA	1	1995	7	30	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12147	André Luiz Carvalhaes	1	1995	3	15	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11876	ARTHUR ARAUJO PORTO	1	1995	10	18	M	196	5ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11861	AMANDA ROBATTOM LOVERBECK	1	1995	9	16	F	487	5 EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11970	AMANDA ADÉLIA CAIUT CALVETTE	1	1995	10	14	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12138	Victor Lage Pessoa	2	1991	9	2	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11886	STEFANI SARAIVA RODRIGUES	2	1993	8	22	F	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11740	Renato Aparecido Silva	2	1990	8	15	M	313	7ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11742	Rafael Da Cruz Fonseca	2	1992	11	19	M	313	7ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12132	Milena Maria Farias de Martins Oliveira	2	1993	4	13	F	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12136	Liana Leal Lima	2	1991	10	31	F	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11743	Jéssica Maria Fernandes	2	1992	1	2	F	313	8°B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11739	Flávia Aparecida Dos Santos Oliveira	2	1992	10	4	F	313	7ªD	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12216	TYANE DE ALMEIDA PINTO	3	1990	11	12	F	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12217	RODRIGO COSTA PEREIRA	3	1990	9	28	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12224	RAYSON GAMA BRANDÃO	3	1991	8	9	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12308	Leonardo L`Abbate Barrea	3	1991	1	30	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12218	LUHANA NYEVIES MARTINS SOARES	3	1991	2	19	F	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12232	LAION  XAVIER  NOGEIRA	3	1990	3	10	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12233	JÔNATAS DA SILVA SANTOS	3	1991	10	14	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12219	JORDAN DE SOUZA ARAÚJO	3	1992	9	9	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12225	JEFFERSON GABRIEL DE SOUZA ALBUQUERQUE	3	1990	5	25	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12212	GUSTAVO PICANÇO CONSENTINI	3	1990	12	21	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12227	GUILHERME DE BRITO CARNEIRO	3	1989	8	14	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12228	GLADSON GALDINO DA SILVA	3	1990	2	3	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12229	GERALDO FREITAS BARBOSA FILHO	3	1992	7	31	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12226	GABRIEL  WUGHAN SILVA	3	1991	11	3	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12014	CARLA CAROLINA DA SILVA BRITO	3	1991	7	30	F	6	1.ª EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12214	ALEXANDRE RAMON MOURA DIAS	3	1990	8	25	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11860	NICHOLAS MOREIRA HOLANDA	1	1995	11	6	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12236	XISTO PEREIRA DE SOUZA JÚNIOR	4	1990	8	2	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	1	90	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12222	ÉRICO RODRIGO FARIAS PINHEIRO	3	1990	11	9	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11803	Tássio Naia dos Santos	4	1988	8	17	M	13	Engenharia - Poli	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11962	Tulio Deined da Silva	4	1987	11	22	M	496	3ºEnsino Médio 2005	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11943	Tiago dos Santos Oliveira	4	1989	4	23	M	496	3ºEnsino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11964	Thiago Adonis de Almeida Omura	4	1988	9	23	M	473	3 série do ensino médio 	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12139	Rodrigo Olegário Catanha	4	1987	12	19	M	59	1a Superior	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11933	Ranieri M. Santos	4	1989	3	5	M	496	3º Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11937	Pedro Henrique Gimenez Ramos	4	1988	9	15	M	496	3ºEnsino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11807	Marcia Tiemi Saito	4	1988	1	1	F	13	Bach em Física diurno	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12170	Iara Ananias Silva	4	1992	11	11	F	313	7ªB	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11954	Helena Aparecida C. Soares	4	1990	4	25	M	496	3ºEnsino Médio 	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12140	Guilherme Silva Leonel Dias	4	1988	4	21	M	59	1a Superior	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11926	Eduardo Gutierres Ruiz	4	1988	1	5	M	496	3º Ensino Médio 2005	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11923	Davi Francisco dos Santos	4	1989	5	1	M	496	3ºEnsino Médiol	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11925	Danielle Barbosa Anastácio	4	1988	4	21	F	496	3º Ensino Médio 2005	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11939	Caio de Oliveira Santos	4	1988	6	23	M	496	3ºEnsino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11963	Bruno Daniel Rodrigues Camara	4	1987	6	23	M	490	1º período de Engenharia da Computação	\N	\N	\N	42	\N	\N	1	245	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12425	VANESSA BARBOSA	1	1993	12	27	F	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12419	Tiago Lemos Prince	1	1995	2	24	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12479	Thomaz Octávio Mendonça Cordeiro	1	1993	12	16	M	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12473	Thales Terra Liberto	1	1995	8	15	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12471	Stéfani de Souza Silva	1	1994	12	23	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12357	Santiago Gabriel C. Kovalenko	1	1995	7	20	M	318	5ª Série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12477	Rafael Henrique de Siqueira	1	1992	11	17	M	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12199	Rafael Batista Corrêa	1	1995	5	17	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12291	ROBERTO PEREIRA ALVES FILHO	1	1995	11	7	M	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12476	Naiara Zenaide Marcolino	1	1993	10	21	F	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12464	Mariana de Almeida Valderramos	1	1995	6	29	F	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12462	Maique Dionísio	1	1992	10	23	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12423	MONICA EDILAINE VAZ 	1	1994	4	25	F	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12478	Luiz Carlos Ruzzi Júnior	1	1995	5	26	M	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12424	Larissa Carolina Santos	1	1993	10	15	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12359	Gustavo Teixeira de Souza	1	1995	4	27	M	318	5ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12469	Gustavo Pellozo de Oliveira	1	1995	3	30	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12208	Gustavo Henrique Lima de Araújo	1	1995	2	2	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12470	Deividson Prudêncio Trajano	1	1992	8	6	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12429	Daniela Cruvinel da Silva	1	1995	3	3	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12475	Bianca de Oliveira	1	1995	2	15	F	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12200	Ana Carolina Tatiana de Souza	1	1994	10	5	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12426	Aline Cristina Amaral Silva	1	1995	5	23	F	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12288	ZHENG JIANPING	2	1992	2	29	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12192	André Augusto Martins	2	1993	2	17	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12929	Thaiane do Amaral Catalano Furtado	2	1991	9	29	F	90	8	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12916	Joana de Lima Moraes	2	1992	5	16	F	90	8	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12918	Raisa Cristina Silveira da Silva	2	1992	12	18	F	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12282	GUILHERME KIYODI FUZATTO	2	1993	1	20	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12893	Thiago Azevedo Ferreira de Souza	2	1991	9	13	M	90	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12304	PEDRO HENRIQUE G. CALVO	2	1992	4	30	M	487	8ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12922	Paula Jannuzzi Cidade	2	1991	12	20	F	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12930	Layla de Medeiros Chedid	2	1992	7	25	F	90	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12932	Rafaela Luzie	2	1992	2	22	F	90	8	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12306	RENATO EIJI RIBEIRO KAVAGUTI	2	1992	7	5	M	487	8ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12923	Vanessa Fernandes da Silva Jorge	2	1992	8	6	F	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12917	Pedro Monte Mor Faria	2	1992	4	23	F	90	8	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12187	Marcos Marques Martins	2	1992	5	23	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12283	MATHEUS SARAIVA LEÃO ANDRADE	2	1993	5	22	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12460	MARCOS VINICIUS LUIZ DE MELLO 	2	1991	5	21	M	355	7ª SÉRIE A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12921	Lucas Silva Moncores	2	1992	8	27	M	90	8	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12296	GUILHERME HASHIZUME DA LUZ	2	1991	9	6	M	487	8ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12181	Felykson Vinícius Da Silva	2	1993	3	9	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12928	Felipe Zarro Lopes da Cunha	2	1991	12	16	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12920	Debora Costa da Silva	2	1992	2	27	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12896	Daniela Xavier de Andrade	2	1992	5	9	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12907	Antonio Alexandre Fernandes de Campos	2	1991	8	31	M	90	8	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12317	Ricardo Juvenal Lima	3	1991	2	28	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12316	Rafael Sant Ana de Carvalho	3	1990	7	16	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12312	Luiza Pellin Biasoto	3	1991	4	24	F	487	1ª EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12314	Eduardo Shigueo Tomikawa	3	1991	6	18	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12313	Davi Kooji Uezono	3	1991	4	26	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12427	VICTOR JOSE ROMAO	1	1993	4	2	M	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12320	Guilherme R N de Souza	4	1989	10	12	M	487	3ª EM	\N	\N	\N	31	\N	\N	1	330	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12618	VITÓRIA ALENCAR DE SOUZA	4	1990	4	21	F	6	2.ª EM	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12385	LEONARDO SAMESHITA TABA	4	1989	10	13	M	23	3C	\N	\N	\N	42	\N	\N	1	170	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12719	Allan Gustavo Amorim Alves	4	1988	4	28	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12624	Túlio Santiago Duarte	4	1988	6	20	M	303	terceiro ano concluido	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12365	TADEU BICARATO SANTANA JUNIOR	4	1988	5	31	M	23	3A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12328	RICARDO SEARA NETO	4	1990	3	19	M	487	2ª EM	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12323	ARTUR DE ALMEIDA LOSNAK	4	1989	11	8	M	487	2ª EM	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12371	ALLINY CAROLINA DIONETE LIMA	4	1987	3	16	F	23	3C	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12322	ALEXANDRE VENTURI	4	1990	2	1	M	487	2ª EM	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12311	Vitor Mori	3	1991	5	25	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12980	Thais Junqueira Pereira Camargo	1	1994	3	24	F	541	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13065	TANIA ARRAIS DE CAMPOS	1	1993	11	13	F	309	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13055	TALITA VICENTIN	1	1994	10	4	F	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13160	SOFIA MAGALHAES CUNHA	1	1997	5	15	F	196	6ª Série - Master	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13209	PAULO ROBERTO DELL ANHOL	1	1994	4	24	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13063	MARINA COZAR ZÓLIO	1	1994	8	24	F	309	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13241	MARIANA FERREIRA MACEDO	1	1996	12	23	F	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13061	LÚCIA RODANTE CORSI PETTAN	1	1994	2	20	F	309	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13242	LUIZ HENRIQUE SOARES ALVES	1	1996	1	9	M	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13060	LUCAS YOSHIO TAKAHASHI	1	1994	4	25	M	309	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12981	Julia Bellintani de Freitas	1	1994	5	27	F	541	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13057	JOÃO PEDRO BONVECHIO SANT´ANNA	1	1994	4	5	M	309	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13207	JONATHAN MIRANDA MASCARENHAS DE OLIVEIRA	1	1994	7	23	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13205	JAQUELINE RODRIGUES DE LIMA	1	1994	3	23	F	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13225	Gustavo Piccolli Faria e Souza	1	1992	7	19	M	59	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12984	Giancarlo Zaccaria	1	1994	4	2	M	541	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13204	GUSTAVO KAZUO WARICODA	1	1994	2	28	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13047	GUILHERME MARCHETTI FURTADO	1	1995	6	29	M	309	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13127	DAVID GIFFONI NOBREGA	1	1994	6	27	M	196	6ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12978	Bruna Leticia Crispim	1	1995	10	20	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13245	BRUNO MACULAN	1	1996	9	10	M	59	4ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13134	AIRTON CESAR PINHEIRO DE MENEZES	1	1996	1	18	M	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12933	Vivian dos Santos Salles	2	1992	11	6	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13085	THAÍS SOUZA DE ANDRADE	2	1992	12	3	F	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12934	Rayssa Drumond de Barro Alcantara	2	1992	7	6	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13083	RENATO BERTANHA IZEPOM	2	1992	10	19	M	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13062	Matheus Modotte da Silva	2	1991	10	22	M	566	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13094	MATEUS RAVANINI DA ROZ	2	1991	9	18	M	309	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13082	MARINA BOVARETTO TESSARI	2	1993	4	15	F	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13002	João Vitor Ducatti	2	1992	10	21	M	541	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13167	JOAO PAULO BENEVIDES SOARES	2	1991	11	27	M	196	8ª Série - Delta	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13162	ICARO ANGELO MILLEN FIGUEIREDO	2	1993	4	24	M	196	7ª Série - Gama	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13226	Emanuelle dos Santos Widal Garcia	2	1993	7	26	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13165	DIEGO RAMON DE SOUSA	2	1992	7	1	M	196	8ª Série - Delta	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13077	BRENO ROCHA COMIN	2	1993	6	22	M	309	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13103	LUAN LEON DELLA LIBERA	3	1990	8	10	M	309	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13101	JÚLIA RODANTE CORSI PETTAN	3	1991	3	2	F	309	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13099	GUILHERME LEMOS DE OLIVEIRA MARQUES	3	1991	2	20	M	309	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13121	BRUNO MENEGHIN ZANIBONI	3	1991	7	31	M	309	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13269	JÉSSICA FERREIRA M. SILVERIO	1	1994	5	11	F	59	6a	\N	\N	\N	92	\N	\N	1	\N	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13027	WASHINGTON MOISÉS RODRIGUES	4	1989	8	15	M	23	2D	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13106	MARÍLIA MATTOS ANTUNES	3	1991	6	17	F	309	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11723	EDVAN RODRIGUES SANTOS	4	1988	5	10	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13224	Sander Lemos Mizael 	4	1988	5	25	M	59	1a Superior	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12986	SILLAS REINATO FERRÃO	4	1990	7	9	M	23	2A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12990	ROMULO MARTINS CARVALHO	4	1990	4	5	M	23	2A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13030	RODRIGO DE LIMA ALENCAR	4	1989	2	4	M	23	2D	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13311	ROBSON DA ROCHA SILVA	4	1982	1	6	M	560	7ºsem-Adm.Habilitação ANALISE SISTEMAS	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13078	Nestário Luiz de Oliveira Santos	4	1988	11	3	M	566	3ª série Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13309	Murilo Silva Guollo	4	1989	5	9	M	83	5ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13221	Murilo Garcia Bento	4	1988	4	1	M	83	Estágio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7898	Marcus Vinicius Ferraz	4	1978	1	15	M	355	3º E	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12310	Thiago da Silva Pinheiro	3	1990	10	15	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12992	MICHELLE RODRIGUES NASTASI	4	1989	5	4	F	23	2A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13282	Jamile Jaruche	4	1987	6	12	F	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12991	JOSÉ ORLANDO RUBIO JUNIOR	4	1990	2	24	M	23	2A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12988	JOSÉ MARCOS SCALÃO MARTINS	4	1990	3	1	M	23	2A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11703	JACKSON CARLOS MENEZES PESTANA	4	1987	11	15	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13095	Heleno Emanoel Pereira da Silva	4	1989	3	16	M	566	3ª série Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12982	HENRIQUE DE ALMEIDA OLIVEIRA	4	1990	9	22	M	23	2A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12985	FELIPE OLIVEIRA CAMPOS	4	1990	2	6	M	23	2A	\N	\N	\N	42	\N	\N	\N	75	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13133	Carlos Sprietti Moda	4	1987	8	12	M	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12993	BRUNO DA CRUZ BUENO	4	1989	12	10	M	23	2A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12939	Amanda Peres dos Santos	4	1987	7	11	F	90	3 ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13123	Aline Fátima Manera	4	1988	7	28	F	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12998	ANDRÉ MELO RIOS	4	1989	9	28	M	23	2B	\N	\N	\N	42	\N	\N	1	150	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13625	Rafaelle Paiva Rocha Veras	1	1994	12	13	F	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13731	Pedro Medeiros Montenegro	1	6	3	24	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13370	Mayara Schaeffer	1	1995	7	12	F	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13725	Manoela Barreto de Meneses	1	1995	6	23	F	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13367	Lucas Santana Sobreira	1	1995	4	12	M	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13611	Lia Macedo de Freitas Melo	1	1994	10	19	F	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13369	Jade Roberta Moreira Monteiro da Silva	1	1995	3	14	F	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13368	Filipy Erick da Silva	1	1995	1	9	M	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13366	Daniele Gomes de Mello	1	1994	11	22	F	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13642	William Moura Mesquita	2	1991	9	4	M	367	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13618	Gessica Cordova França	2	1991	5	28	F	462	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13765	Felipe Araújo Silva	2	1991	9	11	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13380	MARIANA HOLANDA ARCANJO	2	1992	4	29	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13391	CAMILA BRAGA MAIA	2	1991	8	12	F	527	8ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13383	RAISSA FREIRE DE ALMEIDA	2	1992	5	25	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13749	Igor Amorim do Nascimento	2	92	7	5	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13740	Milena Fonseca Marinho da Costa	2	91	11	23	F	90	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13757	Felipe Reis Torres	2	92	1	15	F	90	8	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13759	Vinicius Pereira Maia	2	92	8	5	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13387	VIVIAN RIBEIRO CARVALHO	2	1991	11	5	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13766	Thiago Ribeiro Chagas	2	92	3	25	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13761	Thamyres Geanine Dias do Nascimento	2	92	6	1	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13743	Taiane Caroline Jesus de Araujo	2	91	5	5	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13385	SAULO TEXEIRA PINHEIRO	2	1992	4	1	M	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13739	Rafaela Soares Vieira	2	92	9	9	F	90	8	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13620	Pedro Vale Bedê	2	1993	4	2	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13767	Pamela Caroline Forte Gadelha	2	1993	1	24	F	516	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13755	Nathalia Ferreira Lazaroni	2	91	8	19	F	90	8	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13746	Jessica Veloso Martins	2	90	12	28	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13745	Jessica Fernandes da Rocha	2	91	4	30	F	90	8	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13377	IGOR ELEUTÉRIO PINHEIRO	2	1992	2	21	M	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13468	Gustavo da Silva Delfino	2	1992	5	12	M	504	8ª série	\N	\N	\N	173	\N	\N	1	20	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13762	George Correa de Jesus	2	91	10	16	M	90	8	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13375	EDSON GUSTAVO SANTIAGO SILVA	2	1992	8	16	M	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13622	Diego Rapp de Melo e Silva	2	1993	4	27	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13752	Camila Soares Silvestre Toledo	2	92	5	18	F	90	8	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13748	BRUNO RÜDORFF BRINATI	2	1991	10	10	M	571	1-8MA2	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13372	ANA GABRIELA BRAGA GONÇALVES	2	1992	1	9	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13389	ANA CAROLINA DE CASTRO SILVA MENDES	2	1992	7	9	F	527	8ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13388	AMANDA TABOSA DOS SANTOS OLIVEIRA	2	1992	9	29	F	527	8ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13847	Paulo Sérgio Moreira dos Santos Dias	3	1988	7	31	M	515	3ª série	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13557	LAIZ REGINA DE PAULA	3	1987	2	10	F	355	1º F	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13850	Diego Rodolfo dos Santos	3	1990	2	23	M	515	2ª série	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13626	Thaynara Santa Cruz Lima	1	1995	10	16	F	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13789	Antonio Carlos Maciel	4	1987	9	23	M	472	terceira	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13778	Hebert Trancoso de Carvalho Vianna	4	89	3	9	M	90	3 ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13656	Thiago Shimizu	4	1990	1	31	M	462	2º ano - Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13458	Carlos Augusto Andrade e Souza	4	1986	3	15	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13502	Vinicius Correa Dias	4	1988	3	22	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13774	Victor Augusto Monteiro Lourenço	4	89	7	8	M	90	3 ano	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13452	Tiago Antonio Amorim	4	1988	8	11	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	10	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13464	Rafael Ferreira Pacheco	4	1988	5	7	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13503	Nayara Nogueira	4	1988	6	7	F	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13742	Lilian Barbosa Santos	4	1989	9	21	F	516	2º ano 	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13736	João Vitor de Souza	4	1988	10	8	M	239	2º Semestre	\N	\N	\N	42	\N	\N	1	85	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13455	Flavia Goncalves Caixeta	4	1988	2	29	F	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13734	Douglas Renato Ferraz Beilfus	4	1988	5	18	M	239	2º semestre	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13460	Diego Andrade Andalecio	4	1988	10	1	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13546	Danilo Fernandes Mesquita	4	1988	2	10	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13454	Danieli Ferreira Silva	4	1988	4	7	F	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13462	Daniela Maximo	4	1988	2	28	F	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	10	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13737	Antonio Silveira Antunes	4	1988	5	31	M	239	2º Semestre	\N	\N	\N	42	\N	\N	1	210	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13560	VALTER JOSÉ DE OLIVEIRA	3	1988	2	14	M	355	1º F	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13461	Zama Bandeira Braga	4	1987	3	28	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13830	Nina Bianca Alves Vital	1	1994	7	10	F	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13893	Luisa Nakayama Madeira	1	1993	8	18	F	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13888	Leonardo Camara Ribeiro	1	1993	11	10	M	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13826	Icaro Silva Morais	1	1995	2	7	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13878	Armando Mendonça Rocha Barreira	1	1994	4	23	M	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14158	Allan Germano Reis	1	1992	10	9	M	568	7ª série E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13968	Vitor Eduardo Laureano Dalle Piagge	2	1993	8	16	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13940	Maiony Regis Benjamin Silva	2	1993	7	14	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13963	Vanessa Almeida Albuquerque	2	1992	9	8	F	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13959	Tais Fialho Pimentel	2	1992	5	3	F	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13957	Suellen Sarlo Sousa	2	1992	12	3	F	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13955	Raul Carneiro Moura	2	1992	12	7	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13951	Rafaelle Vilar Nunes Melo	2	1993	1	8	F	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13950	Rafael Mariscal Gonçalves de Souza	2	1993	8	22	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13832	Pedro Lucas Fahd de Oliveira	2	1991	11	29	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1689	Marina Lewinski	2	1991	9	4	F	153	8ª série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13647	Lícia Dias	2	1992	12	2	F	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13936	Juliana Albuquerque Lopes	2	1992	8	4	F	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13835	Italo Morse de Sousa	2	1992	7	16	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13837	Gustavo Araújo Rangel	2	1992	1	3	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13931	Guilherme Leiria de Holanda Peres	2	1992	8	23	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13928	Gabriel Ratz de Queiroz	2	1993	9	24	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13840	Gabriel Bertemes de Carvalho	2	1993	2	19	M	216	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13844	Francisco de Andrade Barroso Neto	2	1992	6	22	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13851	Danilo Pimentel	2	1991	9	1	M	216	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13919	Caio Graco Farias da Escossia	2	1993	5	18	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13845	Caio Gobbo	2	1992	9	16	M	216	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13967	Bruna Íris Dias Rocha Vasconcelos	2	1993	7	2	F	544	7a série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13917	Andre Vitor Alves Tavares	2	1993	8	5	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13852	Ana Beatriz R. Garcia	2	1992	3	24	F	216	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13841	Aline de Almeida Camargo	2	1993	1	25	F	216	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13863	Valdecy A.A.Júnior	3	1990	11	30	M	515	1º colegial	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13864	Rafael Nunes da Costa	3	1990	7	22	M	515	2º colegial	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14161	NAYANA HOLANDA DE ABREU	3	1990	12	5	F	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13854	Michel Diniz Veloso	3	1989	4	1	M	515	2º colegial	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13861	Jonas da Silva	3	1988	9	20	M	515	2º colegial	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13859	Jamile Rodrigues Franco	3	1989	2	1	F	515	3º colegial	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14159	DIEGO FREITAS DE ALMEIDA	3	1991	6	17	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13983	César Portugal Prado Martins	3	1990	11	20	M	516	1º ano	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13862	Charles Maia Nogueira	3	1990	5	15	M	515	2º colegial	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13976	Bruno Matos Paz	3	1990	8	26	M	516	1º ano	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14006	Antonio Edvan Camêlo Filho	3	1990	12	17	M	516	1º ano	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13904	Paula Monteiro Alencar	1	1994	4	6	F	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14166	Régis Prado Barbosa	4	1990	5	6	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13925	Elvis Müller Feksa	4	1990	1	11	M	288	2° ano ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14162	Renan Mendes Soares	4	1989	9	22	M	516	3º ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14003	Nicolas Fontenele Frota	4	1989	12	2	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13945	Misael Alexandre Becker	4	1988	7	4	M	288	2° ano ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13948	Mateus Fagundes	4	1988	7	4	M	288	2° ano ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14046	Lucas Lopes Saldanha	4	1990	5	29	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14040	Luana Batista Cardoso	4	1982	4	13	F	543	3a do médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14039	Luan Alison Cardoso de Carvalho	4	1989	2	20	M	543	3a do médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14038	João Gabriel Macedo Alves	4	1986	5	4	M	543	3a do médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13686	Hanner Mahmud Karim	4	1990	1	6	M	462	2º ano - Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13954	Gustavo Bortocaso Cechinel	4	1987	9	13	M	288	2° ano ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14165	Fábio Camelo Mourão	4	1990	9	14	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13898	Felipe Cancian Bertozzo	4	1988	6	10	M	372	1o - BCC	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13865	Carlos Eduardo Shiniti Saito	4	1987	3	26	M	372	1o - BCC	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13966	Alexsandro Diniz da Costa	4	1988	8	29	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10984	Mike Nicanor da Silva	1	1993	7	27	M	313	6ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14323	MAYARA CAROLINA ANDRADE ROSA	1	1994	3	12	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14326	LUIZ FILIPE AP. BORBA	1	1994	6	5	M	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14340	LORRANA ALVES FÍDELIS	1	1994	6	5	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14331	JOÃO CARLOS QUIRINO DA SILVA	1	1993	7	4	M	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14278	GUSTAVO COSTA BELMIRO	1	1995	1	24	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14322	CAMILA DOS REIS ALVES	1	1994	12	3	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14324	BRUNA LUISA DA SILVA	1	1994	10	6	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13970	Wellington Rocha Leitao Neto	2	1992	6	29	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14293	WILKER HUMBERTO PEREIRA	2	1993	8	10	M	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14085	Victor Prisco	2	1993	4	6	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14069	Vanessa Pinheiro Alencar	2	1991	10	30	F	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14067	Thais Fontes de Magalhaes	2	1992	5	22	F	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14298	TAYRINE REGINA RODRIGUES DOS SANTOS	2	1993	8	24	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14066	Rodrigo Ito	2	1992	5	24	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14064	Roani Simoes Veras	2	1992	5	12	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14086	Renan Abreu	2	1992	12	22	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14220	Raphael Abe	2	1992	5	19	M	293	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14087	Rafael Sampaio	2	1992	10	8	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14061	Pedro Henrique de Souza Marques	2	1992	5	12	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14088	Pedro Gregory	2	1994	1	11	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14288	PAULO HENRIQUE VARGAS	2	1993	12	2	M	5	7o C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14060	Munique Sales Mendes	2	1992	5	15	F	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14059	Mauricio Carvalho Barbosa	2	1991	7	12	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14026	Marina Aguiar da Costa	2	1993	2	23	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14140	Marcus Cavalcante Coelho	2	1993	7	27	M	516	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14299	MATHEUS PAIVA MARTINS	2	1992	4	29	M	5	8o A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14058	Luiz Antonio Melo Marques	2	1992	5	3	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14022	Lucas Saboya Amora	2	1992	8	3	M	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14091	José Unilson	2	1993	3	29	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14142	Joana Paula Pereira Meireles	2	1992	12	25	F	516	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14052	Gustavo Rebelo de Campos	2	1992	7	5	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14100	Guilherme Paiva Pinto	2	1993	3	13	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14108	Guilherme Akira	2	1992	12	13	M	516	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14049	Gabriela Casimiro Linhares	2	1992	1	8	F	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13975	Gabriel Straube	2	1993	16	18	M	544	7a série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14096	Francisco Homero Botelho	2	1993	4	20	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14045	Caio Ito	2	1992	5	24	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14286	BRUNO MOSELLI	2	1992	7	7	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14082	Andrezza Torres	2	1992	11	23	F	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14000	Anamim Dantas Ribeiro	2	1993	11	6	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14041	Adriano Cesar Frota de Holanda Neto	2	1991	9	9	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14264	KIANY FRANCIELE VAZ	3	1994	11	22	F	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14259	DIEGO SILVA MARQUES	3	1990	11	24	M	5	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14265	JÊNNET CHAYENE MARTINS	3	1994	5	26	F	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14272	JULIANO LUIS BOAVENTURA	3	1993	7	9	F	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14271	JULIANO LUIS BOAVENTURA	3	1993	7	9	F	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14269	JAQUELINE DA SILVA G.	3	1994	11	1	F	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14275	BRUNO DE SOUZA DA MOTA	3	1993	9	28	M	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14274	BRUNO DE SOUZA DA MOTA	3	1993	9	28	M	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14262	BIANCA CAROLINE B.	3	1994	12	18	M	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14267	ANA CECÍLIA ROBERTA SANTOS	3	1994	8	4	F	5	6ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14311	Matheus Baldini Cardoso 	1	1994	5	23	M	59	6a	\N	\N	\N	155	\N	\N	1	\N	0	7	116	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14318	Thiago Rafael Vicente	4	1989	7	17	M	110	3º ano do ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14316	Thiago Kupas	4	1989	10	10	M	110	3º ano do ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14013	Sérgio Ricardo Furtado	4	1990	2	9	M	516	2º ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14319	Renan Wilhem Lescowicz	4	1989	5	9	M	110	3º ano do ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14075	Raphael Vinícius Silveira Martignoni	4	1986	7	22	M	372	1o - BCC	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14321	Lucas Kohl	4	1989	9	8	M	110	3º ano do ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14317	James Richard Ohlweiler	4	1989	5	10	M	110	3º ano do ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14315	Daniel Maiochi	4	1989	10	13	M	110	3º ano do ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14258	SAMUEL EURÍPEDES SILVA	3	1989	12	2	M	5	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14043	Lucas Helano Rocha Magalhães	3	1991	3	14	M	516	1º ano	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14074	Yasmin M. Breda	4	1987	5	22	F	543	3a do médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14715	Taís S. Mendes	1	1992	8	30	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14371	PEDRO MORAIS BARBOSA	1	1997	12	22	M	196	6ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14809	PAULA VIEGAS GRECO DE OLIVEIRA	1	1993	8	4	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14609	Murillo Chiaradia Rosa	1	1995	5	1	M	545	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14726	Mesaque Rodrigues Manuel	1	1993	8	29	M	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14718	Matheus A. Alves	1	1993	6	14	M	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14364	Luiz Roncoletta Montoro Peres	1	1994	1	18	M	517	sexta	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14492	Luiz Arthur Brasil Gadelha Farias	1	1993	11	11	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14630	Ligia Gonçalves Otero	1	1994	1	27	F	482	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14720	Lais Ramos de Castro	1	1993	7	4	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14624	KATIELE SILVA CORDEIRO	1	1993	7	18	F	171	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14723	Jenifer C. Carvalho	1	1992	5	13	F	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14620	JESSICA DA SILVA AMORIM	1	1994	9	4	F	171	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14622	GABRIEL HENRIQUE SILVA DE SANTANA CALDAS	1	1994	9	20	M	171	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14627	FLAVIA SANTOS DE QUEIROZ	1	1992	4	24	F	171	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14719	Emilly Cristina Coelho Pansani	1	1994	9	28	F	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14626	DAIANE CRISTINE DOS SANTOS FERREIRA	1	1992	1	2	F	171	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14578	Cristiana Maria S. do Nascimento	1	1994	10	5	F	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14716	Bruno Felipe dos Santos	1	1993	3	11	M	312	6ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14647	BRUNO LEITE DE ALMEIDA	1	1994	7	31	M	179	7º ANO	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14377	Willian Jung Kyu Na	2	1993	6	27	M	517	setima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14383	Stephany Tyemi Vigo Maruyama	2	1993	1	26	F	517	oitava	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14566	Marina vasconcelos Sampaio	2	1993	2	13	F	516	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14365	Luiz Henrique Goes Hamati Rosa	2	1992	10	15	M	517	setima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14366	Luiz Carlos Mayeiro Junior	2	1993	6	14	M	517	setima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14372	Leopoldo Zanellato Oliveira	2	1992	9	21	M	545	7a série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14812	LUANA FONSECA GARCIA 	2	1990	3	8	F	562	OITAVA 	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14770	Juliana Cristina Alonço	2	1992	11	11	F	312	6ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14526	HUGO DE QUEIROZ BORGES 	2	1993	9	1	M	196	7ª Série - Alfa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14762	Gustavo Antônio Pereira	2	1991	12	2	M	5	oitava série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14557	Diego Cavalcante de Abreu	2	1992	12	29	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14761	Bernardo Gomes Oliveira	2	1992	3	16	M	5	oitava série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14567	Antonio de Padua r. Cavalcanti	2	1993	2	25	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14652	Tamiris de Oliveira	3	1990	10	8	F	140	1º ano - Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14651	Joelma Luciane Garcia	3	1990	10	10	F	140	1º ano - Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14811	FERNANDA CÔRTES BORGES	3	1990	9	18	F	5	1o A	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14814	FABIANA CABRINE DA SILVA	3	1990	11	21	F	5	1o A	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14653	Eric Duarte Rocha	3	1991	5	21	M	140	1º ano - Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14547	Diego Neves Faria	3	1989	8	16	M	515	3º colegial	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14577	Victor Yuji Igarachi	1	1994	8	26	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14555	Alex Lucchesi de Oliveira	4	1984	6	19	M	283	3o Semestre de 5	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12784	Gabriel Vilela da Costa	4	1988	12	22	M	321	3ª Ens. Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14638	AFONSO FELIX  RODRIGUES	4	1998	12	12	M	533	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12803	Weverton da Silva Vertuli	4	1989	5	8	M	321	3ª Ens. Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14654	Tadeu Wohlers Gambaro Lima	4	1988	11	2	M	140	3º ano - Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12809	Raul Aguiar	4	1988	11	10	M	321	3ª Ens. Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14568	Rafael Nunes da Costa	4	1990	7	22	M	515	2º colegial	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14583	Paulo Sérgio Moreira dos Santos Dias	4	1988	7	31	M	515	concluinte 2005	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14813	PAULO ALVES DE SOUZA	4	1989	10	27	M	5	2o A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14440	Octavio Augusto Ribeiro	4	1988	10	6	M	321	3ª Ens. Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14581	Michel Diniz Veloso	4	1989	4	1	M	515	3º colegial	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14707	Luiz Carlos Cipriano Junior	4	1989	5	29	M	5	segunda série	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14637	LEONARDO L'BBATE LARUCCIA	4	1989	6	10	M	533	2º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14572	Jonas da Silva	4	1988	9	20	M	515	2º colegial	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14634	Guilherme Carvalho Januário	4	87	9	22	M	13	Engenharia - Poli	\N	\N	\N	42	\N	\N	\N	10	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14632	Filipe Louly Quinan Junqueira	4	1988	3	29	M	13	Engenharia - Poli	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14574	Diego Rodolfo dos Santos	4	1990	2	23	M	515	2º colegial	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14582	Diego Neves Faria	4	1989	8	16	M	515	3º colegial	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14815	DANIEL HIDEYUKI YAMAGUCHI	4	1989	2	10	M	5	3o A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14705	Cirineu Simião Lemos	4	1990	6	6	M	5	segunda série	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14571	Charles Maia Nogueira	4	1990	5	15	M	515	2º colegial	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14823	Anderson Tsai	4	1992	6	6	M	78	2EM	\N	\N	\N	42	\N	\N	1	335	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14554	Adriano de Brito Godinho	4	1988	12	14	M	283	3o Semestre de 5	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14635	ADRIANO PERICLES RODRIGUES	4	1989	10	1	M	533	2º ANO	\N	\N	\N	42	\N	\N	1	110	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15091	VITTÓRIA LA ROCCA TROMBETTI	1	1994	4	12	F	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15397	THAIS HERCULANO COSTA	1	1996	3	16	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15411	SARA MACIEL LIMA	1	1994	2	6	F	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15396	ROBERIO DA SILVA BATISTA FILHO	1	1994	3	9	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15410	RAISSA RIBEIRO DE QUEIROZ	1	1993	11	28	F	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15409	PAULO LIMA DA COSTA NETO	1	1994	2	7	M	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14849	Matheus Teotonio de Sousa	1	1994	4	19	M	367	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14848	Marília Freitas de Moura	1	1994	6	20	F	367	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15393	MATHEUS RIBEIRO CAVALCANTE	1	1994	12	9	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15408	LUIZA DO COUTO BOMFIM	1	1994	6	19	F	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15433	LUCAS DOS SANTOS RIBEIRO	1	1993	8	28	M	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15090	JOÃO L. MORAES BARROS	1	1994	6	10	M	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15619	ISABELA C. PIMENTA	1	1993	11	8	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15617	GABRIELA G. CARDOSO	1	1993	12	16	F	533	6ª S (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15618	FERNANDA M. LYRA	1	1994	1	3	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15425	FELIPE MAGALHÃES SOUSA	1	1994	10	19	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15431	FELIPE BEZERRA DE CASTRO OLIVEIRA	1	1993	11	21	M	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15403	CARLOS AMANCIO SUARTE LACERDA	1	1994	5	18	M	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14846	BEATRIZ MONTEIRO LIMA DE MORAES	1	1996	4	17	F	6	4.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15400	ANDRE LUIZ DE OLIVEIRA MENEZES	1	1994	2	2	M	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15398	ANA KAROLINA V. ROCHA	1	1994	7	11	F	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15089	ALEXANDRE DE BIASI CENACCHI	1	1994	7	22	M	11	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15423	ADRIAN RANSLEY FERREIRA PINTO JUNIOR	1	1995	11	17	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15422	VITOR AFONSO PEREIRA NUNES	2	1992	9	11	M	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14900	THIAGO CONTATO DE MENEZES	2	1993	1	10	M	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15421	THAIS LIA CASTRO LEITE	2	1993	11	15	F	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15098	STEPHANIE ABRAHÃO FERRARI	2	1992	11	22	F	11	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15420	MORENNA GOMES LEANDRO	2	1993	9	11	F	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14899	LUCAS GABRIEL ALVES FERREIRA	2	1993	10	18	M	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15440	LAILA DOS SANTOS LOPES	2	1992	5	28	F	555	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15417	KIMBERLY SOBRINHO DE SOUSA	2	1993	11	1	M	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14902	KENVER KRISTIAN LEANDRO	2	1991	9	19	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14901	JANE CAROLINE FERNANDES DE OLIVEIRA	2	1992	5	26	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14895	Giovanna Guerra Damico	2	1991	10	2	F	285	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14898	GERALDO PEREIRA NETO	2	1993	9	5	M	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15414	FABRICIO OLIVEIRA RAMOS GONDIM	2	1993	5	8	M	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15413	BARBARA RODRIGUES NOGUEIRA GEORGE	2	1994	4	14	F	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14904	ARTHUR LEONARDO B. DA SILVA	2	1993	4	1	M	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14679	Roberto Iuri Parente de Araújo	3	1991	7	8	M	367	1º	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14672	Ricardo Moraes Parolin	3	1991	12	22	M	517	primeiro ensino medio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14671	Raphael David François	3	1990	9	11	M	517	primeiro ensino medio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15190	Neimar Bitencourt Braga	3	1991	1	18	M	512	1ºMD	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15188	Lucas Viana de Oliveira	3	1992	3	10	M	512	1ºMB   	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14942	Janaina Eny Assis de Souza	3	1991	5	28	F	472	Primeira	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15189	Isaac Schmidt Ribeiro	3	1991	7	22	M	512	1ºMC	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15428	WESLEY PAULINO DE ANDRADE	1	1995	6	10	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14775	Érika Xavier Fidêncio	4	1986	10	17	F	379	2º Módulo Curso Técnico Instrumentação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14897	Samir Saraiva Silva	3	1991	3	4	M	555	1	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14772	Gilney Afonso Gonçalves	4	1986	12	21	M	379	2º Módulo Curso Técnico Instrumentação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14946	Luan Dias Caliman	4	1988	11	12	M	472	Terceira	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14862	ANTHONY YAO YAO JI 	4	1987	11	29	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	1	225	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14856	THIAGO MARQUES ESTEVES POVOA	4	1987	2	17	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14947	Raphael Gouvea de Melo	4	1989	5	15	M	472	terceira	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14877	PEDRO HENRIQUE GUEDES DE OLIVEIRA	4	1988	6	18	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14774	Lucas Domingues de Castro	4	1985	5	9	M	498	1a	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14820	Lucas Boeing Scardueli	4	1987	10	4	M	83	Estágio	\N	\N	\N	42	\N	\N	1	105	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14948	José Roberto de Souza	4	1989	2	15	M	472	Terceira	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14675	Gustavo Cavalcante de Vasconcelos	4	1990	1	5	M	367	2º	\N	\N	\N	42	\N	\N	1	140	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14760	Gilda Aparecida da Silva	4	1987	6	23	F	5	segundo ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14940	Gabriel Matheus Netto	4	1991	2	14	M	472	Primeira	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14670	Gabriel Cabral Anderson	4	1988	12	14	M	517	terceira ensino medio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14680	Francisco Dione dos Santos Lima	4	1990	3	14	M	367	2º	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14860	FABIO EIGI IMADA 	4	1988	2	7	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14859	BRUNO MASAYOSHI MATSUMOTO	4	1988	2	20	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14821	Alair João Tavarez	4	1986	11	19	M	83	Estágio	\N	\N	\N	42	\N	\N	\N	25	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11907	Guilherme Casanova Mingatto	1	1994	9	5	M	482	6ª série A	\N	\N	\N	68	\N	\N	1	10	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11909	Thalita dos Reis Ruba	1	1994	3	8	F	482	6ª série A	\N	\N	\N	106	\N	\N	1	11	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13566	Caroline Prochnow	1	1993	8	9	F	482	6ª série A	\N	\N	\N	138	\N	\N	1	13	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11922	Heitor Mendes Cardoso	1	1993	10	9	M	482	6ª série C	\N	\N	\N	163	\N	\N	1	10	0	5	83	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15798	kristhian T. Simoes	1	1991	2	26	M	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15782	Nathalia Oliveira Teixeira	1	1994	3	27	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15627	Vanessa de Almeida Santana	1	1993	10	27	F	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15703	Caroline Klosowski	1	1995	2	2	F	343	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15800	Matheus Ferezin Pompiani	1	1991	3	18	M	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15791	Marissa Mayara Pereira Gonsalves	1	1992	1	11	F	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15621	LUISA C. DIAS	1	1993	9	21	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15715	Bruna Marina Antunes	1	1994	3	25	F	343	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15713	André Eduardo Maas	1	1994	2	9	M	343	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13587	Matheus Boarin de Oliveira	1	1994	9	26	M	482	6ª série B	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15711	Felipe José Campregher	1	1994	1	7	M	343	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11910	Victor Pancheri Muniz	1	1994	5	12	M	482	6ª série A	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15708	Tuani Daiana Peters	1	1995	9	10	F	343	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15777	Thaynah Peres Campos	1	1995	4	4	F	192	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15785	Talita Cristina de O. Quadros	1	1991	12	27	F	510	8ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15793	Regiana Aparecida Canteiro Vieira	1	1991	8	8	F	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15706	Rafael Ferreira de Souza	1	1995	8	8	M	343	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11914	Nicole Sotero de Freitas	1	1994	8	4	F	482	6ª série B	\N	\N	\N	166	\N	\N	1	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11927	Matheus Claro de Oliveira	1	1994	7	11	M	482	6ª série C	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15776	Marcela Freitas Vieira	1	1995	1	24	F	192	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11916	Lucas Di Grazia Zanfelice	1	1994	5	5	M	482	6ª série B	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15629	Kelvim Henrique dos Santos Cintra	1	1994	8	30	M	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15712	Joyce Ribeiro	1	1994	11	15	F	343	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15790	José Carlos Nogueira Jr	1	1990	5	30	M	510	8ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15792	Jessica Liberty	1	1990	12	21	F	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15630	Jefferson Barbosa  de Melo Dias	1	1993	8	16	M	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15705	Jailton Langa	1	1995	2	22	M	343	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15625	JULLYANA W. M. LIMA	1	1993	12	23	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15773	GABRIELLE CRISTINA CHAGAS	1	1995	1	1	F	355	5ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11913	Felipe Mari Vidotto	1	1994	9	16	M	482	6ª série B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15789	Felipe Garcia Silveira	1	1991	6	8	M	510	8ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15788	Everton Afonso Estati	1	1991	2	5	M	510	8ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15626	Evelyn S. Nunes	1	1993	11	25	F	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15628	Eduardo Pereira Gabriel	1	1993	8	9	M	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15784	Edilson Aparecido Alves dos Santos	1	1990	6	22	M	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15710	Débora Barth	1	1994	9	5	F	343	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15797	Danilo Ferreira Atanazio	1	1992	7	7	M	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15622	DIOGO F. Z. PASSOS	1	1993	10	29	M	533	6ª S (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15772	DEISE TAÍS YAMANAKA	1	1995	1	1	F	355	5ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15620	DANIELLA C. S. DE SOUZA	1	1993	7	26	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11906	Caíque Aranha Boteon	1	1994	1	26	M	482	6ª série A	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15799	Caroline Cristine Madakena	1	1991	10	17	F	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15787	Caroline Couto de Oliveira	1	1992	6	2	F	510	8ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11917	Bárbara Íris Cabral Marchesin	1	1993	12	12	F	482	6ª série C	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15796	Ariane Lopes de Camargo	1	1992	1	6	F	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11915	André Gonçalves Tavares	1	1994	2	13	M	482	6ª série B	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15704	Ana Luiza Gütz	1	1995	2	10	F	343	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15795	Aline Bruno da Cruz	1	1991	11	21	F	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15774	ANA PAULA CHAGAS	1	1994	1	1	F	355	6ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15775	ALINE DE JESUS MARIANO	1	1995	1	1	F	355	5ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15723	Marlise Westphal	2	1992	6	1	F	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15720	Bruna Roseneide Langa	2	1993	6	14	F	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13489	Bruno Levy Tasso	2	1992	10	28	M	540	7a série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15722	Kevin Ernesto Martinez	2	1993	7	9	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11279	CAROLINE DE OLIVEIRA LUZ	2	1992	4	16	F	373	8ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15719	Brian Tancon	2	1993	10	10	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15724	André Lorenz	2	1993	5	24	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15718	Ana Carolina Gadotti	2	1993	11	16	F	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15717	Allan Henrique Evaristo	2	1993	5	14	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15886	CRISTIANO DOS SANTOS	4	1986	3	4	M	480	2° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15887	CLAUDIO NIKSON MOURA	4	1988	3	27	M	480	2° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15949	SONALY ULISSES PEREIRA 	4	1987	8	23	F	480	2º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11015	Verônica Silva Albo	1	1995	3	2	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12505	Antônio Fernando Charavallote Júnior	1	1993	8	10	M	312	6ª B	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15913	Marcelo Elias Batista Fernandes dos Santos	1	1994	7	22	M	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15908	Thaís Caroline da Silva	1	1994	11	19	F	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14430	Romulo de Sá Sousa	1	1995	9	29	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12794	Raphael Silva Tonelli Moreira	1	1994	1	14	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12052	PALOMA FRAGA	1	1993	10	5	F	215	16EC	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14686	MARIA FERNANDA DE ARAÚJO ROMERO	1	1995	5	30	F	215	15TA2	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10973	Fabrício Placidino Simão	1	1994	1	17	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12072	FELIPE GAMEIRO BIASIOLI	1	1995	3	15	M	215	15TA2	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15918	ENILSON JUNIOR NOLASCO	1	1995	9	15	M	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12045	DANIELLA LUCILIA DE T. BETTI	1	1995	7	18	F	215	15TA3	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11132	Alex Morelatti	1	1994	10	13	M	258	5ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15801	Alan Henrique Cardoso	1	1191	9	4	M	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13129	THAMARA SALES BARRETO	1	1993	10	23	F	196	6ª Série - Gama	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12039	RICARDO TEIXEIRA DE CARVALHO SILVA	1	1995	6	12	M	215	15TA3	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11189	RAMON TIMBO RIBEIRO	1	1994	8	22	M	196	5ªSérie - Alfa	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10857	MARIANA MASCARIN WENCESLAU DE MORAES	1	1995	8	14	F	48	5ª C	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15930	JONATA LEONARDO MORAIS DE ALMEIDA 	1	1993	7	27	M	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15931	ITNA NÍLCIENE DE SOUZA FERNANDES	1	1998	7	13	F	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14688	HELENA RIGHI CAMARGO	1	1995	6	23	F	215	15TA2	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12040	HELENA O. GOMES DE ATHAYDE	1	1995	7	2	F	215	15TA3	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13147	GABRIEL FRITZ PESSOA	1	1994	11	4	M	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14618	Edilenon P. Vieira	1	1993	8	12	F	112	6ª série	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12459	Daiane Mattos de Lima	1	1995	1	11	F	312	5ª D	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15916	DANIEL AUGUSTO DA SILVA	1	1994	12	13	M	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12017	CAMILA FERREIRA DA SILVA	1	1994	4	29	F	215	16EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14596	Betina Cordeiro Cherfen	1	1995	1	30	F	545	5a	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12053	ANA CAROLINA REA CABRAL	1	1995	11	30	F	215	15TA1	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12008	ANA CAROLINA PEREIRA BASÍLIO	1	1994	3	22	F	215	16EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15909	Rafael Caminhoto Pedrotti de Melo Rocha	2	1992	8	17	M	189	8ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15912	Leonardo Archanjo de Carvalho	2	1990	9	16	M	189	8ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15911	Leonardo Archanjo de Carvalho	2	1990	9	16	M	189	8ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15932	IZABEL RAMONA NOLASCO	2	1992	10	7	F	480	8º	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15910	Bruce Henrique de Melo	2	1993	10	8	M	189	7ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15914	Brenda Helena de Aguiar Melo 	2	1993	1	13	F	189	7ªsérie	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15854	JESSICA RODRIGUES DE SOUZA	3	1991	1	9	F	480	1° ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15856	JEFERSON THIAGO REBOUÇAS BARBOSA	3	1992	2	6	M	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15933	ISAEL FREÍRE DE SOUZA	3	1988	3	15	M	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15919	FRANCISCO JOSÉ DA SILVA 	3	1965	4	3	M	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15922	FRANCISCA ZILDA BATISTA	3	1974	11	1	F	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15088	NICOLA TOMMASINI	1	1994	2	5	M	11	6ª	\N	\N	\N	34	\N	\N	1	12	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15840	MARIANA DOS NAVEGANTES DE SOUZA SILVA	4	1990	8	15	F	480	2° ANO - ENSINO MÉDIO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15842	MARIA MARLEIDE DA SILVA	4	1977	11	14	F	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15841	MARIA CONCEBIDA DE SOUZA	4	1968	1	27	F	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15845	MARCONDES ANTONIO MARQUES DA SILVA	4	1988	7	17	M	480	2º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15846	MADILENE FELIX LOPES	4	1988	1	12	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15847	MACARIO FELIX DE MENEZES NETO	4	1989	2	28	M	480	2° ANO - ENSINO MÉDIO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15849	LINDOELMA CLEMENTINO DE SOUZA	4	1987	4	28	F	480	3° ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15928	JÉSSICA RODRIGUES REBOUÇAS SILVA	4	1992	5	4	F	480	2º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15838	Joaquim Marques de Oliveira Neto	4	1991	7	5	M	480	2° ANO - ENSINO MÉDIO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15851	JUSSARA RAFAELA DA SILVA	4	1984	5	10	F	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15852	JULIÃO RODRIGUES DA SILVA NETO	4	1985	9	1	M	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15853	JOÃO BATISTA DE SOUZA NETO	4	1993	1	29	M	480	6ª SÉRIE	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15929	JANE GRAZIELE K. VIEIRA	4	1989	10	21	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15857	JALISON JULIO RODRIGUES REBOUÇAS SILVA	4	1991	3	8	M	480	2° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15921	FRANCISMAR COSTA	4	1966	1	2	M	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15923	FRANCISCO WILLAME SHATNER NOLASCO 	4	1986	10	4	M	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15927	FRANCISCA RODRIGUES DO NASCIMENTO	4	1975	1	20	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15925	FRANCISCA KARINA FERNANDES COSTA	4	1979	5	20	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15924	FERNANDO SOUZA FERNANDES	4	1987	2	2	M	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15917	DANIELE DO NASCIMENTO SOUZA 	4	1987	7	7	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15915	DANIELA RODRIGUES REBOUÇAS	4	1988	4	23	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15850	CARLA ISABELE LOPES DA COSTA	4	1983	8	5	F	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15844	MARIA AGLAILDE DE FRANÇA	3	1988	9	23	F	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15839	RUBENIGUE DE SOUZA SILVA	4	1984	8	10	M	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13297	Renato Veras Parente	1	1994	5	15	M	367	6ª	\N	\N	\N	41	\N	\N	1	12	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15328	Rafael Melo Marques	1	1994	5	16	M	555	6	\N	\N	\N	41	\N	\N	1	10	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14824	José Guilherme Godoi Alves	1	1995	3	8	M	367	6ª	\N	\N	\N	41	\N	\N	1	12	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14836	Ruan Victor P. de Souza	1	1994	1	30	M	367	6ª	\N	\N	\N	51	\N	\N	1	12	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11444	LUCAS TABUSO DE OLIVEIRA	1	1994	9	5	M	159	6	\N	\N	\N	41	\N	\N	1	12	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15984	Ronaldo Chan Fin Yi	1	1994	7	7	M	78	5EF	\N	\N	\N	51	\N	\N	1	12	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10441	BRUNA ORTIZ EZQUERRO	1	1993	12	14	F	461	6ª SÉRIE VERDE	\N	\N	\N	66	\N	\N	1	12	0	16	266	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1406	Vivian Reuben	1	1993	9	10	F	153	6ª série	\N	\N	\N	68	\N	\N	1	12	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12297	FELIPE PEIXOTO NOBRE	1	1994	8	1	M	196	6ª Série - Master	\N	\N	\N	68	\N	\N	1	12	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13156	Ariela Feiman Halpern	1	1994	2	28	F	40	6ª do Ensino Fundamental	\N	\N	\N	68	\N	\N	1	11	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15317	Noboru Fernando Hatta Regal	1	1993	11	9	M	555	6	\N	\N	\N	79	\N	\N	1	10	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15117	Naira Link	1	1996	2	10	F	144	5ª Série	\N	\N	\N	79	\N	\N	1	10	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13158	VICTOR LEVI DE MELO OLIVEIRA	1	1994	6	30	M	196	6ª Série - Master	\N	\N	\N	106	\N	\N	1	12	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11424	LOUISE C. VISARAI	1	1995	1	12	F	159	5	\N	\N	\N	130	\N	\N	1	12	0	10	166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13669	Ingrid Oliveira Tavares	1	1995	6	3	F	367	5ª	\N	\N	\N	130	\N	\N	1	10	0	10	166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11417	Daniel Loureiro Motta	1	1995	5	22	M	159	5	\N	\N	\N	130	\N	\N	1	12	0	10	166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15757	PEDRO VIEGAS	1	1995	2	4	M	573	5ª SÉRIE	\N	\N	\N	155	\N	\N	1	10	0	7	116	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14847	Hamilton Gomes de Santana Neto	1	1994	12	22	M	367	6ª	\N	\N	\N	130	\N	\N	1	12	0	10	166	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10842	YAGO PRAZERES PAIVA	1	1994	4	27	M	373	5ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12022	GUILHERME JOSÉ DA COSTA NETO 	1	1994	7	20	M	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14598	JULIANA BEKMESSIAN WIDMER	1	1995	7	13	F	215	15MA4	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10555	Raif Luan Lucino	1	1994	1	13	M	473	6 D	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11188	RODRIGO MARQUES RIBEIRO	1	1991	6	11	M	373	6ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11293	Ana Júlia Silva Ribeiro	1	1994	11	14	F	511	5ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11560	Aline da Silva Gouveia	1	1997	9	24	F	350	3ª A	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10882	Bianca Cagliari	1	1995	4	21	F	258	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10604	Uri Levin	1	1995	10	9	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11825	RENNAN MESQUITA ROLIM 	1	1995	6	29	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12644	RENATA FREITAS DA SILVA	1	1994	8	1	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12633	MONALISA SILVA MENDES	1	1994	10	24	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12638	CLÉRIA SOUZA PEREIRA	1	1995	5	11	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15277	Bruno Iberalto de Liro Silva	1	1994	1	28	M	555	6	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16099	Bruno Araújo dos Santos	1	1995	1	1	M	293	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12697	Ana Clara Cobra Pio	1	1994	10	29	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12642	ALINE SANTOS MOURA	1	1995	3	21	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12636	PATRÍCIA OLIVEIRA SILVA	1	1994	8	17	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15074	NATÁLIA MIDORI SANABIO SAZAKI	1	1995	4	13	F	11	5ª	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12020	NADIA VIVIANE DE A. SILVA 	1	1994	10	4	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14540	Maria Eduarda Melli	1	1994	3	14	M	545	6a	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12639	MAYARA PEREIRA DOS SANTOS	1	1994	9	29	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14541	Juliana Cury Rodrigues	1	1995	1	16	F	545	5a	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12643	JAQUELINE B. DE SOUZA	1	1994	12	25	F	215	15EC	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12347	Gabriel Souza Cury	1	1994	1	9	M	318	6ª Série B	\N	\N	\N	166	\N	\N	1	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12026	GABRILELA GUERRA GUIMARÃES	1	1995	3	5	F	215	15MA3	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15385	ELISAMA OLIVEIRA CAMPOS DE ARAUJO	1	1995	10	21	F	555	5ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15279	CAYO PEREIRA DA SILVA	1	1995	6	19	M	555	5ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12276	BRUNO ALAN MIYAMOTO	2	1993	5	12	M	487	7ª EF	\N	\N	\N	41	\N	\N	1	17	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14642	Elvis Eugenio Rocha Lima	2	1992	12	31	M	179	9º ANO	\N	\N	\N	131	\N	\N	1	16	0	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14831	Victor Rocha Isaías	2	1992	11	30	M	367	7ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14673	Lucas Zimermann	2	1993	6	2	M	552	7ª1ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16098	Frederico Felix Figueroa Lessa Pessoa	2	1993	6	4	M	192	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12788	Luiz Fernando Pereira Pussente	1	1991	12	18	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10662	Fábio Mantuan	1	1993	6	18	M	473	6 A	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13443	Vitor Cardoso Queiroz	1	1994	8	20	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15331	THOMAS KASSAUF DE ALMEIDA	1	1995	1	31	M	555	5ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10501	Vera Ruth Simões Pinto	1	1994	9	9	F	473	5 A   	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15329	SISSI FREIMANIS SANFORD FEITOSA	1	1994	7	5	F	555	5ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10572	Rafaela Ap. de Oliveira	1	1994	3	28	F	473	6ª C	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11271	Marcelo Augusto Alves	1	1994	6	14	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12944	GABRIELLE MENDES MOREIRA	1	1994	11	3	F	236	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13459	Eduardo F. Alves	1	1994	9	28	M	112	6ª serie	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13222	ENZO BACCARIN PIRCHIO	1	1996	3	21	M	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12708	Douglas Oliveira Pinto da Cruz	1	1995	4	2	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10588	André Lewinski	1	1995	1	20	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10560	Alvin A. A. Finelli	1	1993	12	24	M	473	6 E	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11456	TIEH S. OKUMURA	1	1994	3	4	M	159	6	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10783	STEFANY FRANÇA MOREIRAS MARTINEZ	1	1996	5	15	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10582	Raíque Guedes de Almeida	1	1993	8	9	M	473	6ª C	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14617	Rayanna Torres Viana	1	1993	7	28	F	112	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12736	Pedro Luiz da Silva Oliveira 	1	1994	12	3	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10781	NATHALIA TAKEDA SANTOLAYA	1	1996	10	17	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14095	Frederico Leite	2	1993	4	9	M	516	7ª Série	\N	\N	\N	9	\N	\N	1	22	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13119	RENAN RODRIGUES ADRIANO	3	1991	3	8	M	309	1ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
1869	Luiza Goldenberg Rotstein	1	1994	5	20	F	153	6 série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13223	FELIPE FERNANDES ANTUNES	1	1997	2	14	M	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10559	Carlos Rogério Ap. Guedes	1	1994	10	5	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4748	Bernardo Augusto do Prado Rivas	1	1994	1	26	M	5	6o A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10493	Osmir Antônio da Silva Júnior	1	1995	5	26	M	473	5ª C	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
132	JÉSSICA DE SOUZA CAMPOS	1	1993	6	25	F	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12764	Igor dos Santos Carneiro	1	1993	4	7	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2146	Henrique Fernandes Gozo	1	1993	10	31	M	258	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12760	Gian Carlo de Aragão 	1	1993	4	12	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14616	Genésio Pontes Batista Junior	1	1993	12	31	M	112	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
133	BRUNA SILVA TOREZANI	1	1993	9	24	F	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10712	BEATRIZ BENEDITO SIMOES	1	1996	5	31	F	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4553	Gustavo Gomes Reis	2	1992	7	7	M	78	8EF	\N	\N	\N	32	\N	\N	1	18	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4618	Rafael Eiki  Takemura	2	1992	7	7	M	78	8EF	\N	\N	\N	41	\N	\N	1	22	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4972	Vanessa Garcia Almeida Ferreira	2	1991	7	7	F	78	8EF	\N	\N	\N	55	\N	\N	1	17	0	28	466	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2958	FELIPE LUÍS DE MENDONÇA	2	1992	1	16	M	57	8ª SÉRIE A	\N	\N	\N	84	\N	\N	1	22	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4620	Arthur Primo Graciano	2	1992	7	7	M	78	8EF	\N	\N	\N	84	\N	\N	1	16	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1671	Yair Gottfried	2	1991	12	2	M	153	8ª série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4407	Watson Aparecido Alves	2	1992	10	27	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14936	HYGOR TIKLES FARIA	2	1993	4	29	M	5	7o	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12082	ROBSON SILVA LOCATELLI	2	1992	4	22	M	215	17EC	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1569	Andrea Dayan	2	1993	6	15	F	153	7ª Série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14501	Carolina Gabriel	2	1993	1	1	F	552	7ª2ª	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12826	Beatriz Georg Riera	2	1993	5	29	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8061	Renato Hummig	2	1992	2	15	M	8	oitava série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12813	Felipe Nunes Duarte 	2	1991	5	15	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11014	Aloísio de Souza P. Júnior	2	1991	12	8	M	473	8 E	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5238	Daniel Moraes Pereira	2	1990	2	3	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12841	Simone Christine Azevedo Teixeira	2	1992	8	24	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4974	Roberta Espírito Santo Correia	2	1992	4	24	F	207	8a. série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14352	Pedro Augusto Silva Costa Ferreira	2	1992	10	9	M	262	7ª Série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4373	Nicolas Herbert de Andrade	2	1992	12	21	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12837	Mauricio Stefano Brito	2	1993	6	8	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6795	Marcos Nogueira Bortoluci	2	1993	2	26	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14354	Lucas Nogueira Pansani	2	1993	2	26	M	262	7ª Série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15993	Larissa Saito	2	1992	7	7	F	78	7EF	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15182	Eveline Wendland	2	1993	3	16	F	512	8ªD	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11476	BRUNO DARDES	2	1992	3	15	M	159	8	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12844	Allan Cavalcante Teixeira	2	1990	12	28	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12591	Alex Borges dos Santos	2	1992	4	1	M	312	8ª D	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4105	Jordan Lambert Silva	4	1989	1	30	M	283	3o Semestre de 5	\N	\N	\N	42	\N	\N	1	85	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3083	Flavio André dos Santos Bindella	4	1988	9	23	M	225	Terceira Série EM	\N	\N	\N	42	\N	\N	\N	15	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13561	Vitória Chuang Lai	1	1994	4	15	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1529	Renato Ejzenmesser	1	1994	7	27	M	153	6ª série	\N	\N	\N	68	\N	\N	1	11	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4607	Fernando Mendonça	1	1994	7	7	M	78	5EF	\N	\N	\N	51	\N	\N	1	13	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4999	Yanne Szirovicza Chagas Lopes	1	1994	7	21	F	207	6a. série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4882	Leonardo Pedro Soares	1	1994	7	7	M	78	6EF	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5006	Lucas Pimenta Vasco	1	1994	7	7	M	78	6EF	\N	\N	\N	166	\N	\N	1	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
134	LAYLA ALVARENGA DA SILVA	1	1994	5	5	F	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7908	Alison Henrique Proença Costa	1	1994	6	4	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1530	Riva Schwartz de Souza Oliveira	1	1993	12	2	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4981	Taís Almeida da Silva	1	1994	1	9	F	207	6a. série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10255	RAISSA TEREZA GONÇALVES BACELAR	1	1994	1	10	F	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4519	Matheus Vitti Santos	1	1993	7	7	M	78	6EF	\N	\N	\N	166	\N	\N	1	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1399	Melina Hirschbrand	1	1994	2	11	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10253	LARISSA MARIANA SALUSTIANO DINIZ	1	1996	5	7	F	6	5.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7899	Erica Aparecida de Souza	1	1993	8	21	F	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10252	CAIO MORAES BENJAMIN	1	1994	5	19	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4582	Bárbara Miotto	1	1994	7	7	F	78	6EF	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1591	André Carasso	2	1993	5	6	M	153	7ª Série	\N	\N	\N	41	\N	\N	1	19	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6805	Willian Aparecido Marques Sales	2	1992	8	27	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6781	Joyce Roberta da Silva Oliveira	2	1992	11	10	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6724	Adriano Ferreira dos Santos	2	1991	11	26	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5219	Marco Aurélio Loureiro Cardoso Júnior	2	1990	5	15	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6793	Leila Santos Alves	2	1993	5	29	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15359	JOAO MENDES VASCONCELOS	2	1992	9	7	M	555	7ª	\N	\N	\N	1	\N	\N	1	22	1	35	583	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
1613	Fábio Zatz Oliveira	2	1993	7	3	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4512	Irene Caroline  Machado Almeida	2	1994	1	10	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1625	Sharon Hasbani	2	1993	5	14	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10278	Diego Garcia Ramos	2	1991	10	28	M	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1621	Rafael Akerman Shinohara	2	1992	9	1	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6799	Otavio Caitano	2	1993	9	13	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6798	Natalia da Silva	2	1993	4	6	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5001	Davi Moraes Pereira	2	1992	2	9	M	207	8a. série	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5040	Pedro Henrique Guerra	2	1992	12	1	M	207	7a. série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6804	William Rodrigues de Moura	2	1992	11	8	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10280	Talita de Sá Siqueira	2	1991	8	19	F	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1605	Nicholas Justus Nitzan	2	1993	5	20	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6796	Mauricio Gomes de Souza	2	1992	2	4	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10277	Mariany Teixeira Pinheiro	2	1991	10	7	F	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6791	Laine Liene Souza Eiras	2	1993	8	30	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6785	Karoline Milsoni Botter	2	1990	6	27	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10279	Jéssica Fernanda Pecin	2	1992	1	20	F	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6779	Joyce Aparecida de Freitas	2	1993	4	1	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6778	Jhon Maiko dos Santos	2	1992	10	28	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6758	Jessika de Assis	2	1992	10	1	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6756	Jessica do Nascimento Faria	2	1992	12	21	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
144	JOSÉ DIOGO DO NASCIMENTO CASTRO	2	1992	4	11	M	29	8ª série B	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6745	Hiago do Espirito Santo Nascimento	2	1993	1	29	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6743	Heveralvio de Paula Andrade	2	1993	4	5	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10276	Henrique de Freitas Schwingel	2	1993	4	15	M	408	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6738	Gustavo Fernandes Jorge	2	1993	3	3	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6736	Guilherme Massamitsu Ribeiro Kanashiro	2	1993	1	8	M	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1616	Gabriel Feher Radomysler	2	1993	7	30	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1615	Fernanda Rytenband	2	1992	10	28	F	153	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15954	RODRIGO TEIXEIRA NORONHA	1	1994	12	7	M	236	5ª SÉRIE	\N	\N	\N	51	\N	\N	1	10	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1919	Patricia Kawaguchi Cesar	4	1989	6	9	F	283	5o Semestre de 7	\N	\N	\N	31	\N	\N	1	100	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2804	William Disner Colombo	4	1988	8	29	M	83	Estágio	\N	\N	\N	42	\N	\N	1	100	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1715	Ezirraffner da Silva	4	1988	3	14	M	225	Prim Ano Informática FATEC	\N	\N	\N	31	\N	\N	1	95	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
289	Alexandre Chofi	4	1989	7	7	M	78	3EM	\N	\N	\N	31	\N	\N	1	235	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6409	Rodrigo Ismail Miguel	4	1989	6	1	M	283	5o Semestre de 7	\N	\N	\N	42	\N	\N	\N	55	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4529	Cindy Yuchi Tsai	3	1991	7	7	F	78	8EF	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1921	Bruno Teixeira Botelho	4	1987	11	5	M	283	5o Semestre de 7	\N	\N	\N	42	\N	\N	1	90	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14408	Victor Fontenele Nascimento	4	1990	1	4	M	555	2	\N	\N	\N	31	\N	\N	1	330	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12363	HAILTON FERRAZ DA SILVA JUNIOR	4	88	12	29	M	23	3A	\N	\N	\N	31	\N	\N	1	140	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14072	Vanrochris Helbert Vieira	4	1988	9	16	M	543	3a do médio	\N	\N	\N	42	\N	\N	1	145	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11896	Thiago Bortoletto	4	1988	7	25	M	282	1º Termo / BCC	\N	\N	\N	42	\N	\N	1	80	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14500	Daniel Chaves Machado 	4	1988	4	15	M	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	1	100	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14015	Guilherme Henrique de Sousa Santos	4	1989	7	1	M	543	3a do médio	\N	\N	\N	42	\N	\N	1	100	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11801	Felipe Iwao Takiyama	4	1988	1	7	M	13	Engenharia - Poli	\N	\N	\N	42	\N	\N	1	130	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13238	Glauber Gonçalves Campinho	4	1988	6	7	M	519	2	\N	\N	\N	42	\N	\N	1	170	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14021	Hudson Pinheiro Campos	4	1988	3	25	M	543	3a do médio	\N	\N	\N	42	\N	\N	1	105	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4886	Rafael Meneguzzi Groterhorst	1	1994	7	7	M	78	6EF	\N	\N	\N	1	\N	\N	1	13	1	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
13800	Caíque Porto Lira	1	1994	5	31	M	516	6ª Série	\N	\N	\N	3	\N	\N	1	14	1	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
15312	Lucas Gonçalves de Lima	1	1994	5	28	M	555	6	\N	\N	\N	5	\N	\N	1	11	2	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
14384	Arthur de Amorim Drigo	1	1994	10	19	M	545	6a série	\N	\N	\N	12	\N	\N	1	11	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12334	Karina Ferreira Piva	2	1991	11	11	F	159	8	\N	\N	\N	4	\N	\N	1	22	2	34	566	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
11363	Gabriel Freitas de Barros	2	1991	6	21	M	511	8ª	\N	\N	\N	4	\N	\N	1	21	2	34	566	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
11369	Lucas de Freitas Smaira	2	1993	1	23	M	511	7ª	\N	\N	\N	9	\N	\N	1	19	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12298	RAFAEL HORIMOTO DE FREITAS	2	1992	2	12	M	487	8ª EF	\N	\N	\N	9	\N	\N	1	21	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11477	LEONARDO PEREIRA STÉDILE	2	1992	2	20	M	159	8	\N	\N	\N	9	\N	\N	1	21	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
16070	Mario Luis Araujo Rocha	2	1993	5	19	M	259	7ª série	\N	\N	\N	19	\N	\N	1	20	3	32	533	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
15967	André Hahn Pereira	2	1991	7	7	M	78	8EF	\N	\N	\N	19	\N	\N	1	22	3	32	533	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13146	Renata Miwa Tsuruda	4	1988	10	26	F	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	1	100	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14027	Hugo Pereira Lima Junior	4	1989	2	8	M	543	3a do médio	\N	\N	\N	42	\N	\N	1	155	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13989	Eurico José Faria Klein	4	1989	1	23	M	543	3a do médio 	\N	\N	\N	42	\N	\N	1	105	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13140	Guilherme Marques Leme	4	1988	5	15	M	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	42	\N	\N	1	170	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13137	Eric Velton de Melo	4	1987	10	30	M	557	Prim. Sem. em Eng. da Computação	\N	\N	\N	42	\N	\N	1	175	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14047	Luiz Fernando Martins de Carvalho	4	1988	7	3	M	543	3a do médio	\N	\N	\N	42	\N	\N	1	100	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14872	JORGE AUGUSTO MELEGATI GONCALVES	4	1988	1	31	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	1	145	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12319	Guilherme A Folego	4	1989	1	8	M	487	3ª EM	\N	\N	\N	42	\N	\N	1	165	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13973	Adenilson Arcanjo de Moura Júnior	4	1990	6	9	M	516	2º ano	\N	\N	\N	42	\N	\N	1	95	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14863	ANDERSON HOSHIKO AIZIRO	4	1988	5	22	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	1	180	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14452	Lucas Grahl	1	1994	9	22	M	552	6ª1ª	\N	\N	\N	34	\N	\N	1	14	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14601	GUSTAVO RODRIGUES FERREIRA	1	1995	9	24	M	215	15MA2	\N	\N	\N	34	\N	\N	1	11	0	19	316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11639	FRANCISCO JAIRO RODRIGUES LIMA	1	1994	9	8	M	196	6ª Série - Master	\N	\N	\N	51	\N	\N	1	13	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13637	Ana Luiza Fátima Castro de Abreu	1	1994	6	17	F	367	5º	\N	\N	\N	51	\N	\N	1	12	0	17	283	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11636	MARIA CAROLINA ARAUJO BATISTA	1	1994	11	25	F	196	6ª Série - Master	\N	\N	\N	68	\N	\N	1	10	0	15	250	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14177	Victor Kioshi Higa	1	1995	8	2	M	293	5ª	\N	\N	\N	79	\N	\N	1	10	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10446	MATHEUS DE ALBUQUERQUE MONTEIRO	1	1994	9	7	M	488	6ª SÉRIE	\N	\N	\N	79	\N	\N	1	13	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12007	ANA BEATRIZ GOIS DA SILVA	1	1993	11	14	F	196	6ª Série - Gama	\N	\N	\N	79	\N	\N	1	13	0	14	233	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13264	PAMELLA SANTOS CAETANO	1	1994	4	2	F	59	6a	\N	\N	\N	92	\N	\N	1	\N	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14658	Marina Pessoa Mota	1	1994	11	17	F	527	5ª Série C - PA	\N	\N	\N	92	\N	\N	1	14	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14401	MAIARA DE LEMOS CÂMARA	1	1994	4	18	F	179	7º ANO	\N	\N	\N	92	\N	\N	1	10	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13270	CAMILA SOUZA A. ANDRADE	1	1994	12	30	F	59	6a	\N	\N	\N	92	\N	\N	1	\N	0	13	216	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1429	Igor Fillippe Goldstein	1	1994	8	22	M	153	6ª série	\N	\N	\N	106	\N	\N	1	13	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10325	André Eduardo da Silva Minikowski	1	1991	8	16	M	7	6ª série - Ensino Fundamental	\N	\N	\N	106	\N	\N	1	12	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11660	RICARDO MAIA TEIXEIRA DE SOUZA	1	1995	12	28	M	467	5ª SÉRIE	\N	\N	\N	117	\N	\N	1	10	0	11	183	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15320	Paulo Elias de Albuquerque e Sá	1	1993	7	20	M	555	6	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11666	LUCAS DE CAMARGO DA SILVA	1	1994	6	7	M	465	6ªA	\N	\N	\N	149	\N	\N	1	\N	0	8	133	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15686	Eduardo Bueno Rodrigues	1	1994	10	7	M	8	sexta série	\N	\N	\N	149	\N	\N	1	10	0	8	133	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12289	CAMILA TIMBO CATUNDA ALMEIDA 	1	1994	10	11	F	196	5ª Série - Master	\N	\N	\N	149	\N	\N	1	12	0	8	133	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15336	Stephanie da Silva Holanda	1	1994	8	29	F	555	6	\N	\N	\N	160	\N	\N	1	14	0	6	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13581	Luiza Helena Magnusson Pizzirani	1	1994	5	29	F	482	6ª série C	\N	\N	\N	160	\N	\N	1	10	0	6	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12958	YARA CRISTINA RABELO NUNES	1	1994	4	20	F	236	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15452	Wellington de Oliveira	1	1994	9	21	M	473	5 E	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11053	Wellington Gabriel de Melo Silva	1	1994	10	20	M	313	6ª B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10489	Viviane Rodrigues Moreira	1	1995	1	30	F	473	5ª C	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10886	Vivian Midori Maruyama	1	1994	10	18	F	258	5ª	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16055	Vitoria Coimbra e Souza	1	1994	12	11	F	259	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10876	Vitor Melo Carrara	1	1995	4	25	M	258	5ª	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15693	Vinícius Gerber Furtado	1	1994	9	5	M	8	sexta série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10881	Vinícius Biazon	1	1995	3	16	M	258	5ª	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15005	Victor dos Santos	1	1995	9	28	M	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13630	Victor Valença Maia	1	1994	11	5	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13909	Thiago Nogueira Gomes	1	1993	11	28	M	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12778	Thais Yuri de Castro Odane	1	1995	11	20	F	112	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10997	Tamires  Cristina da Silva	1	1994	9	30	F	473	5 D	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10490	Talita Adorno de Oliveira	1	94	5	25	F	473	6 D	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13776	TOBIAS SANDEN	1	1994	9	19	M	215	16MB1	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10859	THIAGO LUIS SARTORELLI	1	1995	2	11	M	48	5ª C	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13475	Suzana Cristina Zamuner Zeca	1	1995	2	1	F	540	5a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13908	Sid Guimaraes Palmeira Filho	1	1993	10	11	M	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13109	Sara Idete dos Santos da Conceição	1	1994	5	22	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11225	SARAH DENISE VASCONCELOS	1	1994	4	8	F	196	6ª Série - Gama	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1434	Roni Tarasantchi	1	1994	2	22	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16057	Raphael Petry de Andrade	1	1993	9	23	M	259	6ª série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11206	REGIANE BASTOS DA SILVA	1	1995	8	9	F	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13683	Gabriel Militão Vinhas Lopes	1	1994	3	24	M	367	6ª	\N	\N	\N	1	\N	\N	1	14	1	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
13532	Paulo César da Costa	1	1994	2	7	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10983	Paulo César Marques	1	1994	4	20	M	313	6ªD	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13728	Pamela Petrozian	1	1993	9	18	F	527	6ª Série E - PA	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11214	Natalia Tomaz	1	1994	11	16	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15520	Maria Gabriela Nielsen Stella	1	1994	1	13	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13150	Luiza Maria  de Castro Trindade	1	1995	1	9	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12348	Luiz Flávio Mendes B. Romão	1	1993	10	19	M	318	6ª Série B	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13627	Luiz Antônio de Brito Teixeira	1	1994	3	8	M	527	6ªPI	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14179	Lucas Rodrigues N. Cunha	1	1995	8	20	M	293	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15198	Lucas Criscuolo Chaves	1	1994	8	22	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13304	Laudir Marcos Moretti	1	1994	2	16	M	518	Fundamental	\N	\N	\N	166	\N	\N	1	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13429	LAÍS CRISTINE SANTIAGO SILVA	1	1994	9	19	F	527	6ª Série A	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15512	Júlia Cunha Dubeux Navarro	1	1994	4	26	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14198	Juliana Gonçalves Ozawa	1	1994	1	21	F	293	6ª	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13907	Juliana Arruda de Almeida	1	1995	6	4	F	544	5a série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1395	Julia Akerman Shinohara	1	1993	9	27	F	153	6ª série	\N	\N	\N	166	\N	\N	1	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10936	Jacques Grinspan Schwaitzer	1	1992	8	26	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4992	Igor Henrique de Oliveira	1	1994	11	29	M	207	6a. série	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12301	HIAGO MACIEL DE CARVALHO BARBOSA	1	1993	10	4	M	196	6ª Série - Master	\N	\N	\N	166	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13801	Gustavo David de Oliveira Souza	1	1994	10	6	M	516	5ª	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10770	GABRIELA FERREIRA GUIMARAES	1	1996	7	21	F	57	4ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12713	Fernanda Souza Mata	1	1996	5	24	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14625	Eduardo Figueiredo Mota Diniz Costa	1	1994	9	19	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14424	Davi Moraes Duarte de Vasconcelos	1	1994	4	20	M	526	6ª Série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14722	Caroline Rezende Justino	1	1993	11	9	F	312	6ª C	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14141	Carolina Gentil Parente	1	1995	3	8	F	516	5ª Série	\N	\N	\N	166	\N	\N	1	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12358	Bárbara Framil	1	1995	4	22	F	318	5ª Série B	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13918	Beatriz Yuri Henna	1	1993	10	28	F	544	6a série	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13882	Beatriz Bisol Menezes	1	1993	11	6	F	527	6ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14150	Arthur Gomes de Melo Barros	1	1995	6	13	M	517	quinta	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13154	Ana Laura de Brum Kury da Silva	1	1994	8	1	F	40	6ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13555	Ana Claudia Cleto Piva 	1	1995	1	3	F	285	5ª série	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12286	ANA LETICIA ALVES PINHEIRO	1	1994	8	5	F	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10553	Wendel Rodrigo da Silva	1	1994	2	6	M	473	6ª B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10716	Wendel Gabriel Gimenes	1	1994	6	6	M	473	5 D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10875	WILLIAN APARECIDO SBERCI	1	1995	4	15	M	48	5ª D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12013	WALAFF FAGUNDES DA SILVA 	1	1993	12	22	M	215	16EC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14970	Viviane Solano Lutif	1	1994	6	27	F	367	6ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13166	Vitória Costa Ciampolini	1	1993	7	30	F	40	6ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13551	Vitor Andriotti Nicola	1	1995	7	19	M	285	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12808	Vinicius Moretti Zavalis	1	1994	9	26	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10605	Vanessa Wasserman Macedo	1	1994	8	23	F	153	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15650	Tamiris André	1	1995	7	27	F	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12160	Tainara Ribeiro da Silva	1	1994	8	18	F	312	5ª A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11576	Sharbele Júlia Ferreira Lins	1	1995	7	28	F	350	5ª A (Esc. Amor Divino)	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10895	Rubens de Castro Silva Nascimento	1	1994	4	27	M	258	6ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10757	Ricardo Kozlowski Wizenberg	1	1994	1	7	M	153	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10837	RODRIGO DE ABREU PIRES DE ANDRADE	1	1995	6	2	M	373	5ª	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10373	RHAFAEL MARTINS ALVES 	1	1994	12	5	M	48	6ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12737	Pedro Paulo Santos da Silva	1	1994	7	2	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10969	Nicolau Balbino	1	1994	12	28	M	511	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15055	NATHALIA TORDIVELLI GONZALES	1	1995	7	17	F	11	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10830	NATAN OLIVEIRA RIBEIRO DE PRADO	1	1994	6	7	M	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11109	Mônica Grabriela Luchesi	1	1993	11	26	F	313	6ªC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12648	Murilo Rassele	1	1995	5	4	M	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11012	Mislene Maíra Soares Lopes	1	1995	4	20	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11233	Matheus Inocêncio Pinto	1	1995	9	16	M	504	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13946	Mario Henrique Sewaybricker Munhoz	1	1994	4	4	M	544	6a série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12975	Marina Brasil Vieira Parronchi Costa	1	1994	12	5	F	541	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10577	Marcos de Godoy Bento	1	1994	6	14	M	473	6ª C	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10597	Marcelo Epstein	1	1995	5	16	M	153	5ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16065	Marcell Pinheiro Ganan	1	1994	3	9	M	259	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12024	MIKAELLY  LEMOS  MAIA	1	1995	3	2	F	488	5ª SÉRIE DO ENSINO FUNDAMENTAL	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11957	Lucas Edson Linhares	1	1995	2	27	M	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14593	Letícia Salvador Vieira	1	1995	7	12	F	545	5a	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13145	Laura Amaral de Andréa P de Carvalho	1	1995	3	13	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15563	Lara Pereira Massabni	1	1995	3	5	F	491	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10825	LUCAS RODRIGO SALES ADÃO	1	1993	4	25	M	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12051	LAIS PEREIRA SANTOS	1	1993	12	30	F	215	16EC	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15680	Koody André Hassemi Kitawara	1	1995	11	15	M	8	quinta série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10512	Kaique William Biachi Leandro	1	1995	6	8	M	473	5 A   	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11775	José Antônio Belquior Gomes	1	1994	2	10	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15761	JULIA E. RAMOS	1	1994	9	22	F	573	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15389	JUAN ENRICO CARVALHO OLIVEIRA	1	1995	4	4	M	555	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10820	JOÃO RAFAEL RIBEIRO DA ROCHA RODRIGUES	1	1993	11	6	M	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13135	Hugo de Oliveira Ferreira	1	1995	6	13	M	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13472	Guilherme Martins Panayotou	1	1994	11	10	M	540	5a série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10496	Guilherme Henrique Martins	1	1995	3	16	M	473	5ª C	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11344	Gabriela Maria Candida Ferreira Mota	1	1995	5	9	F	504	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12758	Gabriela Cunha de Carvalho Bernardo	1	1993	6	18	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12382	Gabriel Freire Sanzovo Fernandes	1	1994	11	3	M	318	6ª Série A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15997	Gabriel Chaves Romero	1	9999	99	99	M	207	6a. série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10346	GUSTAVO HENRIQUE ZANI ROSSI	1	1994	1	25	M	48	6ª A	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12466	Felipe Augusto dos Santos Simão	1	1995	4	6	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2942	FERNANDA S. SANTOS E SILVA	1	1994	1	2	F	57	6ª série B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13448	Eduardo Lobato Consentine de Menezes	1	1994	8	4	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14426	Danilo Coelho	1	1995	11	8	M	112	4ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15522	Cecília Mayumi Araújo Sato	1	1993	12	13	F	497	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4143	Carlos Henrique Ferreira	1	1994	1	6	M	313	6ªC	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16044	Bruno Alexandre Pereira	1	1995	3	23	M	259	5ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13114	Beatriz  Alves da Fonseca Pedrosa	1	1995	3	9	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13916	Aureo da Paixão Guedes Filho	1	1991	4	22	M	544	6a série	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15778	Andressa Pereira Pedro	1	1991	1	1	F	313	5ªB	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11550	Aline do Nascimento Nunes	1	1996	9	24	F	350	3ª B	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12746	Alan Alisson Albuquerque do Nascimento	1	1993	8	4	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11209	ADHARA MOREIRA FALCAO PINHEIRO	1	1995	10	29	F	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12472	Érick Jairo Fernandes	1	1994	12	18	M	312	5ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12151	Édino Amaral Júnior	1	1992	12	19	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14126	Ygor Marques de Lucena	1	1994	10	20	M	516	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13788	Yasmim Fernanda de Lima	1	1995	10	20	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10762	Yael Engel	1	1994	1	24	F	153	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15953	YONARA VANIA DE OLIVEIRA 	1	1993	6	14	F	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13259	YGOR CANDIDO FIRMINO	1	1994	7	22	M	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15412	YASMIN TEODORICO GUIMARÃES	1	1994	1	16	F	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11037	Washington Felipe Tavares	1	1994	5	14	M	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14693	Walison F. Silva	1	1993	8	27	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11968	WILLIAM FERNANDO RODRIGUES	1	1995	2	25	M	355	5ª série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11386	Vivian Xavier da Silva	1	1992	5	2	F	313	6ªB	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15125	Vitor Fornazari Trimentose	1	1995	3	24	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15012	Vitor Araujo Chane	1	1995	2	13	M	192	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11147	Vinícius Roveran Ribeiro	1	1995	12	22	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12774	Vinícius Oliveira Gama	1	1995	4	24	M	112	5ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11601	Vinicius da Silva Justiço	1	1995	3	10	M	350	6ª A (Esc. Encursor N Srª do Carmo)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14361	Vinicius Tadeu Anderson	1	1994	3	10	F	517	sexta	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12487	Victor Hugo Zavagli Ramos	1	1994	6	28	M	312	6ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13628	Victor Florencio Machado de Sa	1	1995	5	25	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12496	Valéria Aparecida Leite da Silva	1	1994	1	25	F	312	6ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11087	Valdir José de Flório Júnior	1	1995	5	19	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15623	VITOR S. R. CARONE	1	1994	4	23	M	533	6ª S (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12801	Thais de Oliveira Abreu 	1	1993	7	7	F	561	6ª série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10963	Ricardo Manini Cardoso de Castro	1	1994	12	20	M	511	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16005	Rachel Resende Fernandes	1	9999	99	99	F	207	5a. série	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10979	Paulo Sérgio Martins de Almeida	1	1994	8	30	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14314	Natália Altarugio Barbanera	1	1993	12	6	F	545	6a série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12353	Matheus de Castro Hissi	1	1995	2	26	M	318	5ª Série B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15004	Marcos Aurelio da Luz Júnior	1	1995	5	4	M	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10438	MARCOS CESAR MILANEZ	1	1994	9	17	M	461	6ª SÉRIE VERDE	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14242	MAILA GONÇALVES DE DEUS	1	1994	1	21	F	5	6o	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10946	Luis Guilherme Monteiro Melo Mariano	1	1995	9	1	M	511	5ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11059	Luana Caroline P. de Carvalho	1	1994	9	27	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14608	Larissa Fernanda de Camargo Silva	1	1995	6	24	F	545	5a	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11651	LUCAS PINHEIRO LEITE	1	1994	4	28	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12725	Karoline Angela da Silva Calcado	1	1995	8	22	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13858	Karla Caroline Milhomens Menezes	1	1994	7	21	F	516	6ª Série	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13139	Julia Lellis Teixeira	1	1995	4	11	F	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16001	Joseph William B. de Rezende	1	9999	99	99	M	207	5a. série	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12720	Jessica Paraibuna Ferreira	1	1995	4	24	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10976	Jeferson Diego da Cruz	1	1993	1	3	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11176	JULIANA FERREIRA DA SILVA	1	1993	1	2	F	373	6ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11175	JULIA BARBOSA LEITE	1	1994	9	1	F	373	6ª	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13138	JAMILLE PRATA CAVALCANTE	1	1995	10	8	F	196	5ª Série - Master	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14987	HELOÍSA GUILHERME DE FARIAS	1	2000	1	14	F	215	15EC	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12761	Gustavo Abud Contino Vianna	1	1994	5	11	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11382	Guilherme Gabriel de Lima	1	1993	5	5	M	313	6ªB	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13732	Gabriel Cavalcante Hortêncio	1	1994	10	31	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12755	Gabriel Bastos dos Reis 	1	1993	12	27	M	561	6ª série	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10817	GUSTAVO GOMES DA SILVA PEÇANHA	1	1994	5	30	M	373	5ª	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10851	GUILHERME CARVALHO CAVALCANTE	1	1993	10	14	M	373	6ª	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11446	GIULIANA ROASSALY ALCARO	1	1994	3	24	F	159	6	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13227	GABRIELA CIURCE FERREIRA	1	1994	12	18	F	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12710	Estevão Melo da Costa Monteiro	1	1994	4	24	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11827	DANIEL SALES DE SOUZA	1	1992	11	4	M	467	6ª SÉRIE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12706	Caroline de Souza Freitas	1	1995	5	11	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10668	Caroline Machado Castro	1	1995	4	12	F	473	5 D	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13453	Brenda do Socorro Pantoja da Conceição	1	1994	4	17	F	112	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13730	André Fan Zhong	1	1994	11	1	M	527	5ªPI	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11541	Adriano Francisco da Silva	1	1996	4	4	M	350	3ª B	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16042	ANA CARLA TEIXEIRA MAGALHAES	1	1992	10	8	F	527	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12940	ALISON DOUGLAS COSTA AZEVEDO	1	1995	9	4	M	236	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10454	ALESSANDRO MIRANDA FACUNDO	1	1994	5	27	M	488	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12955	Tiago de Campos Camargo	1	1994	11	4	M	541	5ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11747	Thiago Angelini Dias Faustino	1	1993	9	10	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15138	Thais Martins Bagaiolo Coimbra	1	1994	5	27	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11001	Taís de Haro Boretti	1	1995	1	10	F	473	5 D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14398	THIAGO CAVALCANTI MODESTO DA SILVA	1	1992	7	31	M	179	7º ANO F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15195	Silvio Luis Marsiglio Minarelli	1	1994	12	1	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11537	Silas Leandro Lins Barbosa	1	1996	6	15	M	350	4ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15806	Sara Nair Casagrande	1	1990	10	19	F	510	8ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11991	RÔMULO LOPES SUNTACK	1	1994	11	16	M	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15945	RÔMULO ALVES RODRIGUES FILHO 	1	1993	1	4	M	480	5º SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12430	Rogério Donizette da Silva Júnior	1	1995	6	7	M	312	5ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10573	Raul Baptista de Lima	1	1994	4	20	M	473	6 E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13716	Raimundo Messias de Araujo Junior	1	1995	6	24	M	527	5ª Série 2 - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15247	Rafaela Fiorin de Carvalho	1	1994	8	8	F	262	6ª Série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13827	Rafael Gomes Nepomuceno	1	1995	6	6	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13201	RODRIGO DINIZ BRANCO	1	1992	10	13	M	355	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11811	RICARDO MAIA TEIXEIRA DE SOUZA	1	1995	12	28	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11661	RICARDO MAIA TEIXEIRA DE SOUZA	1	1995	12	28	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10331	RAUL MARCOS MANTOVANI MORELLATO	1	1994	1	31	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15395	RAFAEL LOPES BRITO	1	1995	11	11	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11612	PÂMELA RAÍSSA DE ALMEIDA	1	1995	4	25	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11070	Polyanna de Cassia Silva	1	1995	6	4	F	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11136	Pedro Henrique V. Marques	1	1995	3	24	M	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13829	Pedro Erick Araújo Bezerra	1	1996	5	26	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13305	Paulo José da Silva	1	1994	11	3	M	518	Fundamental	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14730	Paulo César de Jesus Venâncio	1	1993	1	1	M	313	5ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11984	PAULO RICARDO CORRÊA	1	1995	1	18	M	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13200	PAULO ELIZEU PRESTES DE LIMA	1	1994	7	4	M	355	6ª SÉRIE A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14127	Nilo Alberto Carvalho Guerra	1	1993	7	24	M	516	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13727	Nicolas de Salvi Lima	1	1994	5	31	M	527	6ª Série E - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13794	Matheus Narciso de M. Peixoto	1	1994	4	11	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15121	Matheus Morato Bueno de Godoy	1	1995	3	3	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13724	Maria Beatriz Piteiras Pereira Gomes	1	1994	2	3	F	527	6ª Série E - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12483	Marcos Vinícios de Oliveira	1	1995	2	13	M	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11039	Marcos Silva Conte	1	1992	7	6	M	313	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14724	Marcos A. Macedo Filho	1	1994	6	7	M	312	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11150	Marcela B. G. Fernandes	1	1994	6	22	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11588	Manasses Ferreira da Silva	1	1991	5	9	M	350	6ª A (Esc. Marcos de Barros Freires)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11211	MATTHAUS RAMALHO BEZERRA FARIAS	1	1993	7	23	M	196	5ª Série - Gama	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12418	MARLUS RIBEIRO BRANCO	1	1994	7	1	M	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11975	MARIANE DOS SANTOS LEITE	1	1995	11	21	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15600	MARIANA DO C. NOVAES	1	1995	3	31	F	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15134	Luis Fernando de Almeida Prado Martins Filho	1	1995	4	20	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15817	Lucas Mateus da Cruz Pinto	1	1990	10	15	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13698	Lise Lima Lopes	1	1993	11	3	F	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14712	Lisa Herédia B. dos Santos	1	1994	6	9	F	312	6ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15200	Leonardo Vidal de Negreiros Rossanese	1	1995	6	28	M	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15716	Leonardo Pinho	1	1994	11	10	M	343	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10263	LUIZ CARLOS DE OLIVEIRA VIEIRA JUNIOR	1	1993	6	14	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14992	LUCAS PEREIRA C DA SILVA	1	1995	3	18	M	487	5ª EF	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15407	LORENZO GERARDO DA COSTA DUARTE	1	1993	7	16	M	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15604	LORENZO	1	1994	5	22	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14325	LARISSA MENDES DA SILVA	1	1994	5	2	F	5	6o	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13265	KETSIA CAROLINE R. RODRIGUES	1	1994	9	29	F	59	6a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13059	KATTY STEFANIE NOEMI EFFA KAITAZOFF	1	1993	10	15	F	309	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12154	Jéfferson Rômulo Inácio dos Santos	1	1992	3	1	M	312	5ª A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11267	João Pedro Silvério Silva	1	1994	4	18	M	504	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11546	José Igor Ximenes da  Silva	1	1995	9	10	M	350	2ª D	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10891	Joana de Carvalho Crissiuma Pisciotta	1	1990	10	28	F	258	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15128	Jessica da Motta Stripari	1	1995	5	17	F	144	5ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12613	JOÃO PAULO BARREIROS SANTOS	1	1994	9	15	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10204	JOAO VICTOR DE OLIVEIRA	1	1994	1	22	M	175	6a. Série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13564	Iolanda de Souza Barreira	1	1993	10	16	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13685	Ilgner Justa Frota	1	1994	3	31	M	367	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13684	Igor Ribeiro Lemos	1	1995	6	12	M	367	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14255	ISADORA DE MELO REIS	1	1993	10	28	M	5	5º 	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15464	Hélio Bergantini Neto	1	1995	6	7	M	262	5ª Série	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15637	Hugo Lima Cassiano	1	1994	8	25	M	514	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14764	Guilherme Costa	1	1994	6	24	M	216	6ª Serie do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15044	Gregory Borges do Rosário	1	1994	10	8	M	192	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11870	Giovanni Caetano	1	1994	1	1	M	313	5ªE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11591	Gardênia Marcela de França Monte Belo	1	1994	11	19	F	350	6ª A (Esc. Missionário São Bento)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15794	Gagriela da Silva Macedo	1	1992	12	16	F	510	8ª B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15167	Gabriela Marques Lima	1	1994	8	4	F	512	7ªD	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11080	Gabriel Henrique dos Santos	1	1995	12	19	M	313	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11988	GIOVANNA MARCONDES ZAMBIEN	1	1995	6	4	F	355	5 ª Série C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12399	GABRIELLE CAVALCANTE TRIGUEIRO	1	1995	4	20	F	488	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13203	GABRIEL PRADO CAMARGO	1	1994	6	25	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13251	GABRIEL ARAÚJO DOS SANTOS	1	1995	2	29	M	59	5a	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13649	Felipe Souza da Silveira	1	1994	1	10	M	367	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15816	Felipe Augusto R Pereira	1	1991	3	15	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15605	FREDERICO	1	1994	7	21	M	533	6ªS (EF)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11448	FELIPE CORCIONE SANTOS OLIVEIRA	1	1994	4	4	M	159	6	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15901	Evelyn Aparecida Alves Friedberger	1	1994	3	3	F	189	6ªsérie	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13792	Eládio Gouveia Oliveira	1	1993	10	18	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11763	Douglas Rogério Chagas Silva	1	1993	10	13	M	313	6ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15709	Daysi Clarissa Longen	1	1994	2	18	F	343	6ª série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14491	Davi Sampaio de Alencar 	1	1994	1	26	M	516	6ª Série	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15649	Daniela Batista Gonçalves	1	1993	9	3	F	514	6ªB	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15284	DAVID KEN GOMES TERAO	1	1995	1	5	M	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12616	CÍCERO VILHENA DE MENDONÇA	1	1994	11	7	M	6	6.ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15008	Clara Moscoso de Lima	1	1995	5	22	F	192	5ªC	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14155	Carlos José Martins Neves	1	1993	1	9	M	568	7ª série E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13530	Carliane Mendes de Oliveira	1	1994	9	22	F	527	6ªPI	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15813	Caio Vinicius Costa de Oliveira	1	1992	5	11	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13202	CARLOS JOSÉ VARALLO POVOA JUNIOR	1	1994	5	4	M	355	6ª SÉRIE C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
130	CAIO FELIPPE CARDOZO LIMA	1	1993	12	17	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12480	Bárbara Melo Braga	1	1995	5	10	F	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11539	Bárbara Fernanda de Souza Ribeiro da Silva	1	1995	8	12	F	350	1ª C	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10980	Bruno Arcencio Rosa	1	1993	12	29	M	313	6ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10580	Brenda Stephanie Ribeiro da Cruz	1	1994	1	9	F	473	6 E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11085	Brenda Cristina Miguelino 	1	1994	8	7	F	313	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13646	Andressa Almeida Albuquerque	1	1993	12	31	F	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15786	Ana Paula Aparecida Felisbino	1	1992	2	9	F	510	8ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14706	Ana Flávia P. Naccarato	1	1994	10	4	F	312	5ª F	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13821	Amanda Barbosa Evangelista	1	1995	4	26	F	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13860	Alex Pereira Rosa	1	1995	1	18	M	216	5ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12000	AUDRIA MASCARENHAS DE OLIVEIRA	1	1995	5	5	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15401	ARLEY VIEIRA BARROS LEAL DA SILVEIRA	1	1994	1	5	M	555	6ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11878	ANTONIO EIMAR MOURA FILHO	1	1994	11	9	M	196	5ª Série - Alfa	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
443	ANDRÉ FORECCHI GIOVANNI	1	1994	2	2	M	29	6ª série B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11608	ANA FLÁVIA MACHADO 	1	1995	3	21	F	355	5 ª Série A	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15271	ANA CAROLINA BRAUNA DE OLIVEIRA	1	1994	11	4	F	555	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13439	AMANDA FREIRE SYDRIÃO DE ALENCAR	1	1994	6	21	F	527	6ª Série E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13699	Mateus Bezerra Alves da Costa	2	1991	9	25	M	367	8ª	\N	\N	\N	32	\N	\N	1	21	0	30	500	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10322	Yan da Silva Pedroni	2	1993	1	1	M	7	7ª série - Ensino Fundamental	\N	\N	\N	41	\N	\N	1	16	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13894	Fernando Mauro Alcantara	2	1993	6	23	M	216	7ª Serie do Ensino Fundamental	\N	\N	\N	41	\N	\N	1	17	0	29	483	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13857	Victor A. Moraes Carvalho	2	1992	6	9	M	216	8ª Série do Ensino Fundamental	\N	\N	\N	67	\N	\N	1	18	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13199	Rodrigo Pires Junqueira	2	1992	4	27	M	40	8ª do Ensino Fundamental	\N	\N	\N	67	\N	\N	1	19	0	27	450	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6911	Philippe Rodrigues Pádula Henriques	2	1991	3	31	M	207	8a. série	\N	\N	\N	84	\N	\N	1	18	0	26	433	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11644	MARINA ROSA SILVA	2	1993	2	9	F	196	7ª Série - Master	\N	\N	\N	99	\N	\N	1	20	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13834	Amanda Salgado Dionizio	2	1991	10	29	F	216	8ª Série do Ensino Fundamental	\N	\N	\N	99	\N	\N	1	16	0	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2919	CAROLINA REIS MAUÁ	2	1993	5	31	F	57	7ª SÉRIE B	carolina@enterdata.com.br	\N	\N	140	1	\N	1	19	0	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11890	RODRIGO LIMA PEREIRA	2	1992	6	15	M	196	8ª Série - Master	\N	\N	\N	148	\N	\N	1	16	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13839	Pedro Witor G. Silva	2	1991	10	19	M	516	8ª série	\N	\N	\N	158	\N	\N	1	18	0	18	300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16011	Tiago de Góes Lopes	2	9999	99	99	M	207	8a. série	\N	\N	\N	171	\N	\N	1	17	0	12	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14036	Wolney Barbosa da Cunha	2	1992	12	9	M	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13355	Willian Bauermann	2	1990	2	21	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12558	Willian Ananias	2	1992	9	5	M	312	7ª C	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10309	Wesley Rodrigues Ferreira	2	1992	12	15	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15257	VICTOR YUDI LIVORATTI ANDRÉ	2	1995	4	17	M	119	6º Ano	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13607	Tullyo Tomé Garcia Mariano Penasso	2	1992	7	3	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12889	Thayna Vieira Costa	2	1991	10	2	F	90	8	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15224	Thais Helena Floret Magrini	2	1992	1	23	F	144	8ª Série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15701	Thaciane Suleiman Campachi Antonio	2	1993	5	15	F	8	sétima série	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11343	Tales Augusto Monteiro Melo Mariano	2	1993	3	21	M	511	7ª	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13386	THAÍS DE SOUSA LIMA	2	1991	11	23	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1644	Silvia Steinbruch	2	1992	6	2	F	153	8ª série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13419	SANNI SILVINO PARENTE	2	1993	12	17	F	527	7ª Série E	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13601	Ruan Carlos Tadeu de Castro Esposte	2	1991	10	28	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14381	Richard José Algarve	2	1991	7	9	M	545	8a série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13344	Ricardo Cassel Schmitt	2	1991	3	13	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14591	RICCARDO ISATTO PARISE	2	1992	11	27	M	215	17MA4	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14304	Pedro Henrique Campelo Morais	2	1991	5	11	M	492	8ª série do ensino fundamental II	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15467	Patrícia Golgato Aguiar	2	1992	4	25	F	262	8ª Série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13497	Natália Custódio Viscaino	2	1993	2	20	F	540	7a série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13193	Natalia Cabral Alonso	2	1991	11	8	F	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14025	Michelli Penasso Arruda	2	1991	12	1	F	544	8a série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10304	Maycon César Mantovani	2	1993	3	3	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15095	MARIA CAROLINA THOMPSON FERREIRA	2	1992	9	27	F	11	7ª	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11829	MARIA BEATRIZ CAETANO	2	1992	5	27	F	467	8ª SÉRIE	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13600	Luiz Felipe Segatto Jorge da Cunha	2	1992	4	10	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14057	Luisa Pires de Carvalho	2	1992	1	28	F	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	1	16	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13763	Luis Gustavo Coutinho do Rêgo	2	1992	5	21	M	516	8ª série	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13188	Luciane Mirelle Corrêa Takeda	2	1991	11	4	F	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12881	Livia Branth de Arruda	2	1992	1	22	F	90	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14017	Liana Monteiro Pereira	2	1992	12	21	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15232	Jose Guilherme Augustinho	2	1992	6	20	M	483	8ª B	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11350	Jonas Emanuel Lopes Ferreira	2	1991	8	22	M	511	8ª	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15577	Janaína de Fátima Vidotti 	2	1992	8	18	F	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12628	JOSE TUPINAMBA LOPES VIANA JUNIOR	2	1992	11	28	M	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15754	IDA MARIA DE LIMA NEPOMUCENO	2	1992	1	1	F	555	8	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10298	Hortência Souza Costa	2	1993	4	22	F	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15698	Henrique Lourenço Ribeiro	2	1992	1	24	M	8	oitava série	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15264	HUGO BARBOSA LUCIANO ERNESTO	2	1992	7	2	M	119	9º Ano	\N	\N	\N	173	\N	\N	1	22	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13579	Guilherme Duarte Parra	2	1992	11	18	M	285	7ª série	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15568	Giovanny de Camargo Gerlach	2	1993	2	3	M	491	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14011	Gabriela dos Santos Ravagnani	2	1992	8	19	F	544	8a série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16091	Gabriel Bordin Martin	2	1992	8	18	M	259	8ª série	\N	\N	\N	173	\N	\N	1	18	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15579	Fernanda Carolina Ferreti	2	1992	2	28	F	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13215	Evelyn Brenda Marques dos Passos	2	1993	3	12	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14357	Enzo Brena Santos	2	1992	3	18	M	262	8ª Série	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10302	Emerson Batista da Rocha	2	1992	7	28	M	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10283	Daiane Pereira Almeida Silva	2	1991	12	21	F	393	Ciclo IV - Final A	\N	\N	\N	173	\N	\N	1	17	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11231	DANILO XIMENES BESERRA	2	1992	12	23	M	196	7ª Série - Gama	\N	\N	\N	173	\N	\N	\N	13	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11160	Cínthia Franklim da Cunha	2	1991	8	15	F	473	8 B	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10291	Bruno Felipe Gomes Bento	2	1993	5	11	M	393	Ciclo IV - Inicial B	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13180	Bruno Doutel Morais Parada	2	1991	12	3	M	40	8ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15259	BIANCA ANDRADE HANDAN	2	1994	1	30	F	119	7º Ano	\N	\N	\N	173	\N	\N	1	20	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12677	André Philippe Alves Pinto	2	1993	2	6	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12931	Anderson Dabela Luna	2	1992	5	10	M	90	8	\N	\N	\N	173	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14079	Alessandra Mari Goshiyama	2	1992	7	27	F	318	8ª Série A	\N	\N	\N	173	\N	\N	\N	9	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
191	ANA FLÁVIA MARCELINO RICCETTO	2	1992	6	29	F	48	8ª C	\N	\N	\N	173	\N	\N	\N	14	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13012	ÍCARO YAGO BORGES PITOMBEIRA	2	1992	9	9	M	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14930	YORRAN OLIVEIRA ALVES	2	1993	2	15	M	5	7o	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11232	YASMIN HOLANDA TAVARES	2	1993	2	4	F	196	7ª Série - Gama	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15507	Wellington Silva da Costa	2	1992	9	6	M	548	7ª	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12055	WILLIAM LIMA DE MELO	2	1991	8	13	M	215	18EC	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11276	WESLEY VIEIRA DE FRANÇA CORRÊA	2	1993	10	3	M	373	7ª	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12910	Vitoria Regina Domingues Sodre	2	1992	7	9	F	90	8	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12339	VICTOR CUNHA CASTRO	2	1992	10	6	M	488	7ª SÉRIE DO ENSINO FUNDAMENTAL	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16037	Thayane Surcin de Lima	2	9999	99	99	F	207	8a. série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15575	Thais Girolli Pivetta 	2	1992	1	24	F	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12815	Sergio Luiz da Silva Oliveira	2	1993	2	22	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13500	Rodrigo Roccon José	2	1992	8	10	M	540	7a série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14431	Ricardo Afonso dos Santos Albuquerque	2	1991	9	24	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1623	Raphael Bruno Alexander Valle	2	1993	5	28	M	153	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14063	Rafael Augusto Guedes de Medeiros	2	1990	11	29	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11654	RHAYANE COSTA LIMA BATISTA	2	1993	3	22	F	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14473	Paulo Phillippe da Silva Botelho	2	91	4	3	M	90	8	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15584	Paulo Eduardo Fiorin Junior	2	1991	12	5	M	491	8ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14767	Paula Emanuelly Silva Gonçalves	2	1991	8	2	F	312	8ª F	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13756	PEDRO LUCAS VIEIRA BHERING BATISTA	2	1993	11	4	M	571	1-7TA4	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12816	Nathalia de Oliveira Mendonça Souza	2	1992	8	28	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13575	Murilo Carignato	2	1993	3	16	M	285	7ª série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13982	Matheus Figueiredo Campos	2	1992	8	29	M	544	7a série	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15476	Marianne Martins de Farias	2	1991	7	6	F	548	8ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12565	Marcos Vinícius Messias	2	1993	7	4	M	312	7ª D	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12186	Manassés Da Silva Gregório	2	1992	12	17	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14797	MAURA LUCIANO QUEIRÓZ	2	1993	2	20	F	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10379	MARCELO MASCARIN WENCESLAU DE  MORAIS	2	1993	8	13	M	48	7ª C	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10362	LETÍCIA FERNANDA DA SILVA 	2	1993	8	3	F	48	7ª A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10296	Karina Spagnol Sacilotto	2	1993	5	6	F	393	Ciclo IV - Inicial A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14758	Júlio César Diniz da Silva	2	1991	6	15	M	312	8ª D	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14871	João Victor de Oliveira	2	1993	11	2	M	574	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14962	Joyce dos Santos Firmo de Jesus	2	1992	6	6	F	504	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12853	Joyce Maria da Conceição Bispo	2	1991	1	21	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12868	Joice Carvalho de Andrade 	2	1992	1	10	F	561	8ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14664	Helon Moreira Freitas	2	1993	11	24	M	527	7ª Série A - PI	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14433	Heleson Guimarães Alho	2	1991	11	26	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15779	Guilherme Henrique dos Santos Fantini	2	1991	1	1	M	313	7ªE	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13346	Gilberto Anschau	2	1990	2	19	M	288	8ª série completa	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1683	Gabriel Goldenberg Rotstein	2	1992	7	22	M	153	8ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14787	GEORGE HERNANDES GIRARDI	2	1991	10	31	M	122	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13011	FÁBIO JOSÉ COSTA BENTO JÚNIOR	2	1993	11	23	M	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13922	Francisco Aucelio Alves Marinho Junior	2	1994	4	16	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15976	Felipe Augusto Landulpho Persiani	2	1992	1	21	M	544	8a série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13168	FRANCISCA LUANA FREDERICO DO NASCIMENTO	2	1992	4	2	F	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10380	FELIPE RIBOLI MENGALI 	2	1993	3	9	M	48	7ª C	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13399	FELIPE MACHADO DE ALMEIDA	2	1993	11	14	M	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11198	EWERTON JOSÉ PEREIRA DUARTE	2	1991	10	2	M	373	7ª	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11123	Deivid José de Lima	2	1992	12	21	M	313	7ªC	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1650	Debora Abensur	2	1991	9	19	F	153	8ª serie	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14403	Daiane Cristine Negreiros Barbosa Chagas	2	1993	8	23	F	112	7ª série	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12679	Caroline Emily da Silva Pereira	2	1993	9	23	F	504	7ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13169	Caio Taveira Motta 	2	1993	9	9	M	40	7ª do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14889	Caio César Pereira	2	1992	2	18	M	285	8ª série	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1610	Bruno Charak Galacini	2	1993	7	5	M	153	7ª Série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11124	Bruna Aparecida da Silva	2	1993	9	26	F	313	7ªC	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12825	Beatriz Georg Riera	2	1993	5	29	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13113	Arthur Pimentel Barroso	2	1993	9	24	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14007	Ana Paula Geraldo Lage	2	1991	10	19	F	544	8a série	\N	\N	\N	173	\N	\N	\N	8	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13998	Ana Claudia Paiva Fontenele	2	1992	12	9	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12131	Aline Félix da Silva	2	1992	10	14	F	393	Ciclo IV - Inicial B	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12175	Abner Farias Souza	2	1993	2	16	M	313	7ªB	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13606	Yago Gattass Crepaldi	2	1992	5	9	M	462	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15730	Wanderlei Alceu Ruthmann	2	1993	11	1	M	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10922	Vítor Fernandes dos Santos	2	1993	3	16	M	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14034	Vannessa Brasil Fernandes de Oliveira	2	1992	9	22	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13021	THIAGO NUNES LIMA	2	1993	5	20	M	236	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12596	Stéphane Mariane Ribeiro	2	1991	6	17	F	312	8ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12840	Sarah Catarina Ferreira Zamorano Abi-Zaid	2	1993	2	9	F	561	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13408	SAULO VICTOR BENEVIDES NUNES	2	1993	6	5	M	527	7ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14412	Rodrigo Sousa Freires	2	1991	10	17	M	112	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11495	Rodrigo Da Silva Gonçalves	2	1993	4	29	M	313	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14765	Renato Lima de Souza	2	1991	5	17	M	312	8ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13754	Raphaela Valeriane Loureiro	2	91	11	25	F	90	8	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12874	Raphael Azevedo Vinagre	2	1991	6	14	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10415	Raone Donizetti Almeida dos Santos	2	1990	11	27	M	313	8° E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14367	Ramon Ramos Gonçalves Passos	2	1993	1	13	M	517	setima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12894	Paulo Roberto da Costa Junior	2	1992	6	30	M	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12125	Paloma Terezani Asbahr	2	1992	2	12	F	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14089	Noé Praciano	2	1993	4	5	M	516	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15021	Natália Moreira Garcia Zanni	2	1992	3	5	F	192	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13944	Natalia Holanda Maia Cavalcanti	2	1993	3	28	F	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14484	Nahomy Oliveira da Silva de Souza	2	92	6	16	F	90	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14683	NICHOLLAS GOULART DE LIMA	2	1991	1	11	M	215	18MA4	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13058	Mayara Silva de Oliveira	2	1992	8	5	F	566	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12674	Maurício Augusto Gavilan de Fátima	2	1994	2	6	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11031	Marjorie de Oliveira Tenório	2	1991	10	4	F	473	8 B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12352	Marina Mazzeo D. de Castro	2	1992	6	11	F	318	7ª Série A	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11697	Mariana Pintombeira Lage	2	1993	4	25	F	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14737	Marcelo francisco Cesário	2	1990	6	28	M	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8994	Marcela Moreira Garcia Zanni	2	1993	3	8	F	192	7ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11334	Marcela Ferrarini Ferreira	2	1993	5	28	F	511	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14143	Manoella de Araújo M. Lobo	2	1992	10	21	F	516	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15419	MARIANNA ROZAS FREITAS CAVALCANTE	2	1993	4	26	F	555	7ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11855	MANOEL NELSON FERNANDES NETO	2	1993	7	8	M	467	7ª SÉRIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15657	Luiz Rafael Miguel	2	1992	6	4	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14432	Luciana de Oliveira Paula	2	1991	4	27	F	112	8ª série	\N	\N	\N	173	\N	\N	\N	1	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11593	Lucas Kallyu Amêrico de Pontes	2	1993	4	24	M	350	7ª A (Esc. Cordeiro de Deus)	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13110	Leonardo de Alcantara Silva Ramos	2	1993	7	15	M	462	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6792	Lauany Alves Sena Silva	2	1993	11	4	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13393	LIVIA FREIRE MOREIRA PASSOS	2	1992	5	31	F	527	8ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10631	Jéssica de Aguiar Moreira 	2	1991	4	19	F	473	7 B	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13034	Jéssica Beatriz Berti Farias	2	1992	7	27	F	566	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10402	João Otávio de Oliveira Carvalho	2	1991	9	12	M	313	8°C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11362	José Guilherme Daliá Perocco	2	1991	8	20	M	511	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14055	Josue Mendonça de Carvalho	2	1992	3	3	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15740	Jefferson Luan Schiochet	2	1992	1	20	M	343	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10481	Jeferson Wesley de Moraes Oliveira	2	1992	2	18	M	157	8ª Série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6751	Jaqueline Benedito dos Santos	2	1993	8	25	F	387	7C	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11227	JULIA FARIAS DA SILVA	2	1993	4	20	F	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14237	JOÃO PAULO RODRIGUES	2	1992	6	1	M	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12584	Israel da Silva Benfica	2	1991	1	31	M	312	8ª B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14833	Igor de Mesquita Figueredo	2	1992	4	11	M	367	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11120	IEDA MARIANA DA CRUZ LIMA	2	1990	5	14	F	6	7.ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11809	IASMIN CHACUR FUJITA	2	1992	4	13	F	159	8	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11733	Histembergh Fernandes  da Costa Brito Junior	2	1992	12	20	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15252	HALANA RODRIGUES FREIRE ELOY 	2	1994	1	1	F	196	8ª Série - Master	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12127	Gustavo Fonseca Sacco	2	1991	8	28	M	393	Ciclo IV - Final B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14382	Guilherme Zanellato Oliveira	2	1992	9	21	M	545	7a série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12137	Guilherme Parente Leitão de Castro	2	1992	1	24	M	526	8ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14869	Gilmarques Feliciano da Silva	2	1993	2	13	M	574	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12850	Gabriel Henrique Joia Moreira Silva de Souza	2	1991	10	28	M	561	8ª série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13392	DOUGLAS BARROSO TEIXEIRA	2	1992	10	24	M	527	8ª Série E	\N	\N	\N	173	\N	\N	\N	2	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12812	Carlos Henrique Ananias Madeira 	2	1992	1	21	M	561	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11283	Ana Carolina Lopes Fernandes de Oliveira	2	1993	10	19	F	504	7ª série	\N	\N	\N	173	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15346	ALLANE FABELY EZEQUIEL DE ANDRADE FREIRE	2	1993	4	14	F	555	7ª	\N	\N	\N	173	\N	\N	\N	4	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13513	Victor Lassance Oliveira e Silva	4	1989	11	2	M	283	3o Semestre de 5	\N	\N	\N	31	\N	\N	1	175	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12235	DANILO MENDONÇA PEIXOTO	4	1990	6	10	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	31	\N	\N	1	80	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14010	William Vasconcelos de Morais	4	1989	2	13	M	516	3º ano	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14703	Victor Hugo Gimenes Froga	4	1990	5	4	M	5	segunda série	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13501	Victor Douglas M. Alves	4	1987	12	27	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	60	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13024	VIVIAN CRISTHINE DA ROSA SOARES	4	1989	1	19	F	23	2D	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13090	Thiago Antonio Sakr Bisinoto	4	1989	4	8	M	462	3º ano - Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14861	RICARDO ITIRO SABOTA TOMINAGA	4	1988	5	9	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	1	100	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12238	PAULO SÉRGIO DA SILVA FARIAS	4	1989	8	9	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	35	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14854	LUTY RODRIGUES RIBEIRO 	4	1988	7	23	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	42	\N	\N	\N	15	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12897	João Miguel de Oliveira Francisco	4	1988	10	7	M	83	5ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14520	George Akira Suguinoshita Accioly	4	1989	9	24	M	283	5o Semestre de 7	\N	\N	\N	42	\N	\N	\N	60	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12112	Francisco Viégas Vianna	4	1988	2	27	M	274	Primeiro período	\N	\N	\N	42	\N	\N	1	155	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10338	Fernanda Cristina Vasquez Moreira	4	1989	6	6	F	225	Terceira série do Ensino Médio	\N	\N	\N	42	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11483	Diogo Broda de Vasconcellos	4	1988	1	26	M	274	Primeiro período	\N	\N	\N	42	\N	\N	1	135	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11694	DEYVIDE RODRIGUES PEREIRA	4	1988	7	11	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	70	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12113	Alessandro Vieira Grammelsbacher	4	1986	11	12	M	4	1o semestre - Ciência da Computação	\N	\N	\N	42	\N	\N	1	160	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12069	Willian Pereira Munhoz	3	1990	10	5	M	505	Primeira Série do Ensino Médio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13997	Luis Carlos Vieira Queiroz	3	1991	7	13	M	516	1º ano	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12231	KAIO KLINGER VIANA DO NASCIMENTO	3	1988	7	30	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14389	João Vinicius Alves Maciel	3	1991	9	17	M	517	primeiro ensino medio	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15920	FRANCISCA IZABELITA DA SILVA	3	1985	1	25	F	480	1º ANO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10804	DIOGO TEIXEIRA PENA	3	1978	7	23	M	495	1ª	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14754	Cristiano Fraga Guimaraes Nunes	3	1987	10	23	M	5	primeira série	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12213	ADRIANO NAZARÉ DE SOUSA JORGE	3	1989	1	15	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13582	Francisco de Assis A.  de F. Sobrinho	2	1993	7	2	M	527	7ªPI	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10920	Fernanda Gabrielle Braz de Souza	2	1992	11	29	F	54	Sétima	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15039	Felipe Torres Abrantes de Almeida	2	1993	6	23	M	192	7ªB	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12689	Felipe Ribeiro de Sousa	2	1992	3	7	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14236	FERNANDA GONDIM TAVARES	2	1993	10	29	F	5	7o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14910	FERNANDA DE SANTANA ALVES DE SOUSA	2	1992	7	21	F	5	8o	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12281	FELIPE BORGES FONTÃO CORDEIRO	2	1993	2	17	M	487	7ª EF	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10638	Estefânia da Silva Oliveira	2	1992	12	22	F	473	7 A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
439	ESTÉFANO DE CARLI	2	1993	1	12	M	29	7ª série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12435	EDMUNDO NATANAEL VEIGA	2	1993	7	25	M	355	7ª SÉRIE A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15663	Donizete G. Soares	2	1992	4	9	M	514	8ªA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15721	Daiana Cristina Lach	2	1993	7	20	F	343	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13107	DOMINGOS SAVIO CAVALCANTE DE ARAUJO	2	1992	3	4	M	196	8ª Série - Alfa	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12058	DAMONILLY FAIRUZE M. A. VIEIRA	2	1993	3	29	F	215	17EC	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12600	Cristiano Antônio Frésca	2	1991	10	3	M	312	8ª E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13276	CHARLES TAMÊ BERNARDES NASCIMENTO	2	1992	4	2	M	59	7a	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11712	Breno de Castro Honorato Silva	2	1992	12	9	M	526	7ª Série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12570	Brenda Alaíse Nascimento	2	1993	3	27	F	312	7ª D	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14004	Bianca Berdine Martins Mendes	2	1993	7	2	F	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11513	Beatriz A. Dias Branco	2	1992	11	20	F	313	7ºE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13390	BRUNA BÁRBARA FERNANDES MOURA	2	1992	4	21	F	527	8ª Série E	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14042	Atila Amaral Brilhante Filho	2	1992	5	22	M	527	8ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
288	Alessandro Wagner Palmeira	3	1991	7	7	M	78	1EM	alessandro_palmeira@yahoo.com.br	\N	\N	1	1	\N	1	205	1	220	275	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
13518	Renato Barros Ezquerro	3	1991	3	27	M	314	1º Ano - Ensino Médio	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14351	Arthur Avantes Souza Camargo	2	1992	8	21	M	262	7ª Série	\N	\N	\N	173	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13148	Anna Caroline Fernandes Barros	2	1993	6	30	F	462	7ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15237	Amanda Guimarães Gaspar	2	1990	7	1	F	514	8ªC	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11323	Acacio Alkmin de Almeida Cassiano	2	1992	5	7	M	504	8ª série	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14633	ANDRÉ G. BARBIERI	2	1992	6	12	M	571	1-8MA2	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15438	ALAN VICTOR DEE QUEIROZ BASTOS	2	1991	2	5	M	555	8ª	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15873	ABIDAN GIDEONI MEDEIROS SOUZA	2	1992	1	14	M	480	8ª SERIE	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13142	Oscar José Fernandes Tanner	4	1987	11	4	M	557	Prim. Sem. em Ciência da Computação	\N	\N	\N	31	\N	\N	1	175	\N	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12791	Yuri Henrique Kimpel da Conceição	4	1988	12	13	M	321	3ª Ens. Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13496	Willian Antonio Freitas Abrahão	4	1988	8	22	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12935	Wilbert Azeredo Pacheco	4	1989	7	22	M	90	3 ano	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11888	Wellinghton Ferreira Pimentel	4	1987	1	24	M	493	2o. ano do ensino médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12592	Victor Soares Bursztyn	4	1987	10	2	M	274	Primeiro período	\N	\N	\N	42	\N	\N	1	175	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11721	VANICLÉIA PEREIRA BRITO	4	1988	12	15	F	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14771	Sibele Cristina do Nascimento	4	1985	12	17	F	379	2º Módulo Curso Técnico Instrumentação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14644	Rodrigo Fukuhara Souza	4	1988	5	11	M	14	1o. semestre EC	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13504	Rodolfo Magalhães Caixeta	4	1988	7	2	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11934	Renata Maria de Oliveira Marques	4	1988	9	7	F	496	3ºEnsino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12645	RUBEN CAVALCANTE MODA	4	1987	6	9	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12623	Paulo André Carvalho de Melo	4	1989	1	21	M	303	Terceiro ano do ensino medio	\N	\N	\N	42	\N	\N	1	170	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12367	OTAVIO TAVARES DOS SANTOS	4	1988	5	20	M	23	3A	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13921	Marcelo F. Landskron	4	1990	6	27	M	288	2° ano ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10792	MAÍRA LUCIANE M. Q. DE OLIVEIRA	4	1989	7	14	F	495	2ª	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14050	Luiz Henrique Magalhães Passos	4	1988	1	13	M	543	3a do médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13942	Luis Carlos Zuze Dhein	4	1984	12	28	M	288	2° ano ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13499	Luciano de Queiroz Ferreira	4	1987	7	6	M	19	1º Sistemas de Informação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13220	Lucas Ugioni do Livramento	4	1988	6	6	M	83	5ª Fase do Ensino Médio	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15848	LUANA JESSICA ALCANTARA DE SOUZA	4	1990	10	9	F	480	2° ANO - ENSINO MÉDIO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10421	Kariny Nantes Moreira	4	1988	3	5	F	14	1o. semestre EC	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14579	Jamile Rodrigues Franco	4	1989	2	1	F	515	3º colegial	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14678	Ivo Braga da Rocha	4	1990	3	2	M	367	2º	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10419	Isabela Abe de Jesus	4	1989	4	13	F	225	Terceira Série EM	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14320	Guilherme Luis Maba	4	1988	9	3	M	110	3º ano do ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15926	FRANCISCA KATARINA FERNANADES COSTA	4	1983	10	13	F	480	3º ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14778	Eduardo Pereira Vieira	4	1988	3	10	M	379	2º Módulo Curso Técnico Instrumentação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13284	Diego Thales N. Alves	4	1988	9	13	M	531	Ensino superior - 1º período	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14168	David Tiago Conceição	4	1988	1	31	M	564	1º Semestre do Ensino Superior	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13068	Danilo Miralha Franco	4	1989	1	7	M	566	3ª série Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13943	Carlos Alexandre Heidrich	4	1987	1	3	M	288	2° ano ensino médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15885	CLAUDIO REBOUÇAS DUARTE DE LIMA	4	1979	5	3	M	480	3° ANO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13310	CARLOS EDUARDO NAVARRO RIBEIRO	4	1984	1	20	M	560	7ºsem-Adm.Habilitação ANALISE SISTEMAS	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11707	CARLOS ALGUSTO BATALHA DO NASCIMENTO	4	1988	10	20	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11965	Bruno Silvério de Freitas	4	1988	10	5	M	473	3 série do ensino médio 	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14516	Bruno Henrique Rother	4	1989	2	24	M	283	3o Semestre de 5	\N	\N	\N	42	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6412	Arthur Miranda do Espirito Santo	4	1989	12	7	M	283	5o Semestre de 7	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14773	André de Césari Martins Estanislau	4	1987	5	16	M	379	2º Módulo Curso Técnico Instrumentação	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12043	Anderson Leonardo Lodeyro	4	1989	3	10	M	142	1° Módulo	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10771	AUGUSTO CESAR JUSTA CAMELO	4	1990	8	22	M	488	2º SÉRIE DO ENSINO MÉDIO	\N	\N	\N	42	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13891	Lucas Vasconcelos de Carvalho	1	1993	12	29	M	527	6ª Série 2 - PA	\N	\N	\N	138	\N	\N	1	13	0	9	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13818	Ítalo Gabriel de Sousa Fernandes	1	1995	5	19	M	516	5ª	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12771	Wendell Fonseca Pinheiro	1	1994	2	28	M	112	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11911	Vitor Hugo Cardoso Moita	1	1994	9	26	M	482	6ª série A	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14875	Vinicius Roberto Redi	1	1993	6	18	M	285	6ª série	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12743	Valdélio Pinheiro de Souza Neto	1	1993	1	16	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10765	VICTORIA FRAZAO ALVES	1	1996	2	11	F	57	4ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12433	VICTOR AUGUSTO RODRIGUES DE ARAUJO	1	1995	9	17	M	355	5ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11596	Túlio de Lima Pedrosa	1	1995	9	22	M	350	5ª A (Esc. Decisão)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15818	Rodrigo Ramos Chiaro	1	1992	2	12	M	510	8ª E	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13104	Rafael Pereira Büttner Coutinho AlvesRosas	1	1994	10	6	M	40	5ª do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13710	Normando Pinheiro Feliciano Moreira	1	1993	12	2	M	527	6ª Série A - PA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11920	Fernando Luiz Celiberto Renosto	1	1994	4	8	M	482	6ª série C	\N	\N	\N	7	\N	\N	1	10	2	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
15011	Nathália Pissaia de Souza Bastos	1	1994	10	18	F	192	5ªA	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11945	Marina Halmenschlager Foresti	1	1996	2	27	F	7	5ª série - Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11242	Marianne Beatriz de Oliveira Silva	1	1994	1	23	F	504	6ª série	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12410	JOSEVANE MOREIRA DE CASTILHO	1	1994	4	22	F	355	6ª SÉRIE B	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12718	Inaja Elisa Abi-Zaid Teixeira	1	1995	5	8	F	561	5ª serie	\N	\N	\N	166	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11814	ISRAEL ESTEVÃO SILVA FONTENELE	1	1994	12	2	M	467	5ª SÉRIE	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11559	Ginelize Mauricio Souza dos Santos	1	1994	2	4	F	350	5ª C (Esc. Rita Lessa)	\N	\N	\N	166	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11096	Erik Vinicius de Orlando Dopp Pereira	1	1994	4	19	M	313	6ªc	\N	\N	\N	166	\N	\N	\N	3	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15646	Antônio Carlos dos Santos Filho	1	1993	12	20	M	491	6ª Série do Ensino Fundamental	\N	\N	\N	166	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12699	Anderson Raphael Cunha Martins Mele	1	1994	12	28	M	561	5ª serie	\N	\N	\N	166	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14310	Abel Pereira de Macedo Borges Júnior	1	1993	10	3	M	492	6ª série do ensino fundamental II	\N	\N	\N	166	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16036	Stephanie Di Chiari Salgado	2	9999	99	99	F	207	8a. série	\N	\N	\N	122	\N	\N	1	17	0	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10615	Ícaro Borges Domingues	2	1992	4	23	M	473	7 A	\N	\N	\N	173	\N	\N	\N	6	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13373	ÁUREA CRISTINA DE QUEIROZ CASTRO	2	1992	5	3	F	527	8ª Série A	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14037	Yuri Fontenelle Lima Montenegro	2	1993	5	12	M	527	7ª Série 2 - PA	\N	\N	\N	173	\N	\N	\N	15	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11319	Vitor Renan de Oliveira	2	1992	8	24	M	504	7ª série	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11882	TEREZA CRISTINA MARQUES FORTE	2	1993	3	31	F	196	7ª Série - Master	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12657	Raphael Alberto Canellas de Oliveira	2	1993	7	8	M	7	7ª série - Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	5	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14495	RICKELLY KÉLMAN PEREIRA DE SOUZA	2	1993	1	5	F	467	7ª SÉRIE GAMA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14885	Manoel Augusto Barbosa da Costa Mendonça	2	1993	3	27	M	492	6ª série do ensino fundamental II	\N	\N	\N	173	\N	\N	\N	12	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12443	ISADORA DE CARVALHO MACHADO	2	1993	8	11	F	355	7ª SÉRIE B	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13843	Guilherme Luiz da Silva Germano	2	1993	1	27	M	216	7ª Série do Ensino Fundamental	\N	\N	\N	173	\N	\N	\N	11	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13926	Francisco Valdemar Ribeiro Araujo Junior	2	1993	8	21	M	527	7ª Série A - PA	\N	\N	\N	173	\N	\N	\N	\N	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14395	BRUNO EDUARDO DE CASTRO CARRILHO	2	1993	7	26	M	179	8º ANO A	\N	\N	\N	173	\N	\N	\N	7	0	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11961	Daniel Ribeiro Moreira	4	1988	10	14	M	490	1º período de Engenharia da Computação	\N	\N	\N	1	\N	\N	1	320	1	260	260	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
14404	André Linhares Rodrigues	4	1989	5	25	M	555	3	\N	\N	\N	2	\N	\N	1	460	1	230	230	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
10334	Mauro Cardoso Lopes	4	1988	6	23	M	96	1o Semestre	\N	\N	\N	3	\N	\N	1	270	1	200	200	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
10910	Eduardo Augusto Ribas	4	1989	8	28	M	34	3ª série do Ensino Médio	\N	\N	\N	4	\N	\N	1	405	1	170	170	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
13682	Lara Timbó Araújo	1	1995	3	17	F	367	5ª	\N	\N	\N	3	\N	\N	1	15	1	25	416	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
15093	GUILHERME THIAGO PLAZZA	1	1993	9	4	M	11	6ª	\N	\N	\N	5	\N	\N	1	15	2	24	400	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
13299	João Lucas Camelo Sá	1	1994	4	30	M	367	6ª	\N	\N	\N	7	\N	\N	1	16	2	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
12271	FILIPE CASTRO SIMÃO	1	1994	4	8	M	487	6ª EF	\N	\N	\N	7	\N	\N	1	15	2	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
15983	Ramon Silva de Lima	1	1994	7	7	M	78	5EF	\N	\N	\N	7	\N	\N	1	14	2	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
13562	Luiz Alberto Soares	1	1994	8	31	M	482	6ª série A	\N	\N	\N	7	\N	\N	1	15	2	23	383	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
10855	EDUARDO THESOLIM	1	1995	3	16	M	48	5ª C	\N	\N	\N	12	\N	\N	1	11	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
15209	Elisa Moya Kazmarek	1	1993	12	4	F	144	6ª Série	\N	\N	\N	12	\N	\N	1	13	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12270	FABIO AKIRA NAKAMA	1	1993	10	8	M	487	6ª EF	\N	\N	\N	12	\N	\N	1	14	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
2998	RAQUEL MARIA DE MENDONÇA	1	1993	9	21	F	57	6ª série	\N	\N	\N	12	\N	\N	1	16	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14152	Lucas Melo Monteiro	1	1994	5	25	M	516	6ª	\N	\N	\N	12	\N	\N	1	13	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11638	ROSANY DE LIMA ALVES	1	1993	12	5	F	196	6ª Série - Master	\N	\N	\N	12	\N	\N	1	15	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11637	ANA CARLA PIMENTEL PAIVA	1	1993	10	22	F	196	6ª Série - Master	\N	\N	\N	12	\N	\N	1	10	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14661	Fernando Mendes de Paula Pessoa	1	1994	1	31	M	527	6ª Série C - PA	\N	\N	\N	12	\N	\N	1	14	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12272	LUCAS OKUMURA ONO	1	1994	4	18	M	487	6ª EF	\N	\N	\N	12	\N	\N	1	10	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
15888	Lais Silva de Araújo	1	1994	8	15	F	492	6ª série do ensino fundamental 	\N	\N	\N	12	\N	\N	1	10	3	22	366	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
15964	Lucca Matheus Golizia	1	1994	7	7	M	78	5EF	\N	\N	\N	23	\N	\N	1	10	3	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
4221	GIULIANO FURTUNATO DA ROCHA BRITO	1	1996	5	17	M	57	4ª SÉRIE B	\N	\N	\N	23	\N	\N	1	13	3	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13675	Rubens Cainan S. Monteiro	1	1994	1	14	M	367	6ª	\N	\N	\N	23	\N	\N	1	16	3	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
15819	GABRIEL FALCINI SANTOS	1	1993	9	1	M	11	6ª	\N	\N	\N	23	\N	\N	1	12	3	21	350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11879	LEANDRO COSTA ROCHA	1	1993	11	5	M	196	6ª Série - Master	\N	\N	\N	27	\N	\N	1	12	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
14148	Fernanda Maria Queiroz Pereira	1	1994	8	25	F	516	6ª	\N	\N	\N	27	\N	\N	1	14	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
14305	João Mateus Marques de Santana	1	1993	10	4	M	492	6ª série do ensino fundamental II	\N	\N	\N	27	\N	\N	1	12	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
12042	VIVIANE S. N. DE FREITAS	1	1994	2	7	F	215	16TA4	\N	\N	\N	27	\N	\N	1	16	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
15272	Bianca Rohsner Bezerra	1	1994	2	9	F	555	6	\N	\N	\N	27	\N	\N	1	10	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
13164	Louise Goransson Savelli	1	1994	2	27	F	40	6ª do Ensino Fundamental	\N	\N	\N	27	\N	\N	1	10	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
15077	THIAGO SILVA DE FARIAS	1	1995	3	22	M	11	5ª	\N	\N	\N	27	\N	\N	1	11	0	20	333	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
13701	José Aílton Azevedo Araújo Filho	2	1991	8	13	M	367	8ª	\N	\N	\N	1	\N	\N	1	22	1	35	583	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
13182	Eduardo Kaiser Ururahy Nunes Fonseca	2	1991	12	14	M	40	8ª do Ensino Fundamental	\N	\N	\N	1	\N	\N	1	19	1	35	583	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
14989	VITOR MARGATO	2	1992	8	25	M	487	8ª EF	\N	\N	\N	4	\N	\N	1	21	2	34	566	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
13124	MATHEUS MOSTIACK POMALESKI	2	1993	11	25	M	571	1-7MA3	\N	\N	\N	4	\N	\N	1	20	2	34	566	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
13784	Davi de Melo Pontes Mendes	2	1992	6	24	M	516	8ª série	\N	\N	\N	4	\N	\N	1	22	2	34	566	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
13184	Illan Feiman Halpern 	2	1991	9	25	M	40	8ª do Ensino Fundamental	\N	\N	\N	9	\N	\N	1	22	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12262	PHILIP MEYERSIECK	2	1993	7	30	M	215	17MB2	\N	\N	\N	9	\N	\N	1	22	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
6903	Thiago Augusto da Silva Baleixo	2	1991	1	2	M	207	8a. série	\N	\N	\N	9	\N	\N	1	22	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
1614	Felipe Cebukin	2	1992	9	8	M	153	7ª série	\N	\N	\N	9	\N	\N	1	21	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14051	Guilherme Alencar Sorensen Colares	2	1992	12	15	M	527	8ª Série A - PA	\N	\N	\N	9	\N	\N	1	21	3	33	550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
15988	Rodrigo K. da Silva	2	1991	7	7	M	78	8EF	\N	\N	\N	19	\N	\N	1	16	3	32	533	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
16018	Anthony Tomaz Santos Silva	2	9999	99	99	M	207	8a. série	\N	\N	\N	19	\N	\N	1	20	3	32	533	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12098	LEONARDO SCHÄFFER	2	1991	11	8	M	215	18TA4	\N	\N	\N	25	\N	\N	1	22	0	31	516	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
12103	GUSTAVO ABDALA GEHLING	2	1991	7	9	M	215	18MA1	\N	\N	\N	25	\N	\N	1	21	0	31	516	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
16032	Pedro Caetano Cardoso	2	9999	99	99	M	207	8a. série	\N	\N	\N	25	\N	\N	1	19	0	31	516	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
14659	Rebeca Camurça Cunha	2	1991	6	14	F	527	8ª Série C - PA	\N	\N	\N	25	\N	\N	1	22	0	31	516	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
13787	Rafael R. Santiago	2	1992	7	1	M	516	8ª série	\N	\N	\N	25	\N	\N	1	22	0	31	516	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
14102	Raul Cardoso Pinheiro	2	1993	4	6	M	516	7ª Série	\N	\N	\N	25	\N	\N	1	19	0	31	516	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
12649	Carolina de Paula Peters	2	1992	2	3	F	7	8ª série - Ensino Fundamental 	\N	\N	\N	25	\N	\N	1	19	0	31	516	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
13515	Gabriel Luis Mello Dalalio	3	1991	7	4	M	314	1º Ano - Ensino Médio	\N	\N	\N	1	\N	\N	1	85	1	220	275	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	o	\N	\N	\N
11379	André Sterenberg Frankenthal	3	1990	12	18	M	303	1º ano / ensino médio	\N	\N	\N	3	\N	\N	1	100	2	110	137	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
13866	Pedro Veras Bezerra da Silva	3	1991	5	2	M	521	1° ano do ensino médio	\N	\N	\N	4	\N	\N	1	105	2	100	125	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
14587	Yuri Kunde Schlesner	3	1991	4	25	M	573	1ª Série do Ensino Médio	\N	\N	\N	5	\N	\N	1	100	2	20	25	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
14967	DEMÉTRIO DE CASTRO MENEZES NETO	3	1991	5	31	M	488	1ª SÉRIE ENS. MÉDIO	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10801	THIAGO SCHUAB VALÉRIO ALMEIDA	3	1990	2	20	M	495	2ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10796	ROBERTO MARTINS MORAIS JÚNIOR	3	1990	6	19	M	495	2ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10803	RAISA ARAÚJO MENDES SOARES DOS REIS	3	1988	1	12	F	495	1ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10795	MARCO AURÉLIO MOURA OLIVEIRA	3	1990	3	7	M	495	1ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10797	LAYONE TEODORO DA SILAVA SILVEIRA	3	1990	2	22	F	495	2ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10794	GELSNER DA SILVA PENHA	3	1990	3	7	M	495	2ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11380	Luis Felipe Teixeira de Moraes	3	1990	9	2	M	303	1º ano / ensino médio	\N	\N	\N	6	\N	\N	1	185	3	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11378	Bernardo Figueiredo de Castro Ainbinder	3	1991	5	19	M	303	1º ano / ensino médio	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12315	Erick Iussuke Ebesui	3	1991	8	17	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13961	Rosangela Aparecida Pasqualli	3	1991	1	17	F	516	1º ano	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13953	Pollyanna Stéfani Borges Freitas	3	1990	10	6	F	516	1º ano	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14164	Francisco C. M. P. Júnior	3	1991	4	15	M	516	1º ano	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14405	Marlen Lincoln da Silva	3	1990	7	17	M	555	1	\N	\N	\N	6	\N	\N	\N	10	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14420	Levi Almeida Coelho	3	1991	6	12	M	555	1	\N	\N	\N	6	\N	\N	1	105	3	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14419	Francelino Franco Leite de Matos Souza	3	1991	3	19	M	555	1	\N	\N	\N	6	\N	\N	\N	20	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14080	Camilla Matias Morais	3	1990	12	18	F	516	1º ano	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14711	Lucas Ceccato Silva	3	1990	11	15	M	5	primeira série	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11921	Alessandra Gomes da Silva	3	1989	9	27	F	496	3ºEnsino médio	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13116	REBECCA FAGGION ALBERS	3	1991	9	13	F	309	1ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13112	MATHEUS LUÍS DOCEMA	3	1990	9	13	M	309	1ª	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12230	LUAN CAVALCANTE PEREIRA	3	1990	5	12	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12220	JHOZEFEM DA SILVA PONTES	3	1991	5	13	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12077	Heitor Keidy Sonoda	3	1990	7	9	M	505	Primeira Série do Ensino Médio	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11810	David Nissimoff	3	1990	1	22	M	153	2º Ens Médio	\N	\N	\N	6	\N	\N	1	110	3	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12145	ALINE FINOTTI BITTAR	3	1990	12	6	F	215	1ª série Ensino Médio	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12215	ROBERTO DE ALMEIDA CRUZ NETO	3	1991	1	20	M	117	1ª ENSINO TÉCNICO	\N	\N	\N	6	\N	\N	\N	5	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12064	Nicholas Matuzita Miizoguchi	3	1990	6	26	M	505	Primeira Série do Ensino Médio	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10464	LINDOMÁRIO SOUSA LIMA	3	1991	4	11	M	488	1º ANO DO ENSINO MÉDIO	\N	\N	\N	6	\N	\N	1	100	3	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
12309	Henrique Hiroshi M. Watanabe	3	1990	12	27	M	487	1ª EM	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14825	Edgard Nakamoto	3	1992	6	6	M	78	1EM	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14163	Alison de Sousa Rebouças	3	1991	3	22	M	516	1º ano	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11370	André de Freitas Smaira	3	1990	6	11	M	511	1º	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13516	Murilo Murbach Travareli	3	1991	3	1	M	314	1º Ano - Ensino Médio	\N	\N	\N	6	\N	\N	\N	0	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13517	Fábio Mallaco Moreira	3	1991	2	27	M	314	1º Ano - Ensino Médio	\N	\N	\N	6	\N	\N	1	105	3	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10275	Diego Andrés de Barros Lima  Barbosa	4	1989	7	17	M	407	3ºano ensino médio	\N	\N	\N	5	\N	\N	1	320	2	150	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
14173	Victor Arndt Mueller	4	1988	1	12	M	564	1º Semestre do Ensino Superior	\N	\N	\N	5	\N	\N	1	185	2	150	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
11482	Caio Guimarães Souza	4	1988	1	15	M	274	Primeiro período	\N	\N	\N	5	\N	\N	1	325	2	150	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
11621	Bruno Bottino Ferreira	4	1989	8	7	M	274	Primeiro período	\N	\N	\N	8	\N	\N	1	240	2	140	140	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
10767	LUCAS TEIXEIRA SÁ	4	1987	11	18	M	488	ENSINO MÉDIO COMPLETO EM DEZEMBRO 2005	\N	\N	\N	8	\N	\N	1	185	2	140	140	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
9159	Renato Felipe Atilio	4	1989	2	27	M	283	3o Semestre de 5	\N	\N	\N	10	\N	\N	1	110	2	130	130	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
14552	Ricardo Hahn Pereira	4	1992	6	6	M	78	2EM	\N	\N	\N	10	\N	\N	1	490	2	130	130	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
12318	Cesar Ryudi Kawakami	4	1988	11	16	M	487	3ª EM	\N	\N	\N	10	\N	\N	1	290	2	130	130	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	p	\N	\N	\N
13877	Guilherme Oliveira Campos	4	1986	3	22	M	372	1o - BSI	\N	\N	\N	13	\N	\N	1	165	3	120	120	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13005	ALEXANDRE COELHO RONDON	4	1990	1	6	M	23	2B	\N	\N	\N	14	\N	\N	1	80	3	110	110	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
13988	Felipe Holanda Moreira	4	1990	2	1	M	516	2º ano	\N	\N	\N	14	\N	\N	1	175	3	110	110	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14977	Paulo Victor Teixeira Eufrasio	4	1987	10	24	M	559	Primeiro semestre da faculdade	\N	\N	\N	14	\N	\N	1	340	3	110	110	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14857	GABRIEL TAVARES BUJOKAS	4	1988	5	21	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	14	\N	\N	1	465	3	110	110	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
2464	Paulo Roberto Almeida Costa	4	1987	10	24	M	283	7o Semestre de 7	\N	\N	\N	14	\N	\N	1	465	3	110	110	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
11711	CRISTIAN ROSSI	4	1989	9	17	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	19	\N	\N	1	145	3	100	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
1920	Diego Carneiro Camara	4	1989	2	17	M	283	5o Semestre de 7	\N	\N	\N	19	\N	\N	1	145	3	100	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10258	Rodrigo Rafael Santos Costa Chiossi	4	1987	8	24	M	96	1o Semestre	\N	\N	\N	19	\N	\N	1	245	3	100	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
10607	Felipe José de Oliveira	4	1989	3	8	M	469	3º Colegial	\N	\N	\N	19	\N	\N	1	175	3	100	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	b	\N	\N	\N
14858	ALFREDO SANDES SAMPAIO	4	1988	7	1	M	45	1 ANO / ENS. SUPERIOR	\N	\N	\N	23	\N	\N	1	140	\N	80	80	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
13239	Marcos Vinícius Cracco Bozza	4	1988	9	25	M	519	1	\N	\N	\N	23	\N	\N	1	145	\N	80	80	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
7317	Igor Machado Coelho	4	1988	4	11	M	379	3º Ano	\N	\N	\N	23	\N	\N	1	220	\N	80	80	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
13	Tiago Madeira	4	1990	7	6	M	7	2º ano do Ensino Médio	tiagomadeira@terra.com.br	\N	\N	23	1	\N	1	345	\N	80	80	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
14580	Rodrigo Alves Lima 	4	1992	6	6	M	78	2EM	\N	\N	\N	27	\N	\N	1	295	\N	50	50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
11718	VITOR FERREIRA MENDONÇA	4	1989	7	22	M	117	3º ano de Informática/do Ensino Médio	\N	\N	\N	28	\N	\N	1	175	\N	40	40	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
12237	JEYSON RODRIGUES MOREIRA	4	1987	7	8	M	117	2ª ENSINO TÉCNICO	\N	\N	\N	29	\N	\N	1	210	\N	30	30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
10789	Victor Moreira Araújo	4	1988	4	27	M	490	1º período de Engenharia de Computação	\N	\N	\N	29	\N	\N	1	105	\N	30	30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	h	\N	\N	\N
\.


--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: obi
--

COPY public.level (level_id, level_short_name) FROM stdin;
1	I1
2	I2
3	P1
4	P2
5	PJ
6	PU
\.


--
-- Data for Name: school; Type: TABLE DATA; Schema: public; Owner: obi
--

COPY public.school (school_id, school_code, school_name, school_address1, school_address2, school_address3, school_zip, school_city, school_state, school_ddd, school_phone, school_deleg_name, school_deleg_email, school_deleg_ddd, school_deleg_phone, school_deleg_conf, school_deleg_login, school_type, school_deleg_username, school_prev, school_address, school_address_number, school_address_complement, school_address_district, school_is_known, school_is_site_phase3, school_site_phase3_show, school_site_phase3, school_site_phase3_type, school_site_phase3_prog, school_site_phase3_ini, school_address_building, school_address_map, school_has_medal, school_hash, school_inep_code, school_ok, school_turn_phase1_prog, school_turn_phase1_ini, school_address_other, school_change_coord) FROM stdin;
586	0	ESCOLA ESTADUAL SEMINARIO	RUA JOVINA SCHUNCK, 37	CIPO		06900000	EMBU GUAÇU	SP	11	46631203	JUCILENE OLIVEIRA COSTA	relu_neves@ig.com.br	11	46631648	costa2	jucilene	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
591	0	Centro Educacional São Francisco de Assis	Rua F Numero 172  Bairro Staff			68240-000	Monte Dourado	PA	93	37351428	Amilton Oliveira de Araújo	amiltom@gmail.com	93	81117838	juvelino	amiltom	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
589	0	Colégio de Aplicação da UFPE	Rua Acadêmico Hélio Ramos sn	Cidade Universitária		50740530	Recife	PE	81	21268329	ROGÉRIO DA SILVA IGNÁCIO	ignacio@ufpe.br	81	88144428	r141076	ignacio	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
478	481403	ORGANIZAÇÃO EDUCACIONAL FARIAS BRITO	RUA BARÃO DO RIO BRANCO, 2424 - CENTRO			60000000	FORTALEZA	CE	85	64647744	JOSÉ CARLOS FERREIRA BASTOS	jjcarlosb@zipmail.com.br	85	64647744	121212	josecarlos	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
475	666598	Coopem	Rua Eduardo Angelino 1130	Bairro São José		15130000	Mirassol	SP	17	32425185	Maria Amélia Alves Stival	mariamellia@gmail.com	17	32425185	taurina	mariaamelia	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
485	662318	E. E. JOÃO MICHELIN	Rua Manoel Joaquim Garcia, nº 1045	Bairro: Centro		18.730-000	Itai	SP	014	3761 1447	Tania Maria Bergamo Camargo	tania_bc@hotmail.com	014	3761 1447	bergamo	Tania Bergamo	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
474	469926	E.E.ÍTALO BETARELLO	RUA ANDRESA,120 - JARAGUÁ			02995-010	SÃO PAULO	SP	11	3941.4746	Daniel Gelini Quaresma	ibetarello@ig.com.br	11	3941.4746	esporte	Daniel	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
477	665015	Grupo Educacional Ideal	 Rua dos Mundurucus, 1412			66035-360	Belém	PA	91	32419121	Antonio Eurico da Silva Dias	ranido@ic.unicamp.br	91	88472851	040702	arch_ryven	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
476	911177	UNESP - Rio Preto	R. Cristovão Colombo, 2265	J. Nazareth		15054-000	São José do Rio Preto	SP	17	3221-2201	Aleardo Manacero Jr.	ranido@ic.unicamp.br	17	3221-2228	cica1amo	aleardom	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
471	979945	Universidade Salvador - UNIFACS	Al. das Espatódias, 915 - C das Árvores	Campus Iguatemi 		41820-460 	 Salvador - BA	BA	71	3273-8567	Isaac Douglas Moreira	ranido@ic.unicamp.br	71	3341-4186	ravena	isaacmoreira	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
494	694363	E.E. PROFª MARIA DO CARMO LELIS	RUA LIONS CLUB, S/Nº - MORADA DOS NOBRES			16022-000	ARAÇATUBA	SP	18	36310091	LUCIA RODRIGUES DE SOUSA	ranido@ic.unicamp.br	18	36310793	mclelis	luciaroso	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
423	817164	Instituto de Educação e Cultura Unidade Jardim Pueri Domus	Rua silveiras, 70- Vila Guiomar			09071100	Santo André	SP	11	44258537	José Willian Costa	ranido@ic.unicamp.br	11	44258537	gabigui	jwillianc	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
457	537586	Coltec - UFMG	 Av. Antônio Carlos, 6627			CEP 31270-	Belo Horizonte	MG	031	34994973	Humberto Honda	ranido@ic.unicamp.br	031	32252337	burgundio	humberto	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
531	-979017	Centro Universitário Senac	Rua Eusébio Stevaux, 823			04696-000	São Paulo	SP	11	5682-7545	Jefferson Zanutto	jefferson.zanutto@sp.senac.br	11	5682-7545	3bola60	jefferson.zanutto	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
96	-807752	UNICAMP - Universidade Estadual de Campinas	Av. Albert Einstein, 1251			13084-971	Campinas	SP	19	3788-5838	Rodolfo Jardim de Azevedo	rodolfo@ic.unicamp.br	19	3788-5857	1rja%rmm	aires	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
309	-325275	Cooperativa Educacional de Leme - COOPEL	Av. Paul Harris, 1155			13613190	Leme	SP	19	3572-1335	Izabel Cristina Custódio Volpe	coordenacao@coopel.com.br	19	3572-1335	zuzu33zuzu	izabel	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
510	-520229	EE  MATILDE VIEIRA	PRAÇA CORONEL EDMUNDO TRENCH, 104			18701-053	AVARÉ	SP	14	3732-0108	LADILSON APARECIDO CANASSA	laucanassa@ig.com.br	14	3732-0108	laucanassa	laucanassa	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
489	-290867	ETE Philadelpho Gouvea Netto	Avenida dos Estudantes nº 3278	Jardim Aeroporto		15035-010	São José do Rio Preto	SP	17	32339266	Maria Teresa Vilela Puia	mtpuia@click21.com.br	17	32339266	mtpobi	mtpuia1	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
459	125790	Universidade Candido Mendes	Rua Anita Peçanha, 100	Pq. São Caetano		28040-320	Campos dos Goytacazes	RJ	22	2733-4100	Luiz Maurício de Oliveira Monteiro	ranido@ic.unicamp.br	22	9813-6436	136436	mauricio	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
506	844501	UFBA	Av. Adhemar de Barros S/N	Campus de Ondina		40.170-110	Salvador	BA	71	32636143	Luciano Porto Barreto	ranido@ic.unicamp.br	71	32636505	ftcs2000	lucianoufbaobi	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
412	546634	Escola de Ensino Fundamental e Médio "Tenente Rêgo Barros"	Avenida Júlio Cesar, s/n, Souza			66613-010	BELÉM	PA	91	32316526	LUIZ OTÁVIO MACIEL MIRANDA	ranido@ic.unicamp.br	91	3214 6335	ESCOLA	PROF_MATH	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
417	100871	Colégio e Curso Santos Dumont	Rua João Marcelino, 65 - Centro			59678-000	Tibau	RN	84	8803-4071	Luiz Nazareno de Souza	ranido@ic.unicamp.br	84	8803-4071	euteamo	luiznazareno	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
413	863480	Colégio Salesiano Itajaí	R. Felipe Schmidt, 87 - Centro			88.300-000	Itajaí	SC	47	3348-2021	Márcia Silva Madeira	ranido@ic.unicamp.br	47	3348-2021	110566	marcia	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
458	919185	Colégio Militar de Curitiba	Praça Conselheiro Thomas Coelho, 01			82800030	Curitiba	PR	41	33662001	Daniel Birck	ranido@ic.unicamp.br	41	88041693	amarelo	danielbirck	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
470	552449	EE Reverendo Erodice Pontes de Queiroz	Rua Amaro Alves do Rosario 1500			04865000	São Paulo	SP	11	59796959	Berenice Teixeira de Santana	ranido@ic.unicamp.br	11	38857099	reverendo	Berenice	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
592	0	escola estadual de ensino fundamental rosa alvarez rebelo	rua sete de setembro,576	centro		68360000	senador jose porfirio	PA	93	91269102	afntonio neude dantas de paiva	neudesmaira@hotmail.com	93	91274880	elita01	neudesmaira	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
575	0	EE OLIVIA BIANCO	PROF JOSE MARTINS DE TOLEDO, 394 			13403 032	PIRACICABA	SP	19	34227235	Vera Alice	bethangelocci@yahoo.com.br	19	34227235	356535	escolavera	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
553	216687	Teste	a	a	a	13084-971	Campinas	SP	22	222	Rui Castro	ranido@ic.unicamp.br	11	6722-4087	rurururu	ruru	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
558	996251	Colegio Peq	Rua Juvenal da Silva Pires , nº57			08940-000	Biritiba Mirim	SP	11	4692-1366	Marcelo Peq	colegio.peq@terra.com.br	11	4692-1366	brzbrz	Marcelo Peq	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
576	0	E.E. Evilázio de Góes Vieira	Avenida Cristiano Vieira Pedrico nº568			18115-390	Votorantim	SP	015	32421188	Paulo Aires Pimenta Junior	paulo_pimenta@universia.com.br	015	3343-67-84	pimenta28	pimenta29	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
571	-503326	Colégio Visconde de Porto Seguro - Unidade II - Valinhos	Rodovia Visconde de Porto Seguro, 5701	Jd. Itamaracá		13278327	Valinhos	SP	19	38295000	Elisângela Pólvora da Silveira	epsilveira@portomail.org.br	19	38814114	picasso	epsilveira	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
472	-805894	E.E."Patriarca da Independência"	Rua Rui Barbosa, nº 55			13280-000	Vinhedo	SP	19	38761379	Simone Aparecida de Camargo	simonecmrg@hotmail.com	19	38761379	lilo10	Simone	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
467	-928326	Colegio Master S/C  LTDA	Rua Benjamim Moura, 631	Cidade dos Funcionários		60822-480	Fortaleza	CE	085	40090101	Socorro Katiussia Sousa dos Reis	katiussiace@hotmail.com	085	40090101	ms2006	Reis	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
468	-389158	E. E. José Gabriel de Oliveira	Av. de Cillo			1345005	Santa Bárbara d´Oeste	SP	19	34636815	Alexandre Visockas	ranido@ic.unicamp.br	19	96250802	015151	Prof. Xura	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
411	-845666	EE Heloisa Vilalba	Rua 12 de abril			11000-000	São Paulo	SP	11	5555 6666	Ricardo Raphael	menderico@gmail.com 	11	5555 6666	ricardorap	ricardoraphael	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
469	-802307	Colégio Madre Iva	Nelson Raineri, 700	Bairro Lageado	Rod.Raposo Tavares, KM 34,5	06700-500	Cotia	SP	11	4703-2780	Renato de Moraes	ranido@ic.unicamp.br	11	4703-6390	282984	madreiva	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
488	-824335	Colégio Ari de Sá Cavalcante  Sede Duque de Caxias	Av. Duque de Caxias nº 519  	Bairro: Centro		60035-110	Fortaleza	CE	085	32552900	Carlos Eurico Ribeiro Rodolpho	carloseurico@aridesa.com.br	085	32552900	ben-hur	carloseurico	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
464	371502	Unisal-Lorena	R. Dom Bosco 284			12600-100	Lorena	SP	012	31592033	Reinaldo Gen Ichiro Arakaki	menderico@gmail.com	012	31592033	rgia123	rgialorena	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
577	0	SESI - Laura Nascimento Loureiro	Av. Civit, 160, Laranjeiras			29165130	Serra	ES	27	33283896	Jackson Amaral dos Santos	interjackson@yahoo.com.br	27	32823781	nik123	interjackson	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
565	570358	Colégio Ceiva de Edcação Infantil, Ensino Fundamental/Médio	Praça Tiradentes, 194	Centro		39480-000	Januária	MG	38	3621-1403	Fábio Savioli	Luiz765@hotmail.com	38	3621-1403	savioli	Savioli	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
25	49999	EEFM Hildeberto Barroso	Av Leida Soares 1205 - Deserto			62502000	Itapipoca	CE	088	36735002	Marciana de Sousa Cunha	marcianasousa@yahoo.com.br	088	36735063	leandro	Leandro	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
578	0	Organização Educacional Evolutivo	Rua 24 de 1345 - centro			600000	Fortaleza	CE	85	4008-8209	Íris Sérgio Charry de Magalhães	olimpiadas@evolutivo.com.br	85	88471364	supervisao	evolutivo	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
579	0	Escola Estadual Profa. Amira Homsi Challela	Rua Luiz Figueiredo Filho, 1273			15084180	São José do Rio Preto	SP	017	3227-5699	Luis Otavio Piocoppi	nidekaiser@yahoo.com.br	17	32275699	fisica	Evanilde Kaiser	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
580	0	emef prof vicente rao	rua joao batista pupo de moraes, 430	pque industrial		13031690	campinas	SP	19	32722044	andrea ferreira otero	vicenterao@ig.com.br	19	32376149	escola	escolavicente	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
581	0	Colégio Ceiva de Educação Infantil, Ensino Fundamental/Médio	Praça Tiradentes, 194	Centro		39480-000	Januária	MG	38	3621-1403	Fábio Savioli	luiz765@hotmail.com	38	3621-1403	savioli	fábio	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
53	-178934	GENESIS CURSOS E PRÉ VESTIBULINHO	RUA QUINTINO CARDOSO RIBEIRO, 33	VILA BÉTICA		13450-320	SANTA BÁRBARA D'OESTE	SP	19	3455-7143	SAMARA SCALON DE ALMEIDA PERES	ssap@terra.com.br	19	3455-7143	130379	SAMARA	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
582	0	ETE "Pedro Ferreira Alves"	Rua Ariovaldo Silveira Franco, 237	Mirante		13801-005	Mogi Mirim	SP	19	3862 0888	Marcelo Oliveira de Moraes	marcelomogi@gmail.com	19	9124 3830	127730m	marcelomogi	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
583	0	escola estadual de ensino medio rosa alvarez rebelo	rua sete de setembro,576			68360000	senador jose porfirio	PA	93	91260562	antonio neudes dantas de paiva	neudesmaira@hotmail.com	91	35561232	elita01	neudes	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
507	24580	Colégio Ceiva de Ensino Fundamental e Médio	Praça Tiradentes, 164 - Centro			39480-000	Januária	MG	38	3621-1403	Fábio Savioli	luiz765@hotmail.com	38	3621-1403	sabbacadab	Fabão Heavy Metal	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
584	0	Colégio Santa Emília	Rua Marfim, 375	Jardim Atlântico		53140280	Olinda	PE	81	34913416	Paulo Marcelo Pontes	pmarcelopontes@gmail.com	81	34929356	p2o777	pmarcelopontes	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
530	-692648	E.M.E.F. "José Maria Lisboa"	Praça João Rodrigues nº 575	Jardim da Saúde		04290-090	São Paulo	SP	11	5061-1447	Tania Cristina Justo	ranido@ic.unicamp.br	11	9817-5538	051071	taniajusto	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
482	-212882	Colégio Koelle	Rua 5 nº 1827 - Centro			13500181	Rio Claro	SP	19	3522.4400	Sergio Barbosa	ranido@ic.unicamp.br	19	3533.2391	koelle	profkoelle	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
463	-87922	Unidade Integrada Pedro Neiva de Santana	Rua da Matriz s/n Pov. Mineirinho			65398-000	Alto Alegre do Pindaré	MA	98	365880-94	Valdir Vasconcelos Sampaio	ranido@ic.unicamp.br	98	365880-47	102030	valdir	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
495	-703933	Colégio Universitário Padre de Man	Av. Presidente Tancredo Neves 3500	Bloco D	Bairro Universitário	35170056	Coronel Fabriciao	MG	31	38467921	Adilson Mendes Ricardo	ranido@ic.unicamp.br	31	88341901	padredeman	adilsonmr	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
421	716122	E/CRE(03.12.025)E.M. PROFª ARMINDA MOREIRA PÁDOVA	RUA CHAPADINHA, S/Nº - DEL CASTILHO			21051-300	RIO DE JANEIRO	RJ	021	2270-6090	MARIA JULIA RAMOS GONÇALVES	emppadova@pcrj.rj.gov.br	021	2270-6090	070497	THEREZINHA	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
419	337360	EE CONSELHEIRO CRISPINIANO	AV ARMINDA DE LIMA, 57	ANTIGO 75	VILA PROGRESSO	07095010	GUARULHOS	SP	11	64090800	JOÃO LUIS ALVES MONTEIRO	profjl@uol.com.br	11	64090800	informátic	eecc	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
528	718606	Secretaria Municipal de Educação	Rua Marilândia, 275,	Bairro Novo horizonte		29950000	Jaguaré	ES	27	37691770	Juscelino Ribeiro dos Santos	jucelinorsantos@hotmail.com	27	37691770	tecnologia	Semec	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
486	674682	Colégio Dom Bosco	Av General Afonseca, 313			27520-172	Resende	RJ	24	3355-3608	Paulo Cesar Ferreira de Oliveira	pcfo@oi.com.br	24	3355-3608	parrudinho	belini	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
481	981709	E.E. ANTONIO LUIZ BARREIROS	R: Paulo Horcel, 404 - Japui			11013325	Sao Vicente	SP	13	35671412	Rosangela Rosa da Costa	rosangelsrosa2003@ig.com.br	13	35671412	181169	Rosangela	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
461	-117117	Colégio Seletivo	Rua Engenheiro Agronomo Romano Coury	nº 481 - Bairro Caxambu		13420025	Piracicaba - SP	SP	19	34113130	Thiago Rozineli	trozineli@uol.com.br	19	34113130	34113130	trozineli	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
483	-864682	COLÉGIO NOSSA SENHORA DA ASSUNÇÃO	DR ALCIDES VIEIRA ARCOVERDE, 620			81520260	CURITIBA	PR	41	32962135	ANA LUCIA BERNO BONASSINA	informatica@felicianas.com.br	41	32962135	VICTOR	BONASSINA	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
505	-329857	Colégio Etapa - Valinhos	Avenida Dr. Antônio Bento Ferraz, 95			13278-160	Valinhos	SP	19	3881-8181	Carlos Yuzo Shine	ranido@ic.unicamp.br	11	2187-1000	obi2006	Shine	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
498	-831766	UNISAL-LORENA	R. Dom Bosco 244 			12600-290	Lorena	SP	12	31592033	Reinaldo Gen Ichiro Arakaki	ranido@ic.unicamp.br	12	39231282	rgia521	arakaki	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
487	-841913	Colégio Etapa	Rua Vergueiro, 1951			04101-001	São Paulo	SP	11	2187-1000	Edmilson Luis Rodrigues Motta	ranido@ic.unicamp.br	11	5908-1134	danielt	Etapa	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
58	-871442	Escola Estadual Homero Silva	Rua 9 de julho, 335	jd. canhema		09941-380	Diadema	SP	11	40754610	Cleiton Alves de Souza	cleiton.brasil@gmail.com	11	40911873	joao316	cleiton.souza	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
572	-81502	Colégio Santa Teresinha	Rua SAnto Inacio de Loiola, 196			93700000	Campo Bom	RS	051	35971215	Henrique Werno Korndorfer	hwk@santa.g12.br	051	35971215	ironmaiden	quinho_k	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
192	-117030	SESI - CAT. "JOSÉ TARQUÍNIO DA SILVA"	Rua Tupinambas, 240	Jardim da Penha		29060-810	Vitória	ES	27	3334-7303	BRUNO SILVEIRA DE CASTRO	brunoscastro@gmail.com	27	3334-7303	sesijp	brunoscastro	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
573	-393765	Escola de Educação Básica Educar-se	Av. Independência, 2293, Blocos 7 e 8	Bairro Universitário		96815-900	Santa Cruz do Sul	RS	51	37177566	Paulo Gaspar Graziola Junior	pauloj@unisc.br	51	92462698	fantasma	pgraziola	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
574	-308030	Colégio São José Curitiba	Pça Rui Barbosa, 661			80010-030	Curitiba	PR	41	3018-4500	Helen Tessari Brandão	helen@saojosecuritiba.com.br	41	9611-9980	sj2006	helen	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
561	-638361	ADN JUNIOR COLEGIO	RUA OLDEGARD SAPUCAIA, 17	MÉIER		20710005	RIO DE JANEIRO	RJ	021	32730941	edson costa	edsonquimica1@yahoo.com.br	021	99630450	adnjunior	adnjunior	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
564	-521444	Universidade Regional de Blumenau - Campus IV	R. Braz Wanka, 238	Bairro Vila Nova		89036-160	Blumenau	SC	047	3321-7801	Mauricio Capobianco Lopes	mclopes@furb.br	047	3321-7801	bccsislic	mclopes	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
20	-22643	Colégio Marista de Brasília - Ensino Médio	SGAS Qd 615, Módulo C n- Av. L2 Sul			70200750	Brasília	DF	061	4456900	Paulo da Nóbrega Bezerra	pbezerra@marista.org.br	061	4456934	603043	pbezerra	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
29	-104408	CENTRO EDUCACIONAL CASA DO ESTUDANTE	RUA MARIO PIMENTEL ROCHA	213	BAIRRO NOVA ARACRUZ	29190-000	ARACRUZ	ES	27	32562319	EVANDRO MARTINHO DE OLIVEIRA	evandro@educacional.com.br	27	32562319	casaest	casaest	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
562	-651513	E.M. 0515039	QUINTINO BOCAIÚVA 			21380210	RIO DE JANEIRO	RJ	21	22690648	VANESSA DUPHEIN PINHEIRO	vanebrrj@bol.com.br	21	25959852	historia1	vanessaduphein	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
563	-176675	Universidade Gama Filho	Rua Manoel Vitorino, 553			20748900	Rio de Janeiro	RJ	21	2599 7205	Érica Ribeiro de Oliveira	erica@ugf.br	21	8753 6088	comp2006	comp_ugf	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
493	-739515	UNIVERSIDADE FEDERAL DE ITAJUBÁ	Av. BPS, 1303	Bairro Pinheirinho		37500-903	Itajubá	MG	35	3629-1405	Edmilson Marmo Moreira	edmarmo@unifei.edu.br	35	3692-1405	Ka155976	edmarmo	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
16	-376015	Faculdade 7 de Setembro	Rua Alm. Maximiano da Fonseca, 1395	Bairro Eng. Luciano Cavalcante		60811-020	Fortaleza	CE	85	40067600	Vitor Almeida dos Santos	vitoralmeida@fa7.edu.br	85	99970056	doug1230	vitoralmeida	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
11	-266392	Colégio Terras	R. Prof. José Benedicto Gonçalves, 309			13.300-000	Itu	SP	11	4024-1902	Clodoaldo Carlini	clodoaldo@deskvision.com.br	11	8353-5317	250391	clodoaldo	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
282	-750102	Unoeste - Universidade do Oeste Paulista	Av. José Bongiovani, 700	Cidade Universitária		19050-900	Presidente Prudente	SP	18	2291060	Marcelo Vinícius Creres Rosa	mao@unoeste.br	18	2291060	obi2006	mao	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
175	-270823	COLEGIO ADAMANTINENSE JUNIOR	Alameda Fernão Dias, 1372 - Vila Jurema			17800-000	Adamantina	SP	018	3521-2047	JORGE ANTONIO DA SILVA	JORGEVR_BR@YAHOO.COM.BR	018	3521-2934	279101	cl_adamantinense	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
325	596466	E.M. 'PROF. GIUSEPPE CARNIMEO'	TRAVESSA SEBASTIÃO BOTACINI S/N º			14781218	BARRETOS	SP	17	3323-1161	SUELI MORAES	escolagcarnimeo@bol.com.br	17	3322-7840	giuseppe	direcao	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
250	942003	COLEGIO ESTADUAL URBANO CARLOS DE ALMEIIDA	RUA MARIA ALMEIDA PEÇANHA, S/Nº - MONTE 			25810280	TRES RIOS	RJ	24	22559915	CRISTINA  IRACY GOMES DALCOL	uca@md3net.com.br	24	22559577	311586	CRSTINA 	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
128	700711	E.T.E. "Prefeito Alberto Feres"	Avenida Senador Cesar Lacerda de	Vergueiro, nº: 690 - Jardim Cândida		13603-013	Araras	SP	19	3541-2819	José Calixto	js_calixto@yahoo.com.br	19	3541-2819	sucesso	jscalixto	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
189	291498	Colégio Peq. Núcleo Meu Pequeno Mundo	Rua  Francisco Pereira Camargo no. 11			08940000	Biritiba Mirim	SP	11	4692-1366	Marcelo Tcacenco	colegio.peq@terra.com.br	11	4692-1366	terra44aa	Marcelo Tcacenco	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
508	-987968	E E PROF LUIZ CASTANHO DE ALMEIDA	CAMPOS SALES 11-22			17050-000	BAURU	SP	14	32381101	MARCELA LOPES DA SILVA	marcelalds@hotmail.com	14	32381101	jacymogone	marcelalds	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
497	-184477	Colégio Objetivo Bragança	Rua Palmiro Orsi, 121     Jd. Bela Vista			12900-000	Bragança Paulista	SP	11	4034-4444	Gabriela Anselmo Raymundo	profgabi@gmail.com	11	4034-4444	gbrlgbrl	Gabriela	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
490	-403818	Universidade Federal do Rio Grande do Norte	UFRN/CCET/DIMAp	Campus Universitário	Lagoa Nova	59072-970	Natal	RN	084	3215 3814	David Déharbe	deharbe@gmail.com	084	3215 3814	Iaorana8	daviddeharbe	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
479	-96725	Escola ULBRA São Lucas	Rua 25 de Julho, 550 	Bairro Vargas		93222-000	Sapucaia do Sul	RS	51	34517557	Silvio Cesar Viegas	scviegas@brturbo.com.br	51	34517557	sl2006	saolucas	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
416	-241764	Faculdades DOCTUM - Campus Cataguases	Avenida Cel. Antônio Augusto, nº 442	Vila Teresa		39200-000	Cataguases	MG	32	 3422-7005	Renato Afonso Cota Silva	renatoacs@doctum.com.br	32	 3422-7005	renbr018	renatoacs	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
559	-811708	Universidade Federal do Ceará	Bloco 910 - Campus do Pici			60455-760	Fortaleza	CE	85	40089847	Cláudia Linhares Sales	silveiraneto@gmail.com	85	40089847	obi1234	silveira	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
533	-727548	COLÉGIO MARISTA NOSSA SENHORA DA PENHA	AV. CHMAPAGNAT, 925 - CENTRO			29100-012	VILA VELHA	ES	27	4009-4200	FLAVIO MAGALHAES PEREIRA	fmagalhaes@marista.edu.br	27	4009-4200	marista	flamaga	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
532	-771508	E.E> Prof. Ayres de Moura	Rua |Artur Orlandi, 907- Vila Jaguara			05118-000	São Paulo	SP	11	3625-1934	Walter Zaccari	ranido@ic.unicamp.br	11	3906-9886	gepam1	gepam	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
545	-629893	Colégio Anglo Claretiano - Rio Claro	Av. Santo Antonio Maria Claret, n. 1724	Cidade Claret		13503-250	Rio Claro	SP	19	2111-6000	Maria Luiza Altarugio Barbanera	ranido@ic.unicamp.br	19	3427-0669	tinari	luizabarbanera	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
519	-180942	Instituto de Ciências Matemáticas e de Computação-USP	Av. Trabalhador São-carlense, 400	Centro	C.P. 668	13560-970	São carlos	SP	16	3373-9700	Guilherme P. Telles	gpt@icmc.usp.br	16	3373-9700	flgt0ics	gpt	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
539	-979379	Genesis Cursos e Pré Vestibulinho Ltda	R. Quintino Cardoso Ribeiro, 33	Vila Bética		13450-000	Santa Bárbara d'Oeste	SP	019	34557143	Evandir Pereira da Silva Júnior	evandirpereira@hotmail.com	019	34557143	22118546	Evandir	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
522	-876895	Fund. Esc. Tec. Liberato Salzano Vieira da Cunha	Rua Inconfidentes 395  B. Primavera			93340-140	Novo Hamburgo	RS	51	35958000	Andre Luiz Pimenta Tubino	andretubino@liberato.com.br	51	35958000	160387	olimpimenta	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
518	-991645	New Time 	Rua XV de Novembro 728	centro		13400-370	Piracicaba	SP	19	34340799	Samuel Michel Garcia	samuelmichel@uol.com.br	19	34340799	andressa	newtime	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
513	-13181	COLÉGIO FARIAS BRITO	RUA SENADOR, 2607			60025002	FORTALEZA	CE	85	34647788	JOSÉ CARLOS FERREIRA BASTOS	jjcarlosb@zipmail.com.br	85	34647788	121212	JOSE CARLOS	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
512	-116032	Fundação Bradesco - Gravataí	Rua Aristides Davila 390			94000970	Gravataí	RS	051	34881222	Marcelo Henrique Euzebio Batista	6225.mbatista@fundacaobradesco.org.br	051	34881222	1058698711	mbatista	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
460	-46825	COLÉGIO INSTITUTO FRANCISCO DE ASSIS	RUA PADRE FLORENTINO - 208	CENTRO		75503165	ITUMBIARA 	GO	64	34312863	ILMA NERES DA SILVA	bessimabrbr@yahoo.com.br	64	34312863	121966	ilmaneres	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
521	-540055	Pontifícia Universidade Católica do Rio de Janeiro	Rua Marquês de São Vicente 225, Gávea			22453900	Rio de Janeiro	RJ	21	31141500	Luiz Fernando Bessa Seibel	seibel@inf.puc-rio.br	21	31141500	seibelluiz	seibel	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
422	-107530	Escola Estadual Stela Machado	Rua Wenceslau Bras nº 15-73	Vila Pacifico		17050-460	Bauru	SP	14	32382397	Gilamara Aparecida da Silva	gilmara@neobiz.com.br	14	32382397	101300	gilmara	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
414	-665767	EE. "DEPUTADO EDUARDO VICENTE NASSER"	RUA LEONOR MENDES DE BARROS, 309			13780-000	DIVINOLÂNDIA	SP	19	36631221	AILTON DE OLIVEIRA 	ranido@ic.unicamp.br	19	36637185	060264	NASSER	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
514	-855716	EE Prof. Benedicto Leme Vieira Neto.	Rua Francisco Roberto Daniel, 298	Jd. das Bandeiras		18160-000	Salto de Pirapora	SP	15	32921690	Hermelindo Dias Fuglini	fuglini@terra.com.br	15	32921690	fuglini	16006162830	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
24	-300261	EEFM Cônego Luiz Braga Rocha	Rua Pe. João Scopell,113			63970000	Ibaretama	CE	88	34391050	Antonio Eremberg Gonçalves	erembergg@bol.com.br	88	34128104	300674	erembergg	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
529	-454235	Centro Federal De Educação Tecnológica de Ouro Preto	Rua Pandiá Calógeras	nº 898	Bauxita	35400-000	Ouro Preto	MG	031	3559-2193	Cristiano Lúcio Cardoso Rodrigues	cristianolcrodrigues@yahoo.com.br	031	3559-2193	cubulo100	cristianolcrodrigues	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
112	-983945	Escola Professor Jonathas Pontes Athias	Rua Semoacá, s/n			68275000	Porto Trombetas	PA	93	35497665	Rui Cardoso de Almeida	fvtinfo@fvt.com.br	93	35497665	sucessos	ruicardoso	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
37	155259	Escola Municipal Terezinha Moura Brasil	Rua Ponce de Leon, 68	Bairro Compensa II		69036-170	Manaus	AM	092	671-5768	João Batista dos Santos	ararethama@ig.com.br	092	667-4374	guajara	João Batista	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
21	869506	Universidade Salvador - UNIFACS	Al. das Espatódias, 915 - Caminho das 	Árvores - Campus Iguatemi		41820-460	Salvador	BA	071	3273-8566	Isaac Douglas Moreira	isaac@unifacs.br	071	8802-4045	ravena	isaac	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
200	359653	E.E. Maria de Lourdes Vieira	Rua Pedroso da Silva nº 477			08080040	São Paulo	SP	11	65812188	Andresa Zani Dojicsar	andresa.zani@bol.com.br	11	65812188	pepita	Dojicsar	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
50	483100	EE PADRE JOSÉ NARCISO VIEIRA EHRENBERG	RUA CAMPOS SALES, 350	BAIRRO JOÃO ARANHA		13140000	PAULÍNIA	SP	019	38742943	TANIA MARIA RIBEIRO DE ALMEIDA	ESCOLAPENARCISO@IG.COM.BR	019	38333807	PN1978	ESCOLAPENARCISO	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
145	70369	GINASIO ANCHIETA	AV DOM BOSCO Nº 2139  KM 2 	BAIRRO NOSSA SRA DE FATIMA		75180000	SILVANIA	GO	62	332-1261	JOSE INACIO CORREA 	ginasioanchieta@hotmail.com	62	332-1261	160676	JOSE INACIO	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
130	379914	Colégio Marista Maranhense	Rua Oswaldo Cruz, 954 - Centro			65.020.250	São Luís	MA	98	32314805 	Raquel Silva Neiva	maranhense@marista-slz.com.br	98	32314805 	200372	Raquel Neiva	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
371	854344	Organização Educacional Evolutivo	Rua Gal. Sampaio, 1742, Centro			60020030	Fortaleza	CE	085	40088209	Emanuel Augusto de Souza Carneiro	olimpiadas@evolutivo.com.br	085	40088209	danubio	emanuelc	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
526	-716034	Colégio Santo Inácio	Av. Desembargador Moreira, 2355	Dionisio Torres		60170002	Fortaleza	CE	85	30663000	Viviane Maria da Conceição de Souza	viviane@santoinacio.com.br	85	30663000	30663000	csifortaleza	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
515	-580849	EE Profª Olga Chakur Farah	Av. Antonio Paulino de Miranda, nº 101, 	centro		08970000	Salesópolis	SP	11	46961252	Silvana de Fátima Nascimento	silvananascimento77@hotmail.com	11	46961252	98549793	Nascimento	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
496	-635731	ETE Presidente Vargas	Rua Adriano Francisco Salgado, s/nº			08715130	Mogi das Cruzes	SP	11	47991511	Cintia Hitomi Akabane	cintia.akabane@bol.com.br	11	47991511	infoete	CintiaETE	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
492	-374901	Colégio Presbiteriano Agnes Erskine	AV.Rui barbosa, 704 Graças			52011040	Recife	PE	81	34234522	Adriana Alves Aleixo	adrianaaleixo@hotmail.com	81	34234522	201271	adrialeixo	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
525	-206588	CAT "HÉLCIO REZENDE DIAS"	RUA  PROJETADA  S/N		GUARANHUNS	29000100	VILA VELHA	ES	27	33298656	ANTONIO VENANCIO DE ANDRADE JUNIOR	antonio.venanancio@terra.com.br	27	33298656	684337	antonio	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
516	-238210	FARIAS BRITO - PRÉ VESTIBULAR	AV. BARÃO DO RIO BRANCO 2424 CENTRO			60025062	FORTALEZA	CE	85	34647744	JOSÉ CARLOS FERREIRA BASTOS	jjcarlosb@zipmail.com.br	85	34647744	121212	jjcarlosb	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
462	-623217	COLÉGIO IMACULADA CONCEIÇÃO	Praça Barão do Rio Branco - 131	Centro		78200000	Cáceres	MT	65	32231390	Luciany da Silva Muniz Drager	luciany.cic@terra.com.br	65	32231390	amanda	ludrager	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
418	-630283	Escola de Informática e Cidadania de Grossos	Av. Cel. Solon, 239 - Centro			59675-000	Grossos	RN	84	3327-2017	Luiz Nazareno de Souza	nazareno@tibau.com.br	84	8803-4071	12131415	eicgrossos	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
480	-427517	Colégio e Curso Santos Dumont	Rua João Marcelino, 65 - Centro			59678-000	Tibau	RN	84	8803-4071	Luiz Nazareno de Souza	nazareno@tibau.com.br	84	8803-4071	euteamo	nazareno	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
517	-223031	Colégio Atibaia 	Rua da Imprensa 165 Jd. III Centenario			12944720	Atibaia	SP	11	44110214	Ronaldo Lugli	colati@colegioatibaia.com.br	11	44110214	280306	ronaldo	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
560	140314	Faculdade Maringa-Campus Maringá	av.prudente de morais nº815,zona 07.			87015000	Maringa-parana	PR	044	30271100	Angelica Pietro da Silva Sá Giudice	ANGELICAPIETRO@FACULDADESMARINGA.BR	044	88023218	jose2005	angel01	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
511	-45922	Colégio D. Inácio	Av. Dona Floriana, 463	Centro		37.800-000	Guaxupé	MG	35	3551-5330	Adriana Carvalho dos Santos	adrianacsantos@yahoo.com.br	35	3551-5330	bomjardim	adrianacsantos	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
509	-844794	EE DEPUTADO GREGORIO BEZERRA	AV AFRANIO PEIXOTO, 544  VL PAULINA			09941420	DIADEMA	SP	11	40594900	NELSON BEMVINDO	nbenvindo@ig.com.br	11	40594900	123456	NELSON BEMVINDO	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
504	-453436	EMEF Profª Leonor Pereira Nunes Galvão	Rua José Molina, 150 - Vila Industrial			12235-750	São José dos Campos	SP	12	3929-1714	Andréa Campos de Oliveira	an_c_oliveira@ig.com.br	12	3929-1714	leonor	leonorpng	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
502	-221084	Colégio Universitário de Avaré	Praça Prefeito Romeu Bretas, 163			18700-902	Avaré	SP	14	3732-1133	Floriano Castilho	colegio@frea.edu.br	14	3732-1133	mari0806	Mariana	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
499	-212987	EE. Profª Mercedes Paz Bueno	Rua Xingu, 7-46			17013-023	Bauru	SP	14	3223-8481	Cristiane Melendes de Oliveira	crismel_bio@hotmail.com	14	3223-8481	090769	crismpb	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
93	388073	COLEGIO NOSSA SENHORA DA ASSUNÇÃO	RUA DR ALCIDES VIEIRA ARCOVERDE 620			81	CURITIBA	PR	41	2962135	ANA LUCIA BERNO BONASSINA	INFORMATICA@FELICIANAS.COM.BR	41	5730157	VICTOR	ANABONASSINA	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
49	-487804	Instituto Reis Magos	R. Brasilia, 712 - Alecrim			59030060	natal	RN	84	2223539	Nery Adamy Neto	cpd@irm-natal.com.br	84	88231689	falmoc	reis	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
420	-230115	Universidade Presidente Antonio Carlos	Rua Lincoln Rodrigues Costa, 165 - Boa V			36.500-000	Ubá	MG	32	3531-2261	Márcio Aarestrup Arbex	ranido@ic.unicamp.br	32	3531-2261	maa77$	arbex	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
473	-131301	E.E"Dona Elvira Santos de Oliveira"	Praça Moji-Mirim, sem número			13970-000	Itapira	SP	19	3863-3115	Isabel Cristina Durante	ranido@ic.unicamp.br	19	3863-3115	eso2006	belcris	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
8	-853022	Colégio Londrinense	Av. Juscelino Kubitscheck, 1692			86020000	Londrina	PR	43	33757300	José Junior Vendrame	vendrame@filadelfia.br	43	33757333	435126	vendrame	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
87	-810535	Faceca	R. Catanduvas, 173			37006-020	Varginha	MG	35	3221-2999	Hélio Lemes Costa Jr	helio@varginha.com.br	35	8804-4170	4406ad	helionet	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
7	-693957	Colégio Salesiano Itajaí	R. Felipe Schmidt, 87 - Centro			88301-010	Itajaí	SC	47	3348-2021	Márcia Silva Madeira	informatica@salesianoitajai.g12.br	47	3348-2021	infsale	enio	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
9	-968038	Faculdades Integradas de Caratinga	Rua Joao Pinheiro, 168 - Centro			35300-037	Caratinga	MG	33	33212122	Andre Gustavo dos Santos	andre@spep.com.br	33	33212122	eu5obi	andre	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
42	-133363	COTIL-Colégio Técnico de Limeira-UNICAMP	Rua Con. Manoel Alves, 129 	Jd. Nova Itália		13480-970	Limeira	SP	19	34047191	Marcos Teixeira	teixeira@cotil.unicamp.br	19	96087760	brasil98	marcosteix	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
17	-330256	EE Joaquim Gonçalves Ferreira da Silva	Rua Vespaziano, s/n	Estancia Fraternidade		08589030	Itaquaquecetuba	SP	11	46488566	Andréa Dias	deacortelazzi@yahoo.com.br	11	46488566	maynne	cortelazzi	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
78	-621973	COLÉGIO OBJETIVO	Avenida Paulista, 900	1º Andar		01310100	São Paulo	SP	11	3173780	Luís Rogério da Silva	l.rogerio@unip.br	11	38712709	060262	l.rogerio	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
48	-182351	EE. ``Deputado Eduardo Vicente Nasser``	Rua Leonor Mendes de Barros	no. 309		13780-000	Divinolândia  - São Paulo	SP	19	36631221	Ailton de Oliveira	ailtonprof@bol.com.br	19	36631221	060264	nasser	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
69	-586477	Colégio Coração de Maria	Av Padre Claret 1285	Bairro: Centro		93280261	Esteio	RS	51	4736255	Silvio Cesar Viegas	scviegas@brturbo.com	51	4736255	64686468	slbccm	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
60	-23453	COLÉGIO INTEGRAL POÇOS DE CALDAS	PRAÇA GETÚLIO VARGAS, 04 - CENTRO			37701007	POÇOS DE  CALDAS	MG	35	37229300	ALEXANDRE BENEDITO XAVIER	monitorintegral@pocos-net.com.br	35	99240984	integral	Monia	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
184	-253441	E. E. Prof. Arlindo Bittencourt	R: Silvério Ignarra Sobrinho, 455	Vila Monteiro		13560-970	São Carlos	SP	16	3368-3444	Walkiria S. Daccach	e024557a@see.sp.gov.br	16	3368-3444	4507580	Walkiria	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
168	-184196	E.E. Profª Sinésia Martini	R. Geronimo Santon, 33	Praia Azul		13476680	Americana	SP	019	34671344	Silvana Barboza Cordeiro	eesinesia@ig.com.br	019	34671344	Silvana	Silvana	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
6	-338804	ESCOLA DE ENSINO FUNDAMENTAL E MÉDIO "TENENTE RÊGO BARROS"	AV. JÚLIO CESAR, S/N, SOUZA			66063-280	BELÉM	PA	91	3231 6526	LUIZ OTÁVIO MACIEL MIRANDA	luiz@detran.pa.gov.br	91	3214 6335	ESCOLA10	LMIRAND	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
19	-15244	Centro Universitário de Patos de Minas	R. Major Gote, 808	Caiçaras		38702054	Patos de Minas	MG	34	38230300	Sandro de Paula Matias	si_unipam@yahoo.com.br	34	91288175	unipam	unipam	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
124	-330181	Escola D. Pedro II	Rua XV de Novembro , 560 - Centro			13880-000	Vargem Grande do Sul	SP	019	36413200	Odair José dos Santos	dpedrosegundo@itelefonica.com.br	019	36413200	140865	dpedro2	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
13	-522319	IME-USP	Rua do Matão, 1010			05508-090	São Paulo	SP	11	3091 6135	Carlos Eduardo Ferreira	cef@ime.usp.br	11	3091 6135	obi297	cef	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
14	-990219	UCDB - Universidade Católica Dom Bosco	Av. Tamandaré, 6000	Jardim Seminário		79117-900	Campo Grande	MS	67	312-3800	Amaury Antônio de Castro Junior	amaury@ec.ucdb.br	67	3312-3495	bbcdmnd95.	amaury	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
289	-592903	Colégio Acadêmico COC	Via 147 - Km 04	Estrada Limeira-Piracicaba	Cruz do Padre	13482383	Limeira	SP	19	34044731	Sandra Maria Crippa	ci@alie.br	19	30388656	smc1119	smcrippa	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
18	-115451	Centro Universitário Senac	Av Eusébio Stevaux, 823			04696000	São Paulo	SP	11	5682-7300	Elias Roma Neto	elias.rneto@sp.senac.br	11	5682-7549	godi836	eliasromaneto	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
72	-607365	Universidade Católica de Santos	Av. Conselheiro Nébias, 300	Vila Mathias		11015002	santos	SP	13	32055555	Ciro Cirne Trindade	ciroct@unisantos.br	13	32242551	i07l12c18	ciroct	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
22	-488916	Centro de Ensino Médio EIT - CEMEIT 	QNB 01 Área Especial 01 - Setor Central	Taguatinga Norte		72115-010	Taguatinga	DF	61	3512566	Fabrício Manoel de Jesus	fmjesus@pop.com.br	61	81269926	210882	eit_prof	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
23	-528139	Colégio Técnico Industrial - Unesp	Av. Nações Unidas, 58-50 - Vargem Limpa			17033-360	Bauru	SP	14	3203-0161	Celso Massaru Kawashima	cemaka@feb.unesp.br	14	3227-2236	c21m03k65	celso	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
34	-301563	Colégio Militar de Curitiba	Praça Conselheiro Thomas Coelho, 1	Tarumã		82800030	Curitiba	PR	041	3366-2001	Daniel Birck	danielbirck@gmail.com	041	3366-2001	cirrus	birck	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
36	-113436	CENTRO DE ENSINO MÉDIO ASA NORTE - CEAN	SGAN 606 MÓDULOS G/H			70840-060	BRASÍLIA	DF	61	2722338	DONIZETE NUNES VALADAO	donizetevaladao@yahoo.com.br	61	3461668	364897	DONIZETE	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
57	-263424	Colégio Coração de Maria	Av. Cesar Lacerda de Vergueiro nº 45	Bairro Ponta da Praia		11030-220	Santos	SP	13	3261-5119	Paulo Eduardo Mauá	coracao@iron.com.br	13	3261-5119	coracao	coracao	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
252	733793	Colégio Técnico "Antônio Teixeira Fernandes"	Rua Paraibuna, 75	Centro		12245-020	São José dos Campos	SP	012	3928.9822	Eduardo Jorge Brito Bastos	elisete@univap.br	012	3928.9816	123456	elisete	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
284	600852	E.E. Pedro Teixeira de Queiroz	Rua Guarantã, 679	Bairro Jardim Santa Clara		14960-000	Novo Horizonte	SP	17	3542-1006	JULIANA GARCIA FONSECA DE ANDRADE	juliana2a@bol.com.br	17	9722-4806	221063	Silmara	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
405	913741	EE. Gabriel Prestes	Rua Duque de Caxias, 189	Centro		12600-040	Lorena	SP	012	3132 2615	DENISE MOTA SILVA COSTA	denisepscosta@ig.com.br	012	31573390	1214DC	DENISE COSTA	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
135	198858	Universidade Gama Filho	Rua Manoel Vitorino, 625 - Prédio AR 	1. andar		20748900	Rio de Janeiro	RJ	021	25997227	Luiziana Silveira de Rezende	luiziana@ugf.br	021	25997282	sineia	neury	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
41	-454687	Colégio Ágape	Rua Salomão Fadlalah, 286 	3º Piso	Centro	29395000	Ibatiba	ES	28	35431586	Flávio Alcure de Araújo	f.alcure@ig.com.br	28	35431249	lib1001	libanes	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
76	-211491	Colegio Modulo	Rua Tito, 1175			05051000	Sao Paulo	SP	11	38721444	Ivan Sanches Petrucci	ivan@colegiomodulo.com.br	11	38721444	463652	ivansanches	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
70	-641923	Escola Estadual Vilmar Vieira Matos	Rua Manoel Rasselen - 1415- Jardim Rasse	len - 		79813-070	Dourados- MS	MS	67	425-2322	Delma Freo Faccin	delmafaccin@ibest.com.br	67	425-2322	dff2003	delmafaccin	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
45	-270768	ITA - Instituto Tecnológico de Aeronáutica	Praça Marechal Eduardo Gomes, 50	Vila das Acácias		12228-900	São José dos Campos 	SP	12	3947-5899	Armando Ramos Gouveia	armando@ita.br	12	3947-6943	ITAobi05	ITAcomp	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
35	-902293	Colégio Normal São Francisco de Assis	Rua Dom Felício Vasconcelos	320	Capiatã	57300-580	Arapiraca 	AL	82	539-1193	Lucimar Ferreira da Costa	lucimar_mima@ig.com.br	82	9922-7478	7757004800	normal	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
32	-680114	UNESP - Rio Claro - SP	Rua Dez, 2527   Caixa Postal  178			13500-230	Rio Claro	SP	019	35340229	Mário Roberto da Silva	marsilva@rc.unesp.br	019	97586818	0806am	marsilva	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
174	-598768	NEP - Núcleo Educacional Pitágoras	Rua Rio Tapajós, 70	Bairro Zona Norte		15385-000	Ilha Solteira	SP	018	3742-3880	Gilmar Pereira da Silva	giba-dudu@bol.com.br	018	3742-3880	gil1801	giba-dudu	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
30	-161555	Instituto Municipal de Ensino Superior de Assis	Av. Getulio Vargas, 1200	Vila Nova Santana		19807-634	Assis	SP	18	3302-1055	José Augusto Fabri	fabri@femanet.com.br	18	3302-1055	gabi78	fabri	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
28	-24977	EE Reverendo Erodice Pontes de Queiroz	Rua Amaro Alves do Rosario nº 1500	Jardim Iporã	São Paulo	04865000	São Paulo	SP	11	59796959	Berenice Teixeira de Santana	bereteixeira@hotmail.com	11	59796959	ch998yx	berenice	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
169	-419135	E.E. PROF. ALLYRIO DE FIGUEIREDO BRASIL	RUA DUQUE DE CAXIAS, 195			07191-010	GUARULHOS	SP	11	6408-5104	Marise Garçon	e041099a@see.sp.gov.br	11	6408-5709	marise	marise	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
365	-139700	Colégio COC	Rua Carlindo Pereira da Costa, 115	Vila Michelin		13601008	Araras	SP	19	35428787	Eduardo Luz Lagazzi	eduardo@cocararas.com.br	19	97153611	completa	eduardo_lagazzi	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
43	-530247	Colegio Jesus Maria Jose 	Rua Francisco Tarcia, 733	Vila Raycos		14405-289 	Franca	SP	16	3713.6100	Francisco Fernandes	chiquinho@cjmj-franca.com.br	16	3713.6100	250382	Leandra	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
368	-963287	colegio galois	sgas, 902, lote 73, blocos A a F	asa sul		70390-020	brasilia	DF	061	2242070	angel prieto andres	angel_prieto@terra.com.br	061	3664960	galois	galois	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
44	-117519	SPE ANGLO / Silva Mourão	Rua Benjamim Barroso 100	Bairro: Monte Castelo		60325-450	Fortaleza	CE	085	32814560	Priscila Ferraz Couto	pityferraz@yahoo.com.br	085	32814560	14789632	priscila	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
91	-940007	COLÉGIO FLAMA	AV. PRES. KENNEDY, 1804	CENTRO		25020000	DUQUE DE CAXIAS	RJ	21	26712914	JULIANA ELOI DO NASCIMENTO	JULIANA@FLAMAONLINE.COM.BR	21	26712914	CASA11	JULIANA	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
73	-669205	Colégio Sinodal	Av. Dr. Mario Sperb, 874	Morro do Espelho		93032-450	São Leopoldo	RS	051	592-1584	Humberto Schneider	humberto@sinodal.com.br	051	592-1584	527634	hagarrbr	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
47	-986815	E.M.E.F."Profª Esther Silva Valente"	Rua Joaquim de Oliveira, nº134			13910-000	Monte Alegre do Sul	SP	19	38991568	Ewanio de Castro Rück	ewanioruck@itelefonica.com.br	11	40181984	esthers	ewanio	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
55	-243472	Escola Técnica de Eletrônica "Francisco Moreira da Costa"	Av. Sinhá Moreira 350			37540-000	Santa Rita do Sapucaí	MG	35	34733600	Tarcísio Nunes Filgueiras Júnior	tarcisio@ete.g12.br	35	34733600	ShivaGod	major	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
54	-455152	Colégio de Aplicaçao	Av.Getúlio Vargas,654	Centro		6990050	Rio Branco	AC	68	3224-2826	Gilberto Francisco Alves de Melo	gfmelo0032003@yahoo.com.br	68	3224-2826	juliana	Gilberto	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
62	-571271	Monteiro Lobato Cems	Rua Judith Maria Tovar Varejão, 150 	Enseada do Suá 		29000000	Vitória	ES	27	33253941	Carmen Faria Santos	cfaria.vix@terra.com.br	27	99824741	abelha	cfaria	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
68	-710507	Colégio Estadual Brasílio de Araújo - Ensino Fund. e Médio	Rua Joaquim Ladeia, 187			86130000	Bela Vista do Paraíso	PR	43	2421172	Ricardo Gobato	ricardogobato@ibest.com.br	43	2421172	667690	ricardogobato	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
59	-189472	Faculdade de Informatica de Passos	Juca Stockler 1130			37900106	Passos	MG	35	35298013	Gualberto Rabay Filho	rabay@passosuemg.br	35	35298013	xfree386	rabay	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
71	-594949	Universidade Católica de Pelotas	 Rua Félix da Cunha, 412 			96010- 000	Pelotas	RS	053	2848227	Ricardo Andrade Cava	cava@atlas.ucpel.tche.br	053	2255138	violao97	cava	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
263	951705	INSTITUTO EDUCACIONAL PORTO REAL	AV. D. PEDRO II,845 - CENTRO			27570-000	PORTO REAL	RJ	24 	3353-2915	CLAUDIO ALCARAZ	iepr@pcqnet.com.br	24	3353-1559	IEPR2005	CLAUDIO	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
177	699138	EE PROF DOLORES BELEM NOVAES	R : FRANCISCO FRANKLIN DA SILVA  299			14180000	PONTAL 	SP	016	6531126   	KATIA PACIFICO MANFRIM	katiapacifico@yahoo.com.br	016	653 1353	vodila	katiapacifico	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
278	141988	EEFM ENGENHEIRO AGEU ROMERO	RUA EVARISTO GOMES, 143  CENTRO			62685000	PARAIPABA	CE	85	33631339	JOSIELSON BATISTA MELO	josielsonb@yahoo.com.br	85	33631339	123456	JBM	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
161	23321	LICEU SANTA CRUZ	rUA SÃO NICASIO, 420 - MOOCA			03128-050	SÃO PAULO	SP	011	61280086	ERIVAL RODRIGUES DE OLIVEIRA	pedagogico@liceusantacruz.com.br	011	96024794	180167	erival	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
193	-430322	Escola Municipal de Ensino Fundamental Albano Kanzler	R; Lourenço Kanzler, 177			89252240	Jaraguá do Sul	SC	47	2752562	Mirela Fabiana Rengel	emalbano@terra.com.br	47	2752562	mirela28	mirela	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
46	-108233	Colégio Marista de Natal	R. Apodi, 330 - Centro			59020-130	Natal	RN	84	4009 5000	Cassandra Maria CUnha Lisboa de Araújo	cassandra@marista-natal.com.br	84	4009 5000	sinfe234	marista	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
92	-946112	INSTITUTO SANTA TEREZA	QUADRA E 8A LOTE 01 - RUA ATLNATICA Nº01			53370530	OLINDA	PE	081	34293201	MARCELO FIGUEIREDO MENELAU	ist@institutosantatereza.com.br	081	34293201	123456789	MARCELO	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
61	-4981	Colégio Neo Planos	Av. João de Barros, 1563, Espinheiro.			52021-180	Recife	PE	81	34265606	Felipe Pereira	faleconosco@neoplanos.com.br	81	88162829	EeMsDo	neoplanos	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
216	-865374	Colégio Fênix Ltda	Rua Anhangüera, 9-19	Vila Silva Pinto		17013-191	Bauru	SP	14	21067777	Adalberto Carlos Batista	adalberto@colfenix.com.br	14	32037412	210269	adalberto	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
38	-800477	Centro Educacional São Camilo	Rua São Camilo de Lellis, 1 	Bairro Paraíso		29304-040	Cachoeiro de Itapemirim	ES	28	35265913	Maria de Fátima Catta Preta Padilha	mfcpreta@hotmail.com	28	35265913	090600	Matheus	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
285	-426045	NIE	Travessa Coronel Ricardo Auler, 551			17201-200	Jau	SP	14	36213003	Marcelo Sabbadini  Francisco	marcelosf09@ig.com.br	14	36213003	einein	marcelonie	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
64	-341948	Colégio Paula Frassinetti	Av. Ângelo Calafiori, 393			37950000	São Sebastão do Paraíso	MG	35	35316203	Ana Maria Costa Heto	anaheto@uol.com.br	35	35316203	a1n2a3	anaheto	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
196	-841418	Centro Educacional Master S/C Ltda	Av. Bezerra de Menezes, 1802	São Gerardo		60341360	Fortaleza	CE	85	4011-1212	Núbia Cordeiro Pinto	nubia@neomaster.com.br	85	4011-1212	747582	Nubia	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
398	-890886	EE PROFª ROSA SALLES LEITE PENTEADO	PRAÇA BERNARDINO DE CAMPOS S/Nº			16450-000	GETULINA	SP	014	35521343	SUELY MARIA COTARELLI MADI	suelymady@yahoo.com.br	014	35521708	salles	suely	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
40	-742661	Colégio Dom Bosco	Av Gal  Affonseca , 313			27521-010	Resende	RJ	24	3355-3608	Paulo Cesar Ferreira de Oliveira	pacefeol@superig.com.br	24	3354-6174	2861318	Paulo Cesar	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
81	-440770	FIEB-Fundação Instituto de Educação de Barueri	Av. Andromeda, 500			06500-000	Barueri	SP	11	41950252	Ana Maria Correia Bakos	acorba@terra.com.br	11	4153-1073	265772	acorba	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
80	-146475	Elite Porto Alegre	Av. Princesa Isabel,  844/502 	Santana		90620-000	Porto Alegre	RS	51	3219-6001	Daniel Fonseca Lavouras	elitepoa@uol.com.br	51	32196001	bag227	bagual227	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
82	-627718	ESCOLA ESTADUAL JOSEFINA XAVIER	AV. GETULIO VARGAS, 398			59805-000	LUCRÉCIA	RN	84	3960137	AJINELDO FERREIRA DA SILVA	ajineldo@brisanet.com.br	84	3960049	estudo	ajineldo	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
375	-264306	Escola Estadual Cel Joaquim Salles	Rua 7,nº 793,centro			13500-060	Rio claro	SP	19	35243301	Carmem Silvia Chiarinotti	carmem@claretianas.com.br	19	35342100	110158	silvia	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
83	-295244	SATC - Associação Beneficente da Indústria Carbonífera de SC	Rua Pascoal Meller, 73	Bairro Universitário		88805-380 	Criciúma	SC	048	431-7535	Luciano Bitencourt Fernandes	lbf@satc.edu.br	048	443-5694	luc10cri	satc	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
225	-696538	ETE Philadelpho Gouvea Netto	Avenida dos Estudantes, número 3278			15035-010	São José do Rio Preto	SP	17	32339266	Maria Teresa Vilela Puia	mtpuia@click21.com.br	17	32339266	oli72005	mtpuia	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
152	-869197	ESCOLA SEMPRE VIVA	RUA MACIR RAMAZINI, 842 - CENTRO			14180-000	PONTAL	SP	16	6531017	MARCO BUOZI	sempreviva@3ax.com.br	16	6531017	ma132639	marcobuozi	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
237	-171622	Centro Educacional Objetivo do litoral	Av. César Lacerda de Vergueiro, 81			11030-220	Santos	SP	13	3261-1007	Linita Ribeiro Duarte Lisboa	linita@objetivo-santos.br	13	3261-1007	arte05	Linita	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
77	-691072	Colegio Mestre	Rua Santo Antonio 79			11600000	São Sebastião	SP	12	38622423	Periça Vatavuk Michelucci	pericavatavuk@yahoo.com.br	12	38921664	mestre	Periça	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
88	-690764	PUC Minas campus de Poços de Caldas	Av. Padre Fracis Cletus Cox, 1661			37701-367	Poços de Caldas	MG	35	3729-9200	Neil Paiva Tizzo	neil@pucpcaldas.br	35	3729-9227	obi2005	neil	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
109	-4962	Colégio Johann Gauss	Rua Américo Brasiliense, 1106			04715-001	São Paulo	SP	11	5182-8443	Lucilene Varandas	diretoria@johanngauss.com.br	11	5182-8443	johanninfo	colegiojohanngauss	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
330	-877001	Escola Profissional Dom Bosco	Av. José Remígio Prézia  nº 911			37701-102	Poços de Caldas	MG	35	3722-1471	Claudinei Noronha	dombosco@pocos-net.com.br	35	3722-1471	dombosco	Claudinei	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
378	190596	CENTRO DE EDUCAÇÃO TECNOLÓGICA DO AMAPÁ - CETE	RUA: Pedro Siqueira,333			68903150	Macapá	AP	96	241-6636	Valeria	valeria@cete.edu.br	96	241-6636	yasmim	Augusto	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
297	503103	Escola Municipal Cel. Durival Britto e Silva	R. Emílio Bertoline, 44, Cajuru			82920030	Curitiba	PR	41	3662989	Maria Isabel Porto Tobias	isatobiass@yahoo.com.br	41	99880547	cidoss	isatobiass	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
369	45753	escola de ensino fundamental e medio hermenegildo firmeza	rua gabriel fiuza 336 vila pery			60000	fortaleza	CE	85	32923265	sonia nnunes cavalcante	soniancp@hotmail.com	85	88337378	102028	sonia	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
213	439729	Colégio Lais Rodrigues Fortes	Rua Ribeiro do Amaral, 190			04268-000	São Paulo	SP	11	2739553	Alessandra Recamon Caldelas	ale.recaman@uol.com.br	11	61618331	ferrari9	recaman	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
191	414693	ESCOLA ESTADUAL PROFESSORA LIENETTE AVALONE RIBEIRO	RUA LICINIO ALVES DA CRUZ N° 140	PARQUE SANTA MARIA		18271-750	TATUI	SP	15	32514311	JOSE LUIZ MIRANDA	diretorjoseluiz@ig.com.br	15	32516786	lar2005	gersontrevisan	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
245	238849	E. E. Profª EMÍLIA DE PAIVA MEIRA	RUA PORTO XAVIER, 172			08210-170	SÃO PAULO	SP	11	62860014	SÉRGIO LUIZ DE CAMARGO BUENO	sergio.bueno@ig.com.br	11	68646675	emilia	EMÍLIA	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
84	-370514	Escola Ludovico Pavoni	Av Santo Antônio 2030. Santo Antônio. 			29026170	Vitória	ES	27	32237477	Christie Renata Videira Freitas	infoelp@terra.com.br	27	32370617	galaxia	christie	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
26	-934899	CEFET - MG / Uned Leopoldina	Rua José Peres, 558	Centro		36700000	Leopoldina	MG	32	3441-4343	José Geraldo Ribeiro Junior	junior@leopoldina.cefetmg.br	32	3441-4343	leopoldina	cefet	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
86	-876970	Universidade Estadual de Ponta Grossa	Departamento de Informática	Av. Carlos Cavalcanti, 4748	Campus Uvaranas	84030-900	Ponta Grossa	PR	042	32203300	Alceu de Souza Britto Jr.	alceu@ppgia.pucpr.br	042	9917-9951	uepg2005	uepg2005	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
94	-305941	Colégio Dom Inácio	Av. Dona Floriana, 463	Centro		37.800-000	Guaxupé	MG	35	3551-5330	Adriana Carvalho dos Santos	adrianacsantos@yahoo.com.br	35	3551-5330	017364	adrianacs	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
384	-164041	EE PROF ANA MARIA JUNQUEIRA	RUA DA LIBERDADE n 985	Vila Raycos		14.405-294	FRANCA	SP	016	37204837	Tânia Coelho Nunes Moscardini	tcnmoscardini@uol.com.br	016	37204837	37225169	alunoamj	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
90	-672117	Colégio Santa Maria	Av Automóvel Clube, 269			25515120	São João de Meriti	RJ	21	2756-4751	Branca Heloísa Britto de Souza	brancaheloisa@uol.com.br	21	9148-3893	csm2005	csm	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
171	-906077	EMEF MAURO FACCIO GONÇALVES - ZACARIA	AV. RAQUEL ALVES MOREIRA, 823, 	JD. GUARUJA		05821-130	SÃO PAULO	SP	11	55140672	DOUGLAS FERREIRA TOMÉ	poiedouglas@yahoo.com.br	11	55140672	bianca04	poiedouglas	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
89	-570733	Faculdade de Direito e Ciências Sociais do Leste de Minas 	Av. Marcionília Breder Sathler, 01 			36.920-000	REduto	MG	33	33784000	Alessandra Alves Fonseca	alefonseca@ig.com.br	33	33784000	mestrado	alefonseca	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
230	-971936	Centro Educacional SESI n.º 329	Rua Peçanha, 135 - Jd. IV Centenário			03934075	São Paulo	SP	11	6722-4087	Rosana Buratto	ce329@sesisp.org.br	11	6722-4087	050282	ce329	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
103	-267291	Liceu Noroeste S/C de Educação	Avenida Rodrigues Alves 8-35			17015-002	Bauru	SP	14	3224-1800	Ana Carla Fernandes Cacere	anacacere@aol.com	14	3214-1964	140665	anacacere	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
373	-497455	Colégio Spezani Fonseca	Av. Marechal Mallet, nº 232	Magalhães Bastos		21745090	Rio de Janeiro	RJ	21	2301-0135	Fabiana de Oliveira Mendes	fabianao-mendes@ig.com.br	21	33577719	csfcsf	colegiospezani	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
406	-72427	Colégio Clarice Lispector	Av: Recife 5141			78987-000	Rolim de Moura	RO	069	34421129	Ederson Nogara	enogara@ibest.com.br	069	34421356	eder123	Nogara	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
118	-846919	Faculdade de Tecnologia e Ciências	rua Artêmia Pires Freitas S/N			44.115-000	Feira de Santana	BA	75	6027049	Gilberto Luiz de Souza Paula	gilberto.fsa@ftc.br	75	88069247	anaester	gilbertop	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
100	-370548	Colégio Mater Amabilis	Rua Josefina Mandotti, 148a	Jardim Maia		07115-080	Guarulhos	SP	11	6468-0615	Andréa Minichelli Mazoni Lourenço	andrea_mml@yahoo.com.br	11	64591800	julia97	andreamml	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
121	-3295	COLEGIO CEC - CENTRO EDUCACIONAL CIANORTE	RUA MONTE CASTELO - 375			87200000	CIANORTE	PR	44	6311200	ANA LÚCIA DE OLIVEIRA	analucia@colegiocec.com.br	44	6311200	130869	annalife	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
122	-803023	COLEGIO XXV DE ABRIL	RUA JOÂO BATISTA VEIGA, 1725			18460000	ITARARÉ	SP	15	35324430	NEUMAR ALBERTI WILDNER	nawildner@uol.com.br	15	35322167	9502167	wneumar	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
156	-481029	COLÉGIO CEUB	SEPN 707/907 BLOCO 6	CAMPUS UNIVERSITÁRIO		71790075	BRASÍLIA	DF	61	3401834	GIOVANNI GUEVARA RAMON LIMA DE SOUZA	colegio@ceub.br	61	3401834	898989	ceub	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
349	-357335	Pontifícia Universidade Católica do Paraná	Rua Imaculada Conceição, 1155 	Prado Velho 	CEP: 80215-901 	80215-901 	Curitiba	PR	41	2711515	Edson José Pacheco	pacheco@ppgia.pucpr.br	41	2711515	ejpsystem	pacheco	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
110	-659485	SENAI/SC - Jaraguá do Sul	Rua Isidoro Pedri, 263 - Rio Molha			89259-590	Jaraguá do Sul	SC	47	372-9522	Rodrigo Machado Prado	roprado@senai-sc.ind.br	47	372-9522	ra1212	roprado	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
302	714778	E.E. Engenheiro Haroldo Guimarães Bastos	Rua Luci Ercília, 335			15620000	Macedônia	SP	17	38491207	Jucimara Alves Pinheiro	jualpinheiro@hotmail.com.br	17	38491207	221173	jupinheiro	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
194	83216	Privest-Sistema Positivo de Ensino	Rua Nenê,30			37640000	Extrema	MG	35	34352027	Marisa Monteiro Marques camargo	ppassos@exnet.com.br	35	34354104	290467	marisa	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
176	123425	EE João Alfredo da Silva	Rua Noroeste, nº 189 Bairro Eneida			19130000	Presidente Prudente	SP	18	2391100	Marcela Dalana Gomes Queiroz	marceladgq@hotmail.com	18	2236715	sajibo	obijas	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
221	250402	EE Profª Ismênia Monteiro de Oliveira	Rua Sebastião Machado de Andrade,111			12402500	Pindamonhangaba	SP	12	36425077	Daniela Silva da Costa Rosa	danielascrosa@bol.com.br	12	36427915	imo2005	daniela	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
228	914980	Escola Estadual Cidade de Hiroshima	Rua Ve^nâncio Lisboa, n.º 382 Jd Nossa 	Senhora do Carmo		08280-590	São Paulo	SP	11	6748-6797	Roselí Rita Fernandez	kuukaa@bol.com.br	11	6748-9085	kuki11	Roselí Rita Fernande	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
232	440261	UNIDERP	Rua Ceará, 333	Bairro Miguel Couto	Ciência da Computação Bloco VI -1º andar	79003-010	Campo Grande	MS	67	3488032	Edilene Aparecida Veneruchi de Campos	edilenecampos@mail.uniderp.br	67	92029540	edseana	edilenecampos	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
246	618344	CENTRO EDUCACIONAL SESI 338	RUA SÃO JOÃO , 1765	BAIRRO BOA VISTA		15025025	SÃO JOSÉ DO RIO PRETO	SP	17	2355606	ELI PARECIDA COLOMBO	elicolombo@uol.com.br	17	2315003	3amores	Eli Aparecida Colomb	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
238	976482	EE Prof. Oscar Salgado Bueno	Rua Orozimbo Miguel de Abreu s/nº	Vila Diniz		15013-170	São José do Rio Preto	SP	17	234-6680	Alice Rissoli Pereira	salgadobueno@hotmail.com	17	234-6680	osb28599	salgadobueno	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
214	13362	CIEP 145 DR. OSWALDO CRUZ	PARQUE RAUL VEIGA S/Nº	CENTRO		28540000	CORDEIRO	RJ	22	25511114	RAFAEL ORNELLAS PINHEIRO	rafnf2003@yahoo.com.br	22	99081620	221266	ornellas	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
223	610343	Escola de Ensino Fundamental União	General Osório,1125			96020-350	Pelotas	RS	053	2251566	Geisa Muenzer Salvador	geisa.ms@bol.com.br	053	99812925	pm677pm	geisa	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
359	819893	Colégio Stella Maris. EFMP	Rua Guaicurus, 281			86.380-000	Andirá	PR	043	3538-1329	Maria de Lourdes Lério	stellamaris.andira@uol.com.br	043	3538-1329	123476	lourdes	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
235	9435	EMEB CARMINE BOTTA	Rua Philomena Fauvel, 261 - Boa Vista II			13575-120	São Carlos	SP	16	3371-5285	Wanderley Escrivani Junior	emebcb@terra.com.br	16	3371-5285	carmine	joso	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
569	399889	Escola Técnica - SATC	Rua Pascoal Meller, 73	Bairro Universitário 		88805-380 	Criciúma 	SC	048	3431-7535	Luciano B. Fernandes	lbf@satc.edu.br	048	3443-5694	luc10cri	SATC2006	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
116	-320833	Instituto de Tecnologia de Jacareí	Av. Siqueira Campos, 1174 - Jardim Esper			12307-000	Jacareí	SP	12	39513388	Ricardo de Macedo Silva	ricardo@itj.g12.br	12	97020297	197508	ricardoitj	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
97	-278054	Colégio Integração	Av Cap Mor Aguiar 798			11310200	São Vicente	SP	13	35698200	Débora Eduarda Barbosa Kutne	informatica@faculdadeintegracao.com.br	13	34662157	debk2005	d_eduarda	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
292	-985756	CENTRO EDUCACIONAL OBJETIVO	AV CONSELHEIRO NEBIAS 766			11045-002	SANTOS	SP	13	32346767	CHRISTIANNE FERNANDES	chrisfer@bignet.com.br	13	97760557	educacao	chriscricri	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
320	-249115	Instituto Estadual Couto de Magalhães	R. Arthur da Costa e Silva, 18			96740000	Arroio dos Ratos	RS	51	6561435	Clairton Batista Machado	clairton.machado@terra.com.br	51	6561435	couto1	clairton	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
265	-853777	EMEF PROFª LEONOR PEREIRA NUNES GALVÃO	RUA JOSÉ MOLINA, 150			12220-300	SÃO JOSÉ DOS CAMPOS	SP	12	39291714	ISABEL FERRAZ CANTERAS POUSA	belpousa@yahoo.com.br	12	39291714	leonorpng	Isabel	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
257	829102	 E.E.F.MÉDIO BALBINA VIANA ARRAIS	R- OLEGARIO EMIDIO S/N			63260000	 BREJO SANTO	CE	088	3531-44	FLAVIO CESAR VIDAL COUTO	FLAVIOCESARVIDALCOUTO@BOL.COM.BR	088	35311452	666800	FLAVIO CESAR VIDAL C	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
266	416650	E. E. MAÍSA THEODORO DA SILVA PROFª.	ALAMEDA JUNDIAÍ, 366 B.  PORTO GRANDE			11600000	SÃO SEBASTIÃO	SP	012	3892 1137	Wagner Rogeri	rogeri_w@ig.com.br	012	38931923	pipa1923	WAGNER ROGERI	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
251	383426	E.E."José Inocêncio da Costa"	Rua Cesário Mota, 756 - Centro			15990-000	Matão	SP	16	3382-1767	Emílio Carlos Mendes	emilioiris@ig.com.br	16	3382-3190	33821767	jic	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
397	-543697	Centro Universitário do Sul de Minas - UNIS/MG	Rua Coronel José Alves, 256	Bairro Vila Pinto		37010-540	Varginha	MG	35	32195000	Juliano Coelho Miranda	coelhojm@unis.edu.br	35	32195000	5002sinuib	obiunis2005	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
115	-416397	Colégio FAG-COC	Av. das Torres 500			85800000	Cascavel	PR	45	3213973	Tania Lúcia Monteiro	taniamonteiro@certto.com.br	45	99784212	doceamor	taniamonteiro	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
113	-19375	COLÉGIO ESTADUAL TIMBU VELHO	RUA JACOB CECCON, 438			83430000	CAMPINA GRANDE DO SUL	PR	41	6791135	CLAUDIA MOREIRA GARCIA	claudia_moreiragarcia@yahoo.com.br	41	2563777	clauclau	cmoreira	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
151	-193942	Sociedade Educacional Premedico Ltda	Rua 32, nº 147 - St. Marista			74000000	Goiânia	GO	62	2815654	Cátia Shibuya	catiashibuya@ig.com.br	62	2815654	guilherme	catiashibuya	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
104	-554956	AIMCA - COLÉGIO SÃO JOSÉ	PRAÇA PANTEON, 03 CENTRO			65606970	CAXIAS	MA	99	35213944	FRANCISCO EVANDRO DE OLIVEIRA	csaojose@portalmail.com.br	99	35213944	052805	evandro	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
227	-520097	COLEGIO KERYGMA	RUA 3, 409 ST. MARECHAL RONDON			74560310	GOIANIA	GO	62	2111933	TANIA MARIA MORAIS DA MOTA	taniammota@click21.com.br	62	2339247	tmota20	taniamota	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
120	-58019	Colégio Marista de Cascavel	Rua Paraná, 2680 - Centro			85812-011	Cascavel	PR	045	30306000	Antonio de Lisboa Coutinho Júnior	lcoutinho@marista.org.br	045	9111-9208	123456	lcoutinho	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
108	-886325	Colégio Terceiro Milênio	Rua Amaro Bezerra Cavalcanti, 751			03513010	São Paulo	SP	011	66511255	Bernadete Helena Giro	begiro@ig.com.br	011	94678118	bezinha	begiro	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
102	-861291	COLÉGIO UNIVERSITÁRIO DE AVARÉ	PRAÇA PREFº ROMEU BRETAS, 163	CENTRO		18700-902	AVARÉ	SP	14	3732 1133	FLORIANO CASTILHO	colegio@frea.edu.br	14	3732 1133	am1613	Angela	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
139	-393774	E.E. "Cardeal Leme" - Ensino Fundamental e Médio	Pç Presidente Kennedy nº 36   Centro			13990000	Espírito Santo do Pinhal	SP	19	36511099	Imaculada Conceição Del Cool de Souza	delcool_imaculada@yahoo.com.br	19	36516715	delcool	Imaculada	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
275	-163246	Curso de Bacharelado em Ciência da Computação da UFPR	Departamento de Informática	Centro Politécnico	Jardim das Américas	81531980	Curitiba	PR	41	3603102	Laura Sánchez García	laura@inf.ufpr.br	41	91813023	sdplsg	lsgsdp	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
138	-891061	EE.Miguel Jorge	Rua Domingos Padovan, s/nº	Jd.Novo Mundo		14092-040	Ribeirão Preto	SP	16	6271627	Maria Esmeralda Manzoli de Oliveira	esmeralda010502@hotmail.com	16	6271627	010502	esmeralda	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
129	-705995	Colegio Duque de Caxias	Rua Dinorah Pereira Combat , 39	Centro - Duque de Caxias		25010230	Duque de Caxias	RJ	21	27720160	Johnny Verissimo	profjohnny@bol.com.br	21	24817416	730730	profjohnny	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
27	-501313	E. E. Prof. Lauro Sanchez	Rua Arnaldo Cunha, 237	Vila Carol		18075-240	Sorocaba	SP	15	32313683	Angelo Oscar da Silva Pedroso	angeloped1@ig.com.br	15	32313683	silped01	Angelo Oscar	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
394	-368332	EE DR MOACYR TEIXEIRA	RUA PREFEITO JOSÉ CARLOS, 181			19230-000	ESTRELA DO NORTE 	SP	18	249-1144	IRINEU APARECIDO PETENUCI	eemoacyr@uol.com.br	18	249-1144	escola10	irineu	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
133	-46139	COLÉGIO MARISTA SANTA MARIA	RUA FLORIANO PEIXOTO, 1217			97015373	SANTA MARIA	RS	55	32222232	DENILSON MORO	den_moro@yahoo.com.br	55	30271923	nicole	denmoro	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
144	-172659	Colégio da Fundação Educacional "Dr Raul Bauab" Jahu	Rua Tenente Navarro, 642			17207-310	Jaú	SP	14	3602 3300	Heloisa Ruiz Pereira	heloisarp@itelefonica.com.br	14	3622 6172	lucila	Heloisa	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
158	-819267	EE PROFA DANUZIA DE SANTI	PRAÇA SAO BENEDITO 549			186900000	ITATINGA	SP	014	38481488	VANI MARIA ELIAS TEOFILO JAMMAL	E014448A@SEE.SP.GOV.BR	014	38481488	014448	DANUZIA	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
210	-719989	Colegio PM Unidade Penha	Rua: Doutor Luiz Carlos, 1000			03505-000	São Paulo	SP	11	61913005	Regiane Muniz	coordenacaopenha5-8ef@colegiopm.com.br	11	61913005	gcm325	regianem	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
142	-293455	Escola Técnica José Cesar de Mesquita	Av. do Forte, 77, Bairro Cristo Redentor			91360-000	Porto Alegre	RS	51	33403110	Ronaldo Bianchin	ronaldo@mesquita.com.br	51	91769355	mesq2005	Mesquita2005	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
141	-85310	EE DEPUTADO GREGORIO PEIXOTO	AV AFRANIO PEIXOTO, 281 VILA PAULINIA			09971360	DIADEMA	SP	11	4059-4900	NELSON BEMVINDO	NBENVINDO@IG.COM.BR	11	4059-4900	123456	NBENVINDO	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
335	-568911	Escola Estadual República Oriental do Uruguai	Av. Presidente Affonso Camargo, 3407			82800240	Curitiba	PR	41	2671772	Luiz Carlos Silva	secret.uruguai@brturbo.com	41	2671772	marcia	Luiz	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
220	-758420	Colégio Santo Agostinho - SP	Praça Santo Agostinho, 79			01533070	São Paulo -  SP	SP	011	32082588	David Orlando Silva	david@csa.osa.org.br	011	32082588	dos357	david@csa.osa.org.br	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
281	980906	E.E."Paulo Virgínio"	Largo Bom Jesus, 107, Margem Esquerda			126300000	Cachoeira Paulista	SP	12	31011211	Ana Maria de Souza Barreiros	e013146a@see.sp.gov.br	12	31012592	paulovirgi	paulovirginio	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
295	952355	ETE GUARACY SILVEIRA	Rua Ferreira de Araújo,527			05428-001	São Paulo	SP	11	3031-6208	Alberto Marques	eteguaracy@uol.com.br	11	3813-3986	info061	Alberto Marques	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
301	317195	Escola Municipal de Ensino Fundamental Henrique Bertoluci So	Rua Antônio Hencke nº 100	Bairro Casagrande - Gramado RS	hbs@hy.com.br	95670000	Gramado	RS	54	286 6410	Miriam Dolores Krapf Andrade	hbs@hy.com.br	54	282 7750	MIMIHBS	MIMI	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
391	317137	Universidade de Brasília	Campus Universitário Darcy Ribeiro	Instituto de Ciências Exatas	Departamento de Ciência da Computação	70910-900	Brasília	DF	61	307--2482 	José Carlos Loureiro Ralha	ralha@cic.unb.br	61	307--2482 	zecaralha	ralha	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
380	-641824	Colégio Batista Brasileiro	Rua Dr. Homem de Mello, 537			05007	São Paulo	SP	11	38746344	Mônica Huertas Cerqueira	monica@cbb.g12.br	11	38746344	infoedu	monica	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
154	-78184	Colégio Visconde de Porto Seguro - Unidade II Valinhos	Rodovia Visconde de Porto Seguro, 5701	Jd. Itamaraca		13278-327	Valinhos	SP	19	38295000	Elizangela Polvora da Silveira	epsilveira@portomail.org.br	19	38814114	38814114	visconde	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
140	-616217	Escola Agrotécnica Federal de Inconfidentes	Praça Tiradentes, n. 416 - Centro			37576-000	Inconfidentes	MG	35	3464-1200	Maria de Fatima de Freitas Bueno	mf_bueno@yahoo.com.br	35	3441-2686	mffb90	mfatima	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
146	-321527	EE Profª Lourdes Pereira	Rua Montes Claros nª 525	Vila Fiuza		19814-230	Assis	SP	18	33247810	Pedro Silveira Junior	silveirapjassis@ig.com.br	18	33231741	frabru	familialourdes	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
270	-732318	EMEF Prof. Olavo Pezzotti	Rua Fradique Coutinho, 2200	Vila Madalena		05416-002	São Paulo	SP	11	30329908	Franca Piscina Macchia	piscinaf@uol.com.br	11	30329908	franfran	fmacchia	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
304	-461471	COLÉGIO DE APLICAÇÃO DA UNIVALI	URUGUAI - 458			88 300 000	ITAJAÍ	SC	47	3417546	ANDRÉA MÁRCIA FERREIRA DA SILVA	andreamfs@itj.viacabocom.com.br	47	3417546	an8603	aferreira	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
387	-812626	EE Dr. Francisco de Araujo Mascarenhas	Av. Aristóteles Costa, 373			13140000	Paulinia	SP	19	38741596	Renato Elias da Silva	renato_obi@yahoo.com.br	19	32877295	341438	renato_obi	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
188	-244478	EEFM Flávio Gomes Grangeiro	Av. maria Moreira,323 - Monte Alverne			62.685-000	Paraipaba	CE	85	3363:1473	Adail dos Santos Teixeira	flagogeiro@yahoo.com.br	85	3363:1473	flavio2004	Adail	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
162	-952244	E.E. VEREADOR VALTER DA SILVA COSTA	RUA MARINGÁ, 368, RANCHO GRANDE			08574-310	ITAQUAQUECETUBA	SP	11	4640-3533	SILVANA DA SILVA LOCATELI	e036353a@see.sp.gov.br	11	4678-3410	230663	LOCATELI	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
157	-780485	EMEIEF "Professor Raul de Paiva Castro"	Avenida Deputado Narciso Pieroni, Nº24	Distrito das Mostardas		13910000	Monte Alegre - Distrito de Mostardas	SP	19	38991588	Luciano Gomes Carneiro	escola.mostardas@ig.com.br	19	38991966	raul05	luciano	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
222	-466650	ETE Dr. Francisco Nogueira de Lima 	Av. Coronel Castro, 12 	Centro		13700-000	Casa Branca	SP	19	3671-1170	Ronaldo Lavestein	ronaldolavestein@yahoo.com.br	19	3671-4829	dedeinha09	lavestein	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
206	-894821	E.E. MONSENHOR GONÇALVES	R: DR. PRESCILIANO PINTO, 940 	BAIRRO BOA VISTA		15025100	SÃO JOSÉ DO RIO PRETO	SP	17	2352435	SANDRA REGINA PARREIRA RIBEIRO	sandra@plotenge.com.br	17	2278730	sandra	monsenhor	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
182	-755052	Escola Estadual Técnica São João Batista	Rua João Pessoa, 1468			95780-000	Montengro	RS	51	632-1709	Angelita Beatriz Bordignon Vian	eesjb@terra.com.br	51	632-1709	200501	eesjb	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
181	-76257	Colegio Cristo Rei	Rua D qd 35 Nº 19, Cohapam São Cristovão			65055130	Sao Luis	MA	98	3245 4787	Ibraim da Cunha Rodrigues	cristorei@oi.com.br	98	3245 4787	CREI2005	IBRAHIM	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
179	-438001	Complexo Educacional Contemporâneo	Rua do Cobre nº 18	Bairro Lagoa Nova		59076-210	Natal	RN	84	2063930	Sérgio Petterson Confessor da Paz	natal@contemporaneo.com.br	84	2063930	vaninha	spetterson	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
204	-583014	E.E. JORNBALISTA PAULO EDUARDO OLINTHO REHDER	PRAÇA DA MATRIZ, 49			08550-000	POÁ	SP	11	46360102	MARIA TEREZA MARCOS	m-tereza1@uol.com.br	11	936254580	mtm001	m-tereza	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
332	-150092	EE Dr Joubert de Carvalho	Rua: Pará, 469	Bairro: Jardim Paulista		16011-015	Araçatuba	SP	18	36237067	Aparecida das Graças Tallon	e030089a@see.sp.gov.br	18	36237067	escola	Joubert	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
164	-801784	EE Rubens Pietraróia	rua da Imprensa, 431- NH Luiz Zillo			18685390	Lençóis Pta	SP	14	32632120	Nilza Santana de Oliveira	anagui_dory@yahoo.com.br	14	32632120	124578	eerubensp	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
323	-414335	Universidade Federal do Pará	Av Augusto Correa 1	Guamá - CT - DEEC		66075-110	Belém	PA	91	31831250	Aldebaro Barreto da Rocha Klautau Júnior	a.klautau@ieee.org	91	31831306	agoravai	aklautau	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
254	-500655	EE VOLUNTÁRIOS DE 32	RUA JORGE TIBIRIÇA, 1335 	PQ INDUSTRIAL		15025060	SÃO JOSÉ DO RIO PRETO	SP	17	2123202	VILSON BARCOS LINDQUIST	vilbar@ig.com.br	17	2123202	221100	vilson	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
346	131141	E.E.F.M PATRONATO SAGRADA FAMILIA	RUA: MARTINS NETO 379			60360700	FORTALEZA	CE	085	31015087	NILTON	patronatosf@bol.com.br	085	32356750	escola	patronatosf	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
180	-819468	Escola Municipal João Costa	Rua Monsenhor |Gercino 3900			89230-000	Joinville	SC	47	4650549	Eliana Maria Gastaldi	elianagastaldi@gmail.com	47	4650549	jc0549	joaocosta	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
244	-109659	U I Pedro Neiva de Santana	Rua da Matriz S/N - Pov. Mineirinho 			65398-000	Alto Alegre do Pindaré -  MA	MA	098	3658-8094	Valdir Vasconcelos Sampaio	professorvsampaio@bol.com.br	098	3658-8047	escola	PNS	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
229	-417794	Unidade Integrada Professor Sá Valle	Rua da Companhia S/N	Bairro -Anil 		65.045-000	São Luís	MA	98	3244 9587	Patrícia Borges de Sousa	holanda254@hotmail.com	98	32264532	212121	Patrícia	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
203	-788733	EE Profª Ephigênia Cardoso Machado Fortunato	Av. Antonio José da Silva, 603			1725000	Bariri	SP	14	36621083	Arnaldo Luiz Piotto	olinfo005@bol.com.br	014	36625181	madica	cadasa	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
199	-129848	Universidade Vale do Rio Verde - Unincor	Av. Castelo Branco, 82 - Centro			37410-000	Três Corações	MG	35	3239-1238	Gustavo Pereira Rezende	gprezende@yahoo.com.br	35	88126785	gu2838	gprezende	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
185	-707401	E.E. Dr. Paulo Araújo Novaes	Rua José Eufrásio Leal, 46			18700-300	Avaré	SP	14	37320925	Vanete dos Santos Cruz	psique_@uol.com.br	14	37311890	profvan	Prof.Vanete	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
247	-444975	Colégio Novaera - Ed. Infantil, Ensino Fundamental e Médio	Rua Santana, 795			13880-000	Vargem Grande do Sul	SP	019	36411044	Colégio Novaera - Ed. Infantil, Ensino Fundamental e Médio	colnovaera@uol.com.br	019	36411044	36411044	novaera	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
195	-758056	Centro Educacional Leonídia Ltda - EPP	Av. Major Acácio Ferreira, 532	Jd. Leonídia		12327070	Jacareí	SP	12	39532911	Cristiane da Penha Silva	cris.yourfriend@uol.com.br	12	39532911	336699	professoracris	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
183	-561883	Colégio Nossa Senhora do Amparo	Avenida Domingos Mariano, 447 - Centro			27345-310	Barra Mansa	RJ	24	33224323	Dayse Portugal Pereira	dayse@colegioamparo.com.br	24	33224323	lulise	dppereira	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
166	-338150	Colegio Cidade de Iracemápolis "Anglo"	Rua Ralpho Elisios Monteiro dos Santos 	nº 405	Pq. Cesarino Borba	13495-000	Iracemapolis	SP	19	3456-2439	Samuel Michel Garcia	samuelmichel@uol.com.br	19	91925618	pt1471	angloiracema	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
382	-137058	C. C. C. Centro de Ciência e Cultura	Rua Jorge Figueiredo Correa, 735	Pq. Taquaral		13087-261	Campinas	SP	19	3756-1600	César Adriano do Amaral Sampaio	cesars.idt@sao.terra.com.br	19	3894-6051	anglotaq	sampaio	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
255	-185539	Centro Educacional Montessoriano - Reino Infantil	Rua dos Sapotis, quadra 113. nº 01 	Renascença II		65075-370	São Luis	MA	98	3235-7744	Marcos Campos Náufel	reinoinfantil@elo.com.br	98	3235-7744	reino5	Marcos	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
296	-529070	Unesp - Rio Preto	R. Cristovão Colombo, 2265	Jardim Nazareth		15110-000	São José do Rio Preto	SP	17	3221-2201	Aleardo Manacero Jr.	aleardo@ibilce.unesp.br	17	3221-2201	obiunesp	aleardo	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
262	-459576	Colégio SETA - Ensino Fundamental	AV. Francisco Chagas de Oliveira, 791	chácara municipal		15090-190	São José do Rio Preto	SP	17	227-4555	Carlos Eduardo Sanches Guidastre	carlosedu@setanet.com.br	17	2136-4555	pt765rx	colegioseta	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
321	-100407	FACULDADES NETWORK	AV. AMPÉLIO GAZZETA, 2445	LOPES IGLESIAS		13460000	NOVA ODESSA	SP	19	34662527	TANIA CRISTINA BASSANI CECILIO	diretoriageral@nwk.edu.br	19	34662527	worknnet	network	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
327	-255027	EMEF ADONIRAN BARBOSA	RUA DOS GERANIOS			13273340	VALINHOS	SP	019	38691155	ROBERTO VINICIUS VOLPE	robvinicius@ig.com.br	019	38691155	140672	robertoviniciusvolpe	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
407	-334789	Colégio Motivo	Rua padre Carapuceiro,590 - Boa Viagem			51020-280	recife	PE	81	3325-0418	wellington silva de jesus	wellington.silva@colegiomotivo.com.br	81	88613179	0211jesus	wellnet5	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
190	-445514	Colegio Nossa Senhora das Neves	Rua Antonio Martins de Mello, 159	Bairro: Centro		84900-000	Ibaiti	PR	43	3546-1097	Edilberto de Freitas	edilberto@portalpositivo.com.br	43	3546-1097	ma3105	edilberto	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
125	-721643	Colégio Cenecista Capitão Lemos Cunha	Estrada do Galeão S/N	Ilha do Governador		21941000	Rio de Janeiro	RJ	21	33932003	RENATO DOS SANTOS DA COSTA	renatodacosta@osite.com.br	21	33932003	090187	renatodacosta	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
186	-412514	Colégio Estadual  Polivalente  de Orizona	Av. 07 de Setembro-71	Bairro Campo Formoso		75280000	Orizona	GO	064	4741771	Amália de Cássia Leite	cassinhabatan@yahoo.com.br	064	4741771	mabeve	cassinha	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
198	-697369	CEFET-CE	Av. 13 de Maio  2081	Benfica		60430-531	Fortaleza	CE	85	32883607	Itamar de Souza Lima	itamarsl@fortalnet.com.br	85	99458201	5361got	itamarsl	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
408	-103511	Colégio Gaspar Silveira Martins	Rua Conde D`Eu, 1322	Centro		95800000	Venâncio Aires	RS	051	37411575	Ivete Schwingel	gaspar@viavale.com.br	051	37411575	150402	Colégio Gaspar	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
280	-1792	Colégio San Conrado	Rua João Leone,155			13105530	Campinas	SP	019	32584710	Fernando Lorenzo Pascoal	sanconrado@uol.com.br	019	32584710	csc155	Fernando	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
333	-880991	Colégio Sinodal Ruy Barbosa	Rua Rui Barbosa, 295	Bairro Sumaré		89160000	Rio do Sul	SC	47	5212155	Andrea Carla Krieck dos Santos Roussenq	deia@cerb.com.br	47	5212155	ce05de	deia	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
331	-20496	SOC. EDUC. TRISTÃO DE ATHAIDE - BAURU	RUA XINGU, 13-70			17011-040	BAURU	SP	14	2106-7000	PATRICIA  MATTIOLI	PATRICIA@MATTIOLI.ENG.BR	14	9701-3262	970132	setabauru	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
202	-423794	Escola Municipal Durival Britto e Silva	Emilio Bertolini, 44			82920030	Curitiba	PR	041	3662989	Maria do Carmo Fontoura	ducarmo29@yahoo.com.br	041	84152731	999692	ducarmo29	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
215	-426178	Colégio Visconde de Porto Seguro - Unidade I	Rua Floriano Peixoto dos Santos, 55	Morumbi		05658080	São Paulo	SP	11	37493250	Luciene Cruz	lucienec@portoseguro.org.br	11	37493250	ctamorumbi	cvpsmorumbi	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
211	-971587	Colégio Batista "Daniel de La Touche"	Av. João Pessoa, 214-B - João Paulo			65040-000	São Luis	MA	98	3423-1411	Herbeth Ribeiro Viana	herbethviana@hotmail.com	98	3423-1411	batista05	herbeth	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
377	605003	COLEGIO NOVA CACHOEIRINHA	RUA DOS PATIS 141	VILA NOVA CACHOEIRINHA		02613000	SAO PAULO	SP	011	39844650	FLAVIA MARIA GALINDO DE JESUS	mariamatilde@superig.com.br	011	39847374	tiatina	MARIA MATILDE CERRON	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
402	159917	EM Maria Baptistina D.T. Lott	Rua Ponta Porã, 479 - Vista Alegre 			21230690	Rio de Janeiro	RJ	21	33910383	MARIA HELENA DE FIGUEIREDO MENDES	emlott@pcrj.rj.gov.br	21	33715653	051408	ANA	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
217	177919	Colégio Objetivo Taquarituba	Av. Silvano de Paula Bueno nº 423			18740000	Taquarituba	SP	014	37621119	Odair José de Oliveira	odairoliva@hotmail.com	014	37623221	isadora	odairoliva	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
224	327630	Escola Estadual "José Penna"	Rua 24 de dezembro 559			18740000	Taquarituba	SP	014	37621105	Odair José de Oliveira	odairoliva@hotmail.com	014	37623221	joaolucas	josepenna	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
241	-275104	Escola Técnica Estadual Dr. Adail Nunes da Silva	Rua Francisco Valzacchi, 51 	Bairro Vila Rosa		15900-000	Taquaritinga	SP	016	3252-5615	Rosana Cristina Colombo	roancolombo@yahoo.com.br	016	3253-2471	roan25	roancolombo	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
201	-611784	fanor	av santos dumont, 7800	dunas		60270190	fortaleza	CE	85	3249.4848	jose maximiano arruda ximenes de lima	maximiano.lima@fanor.com.br	85	3249.4848	m4a0x40	maximiano	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
205	-5157	E.E. Helen Keller	Rua Mário Olivero Nº 122			17800-000	Adamantina	SP	018	35212492	Maria Aparecida Martins Vasconcelos	apmhelenkeller@uol.com.br	018	32512492	030806	030806	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
99	-343030	Colégio Santo Agostinho	Rua Marte, 435			32241-250	Contagem	MG	31	33968529	Fábio Augustus de Almeida	fabio@santoagostinho.com.br	31	33968529	detec2005	Sto Ago Contagem	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
207	-386383	Sistema ELITE de Ensino -- Rio de Janeiro	Rua Domingos Lopes, 614	Madureira		21310-120	Rio de Janeiro	RJ	21	24521633	Fábio Dias Moreira	fabio@dias.moreira.nom.br	21	22888636	kSLyzgrd	fmoreira	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
392	-209812	Colégio Casimiro de Abreu	Avenida Paraíso, 218 - Jardim Paraíso			12235-460	São José dos Campos	SP	12	39372450	Rodrigo Monteiro de Oliveira	rodrigo-cruzeiro@bol.com.br	12	97187748	suporte	ccadombosco	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
218	-481568	Colégio Sinodal Progresso	Fernando Ferrari, nº 1304			95780000	Montenegro	RS	51	6322318	Elisabeth Marx Bellina	csp.info@terra.com.br	51	6322318	luares	Elisabeth	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
305	-214489	Colégio Cruzeiro do Sul	Rua José Aldo Piassi, 362			08011-300	São Paulo	SP	11	6297-9988	Roberto Luiz Garcia Vichinsky	informatica@cruzeiro.g12.br	11	6956-9994	boneca	vichinsky	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
236	-919743	CENTRO EDUCACIONAL SÃO VICENTE DE PAULO S/C LTDA	RUA SABINO ROBERTO Nº 3098 - CENTRO			62930-000	LIMOEIRO DO NORTE	CE	88	34231318	ACÁCIO LIMA DE FREITAS	acacio@secrel.com.br	88	34231318	OBI145	CESVP	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
240	-318447	EE PROF ADAHIR GUIMARAES FOGAÇA	RUA AURIFLAMA , 3001	BAIRRO ELDORADO		15043330	SÃO JOSÉ DO RIO PRETO	SP	17	2362811	ANTONIO FRANCISCO PORTO SOBRINHO	antoniofporto@uol.com.br	17	32198208	lilidara	antonio65	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
347	-10117	Organização Educacional Evolutivo	Rua Gal. Sampaio, 1742, Centro			60020030	Fortaleza	CE	085	40088209	Emanuel Augusto de Souza Carneiro	emanuelc@baydenet.com.br	085	40088209	coordger	emanuel	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
294	-197518	EE Prof. Antonio Matarazzo	Rua Noruega, 2165 - Jardim Europa			13.455-186	Santa Bárbara d'Oeste	SP	19	3458-4317	Regina Célia Moreira Guimarães	e017292a@see.sp.gov.br	19	3458-4317	290798	Guimarães	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
403	-568019	Colégio da Polícia Militar	R. Bento Quirino,467			03534-010	São Paulo	SP	011	6651-9764	Patricia Mendes Fidilmaque	coordenacaotalarico5-8ef@colegiopm.com.br	011	6651-1317	fregonese	ivone	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
274	-903661	Universidade Federal do Rio de Janeiro - DCC UFRJ	Departamento de Ciência da Computação	Universidade Federal do Rio de Janeiro	Ilha do Fundão, Caixa Postal 68530	21941-590	Rio de Janeiro	RJ	21	2598-3393	Tiago da Conceição Mota	tiagomt@gmail.com	21	2598-3393	dccufrj	demasi	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
239	-943033	Escola Técnica Santo Inácio	Av. Padre Leopoldo Brentano, 700	Bairro Humaitá 		90250-590	Porto Alegre	RS	51	3374-2858 	Eduardo Isaia Filho	isaia@inf.ufrgs.br	51	99441270	petzel	isaia	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
248	-691908	Colégio César Lattes 	Rua Pedro Antonio de Arruda, 420 	Jd. Murilo		13847-014	Mogi Guaçu	SP	19	3861-2412	Ana Cláudia Rocha Sani	anaclaudia.ccl@terra.com.br	19	3861-2412	ana369	lattes	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
260	-526702	Colégio Princípio das Artes	Rua 	Márcio Beck Machado 	109A	08490-495	São Paulo	SP	011	6282-0107	João Alexandre Ramos	ja_ramos@ig.com.br	011	6282-9966	escola	Bone 	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
390	-735382	COLEGIO EDUCATOR	AV. JOAO PESSOA N. 437 CUTIM ANIL			65040400	SAO LUIS	MA	98	32433355	THIAGO LUIS FRIAS DA SILVA	informatica@educator.com.br	98	81167748	infoedu	educator	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
298	-90882	EE Profª Maria Paula Ramalho Paes	Rua Francisco Antonio Correa - 381	Parque da Torre		18170-000	Piedade	SP	15	32443099	Maria Inez de Oliveira Dias	miod@itelefonica.com.br	15	32443708	domingo	Marisa Peres Moreno	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
271	-871567	ETERJ - ESCOLA TÉCNICA DO RIO DE JANEIRO	Av. Santa Cruz 9.591 Santissimo			23010000	Rio de Janeiro	RJ	021	24040330	Wellington Eloy Ramalho da Silva	weloy@click21.com.br	021	97556232	eterj22	eterj	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
396	-1484	Colégio São José	Avenida Mauá, 980	Bairro São José		93110220	São Leopoldo	RS	51	5921575	Rodrigo Luís de Oliveira	informatica@saojose-sl.com.br	51	81546539	lorena	bethy	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
322	-108059	EE Jardim Imperial	Rua Jaçanã 155			15800000	Catanduva	SP	17	3525 0483	Osmar Ferreira	osmar@alecrim.com	17	3525 0483	102030	osmarf	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
585	0	C. E Pedro Álvares Cabral	R. Barão de Jaguaribe, 362/304			22421000	Rio de Janeiro	RJ	21	22562936	Ananda Machado	machado.ananda@gmail.com	21	22947866	clarice	machadoananda	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
590	0	JOSE HUGO MARIA RODRIGUES	MARQUES DE HERVAL			79015-000	CAMPO GRANDE	MS	67	3355-0936	LETÍCIA MONTEIRO ROCHA	natasha_let@hotmail.com	67	99467947	123789	LETICIANATASHA	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
550	540291	EE PROFESSORA OLGA CHAKUR FARAH	Avenida Antonio Paulino de Miranda,101	Centro		08970-000	Salesópolis	SP	011	46961865	Silvana de Fátima Nascimento	silvananascimento77@hotmail.com	011	46961865	olgafarah	olgafarah	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
549	631438	CENTRO DE EDUCAÇÃO BÁSICA  SESI  RAUL GIUBERTI	ROD. DO CAFÉ, KM 02 , SÃO SILVANO			29705-200	COLATINA	ES	27	3721-3788	CRISTIANO FOLETTO	www.crisfol@ig.com.br	27	3721-3788	FOLETTO	CRISFOL	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	f	\N	\N	\N	\N
566	-69638	E.E. "Profª Leny Barros da Silva"	Rua Olimpio de Melo,900-Parque das Acá-	cias- 		19813-105	Assis	SP	18	33249440	Rosane Aparecida Rabelo Ramalho	leny@femanet.com.br	18	33236030	rosade	lenyinformatica	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
588	-376692	Colegio Anglo Claretiano - Rio Claro	Av. Santo Antonio Maria Claret, 1724	Cidade Claret		13503-250	Rio Claro	SP	19	2111 6000	Maria Luiza Altarugio Barbanera	luizabarbanera@claretianas.com.br	19	3527 0669	bern.wow	sedefase2	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
379	-627287	Centro Federal de Educação Tecnológica de Ouro Preto	Rua Pandiá Calógeras	Número 898 	Bairro Bauxita	35400-000	Ouro Preto	MG	31	3559-2193	Cristiano Lúcio Cardoso Rodrigues	cristianolcrodrigues@yahoo.com.br	31	3559-2193	cubulo10	cristianolcr	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
367	-918271	Colégio Ari de Sá Cavalcante	Av. Washington Soares, 3737			60830641	Fortaleza	CE	85	34772000	Fabrício	fabricio@aridesa.com.br	85	34772000	dianapires	fabriciopires	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
465	-950168	COLEGIO INTEGRADO GLOBAL	RUA APINAGES, 1231, SUMARE			01254010	SAO PAULO	SP	11	36733577	CESAR AUGUSTO CARNEIRO BETIOLI	cbetioli@uol.com.br	11	36733577	globalg2	coordg2	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
527	-839309	Colégio Antares	Rua Ocelo Pinheiro, 101			60175565	Fortaleza	CE	85	34523990	Alexandre Queiroz de Mattos Brito	alexandreats@gmail.com	85	34523990	ats2006	Alex_ats	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
300	-766902	Centro Federal de Educação tecnológica de Minas Gerais	AV Amazonas, 5253 ( Sala 325 )	Bairro : Nova Suiça 		30480000	Belo Horizonte	MG	031	33195136	Márcia Gorett Ribeiro Grossi	marciagrossi@terra.com.br	031	33195136	augusta05	marciagrossi	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
264	-535076	Colégio Diocesano de Garanhuns	Praça Monsenhor Adelmar da Mota Valença	53		55295090	Garanhuns	PE	087	37611505	Claudenor Ferreira de Lima	lima@bravil.com.br	087	91034990	lima2005	lima	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
249	-810375	E.E"Dona Elvira Santos de Oliveira"	Praça Moji-Miirm, sem número			13970-000	Itapira	SP	19	3863-0121	Isabel Cristina Durante	bel.durante@bol.com.br	19	3863-0121	eso2005	Bel	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
339	-290780	Colégio Pedro Souza	Rua Pedro Souza, Lt 17, Qd G - Pilar			25233-280	Duque de Caxias	RJ	21	2776-3374	Luciano Berto	rothayce@ig.com.br	21	2776-3374	vvvvvv	Luciano Berto	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
261	-117373	Centro Federal de Educação Tecnológica de Goiás Uned Jataí	Rua Riachuelo, 2090	Bairro Samuel Graham		75800-000	Jataí	GO	64	631-2541	Gustavo de Assis Costa	gassis@cefetgo.br	64	636-7963	blaster75	gassis	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
279	-904363	Colégio Nossa Senhora de Nazaré	Pc. Madre Tereza Grillo Michel,176 	Centro		36400-000	Conselheiro Lafaiete	MG	031	763 -1919	Gean Cláudio Costa	geanster@gmail.com	031	88836-7360	n@zare	gean	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
272	-65376	Instituto Profissional Maria Auxiliadora	Rua Joaquim Nabuco , 237 Graças			52011000	Recife	PE	81	3222-4097	Rosemayre Bezerra Dantas	coordenainfo1@colegioauxiliadora.com.br	81	99795542	paula1	rosemayre	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
268	-141124	EMEF Edson Luís Lima Souto	Av. Dr. Armando Antônio D'Ottaviano, 12	Bairro San Martin		13110540	Campinas	SP	19	32812696	Adriana Correa Almeida	profa_adriana_correa@yahoo.com.br	19	32549450	280573	radrica	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
395	-462140	Escola Agrotécnica Federal de Muzambinho	Zona Rural	Morro Barro Preto		37810000	Muzambinho	MG	35	3571-1529	Paulo César dos Santos	paulo@eafmuz.gov.br	35	3551-3916	123456	eafmuz	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
39	-585415	Escola Alternativa	Rua Marechal Floriano Peixoto, 98	Eldorado		57306-010	Arapiraca	AL	82	530-4250	Valdineide Menezes Vitória	analista_al@ibest.com.br	82	530-4250	val140600	valdineide	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
167	-375123	Colégio Politécnico de Sorocaba-Jornal Cruzeiro do Sul-FUA	Rua Barão de Cotegipe nº 400	Vila Leão		18040.420	Sorocaba	SP	15	21017400	Angela dos Santos Oshiro	colegio@poli-sorocaba.org.br	15	21017400	040301	Ivonete	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
136	-210645	Centro Tecnológico Universidade de Caxias do Sul - CETEC/UCS	Rua Francisco Getúlio Vargas, 1130	Bloco C	Cidade Universitária	95070-560	Caxias do Sul	RS	054	2182278	Cristiano Felippetti	cpfelipp@ucs.br	054	2182278	cetec@ucs	cetec	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
170	-254600	Educandário Santa Rita de Cássia	Rua Márabu 223, Vila Sabrina 			02138-040	São Paulo	SP	11	69496686	Nivaldo Neves Oliveira Junior	junior@nivaldo-junior.pro.br	11	69496686	juka2005	Professorjunior	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
277	-383718	Diva Figueiredo da Silveira	Av: Siqueira Campos			1970000000	Paraguaçu Paulista	SP	018	33614050	Manuel Antonio	gilson.lucio@uol.com.br	018	33615172	040790	toretto	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
283	-944534	UNICAMP - Colégio Técnico de Campinas	R Culto à Ciência 177	Bairro Botafogo		13020060	Campinas	SP	19	37758600	André Luís dos Reis Gomes de Carvalho	andre@unicamp.br	19	32435369	32435369	andrelrgc	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
253	-605352	ESCOLA MUNICIPAL 01.21.002 PEDRO BRUNO	RUA PADRE JUVENAL, 74	ILHA DE PAQUETÁ		20397070	RIO DE JANEIRO	RJ	021	33970275	JOSÉ ROBERTO SOUZA SILVA	jrssilva@brfree.com.br	021	87021151	0121002	empbruno	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
288	-361299	Instituto de Educação Ivoti	Rua Pastor Ernesto SChliper, 200	Bairro Sete de Setembro		93900-000	Ivoti	RS	51	5631318	Fabian Viégas	fabianv@terra.com.br	51	91925825	12qwaszx	fabianv	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
5	-760682	Centro Universitário do Planalto de Araxá - Uniaraxá	Av. Amazonas, número 777	Bairro São Geraldo		38180084	Araxá	MG	034	36616120	Jorge Luis Takahashi Hattori	paulatn2002@yahoo.com.br	034	36616120	proto2jvc	paulatn	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
306	-433689	URI - Universidade Regional Integrada - Campus de Erechim	Av. Sete de Setembro, 1621	Centro		99700000	Erechim	RS	54	520-9000	Neilor Avelino Tonin	nat@uri.com.br	54	99990230	ifw6673	neilor	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
259	-491727	Centro Interescolar Objetivo Unidade XXVII	R. Magada Perona Frossard, 571, Jardim 	Nova Aliança		14026596	Ribeirão Preto	SP	16	6217700	Claudiane Alves Pereira	objetivoribeirao@yahoo.com.br	16	6217700	clauribeir	objetivoribeirao	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
153	-786478	Colégio I. L. Peretz	Rua Madre Cabrini, 175 - Vila Mariana			04020000	São Paulo	SP	11	55740131	Cleide Maria dos Santos Muñoz	cleide@peretz.com.br	11	55740131	cacas04	checrc	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
143	-743630	EE Coronel Francisco Schmidt	Rua Cyro Maia nº 2245			15370000	Pereira Barreto	SP	18	3704 4355	Márcia Gomes da Silva	marciapbto@yahoo.com.br	18	3704 4355	241061	Marcia	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
286	-21935	Colégio Técnico Industrial de Guaratinguetá - Unesp	Av. Ariberto Pereira da Cunha, 333	Pedregulho		125000-000	Guaratinguetá	SP	012	3123-2825	Cristóvão José Dias da Cunha	cristov@feg.unesp.br	012	9777-8648	26021982	cristov	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
290	-999458	Instituto MairiporãThomaz Cruz	Av. Dr. Thomaz Rodrigues da Cruz, 1113	Bairro Barreiro		07600-000	Mairiporã	SP	11	4604-2999	Ivete Pincelli(coordenadora pedagógica)	secretaria_im@yahoo.com.br	11	4604-2999	tulipa	instituto	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
303	-849834	Instituto de Tecnologia ORT	Rua Dona Mariana, 213 - Botafogo			22280-020	Rio de Janeiro	RJ	21	2539-1842	Daniel Fleischman	fernandopinheiro@clubedohardware.com.br	21	9761-8193	frinkaedro	fppinheiro	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
269	-606928	Universidade Federal da Bahia	Av. Adhemar de Barros, s/n	Campus de Ondina - UFBA	Departamente de Ciência da Computação	40170-110	Salvador	BA	71	3263-6143	Aline Maria Santos Andrade	aline@ufba.br	71	3263-6143	*sorte*	aline	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
312	-108033	Escola Estadual Dr. Benedito Leite Ribeiro	Caixa Postal 140			37800000	Guaxupé	MG	35	3551-1257	Thaise Ferreira	thaisecorporium@yahoo.com.br	35	3551-1257	suflair	estadual	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
326	-132669	E.E. PROFª Maria Santana de Almeida	Rua Presidente Humberto de Alencar 	Castelo Branco Nº 283      Centro		11910-000	Sete Barras	SP	13	3872-1217 	Odair Carlos	softwareeng2003@yahoo.com.br	13	3872-1703	1234567	odasantana	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
307	-847010	UNISAL - Centro Universitário Salesiano de São Paulo	Av. Almeida Garret, 267	Jd. N. Sra. Auxiliadora		13087-290	Campinas	SP	19	37443128	Marco Antonio Garcia de Carvalho	mcarvalho@unisal.com.br	19	32138167	unp22mar	mcarvalho	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
291	-894459	CENTRO EDUCACIONAL SANTA MARTA	R. MADAME SCHIMIDT, 90			37470-000	SÃO LOURENÇO	MG	035	3332-3355	WANDERSON GOMES DE SOUZA	si@santamarta.br	035	9198-2964	123098	Wanderson	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
316	-864142	E.E. Prof. Dr. Domingos João Baptista Spinelli	R: Deputado Orlando Jurca  , nº 92			14.070-280	Ribeirão Preto	SP	016	3974-1200	Pedro Martins Concórdia	e_mailpedro@yahoo.com.br	017	97038222	101010	profpedro	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
334	-134599	E. E. F. M. Luiz de Gonzaga Fonseca Mota	AV. Gal. Alípio dos Santos,1360. Centro			62540-000	Amontada	CE	88	36361419	Francisco Cadorno Vasconcelos Teles	cadornot@bol.com.br	88	36361419	220476	spetro	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
341	-286521	EMEF "VIRGÍNIA MENDES ANTUNES DE VASCONCELLOS"	RUA ARMANDO DOS SANTOS, Nº 255 JD Maria 	Rosa		13052410	Campinas	SP	19	32258397	Rosana Maria Pasinato Tinel	virginiavasconcellos@globo.com	19	32258397	virginia	rptinel	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
318	-935038	Escola Monteiro Lobato	Av. São João nº 2500	Jd. Esplanada II		12242-100	São José dos Campos	SP	12	39289700	Rosane Maria Gama Ramos	rosane@monteirolobato-sjc.com.br	12	39289700	ro1970	rosane	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
314	-284618	Centro Escolar Objetivo - São José dos Campos	Av Dr Nélson D`Ávila, 1757			12.245-030	São José dos Campos	SP	12	39211877	Luiz Fernando Ribeiro dos Santos	fernando@objetivo-sjc.com.br	12	39211877	180955	dirtcrusty	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
319	-618824	CEFET - SP	Pedro Vicente, 625	Canindé		01109-010	São Paulo	SP	11	3328-0500	Claudia Miyuki Werhmuller	claudiay@cefetsp.br	11	33280525	cefetsp	cefetsp	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
101	-946882	Instituto Marcos Freitas	Rua José de Alvarenga, 713 - Centro			25020-140	Duque de Caxias	RJ	21	2671-2048	Fabio Costa	fabiocosta@ee.g12.br	21	2671-2048	ez2308	fabiocosta	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
313	-314845	Escola Estadual Dr. André Cortez Granero	Caixa Postal 140			37800000	Guaxupé	MG	35	3551-5554	Rosana Oliveira Ferreira Sousa	rosanynha@yahoo.com.br	35	3551-5554	1973aa	polivalente	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
342	-252705	EE PROFA REGINA VALARINI VIEIRA	RUA ROBERTO CLARK, 357	CENTRO - 		16200-043	BIRIGUI	SP	18	3642-3576	CLEUSA ALVES BONIFACIO	e030272a@see.sp.gov.br	18	3642-3576	pascal	cleusinha	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
197	-875728	ESFA - Escola São Francisco de Assis	Av. Castelo Branco, s/n	Vila Landinha		29800-000	Barra de São Francisco 	ES	27	3756-2677	Adalberto Bentes de Menezes Filho	betobentes@yahoo.com.br	27	3756-2677	pitagoras	beto.bentes	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
65	-115853	Centro Educacional Batista 	Conjunto Nova Marambaia Passagem J-1 40	COHAB		66623 000	Belém	PA	91	2382136	Luiz Otavio da Conceição Araujo	txtvkm@ig.com.br	91	2382136	yyamada	otavio	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
293	-907998	Colégio Nossa Senhora Consolata	Avenida Imirim, 1424 - Imirim			02464-200	São Paulo	SP	11	6256-6688	Vera Lucia Merlini	velumes@uol.com.br	11	6256-6688	vl010900	Vera Merlini	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
340	-455052	Colégio Marista de Colatina	Av. Champagnat, 225 - Bairro Marista			29.707-100	Colatina	ES	27	3722 1633	Alícia Bahia de Andrade	abahia@ubee-marista.com.br	27	3722 1633	alicia	alicia	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
345	-565036	Escola Municipal Maria das Graças Teixeira Braga	Rua São Judas Tadeu, 271 - São Benedito			33125270	Santa Luzia	MG	31	36377544	Josué Geraldo Botura do Carmo	josue.carmo@terra.com.br	31	36498229	emmgtb	mgtb	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
258	-321097	Colégio Renovatus	Rua 24 de maio, 731	Vila Industrial		13035370	Campinas	SP	19	32728699	Regina Maria da Silveira Cardoso	reginamscardoso@uol.com.br	19	32728699	imaginacao	inforenovatus	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
350	-797957	Escola Municipal Nossa Senhora dos Prazeres	Rua São Salvador, 180 - Jardim Jordão			54320240	Jaboatão dos Guararapes	PE	81	34625114	Ana Larissa Bezerra de Lima	alarissabl@ig.com.br	81	99552582	caramel@	alarissa	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
287	-63838	Escola Municipal de Ensino Fundamental João César	Distrito de Muquém			58397000	Areia	PB	083	3362-1300	Radamés Alves Rocha da Silva	rad_rocha@hotmail.com	083	3362-1300	221252	radamesrocha	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
311	-403945	Universidade Federal Fluminense	Rua Passo da Pátria, 156	Bloco E - Sala 315	Coordenação da Ciência da Computação	24210-240	Niterói	RJ	21	2629-5668	Dante Corbucci Filho	dante@dcc.ic.uff.br	21	2629-5668	DCFDCF	UFF	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
328	-7828	E.E. Prof Carlos Correa Vianna	R. Padre Moisés de Miranda 222	Centro		17190000	Reginópolis	SP	14	35891101	Cristiano Natal Toneis	cristoneis@hotmail.com	14	97159591	295074	cristoneis	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
337	-36414	Escola Municipal Tio Ângelo	Bairro Rural Lage			37990-000	Ibiraci	MG	35	3544-2266	Kênya Vitoriano da Silva Norinho	prefeibiraci@netsite.com.br	35	3544-1439	norinho	Kênya Vitoriano	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
366	-134631	Depto de Computação - Universidade de Brasília	Campus Universitário - Asa Norte	Caixa Postal 4466		70.910-090	Brasília	DF	61	3072702	Cláudia Nalon	nalon@unb.br	61	3072703	obicon	cnalon	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
276	-448847	E.E. João Ometto	Rua: Zaira Pagiaro  ,255	Bairro :João Ometto		13495-000	Iracemápolis	SP	19	34561686	Valdecir Aparecido C.C.Macedo	vamat@hotmail.com	19	34561686	jajapa	Wandaimme	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
356	-103265	Centro Federal de Educação Tecnológica do Paraná	Av. Monteiro Lobato Km 04			89000-000	Ponta Grossa	PR	042	2204800	Daniel Fernando Anderle	daniel@pg.cefetpr.br	042	2204800	smba8010	daniel	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
343	-484844	Escola Municipal Maurício Germer	Rua Saudades, 555			89120000	Timbó	SC	47	382-1632	Suzete Keiner Marcarini	mmgermer@terra.com.br	47	382-4745	brunalu	marcarini	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
329	-902890	E. E. Prof. Dr. João Chiarini	Rua Jordão Martins, 280 Vila Fátima			13412082	Piracicaba	SP	019	34219211	Fabiano Luíz Destro	destro18@bol.com.br	014	36412527	142536	killer	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
308	-624430	ETE JACINTO FERREIRA DE SÁ	AV. ANTONIO DE ALMEIDA LEITE, 913			19907000	OURINHOS	SP	014	33224908	HERMÍNIA RITA ROSALEM	rita_eteourinhos@yahoo.com.br	014	33247572	tatu2004	RITA ROSALEM	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
336	-855843	Faculdade Ruy Barbosa	Rua Theodomiro Batista, 422, 	Bairro - Rio Vermelho		41940-210	Salvador	BA	71	32051700	Maria Luiza de Carvalho Braga	luiza@ufba.br	71	9984-4026	brrorrri	luizabraga	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
363	-947151	Instituto Militar de Engenharia	Praça General Tibúrcio 80			20735060	Rio de Janeiro	RJ	21	25467012	André Luis Ribeiro de Medeiros	medeiros@ime.eb.br	21	96093284	louco22	medeiros	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
119	-70374	EEIEF. Colégio Dinâmico Balão Azul S/C LTDA	Bernardino de Campos, 8-81, V. Souto			17050040	Bauru	SP	014	32238181	João Pereira de Andrade Neto	netto_jp@yahoo.com.br	014	32238181	05202933	Netto	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
374	-379838	ALBERTO ALVES ROLLO	RUA CAP. ALBERTO MENDES JR  sem número			14820000	AMÉRICO BRASILIENSE	SP	16	33922971	ROSANA CLAUDIA RODRIGUES	e907704a@see.sp.gov.br	16	33922971	ros2908	rosana	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
354	-129971	EE. Prof. Augusto da Silva César	Rua: Expedicionários do Brasil,277	Bairro São José		14800230	Araraquara	SP	16	33224918	Angela Maria Araujo	e021957a@see.sp.gov.br	16	33356130	333561	Araujo	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
355	-910982	EE Dr Epaminondas Ferreira Lobo	Rua Major Salvador Rufino,59			18460-000	Itararé	SP	15	35324736	Márcio Antunes de Lima	profmarcio.l@ig.com.br	15	35325382	rafaela	profmarcio.l	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
353	-792264	E.E.Cesarino Borba	Rua José Ometto , 440       Centro			13495-000	Iracemápolis	SP	19	3456-1172	Marcelo Bassan  Barboza	cesarino@widesoft.com.br	19	3456-2302	bassan	Marcelo	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
352	-597930	ROFESSOR ULISSES DE OLIVEIRA VALENTE	Rua Prudente de Moraes,222			1345000	Santa Bárbara d´Oeste	SP	019	34637317	Rosana Rosolen	rrosolen@fundacaoromi.org.br	019	34637317	250355	rrosolen	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
383	-350820	EMEF Padre Francisco Silva	Av Ibirapuera, s/nº - Jardim Londres			13061280	Campinas	SP	19	3269-6092	Antonio Roberto Barbutti	padresilva@ig.com.br	19	3269-6092	210765	Barbutti	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
358	-282286	Colégio Anjos Custódios	Praça Madre Rafaela Ybarra, nº 418	Bairro Centro	Caixa Postal: 137	86990-000	Marialva	PR	44	3232-1408	Luiz Otávio Sgarioni Nacamura	nacamura@colegioanjoscustodios.com.br	44	3232-1408	ro0tcac	anjoscustodios	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
357	-333003	Colégio Ser Universitário de Jundiaí	Av. Navarro de Andrade, 500			13200	Jundiaí	SP	11	45826821	José Roberto Cunha Jr.	jrob@educacional.com.br	11	45817199	qwerty	prof_jrob	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
381	-803048	Sociedade Educacional Comecinho de Vida	Rua Rodrigo Alves de Abrel Rangel 	96	Piquete	24900000	Maricá	RJ	21	26372715	Davi Marcos Pereira Braga	davimarcos@bol.com.br	21	37310327	davi123	colegiohms	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
160	-989753	Colégio Nova Cachoeirinha	Rua dos Patis, 141			02613-000	São Paulo	SP	11	3851-9827	Flavia G. de Jesus	colegionc@superig.com.br	11	3851-9827	jesus1	Flavia	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
173	-542594	E.E. Profª "Olívia Bianco"	rua professorJosé Martins de Toledo, 	nº394, 	bairro Jaraguá.	13403-032	Piracicaba	SP	019	34227235	Marinilza Rossetto Bello	oliviab@terra.com.br	019	34227235	06rvsf	oliviab	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
117	-651514	FUNDAÇÃO NOKIA DE ENSINO	RUA MINISTRO JOAO GONÇALVES, S/N			69075830	MANAUS	AM	092	2376972	MARIA EVANI DE OLIVEIRA ASSIS PATRICIO	epatricio@fnet.org.br	092	2376972	140255	fnet	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
159	-351116	COLÉGIO AUGUSTO LARANJA	RUA CHANÉS, 205			04087-031	SÃO PAULO	SP	11	5542-4433	JÂNIA DO VALLE	jania@augustolaranja.com.br	11	5542-4433	isabela	jania	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
360	-747718	Centro Federal de Educação Tecnológica do Espírito Santo	Av. Vitória, n.º 1729	Jucutuquara		29.040-780	Vitória	ES	27	3331-2201	Helaine Barroso dos Reis	helaine@cefetes.br	27	9939-3164	edilia123	edilia	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
393	-566853	Centro Educacional SESI	Rua Presidente Roosevelt, 530 - Centro			13480-060	Limeira	SP	19	34953587	Helba Alexandra Hermini	hhermini@yahoo.com.br	19	34953587	sesi149	sesi149	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
409	-326225	Escola Técnica Estadual Visconde de Mauá 	Rua João Vicente, 1775 	Bairro: Marechal Hermes	-	21610-210	Rio de Janeiro	RJ	21	2489-7710	Sergio Brauna da Silva	sergiobrauna@yahoo.com	21	8132-0148	lbxobi	brauna	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
372	-785402	Unesp - Bauru	Av. Luis Edmundo Carrijo Coube, s/n			17033-360	Bauru	SP	14	3103-6079	Andréa Carla Gonçalves Vianna	vianna@fc.unesp.br	14	3281-6633	calula	vianna	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
361	-553250	SOCIESC - UNIDADE DE SÃO BENTO DO SUL	Hans Dieter Schmidt	n. 879, bairro Centenário		89290000	São Bento do Sul	SC	47	6262222	Juliano Prim	julianoprim@creativenet.com.br	47	99960988	031078	juliano	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
399	-772737	EE Prefeito Antonio da Costa Santos	Rua Guerino Dinega, 40 - Jd. Planalto de	Viracopos 		13056-017	Campinas 	SP	19	3225-9944	Joaquim Machado Filho	eeprefacsantos@yahoo.com.br	19	3225-9944	32259944	joaquim	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
404	-14646	EE Monsenhor Sarrion	Rua Marcondes Filho nº 93	Vila Roberto		19013-160	Presidente Prudente	SP	018	2234898	Ana Lourdes Kuhn Lopes Pinheiro	annacalamid@bol.com.br	018	2234898	2231473	sarrion	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
315	-166480	Colégio Objetivo Bragança	Rua Palmiro Orsi, 121   Jd. Europa			12.916-082	Bragança Paulista	SP	11	4034-4444	Gabriela Anselmo Raymundo	profgabi@gmail.com	11	7175-1393	infoarte	Gabriela R	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
376	-258740	Colégio Sant'Anna	Av. Independência, 5656			13280000	Vinhedo	SP	19	3876-3691	Daniela Vicentini	informatica@santanna.g12.br	19	3876-3691	santanna99	santanna	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
126	-757360	UniCeuma -Centro Universitario do Maranhao	Rua Josue Montelo, 01			65075-120	Sao Luis	MA	98	3214-4145	Marcos Barros e Silva	marcos@ceuma.br	98	9972-5689	blogaion	marcosbarros	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
362	-630593	INSTITUTO EDUCACIONAL MATER DEI	Av. 03 - Lote 04 - quadra 15 	Loteamento Jaracaty		65.076-830	SAO LUIS	MA	98	235-2560	Marcos Barros e Silva	marcos@ceuma.br	98	9972-5689	mdei2005	mdei	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
388	-487001	GeoAlpha	Av. Daniel de La Touche, Quadra - D	nº 6 - Loteamento Bela Vista	COHAJAP	6500000000	SAO LUIS	MA	98	2568888	Marcos Barros e Silva	marcos@ceuma.br	98	3214-4145	geo2005	geoalpha	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
98	-5620	Colégio Dom Feliciano	Av. Dr. José Loureiro da silva, n° 655 	 - Centro		94010-001	Gravataí	RS	51	4881400	Christiano Cadoná	chriscad@terra.com.br	51	81213886	chriscad12	chriscaddom	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
63	-128807	Unidade de Ensino São Mateus	Rua Mario Teixeira de Souza,511			94960-410	Cachoeirinha	RS	51	4697347	Christiano Cadoná	chriscad@terra.com.br	51	4697347	chriscad12	chriscad	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
131	-332189	Colégio Estadual Nestor Víctor - Ensino Fundamental e Médio	Avenida Passos, 188			87540-000	Pérola	PR	44	6361172	Maria Totoli Bigoli	totoli@ibest.com.br	44	6361172	010800	Totoli	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
132	-343420	Colégio Est.  Min. Petrônio Portela - Ensino Fund. e Médio	Rua Osório Monteiro, 91			87555-000	São Jorge do Patrocínio	PR	44	6341114	Maria Totoli Bigoli	totoli@ibest.com.br	44	6341114	532207	Bigoli	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
209	-466682	Centro Universitário Uninahnguera	Rua Waldemar Silenci, 340			13614-240	Leme	SP	019	3571-5717	Marcelo Zani	marcelozani@linkway.com.br	019	3571-3430	atc3ejs7	Prof. Marcelo Zani	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
208	-819011	Escola Técnica Dep. "Salim Sedeh"	Rua Neida Zencker Leme, 500			13614-240	Leme	SP	019	3571-4898	Marcelo Zani	marcelozani@linkway.com.br	019	3571-3430	atc3ejs7	Marcelo Zani	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
400	-22754	EMEF MARIO JOAQUIM ESCOBAR DE ANDRADE	ESTRADA DOS PINHEIROS, 193			06449000	BARUERI	SP	011	41940009	HUMBERTO ARAUJO	prattn@estadao.com.br	011	41421618	141169	majo	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
401	-88599	EMEF FRANCISCO ZACARIOTO	RUA IPANEMA, 420			06449000	BARUERI	SP	011	41941334	hUMBERTO ARAUJO	prattn@estadao.com.br	011	41421618	141169	zaca	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
4	-520793	Universidade Anhembi Morumbi	Rua Casa do Ator, 275	1o. andar - Sala dos Professores	Vila Olímpia	04.546-001	São Paulo	SP	11	3847.3159	Calebe de Paula Bianchini	calebe@anhembi.br	11	8304.7573	Bull Dog	calebe	4		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
491	-148602	Colégio Santo Antônio	Rua Francisco Jozolino 241			15820000	Pirangi	SP	17	33862382	Walison Joel Barberá Alves	wbarbera@bol.com.br	17	33862382	ddl4349	wbarbera	5		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
557	-574496	Universidade Federal de São Carlos (UFSCar)	Rod. Washington Luís, Km 235			13565-905	São Carlos	SP	16	3351-8232	José de Oliveira Guimarães	jose@dc.ufscar.br	16	3351-8232	jogmrng	joseoliv	3		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
554	-368221	Luiz Gonzaga Duarte	Rua Ver. José Barreto Alencar, 222 			56280000	Araripina	PE	87	38733352	Armando Arruda Gomes	gomes_arruda@yahoo.com.br	87	38733352	elgd2006	professorarmando	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
567	-294803	Colégio Disneylândia & Instituto SIlva Serpa	Rua José dos Santos Silva, nº 20	Bairro : Centro 		28940000	São Pedro da Aldeia	RJ	22	26212146	Carlos Magno Goiabeira Lobo	cmagnolobo@gmail.com	22	92534073	divalobo	cmagnolobo	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
555	-261864	Colégio Batista Santos Dumont	R. Desembargador Leite Albuquerque, 1056	Aldeota		60000-000	Fortaleza	CE	85	40082300	Paulo José Bonfim Gomes Rodrigues	teorema@gmail.com	85	32481046	p142857	Batista2006	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
552	-169828	Colégio Bom Jesus Santo Antônio	Rua Santo Antônio			89010110	Blumenau	SC	47	21023500	Leirson Hélio Schiestl	leirson@bomjesus.br	47	21023500	bomjesus	bomjesus	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
548	-889226	escola municipal presidente arthur da costa e silva	rua Assunção, 257	Botafogo		22251-040	rio de janeiro	RJ	21	22667909	Marcellus Braga Machado	marcellusmachado@hotmail.com	21	22667909	buana29	marcellus	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
546	-411410	Escola Padre Luiz Gonzaga	Rua 11 de setembro, 163 - Centro			56280000	Araripina	PE	87	38739004	Armando Arruda Gomes	gomes_arruda@yahoo.com.br	87	38739004	eplg2006	profarmando	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
544	-45291	Colégio Companhia no Ensino	Avenida Nove de Julho, 585 - Jd. Zulmira			18060-630	Sorocaba	SP	15	3221-8859 	Angela dos Santos Oshiro	angso@uol.com.br	15	3221-8859 	217560	ciaensino	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
543	-463496	Centro Federal de Educação Tecnológica de Minas Gerais	Av. Amazonas 5253 - Bairro Nova Suissa			30480-000	Belo Horizonte	MG	31	3319-5136	Gilmar Machado Grossi	gilgrosi.bh@terra.com.br	31	3319-5136	123456	gilmar_grossi	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
541	-293830	Colégio Acadêmico de Limeira	Via 147 - Limeira/Piracicaba Km 4			13482-383	Limeira	SP	019	34044720	Frederico Czar Filho	profczar@bol.com.br	019	34044720	512469	profczar	2		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
540	-355529	Escola Magnus Júnior	R. Evaristo da Veiga, 574 - Jd. Magnólia			18044-130	Sorocaba	SP	15	3222 1353	Angela dos Santos Oshiro	angso@uol.com.br	15	3222 1353	217560	angelaoshiro	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
568	-954539	Colégio Santo André	Rubião Júnior, 3609 - Bom Jesus			15014-220	São José do Rio Preto	SP	017	32147121	Elaine Barbosa de Figueiredo	elainebf@rp.csa.org.br	017	96010250	csacsa86	csariopreto	1		\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	\N	\N	f	\N	0	t	\N	\N	\N	\N
\.


--
-- Name: colab_colab_id_seq; Type: SEQUENCE SET; Schema: public; Owner: obi
--

SELECT pg_catalog.setval('public.colab_colab_id_seq', 403, true);


--
-- Name: compet_compet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: obi
--

SELECT pg_catalog.setval('public.compet_compet_id_seq', 16099, true);


--
-- Name: school_school_id_seq; Type: SEQUENCE SET; Schema: public; Owner: obi
--

SELECT pg_catalog.setval('public.school_school_id_seq', 592, true);


--
-- PostgreSQL database dump complete
--

